/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.media.AudioAttributes
 *  android.net.Uri
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import android.app.Notification;
import android.media.AudioAttributes;
import android.net.Uri;

public abstract class v {
    public static Notification.Builder a(Notification.Builder builder, String string) {
        return builder.addPerson(string);
    }

    public static Notification.Builder b(Notification.Builder builder, String string) {
        return builder.setCategory(string);
    }

    public static Notification.Builder c(Notification.Builder builder, int n2) {
        return builder.setColor(n2);
    }

    public static Notification.Builder d(Notification.Builder builder, Notification notification) {
        return builder.setPublicVersion(notification);
    }

    public static Notification.Builder e(Notification.Builder builder, Uri uri, Object object) {
        return builder.setSound(uri, (AudioAttributes)object);
    }

    public static Notification.Builder f(Notification.Builder builder, int n2) {
        return builder.setVisibility(n2);
    }
}

