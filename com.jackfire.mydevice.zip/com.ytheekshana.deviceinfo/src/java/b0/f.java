/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  android.os.Bundle
 *  android.os.Handler
 *  android.util.Log
 *  androidx.appcompat.widget.j
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Field
 */
package b0;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import androidx.appcompat.widget.j;
import b0.g;
import java.lang.reflect.Field;

public final class f
implements Application.ActivityLifecycleCallbacks {
    public Object q;
    public Activity r;
    public final int s;
    public boolean t = false;
    public boolean u = false;
    public boolean v = false;

    public f(Activity activity) {
        this.r = activity;
        this.s = activity.hashCode();
    }

    public final void onActivityCreated(Activity activity, Bundle bundle) {
    }

    public final void onActivityDestroyed(Activity activity) {
        if (this.r == activity) {
            this.r = null;
            this.u = true;
        }
    }

    public final void onActivityPaused(Activity activity) {
        if (this.u && !this.v && !this.t) {
            boolean bl;
            block7 : {
                block6 : {
                    Object object = this.q;
                    Object object2 = g.c.get((Object)activity);
                    if (object2 != object) break block6;
                    int n2 = activity.hashCode();
                    if (n2 != this.s) break block6;
                    try {
                        Object object3 = g.b.get((Object)activity);
                        g.g.postAtFrontOfQueue((Runnable)new j(object3, object2, 4));
                        bl = true;
                        break block7;
                    }
                    catch (Throwable throwable) {
                        Log.e((String)"ActivityRecreator", (String)"Exception while fetching field values", (Throwable)throwable);
                    }
                }
                bl = false;
            }
            if (bl) {
                this.v = true;
                this.q = null;
            }
        }
    }

    public final void onActivityResumed(Activity activity) {
    }

    public final void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public final void onActivityStarted(Activity activity) {
        if (this.r == activity) {
            this.t = true;
        }
    }

    public final void onActivityStopped(Activity activity) {
    }
}

