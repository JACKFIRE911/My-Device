/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Object
 */
package b0;

import b0.q;

public final class p {
    public q a;
    public CharSequence b;
}

