/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.os.Bundle
 *  java.lang.Object
 */
package b0;

import android.app.Notification;
import android.os.Bundle;

public abstract class t {
    public static Notification.Builder a(Notification.Builder builder, Bundle bundle) {
        return builder.setExtras(bundle);
    }
}

