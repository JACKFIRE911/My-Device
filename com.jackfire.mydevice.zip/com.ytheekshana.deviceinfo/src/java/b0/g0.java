/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AppOpsManager
 *  android.app.NotificationManager
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.NoSuchFieldException
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.reflect.Field
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.util.HashSet
 */
package b0;

import android.app.AppOpsManager;
import android.app.NotificationManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import b0.f0;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashSet;

public final class g0 {
    public final Context a;
    public final NotificationManager b;

    public static {
        new HashSet();
    }

    public g0(Context context) {
        this.a = context;
        this.b = (NotificationManager)context.getSystemService("notification");
    }

    public final boolean a() {
        boolean bl;
        if (Build.VERSION.SDK_INT >= 24) {
            return f0.a(this.b);
        }
        Context context = this.a;
        AppOpsManager appOpsManager = (AppOpsManager)context.getSystemService("appops");
        ApplicationInfo applicationInfo = context.getApplicationInfo();
        String string = context.getApplicationContext().getPackageName();
        int n2 = applicationInfo.uid;
        bl = true;
        try {
            Class class_;
            Class class_2 = Class.forName((String)AppOpsManager.class.getName());
            Class[] arrclass = new Class[3];
            arrclass[0] = class_ = Integer.TYPE;
            arrclass[bl] = class_;
            arrclass[2] = String.class;
            Method method = class_2.getMethod("checkOpNoThrow", arrclass);
            int n3 = (Integer)class_2.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class);
            Object[] arrobject = new Object[3];
            arrobject[0] = n3;
            arrobject[bl] = n2;
            arrobject[2] = string;
            int n5 = (Integer)method.invoke((Object)appOpsManager, arrobject);
            if (n5 == 0) {
                return bl;
            }
            bl = false;
        }
        catch (ClassNotFoundException | IllegalAccessException | NoSuchFieldException | NoSuchMethodException | RuntimeException | InvocationTargetException throwable) {}
        return bl;
    }
}

