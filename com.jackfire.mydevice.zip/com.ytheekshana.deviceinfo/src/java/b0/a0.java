/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$BubbleMetadata
 *  android.app.Notification$Builder
 *  android.content.LocusId
 *  androidx.appcompat.widget.o1
 *  java.lang.Object
 */
package b0;

import android.app.Notification;
import android.content.LocusId;
import androidx.appcompat.widget.o1;

public abstract class a0 {
    public static Notification.Builder a(Notification.Builder builder, boolean bl) {
        return o1.f((Notification.Builder)builder, (boolean)bl);
    }

    public static Notification.Builder b(Notification.Builder builder, Notification.BubbleMetadata bubbleMetadata) {
        return o1.d((Notification.Builder)builder, (Notification.BubbleMetadata)bubbleMetadata);
    }

    public static Notification.Action.Builder c(Notification.Action.Builder builder, boolean bl) {
        return o1.c((Notification.Action.Builder)builder, (boolean)bl);
    }

    public static Notification.Builder d(Notification.Builder builder, Object object) {
        return o1.e((Notification.Builder)builder, (LocusId)o1.h((Object)object));
    }
}

