/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  java.lang.Object
 */
package b0;

import android.app.Notification;

public abstract class s {
    public static Notification.Builder a(Notification.Builder builder, boolean bl) {
        return builder.setShowWhen(bl);
    }
}

