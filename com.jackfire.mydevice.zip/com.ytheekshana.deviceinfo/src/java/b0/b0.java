/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  android.content.pm.ApkChecksum
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$OnChecksumsReadyListener
 *  android.media.metrics.LogSessionId
 *  android.media.metrics.MediaMetricsManager
 *  android.media.metrics.NetworkEvent
 *  android.media.metrics.NetworkEvent$Builder
 *  android.media.metrics.PlaybackErrorEvent
 *  android.media.metrics.PlaybackErrorEvent$Builder
 *  android.media.metrics.PlaybackMetrics
 *  android.media.metrics.PlaybackMetrics$Builder
 *  android.media.metrics.PlaybackSession
 *  android.media.metrics.PlaybackStateEvent
 *  android.media.metrics.PlaybackStateEvent$Builder
 *  android.telephony.TelephonyCallback
 *  android.telephony.TelephonyManager
 *  com.google.android.gms.internal.ads.f9
 *  com.google.android.gms.internal.ads.ji0
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.concurrent.Executor
 */
package b0;

import android.app.Notification;
import android.content.pm.ApkChecksum;
import android.content.pm.PackageManager;
import android.media.metrics.LogSessionId;
import android.media.metrics.MediaMetricsManager;
import android.media.metrics.NetworkEvent;
import android.media.metrics.PlaybackErrorEvent;
import android.media.metrics.PlaybackMetrics;
import android.media.metrics.PlaybackSession;
import android.media.metrics.PlaybackStateEvent;
import android.telephony.TelephonyCallback;
import android.telephony.TelephonyManager;
import com.google.android.gms.internal.ads.f9;
import com.google.android.gms.internal.ads.ji0;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;

public abstract class b0 {
    public static /* bridge */ /* synthetic */ byte[] A(ApkChecksum apkChecksum) {
        return apkChecksum.getValue();
    }

    public static /* synthetic */ void B() {
        new android.media.metrics.PlaybackErrorEvent$Builder;
    }

    public static /* synthetic */ void C() {
        new android.media.metrics.NetworkEvent$Builder;
    }

    public static /* synthetic */ void D() {
        new android.media.metrics.PlaybackStateEvent$Builder;
    }

    public static /* bridge */ /* synthetic */ int a(ApkChecksum apkChecksum) {
        return apkChecksum.getType();
    }

    public static /* bridge */ /* synthetic */ Notification.Action.Builder b(Notification.Action.Builder builder, boolean bl) {
        return builder.setAuthenticationRequired(bl);
    }

    public static /* bridge */ /* synthetic */ Notification.Builder c(Notification.Builder builder, int n2) {
        return builder.setForegroundServiceBehavior(n2);
    }

    public static /* bridge */ /* synthetic */ ApkChecksum d(Object object) {
        return (ApkChecksum)object;
    }

    public static /* bridge */ /* synthetic */ LogSessionId e() {
        return LogSessionId.LOG_SESSION_ID_NONE;
    }

    public static /* bridge */ /* synthetic */ LogSessionId f(PlaybackSession playbackSession) {
        return playbackSession.getSessionId();
    }

    public static /* bridge */ /* synthetic */ MediaMetricsManager g(Object object) {
        return (MediaMetricsManager)object;
    }

    public static /* synthetic */ NetworkEvent.Builder h() {
        return new NetworkEvent.Builder();
    }

    public static /* bridge */ /* synthetic */ NetworkEvent.Builder i(NetworkEvent.Builder builder, int n2) {
        return builder.setNetworkType(n2);
    }

    public static /* bridge */ /* synthetic */ NetworkEvent.Builder j(NetworkEvent.Builder builder, long l2) {
        return builder.setTimeSinceCreatedMillis(l2);
    }

    public static /* bridge */ /* synthetic */ NetworkEvent k(NetworkEvent.Builder builder) {
        return builder.build();
    }

    public static /* synthetic */ PlaybackErrorEvent.Builder l() {
        return new PlaybackErrorEvent.Builder();
    }

    public static /* bridge */ /* synthetic */ PlaybackErrorEvent.Builder m(PlaybackErrorEvent.Builder builder, long l2) {
        return builder.setTimeSinceCreatedMillis(l2);
    }

    public static /* synthetic */ PlaybackMetrics.Builder n() {
        return new PlaybackMetrics.Builder();
    }

    public static /* bridge */ /* synthetic */ PlaybackMetrics.Builder o(PlaybackMetrics.Builder builder) {
        return builder.setPlayerName("AndroidXMedia3");
    }

    public static /* bridge */ /* synthetic */ PlaybackSession p(MediaMetricsManager mediaMetricsManager) {
        return mediaMetricsManager.createPlaybackSession();
    }

    public static /* synthetic */ PlaybackStateEvent.Builder q() {
        return new PlaybackStateEvent.Builder();
    }

    public static /* bridge */ /* synthetic */ PlaybackStateEvent.Builder r(PlaybackStateEvent.Builder builder, int n2) {
        return builder.setState(n2);
    }

    public static /* bridge */ /* synthetic */ PlaybackStateEvent.Builder s(PlaybackStateEvent.Builder builder, long l2) {
        return builder.setTimeSinceCreatedMillis(l2);
    }

    public static /* bridge */ /* synthetic */ PlaybackStateEvent t(PlaybackStateEvent.Builder builder) {
        return builder.build();
    }

    public static /* synthetic */ void u() {
        new android.media.metrics.PlaybackMetrics$Builder;
    }

    public static /* bridge */ /* synthetic */ void v(PackageManager packageManager, String string, ArrayList arrayList, f9 f92) {
        packageManager.requestChecksums(string, false, 8, (List)arrayList, (PackageManager.OnChecksumsReadyListener)f92);
    }

    public static /* bridge */ /* synthetic */ void w(PlaybackSession playbackSession, NetworkEvent networkEvent) {
        playbackSession.reportNetworkEvent(networkEvent);
    }

    public static /* bridge */ /* synthetic */ void x(PlaybackSession playbackSession, PlaybackStateEvent playbackStateEvent) {
        playbackSession.reportPlaybackStateEvent(playbackStateEvent);
    }

    public static /* bridge */ /* synthetic */ void y(TelephonyManager telephonyManager, ji0 ji02) {
        telephonyManager.unregisterTelephonyCallback((TelephonyCallback)ji02);
    }

    public static /* bridge */ /* synthetic */ void z(TelephonyManager telephonyManager, Executor executor, ji0 ji02) {
        telephonyManager.registerTelephonyCallback(executor, (TelephonyCallback)ji02);
    }
}

