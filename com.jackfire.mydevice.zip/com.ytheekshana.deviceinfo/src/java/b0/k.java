/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.view.View
 *  android.view.Window
 *  android.view.Window$Callback
 *  androidx.lifecycle.u
 *  androidx.lifecycle.w
 *  java.lang.Class
 *  java.lang.String
 */
package b0;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import androidx.lifecycle.u;
import androidx.lifecycle.w;
import b7.e;
import j7.b;
import n0.l;

public abstract class k
extends Activity
implements u,
l {
    public final w q = new w((u)this);

    @Override
    public final boolean b(KeyEvent keyEvent) {
        return super.dispatchKeyEvent(keyEvent);
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        View view = this.getWindow().getDecorView();
        if (view != null && b.e(view, keyEvent)) {
            return true;
        }
        return b.f(this, view, (Window.Callback)this, keyEvent);
    }

    public final boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
        View view = this.getWindow().getDecorView();
        if (view != null && b.e(view, keyEvent)) {
            return true;
        }
        return super.dispatchKeyShortcutEvent(keyEvent);
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        e.w(this);
    }

    public void onSaveInstanceState(Bundle bundle) {
        w w2 = this.q;
        w2.getClass();
        w2.d("markState");
        w2.g();
        super.onSaveInstanceState(bundle);
    }
}

