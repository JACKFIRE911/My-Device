/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  android.widget.RemoteViews
 *  androidx.appcompat.widget.i0
 *  java.lang.CharSequence
 *  java.lang.Object
 */
package b0;

import android.app.Notification;
import android.widget.RemoteViews;
import androidx.appcompat.widget.i0;

public abstract class x {
    public static Notification.Action.Builder a(Notification.Action.Builder builder, boolean bl) {
        return i0.c((Notification.Action.Builder)builder, (boolean)bl);
    }

    public static Notification.Builder b(Notification.Builder builder, RemoteViews remoteViews) {
        return i0.B((Notification.Builder)builder, (RemoteViews)remoteViews);
    }

    public static Notification.Builder c(Notification.Builder builder, RemoteViews remoteViews) {
        return i0.D((Notification.Builder)builder, (RemoteViews)remoteViews);
    }

    public static Notification.Builder d(Notification.Builder builder, RemoteViews remoteViews) {
        return i0.d((Notification.Builder)builder, (RemoteViews)remoteViews);
    }

    public static Notification.Builder e(Notification.Builder builder, CharSequence[] arrcharSequence) {
        return i0.e((Notification.Builder)builder, (CharSequence[])arrcharSequence);
    }
}

