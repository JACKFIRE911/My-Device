/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b0;

public final class l {
    public final boolean a;

    public l(boolean bl) {
        this.a = bl;
    }

    public l(boolean bl, int n2) {
        this.a = bl;
    }
}

