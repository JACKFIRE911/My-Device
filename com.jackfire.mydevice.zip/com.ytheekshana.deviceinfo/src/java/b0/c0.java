/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  java.lang.Object
 */
package b0;

import android.app.Notification;
import b0.b0;

public abstract class c0 {
    public static Notification.Action.Builder a(Notification.Action.Builder builder, boolean bl) {
        return b0.b(builder, bl);
    }

    public static Notification.Builder b(Notification.Builder builder, int n2) {
        return b0.c(builder, n2);
    }
}

