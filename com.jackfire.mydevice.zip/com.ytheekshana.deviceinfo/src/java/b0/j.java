/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  android.os.IBinder
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import android.os.Bundle;
import android.os.IBinder;

public abstract class j {
    public static IBinder a(Bundle bundle, String string) {
        return bundle.getBinder(string);
    }

    public static void b(Bundle bundle, String string, IBinder iBinder) {
        bundle.putBinder(string, iBinder);
    }
}

