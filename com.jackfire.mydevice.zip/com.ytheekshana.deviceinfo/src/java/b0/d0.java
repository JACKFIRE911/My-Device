/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 *  q.f
 *  y7.s
 *  y7.t
 */
package b0;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import q.f;
import y7.s;
import y7.t;

public final class d0 {
    public final int a;
    public final Object b;
    public final Object c;
    public final Object d;
    public final String e;
    public final t f;
    public final String g;
    public final Serializable h;
    public final Object i;

    public d0(String string, String string2, String string3, String string4, s s2, String string5, String string6, String string7, int n2) {
        this.b = string;
        this.c = string2;
        this.d = string3;
        this.e = string4;
        this.f = s2;
        this.g = string5;
        this.h = string6;
        this.i = string7;
        this.a = n2;
    }

    public static List a(ArrayList arrayList, ArrayList arrayList2) {
        if (arrayList == null) {
            return arrayList2;
        }
        if (arrayList2 == null) {
            return arrayList;
        }
        f f2 = new f(arrayList.size() + arrayList2.size());
        f2.addAll((Collection)arrayList);
        f2.addAll((Collection)arrayList2);
        return new ArrayList((Collection)f2);
    }

    public static ArrayList b(ArrayList arrayList) {
        if (arrayList == null) {
            return null;
        }
        ArrayList arrayList2 = new ArrayList(arrayList.size());
        Iterator iterator = arrayList.iterator();
        if (!iterator.hasNext()) {
            return arrayList2;
        }
        a2.s.z(iterator.next());
        throw null;
    }
}

