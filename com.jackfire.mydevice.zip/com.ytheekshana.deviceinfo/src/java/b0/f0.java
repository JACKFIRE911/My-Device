/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.NotificationManager
 *  androidx.appcompat.widget.i0
 *  java.lang.Object
 */
package b0;

import android.app.NotificationManager;
import androidx.appcompat.widget.i0;

public abstract class f0 {
    public static boolean a(NotificationManager notificationManager) {
        return i0.y((NotificationManager)notificationManager);
    }

    public static int b(NotificationManager notificationManager) {
        return i0.a((NotificationManager)notificationManager);
    }
}

