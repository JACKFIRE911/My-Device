/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.XmlResourceParser
 *  android.os.Process
 *  android.text.TextUtils
 *  android.util.Log
 *  android.util.SparseArray
 *  android.util.TypedValue
 *  j0.b
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.ThreadLocal
 *  java.lang.Throwable
 *  java.util.WeakHashMap
 */
package b0;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Process;
import android.text.TextUtils;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import b0.g0;
import d0.j;
import d0.k;
import d0.l;
import d0.p;
import j0.b;
import java.util.WeakHashMap;

public abstract class e {
    public static final Object a = new Object();

    public static int a(Context context, String string) {
        if (string != null) {
            if (!b.a() && TextUtils.equals((CharSequence)"android.permission.POST_NOTIFICATIONS", (CharSequence)string)) {
                if (new g0(context).a()) {
                    return 0;
                }
                return -1;
            }
            return context.checkPermission(string, Process.myPid(), Process.myUid());
        }
        throw new NullPointerException("permission must be non-null");
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static ColorStateList b(Context var0, int var1_1) {
        var2_2 = var0.getResources();
        var3_3 = var0.getTheme();
        var4_4 = new l(var2_2, var3_3);
        var18_6 = var5_5 = p.c;
        // MONITORENTER : var18_6
        var7_7 = (SparseArray)p.b.get((Object)var4_4);
        var8_8 = null;
        if (var7_7 == null || var7_7.size() <= 0 || (var17_9 = (k)var7_7.get(var1_1)) == null) ** GOTO lbl14
        if (var17_9.b.equals(var2_2.getConfiguration()) && (var3_3 == null && var17_9.c == 0 || var3_3 != null && var17_9.c == var3_3.hashCode())) {
            var9_10 = var17_9.a;
            // MONITOREXIT : var18_6
        } else {
            var7_7.remove(var1_1);
lbl14: // 2 sources:
            // MONITOREXIT : var18_6
            var9_10 = null;
        }
        if (var9_10 != null) {
            return var9_10;
        }
        var10_11 = p.a;
        var11_12 = (TypedValue)var10_11.get();
        if (var11_12 == null) {
            var11_12 = new TypedValue();
            var10_11.set((Object)var11_12);
        }
        var12_13 = true;
        var2_2.getValue(var1_1, var11_12, var12_13);
        var13_14 = var11_12.type;
        if (var13_14 < 28 || var13_14 > 31) {
            var12_13 = false;
        }
        if (var12_13) {
            var8_8 = null;
        } else {
            var14_15 = var2_2.getXml(var1_1);
            try {
                var8_8 = d0.b.a(var2_2, var14_15, var3_3);
            }
            catch (Exception var15_16) {
                Log.w((String)"ResourcesCompat", (String)"Failed to inflate ColorStateList, leaving it to the framework", (Throwable)var15_16);
            }
        }
        if (var8_8 == null) return j.b(var2_2, var1_1, var3_3);
        p.a(var4_4, var1_1, var8_8, var3_3);
        return var8_8;
    }
}

