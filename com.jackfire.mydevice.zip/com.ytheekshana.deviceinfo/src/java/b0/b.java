/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.SharedElementCallback
 *  android.app.SharedElementCallback$OnSharedElementsReadyListener
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import android.app.Activity;
import android.app.SharedElementCallback;

public abstract class b {
    public static void a(Object object) {
        ((SharedElementCallback.OnSharedElementsReadyListener)object).onSharedElementsReady();
    }

    public static void b(Activity activity, String[] arrstring, int n2) {
        activity.requestPermissions(arrstring, n2);
    }

    public static boolean c(Activity activity, String string) {
        return activity.shouldShowRequestPermissionRationale(string);
    }
}

