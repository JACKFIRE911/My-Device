/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

public interface c {
    public void onRequestPermissionsResult(int var1, String[] var2, int[] var3);
}

