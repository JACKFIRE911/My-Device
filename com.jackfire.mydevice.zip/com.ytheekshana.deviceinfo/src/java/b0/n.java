/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.PendingIntent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.util.Log
 *  androidx.core.graphics.drawable.IconCompat
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.Integer
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 */
package b0;

import android.app.PendingIntent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import androidx.core.graphics.drawable.IconCompat;
import b0.q;
import f0.f;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class n {
    public final Bundle a;
    public IconCompat b;
    public final boolean c;
    public final boolean d;
    public final int e;
    public final CharSequence f;
    public final PendingIntent g;

    public n(String string, PendingIntent pendingIntent) {
        Bundle bundle;
        int n2;
        IconCompat iconCompat;
        block8 : {
            iconCompat = IconCompat.b((int)2131230934);
            bundle = new Bundle();
            this.d = true;
            this.b = iconCompat;
            n2 = iconCompat.a;
            if (n2 == -1) {
                int n3 = Build.VERSION.SDK_INT;
                Object object = iconCompat.b;
                if (n3 >= 28) {
                    n2 = f.c(object);
                } else {
                    try {
                        n2 = (Integer)object.getClass().getMethod("getType", new Class[0]).invoke(object, new Object[0]);
                        break block8;
                    }
                    catch (NoSuchMethodException noSuchMethodException) {
                        StringBuilder stringBuilder = new StringBuilder("Unable to get icon type ");
                        stringBuilder.append(object);
                        Log.e((String)"IconCompat", (String)stringBuilder.toString(), (Throwable)noSuchMethodException);
                    }
                    catch (InvocationTargetException invocationTargetException) {
                        StringBuilder stringBuilder = new StringBuilder("Unable to get icon type ");
                        stringBuilder.append(object);
                        Log.e((String)"IconCompat", (String)stringBuilder.toString(), (Throwable)invocationTargetException);
                    }
                    catch (IllegalAccessException illegalAccessException) {
                        StringBuilder stringBuilder = new StringBuilder("Unable to get icon type ");
                        stringBuilder.append(object);
                        Log.e((String)"IconCompat", (String)stringBuilder.toString(), (Throwable)illegalAccessException);
                    }
                    n2 = -1;
                }
            }
        }
        if (n2 == 2) {
            this.e = iconCompat.c();
        }
        this.f = q.c(string);
        this.g = pendingIntent;
        this.a = bundle;
        this.c = true;
        this.d = true;
    }

    public final IconCompat a() {
        int n2;
        if (this.b == null && (n2 = this.e) != 0) {
            this.b = IconCompat.b((int)n2);
        }
        return this.b;
    }
}

