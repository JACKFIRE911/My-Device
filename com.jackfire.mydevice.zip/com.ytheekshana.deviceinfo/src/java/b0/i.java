/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AppOpsManager
 *  android.content.Context
 *  androidx.appcompat.widget.o1
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import android.app.AppOpsManager;
import android.content.Context;
import androidx.appcompat.widget.o1;

public abstract class i {
    public static int a(AppOpsManager appOpsManager, String string, int n2, String string2) {
        if (appOpsManager == null) {
            return 1;
        }
        return appOpsManager.checkOpNoThrow(string, n2, string2);
    }

    public static String b(Context context) {
        return o1.m((Context)context);
    }

    public static AppOpsManager c(Context context) {
        return (AppOpsManager)context.getSystemService(AppOpsManager.class);
    }
}

