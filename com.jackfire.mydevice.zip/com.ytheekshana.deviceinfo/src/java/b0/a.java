/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.content.IntentSender
 *  android.os.Bundle
 *  java.lang.Object
 */
package b0;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;

public abstract class a {
    public static void a(Activity activity) {
        activity.finishAffinity();
    }

    public static void b(Activity activity, Intent intent, int n2, Bundle bundle) {
        activity.startActivityForResult(intent, n2, bundle);
    }

    public static void c(Activity activity, IntentSender intentSender, int n2, Intent intent, int n3, int n5, int n6, Bundle bundle) {
        activity.startIntentSenderForResult(intentSender, n2, intent, n3, n5, n6, bundle);
    }
}

