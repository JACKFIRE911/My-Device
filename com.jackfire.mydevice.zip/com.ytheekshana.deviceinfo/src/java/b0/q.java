/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  android.app.PendingIntent
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.drawable.Icon
 *  android.media.AudioAttributes
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  android.widget.RemoteViews
 *  androidx.core.graphics.drawable.IconCompat
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Iterator
 */
package b0;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.widget.RemoteViews;
import androidx.core.graphics.drawable.IconCompat;
import b0.a0;
import b0.c0;
import b0.d0;
import b0.n;
import b0.o;
import b0.p;
import b0.r;
import b0.s;
import b0.t;
import b0.u;
import b0.v;
import b0.w;
import b0.x;
import b0.y;
import b0.z;
import f0.d;
import java.util.ArrayList;
import java.util.Iterator;

public final class q {
    public final Context a;
    public final ArrayList b = new ArrayList();
    public final ArrayList c = new ArrayList();
    public final ArrayList d = new ArrayList();
    public CharSequence e;
    public CharSequence f;
    public PendingIntent g;
    public int h;
    public final boolean i = true;
    public p j;
    public boolean k = false;
    public Bundle l;
    public String m;
    public final boolean n;
    public final Notification o;
    public final ArrayList p;

    public q(Context context, String string) {
        Notification notification;
        this.o = notification = new Notification();
        this.a = context;
        this.m = string;
        notification.when = System.currentTimeMillis();
        notification.audioStreamType = -1;
        this.h = 0;
        this.p = new ArrayList();
        this.n = true;
    }

    public static CharSequence c(String string) {
        if (string == null) {
            return string;
        }
        if (string.length() > 5120) {
            string = string.subSequence(0, 5120);
        }
        return string;
    }

    public final Notification a() {
        Notification notification;
        p p2;
        ArrayList arrayList;
        int n2;
        Iterator iterator;
        Bundle bundle;
        new ArrayList();
        Bundle bundle2 = new Bundle();
        int n3 = Build.VERSION.SDK_INT;
        Context context = this.a;
        Notification.Builder builder = n3 >= 26 ? y.a(context, this.m) : new Notification.Builder(context);
        Notification notification2 = this.o;
        Notification.Builder builder2 = builder.setWhen(notification2.when).setSmallIcon(notification2.icon, notification2.iconLevel).setContent(notification2.contentView).setTicker(notification2.tickerText, null).setVibrate(notification2.vibrate).setLights(notification2.ledARGB, notification2.ledOnMS, notification2.ledOffMS);
        int n5 = 2 & notification2.flags;
        boolean bl = true;
        boolean bl2 = n5 != 0 ? bl : false;
        Notification.Builder builder3 = builder2.setOngoing(bl2);
        boolean bl3 = (8 & notification2.flags) != 0 ? bl : false;
        Notification.Builder builder4 = builder3.setOnlyAlertOnce(bl3);
        boolean bl4 = (16 & notification2.flags) != 0 ? bl : false;
        Notification.Builder builder5 = builder4.setAutoCancel(bl4).setDefaults(notification2.defaults).setContentTitle(this.e).setContentText(this.f).setContentInfo(null).setContentIntent(this.g).setDeleteIntent(notification2.deleteIntent);
        if ((128 & notification2.flags) == 0) {
            bl = false;
        }
        builder5.setFullScreenIntent(null, bl).setLargeIcon(null).setNumber(0).setProgress(0, 0, false);
        r.b(r.d(r.c(builder, null), false), this.h);
        for (n n6 : this.b) {
            IconCompat iconCompat = n6.a();
            Icon icon = iconCompat != null ? d.c(iconCompat, null) : null;
            Notification.Action.Builder builder6 = w.a(icon, n6.f, n6.g);
            Bundle bundle3 = n6.a;
            Bundle bundle4 = bundle3 != null ? new Bundle(bundle3) : new Bundle();
            boolean bl5 = n6.c;
            bundle4.putBoolean("android.support.allowGeneratedReplies", bl5);
            int n7 = Build.VERSION.SDK_INT;
            if (n7 >= 24) {
                x.a(builder6, bl5);
            }
            bundle4.putInt("android.support.action.semanticAction", 0);
            if (n7 >= 28) {
                z.b(builder6, 0);
            }
            if (n7 >= 29) {
                a0.c(builder6, false);
            }
            if (n7 >= 31) {
                c0.a(builder6, false);
            }
            bundle4.putBoolean("android.support.action.showsUserInterface", n6.d);
            u.b(builder6, bundle4);
            u.a(builder, u.d(builder6));
        }
        Bundle bundle5 = this.l;
        if (bundle5 != null) {
            bundle2.putAll(bundle5);
        }
        int n8 = Build.VERSION.SDK_INT;
        s.a(builder, this.i);
        u.i(builder, this.k);
        u.g(builder, null);
        u.j(builder, null);
        u.h(builder, false);
        v.b(builder, null);
        v.c(builder, 0);
        v.f(builder, 0);
        v.d(builder, null);
        v.e(builder, notification2.sound, (Object)notification2.audioAttributes);
        ArrayList arrayList2 = this.c;
        ArrayList arrayList3 = this.p;
        if (n8 < 28) {
            arrayList3 = d0.a(d0.b(arrayList2), arrayList3);
        }
        if (arrayList3 != null && !arrayList3.isEmpty()) {
            Iterator iterator2 = arrayList3.iterator();
            while (iterator2.hasNext()) {
                v.a(builder, (String)iterator2.next());
            }
        }
        if ((arrayList = this.d).size() > 0) {
            Bundle bundle6 = this.b().getBundle("android.car.EXTENSIONS");
            if (bundle6 == null) {
                bundle6 = new Bundle();
            }
            Bundle bundle7 = new Bundle(bundle6);
            Bundle bundle8 = new Bundle();
            for (int i2 = 0; i2 < arrayList.size(); ++i2) {
                String string = Integer.toString((int)i2);
                n n9 = (n)arrayList.get(i2);
                Bundle bundle9 = new Bundle();
                IconCompat iconCompat = n9.a();
                int n10 = 0;
                if (iconCompat != null) {
                    n10 = iconCompat.c();
                }
                bundle9.putInt("icon", n10);
                bundle9.putCharSequence("title", n9.f);
                bundle9.putParcelable("actionIntent", (Parcelable)n9.g);
                Bundle bundle10 = n9.a;
                Bundle bundle11 = bundle10 != null ? new Bundle(bundle10) : new Bundle();
                bundle11.putBoolean("android.support.allowGeneratedReplies", n9.c);
                bundle9.putBundle("extras", bundle11);
                bundle9.putParcelableArray("remoteInputs", null);
                bundle9.putBoolean("showsUserInterface", n9.d);
                bundle9.putInt("semanticAction", 0);
                bundle8.putBundle(string, bundle9);
            }
            bundle6.putBundle("invisible_actions", bundle8);
            bundle7.putBundle("invisible_actions", bundle8);
            this.b().putBundle("android.car.EXTENSIONS", bundle6);
            bundle2.putBundle("android.car.EXTENSIONS", bundle7);
        }
        if ((n2 = Build.VERSION.SDK_INT) >= 24) {
            t.a(builder, this.l);
            x.e(builder, null);
        }
        if (n2 >= 26) {
            y.b(builder, 0);
            y.e(builder, null);
            y.f(builder, null);
            y.g(builder, 0L);
            y.d(builder, 0);
            if (!TextUtils.isEmpty((CharSequence)this.m)) {
                builder.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null);
            }
        }
        if (n2 >= 28 && (iterator = arrayList2.iterator()).hasNext()) {
            a2.s.z(iterator.next());
            throw null;
        }
        if (n2 >= 29) {
            a0.a(builder, this.n);
            a0.b(builder, null);
        }
        if ((p2 = this.j) != null) {
            o.a(o.c(o.b(builder), null), p2.b);
        }
        if (n2 >= 26) {
            notification = r.a(builder);
        } else if (n2 >= 24) {
            notification = r.a(builder);
        } else {
            t.a(builder, bundle2);
            notification = r.a(builder);
        }
        if (p2 != null) {
            this.j.getClass();
        }
        if (p2 != null && (bundle = notification.extras) != null) {
            bundle.putString("androidx.core.app.extra.COMPAT_TEMPLATE", "androidx.core.app.NotificationCompat$BigTextStyle");
        }
        return notification;
    }

    public final Bundle b() {
        if (this.l == null) {
            this.l = new Bundle();
        }
        return this.l;
    }

    public final void d(p p2) {
        if (this.j != p2) {
            this.j = p2;
            if (p2.a != this) {
                p2.a = this;
                this.d(p2);
            }
        }
    }
}

