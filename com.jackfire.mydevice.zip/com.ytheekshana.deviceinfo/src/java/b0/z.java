/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  android.app.Person
 *  androidx.appcompat.widget.e1
 *  java.lang.Object
 */
package b0;

import android.app.Notification;
import android.app.Person;
import androidx.appcompat.widget.e1;

public abstract class z {
    public static Notification.Builder a(Notification.Builder builder, Person person) {
        return e1.b((Notification.Builder)builder, (Person)person);
    }

    public static Notification.Action.Builder b(Notification.Action.Builder builder, int n2) {
        return e1.a((Notification.Action.Builder)builder, (int)n2);
    }
}

