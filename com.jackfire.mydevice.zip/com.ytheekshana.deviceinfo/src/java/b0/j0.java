/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b0;

public final class j0 {
    public final boolean a;

    public j0(boolean bl) {
        this.a = bl;
    }

    public j0(boolean bl, int n2) {
        this.a = bl;
    }
}

