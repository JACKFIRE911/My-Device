/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Action
 *  android.app.Notification$Action$Builder
 *  android.app.Notification$Builder
 *  android.app.PendingIntent
 *  android.app.RemoteInput
 *  android.os.Bundle
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.os.Bundle;

public abstract class u {
    public static Notification.Builder a(Notification.Builder builder, Notification.Action action) {
        return builder.addAction(action);
    }

    public static Notification.Action.Builder b(Notification.Action.Builder builder, Bundle bundle) {
        return builder.addExtras(bundle);
    }

    public static Notification.Action.Builder c(Notification.Action.Builder builder, RemoteInput remoteInput) {
        return builder.addRemoteInput(remoteInput);
    }

    public static Notification.Action d(Notification.Action.Builder builder) {
        return builder.build();
    }

    public static Notification.Action.Builder e(int n2, CharSequence charSequence, PendingIntent pendingIntent) {
        return new Notification.Action.Builder(n2, charSequence, pendingIntent);
    }

    public static String f(Notification notification) {
        return notification.getGroup();
    }

    public static Notification.Builder g(Notification.Builder builder, String string) {
        return builder.setGroup(string);
    }

    public static Notification.Builder h(Notification.Builder builder, boolean bl) {
        return builder.setGroupSummary(bl);
    }

    public static Notification.Builder i(Notification.Builder builder, boolean bl) {
        return builder.setLocalOnly(bl);
    }

    public static Notification.Builder j(Notification.Builder builder, String string) {
        return builder.setSortKey(string);
    }
}

