/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.content.Context
 *  androidx.appcompat.widget.c1
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import a2.s;
import android.app.Notification;
import android.content.Context;
import androidx.appcompat.widget.c1;

public abstract class y {
    public static Notification.Builder a(Context context, String string) {
        s.w();
        return c1.h((Context)context, (String)string);
    }

    public static Notification.Builder b(Notification.Builder builder, int n2) {
        return c1.A((Notification.Builder)builder, (int)n2);
    }

    public static Notification.Builder c(Notification.Builder builder, boolean bl) {
        return c1.g((Notification.Builder)builder, (boolean)bl);
    }

    public static Notification.Builder d(Notification.Builder builder, int n2) {
        return c1.c((Notification.Builder)builder, (int)n2);
    }

    public static Notification.Builder e(Notification.Builder builder, CharSequence charSequence) {
        return c1.e((Notification.Builder)builder, (CharSequence)charSequence);
    }

    public static Notification.Builder f(Notification.Builder builder, String string) {
        return c1.f((Notification.Builder)builder, (String)string);
    }

    public static Notification.Builder g(Notification.Builder builder, long l2) {
        return c1.d((Notification.Builder)builder, (long)l2);
    }
}

