/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  java.lang.CharSequence
 *  java.lang.Object
 */
package b0;

import android.app.Notification;

public abstract class r {
    public static Notification a(Notification.Builder builder) {
        return builder.build();
    }

    public static Notification.Builder b(Notification.Builder builder, int n2) {
        return builder.setPriority(n2);
    }

    public static Notification.Builder c(Notification.Builder builder, CharSequence charSequence) {
        return builder.setSubText(charSequence);
    }

    public static Notification.Builder d(Notification.Builder builder, boolean bl) {
        return builder.setUsesChronometer(bl);
    }
}

