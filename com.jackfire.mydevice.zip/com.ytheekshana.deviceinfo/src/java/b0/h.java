/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.AppOpsManager
 *  android.content.Context
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package b0;

import android.app.AppOpsManager;
import android.content.Context;

public abstract class h {
    public static <T> T a(Context context, Class<T> class_) {
        return (T)context.getSystemService(class_);
    }

    public static int b(AppOpsManager appOpsManager, String string, String string2) {
        return appOpsManager.noteProxyOp(string, string2);
    }

    public static int c(AppOpsManager appOpsManager, String string, String string2) {
        return appOpsManager.noteProxyOpNoThrow(string, string2);
    }

    public static String d(String string) {
        return AppOpsManager.permissionToOp((String)string);
    }
}

