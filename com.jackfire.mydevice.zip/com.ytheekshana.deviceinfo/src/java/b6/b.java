/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.String
 *  java.lang.Throwable
 */
package b6;

public final class b
extends IllegalStateException {
    public static final /* synthetic */ int q;

    public b() {
    }

    public b(String string, Exception exception) {
        super(string, (Throwable)exception);
    }
}

