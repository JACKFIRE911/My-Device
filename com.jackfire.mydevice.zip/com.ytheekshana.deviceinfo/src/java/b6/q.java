/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.biometric.n
 *  com.bumptech.glide.manager.t
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.CancellationException
 *  java.util.concurrent.Executor
 *  q0.b
 */
package b6;

import a8.b1;
import androidx.biometric.n;
import b6.a;
import b6.b;
import b6.e;
import b6.f;
import b6.g;
import b6.h;
import b6.i;
import b6.k;
import b6.m;
import b6.o;
import b6.p;
import com.bumptech.glide.manager.t;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;

public final class q
extends i {
    public final Object a = new Object();
    public final t b = new t(6);
    public boolean c;
    public volatile boolean d;
    public Object e;
    public Exception f;

    @Override
    public final q a(Executor executor, e e4) {
        o o5 = new o(executor, e4);
        this.b.i((p)o5);
        this.n();
        return this;
    }

    @Override
    public final q b(Executor executor, f f4) {
        o o5 = new o(executor, f4);
        this.b.i((p)o5);
        this.n();
        return this;
    }

    @Override
    public final q c(Executor executor, a a3) {
        q q4 = new q();
        m m4 = new m(executor, a3, q4, 0);
        this.b.i((p)m4);
        this.n();
        return q4;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Exception d() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            return this.f;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Object e() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            b1.l("Task is not yet complete", this.c);
            if (this.d) {
                throw new CancellationException("Task is already canceled.");
            }
            Exception exception = this.f;
            if (exception != null) throw new g(exception);
            return this.e;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final boolean f() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            return this.c;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final boolean g() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            boolean bl = this.c;
            boolean bl2 = false;
            if (!bl) return bl2;
            boolean bl3 = this.d;
            bl2 = false;
            if (bl3) return bl2;
            Exception exception = this.f;
            bl2 = false;
            if (exception != null) return bl2;
            return true;
        }
    }

    @Override
    public final q h(Executor executor, h h3) {
        q q4 = new q();
        o o5 = new o(executor, h3, q4);
        this.b.i((p)o5);
        this.n();
        return q4;
    }

    public final q i(q0.b b4) {
        this.b((Executor)k.a, (f)b4);
        return this;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void j(Exception exception) {
        if (exception != null) {
            Object object;
            Object object2 = object = this.a;
            synchronized (object2) {
                this.m();
                this.c = true;
                this.f = exception;
            }
            this.b.k((i)this);
            return;
        }
        throw new NullPointerException("Exception must not be null");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void k(Object object) {
        Object object2;
        Object object3 = object2 = this.a;
        synchronized (object3) {
            this.m();
            this.c = true;
            this.e = object;
        }
        this.b.k((i)this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void l() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            if (this.c) {
                return;
            }
            this.c = true;
            this.d = true;
        }
        this.b.k((i)this);
    }

    public final void m() {
        if (this.c) {
            IllegalStateException illegalStateException;
            if (this.f()) {
                Exception exception = this.d();
                String string = exception == null ? (!this.g() ? (this.d ? "cancellation" : "unknown issue") : "result ".concat(String.valueOf((Object)this.e()))) : "failure";
                illegalStateException = new b("Complete with: ".concat(string), exception);
            } else {
                illegalStateException = new IllegalStateException("DuplicateTaskCompletionException can only be created from completed Task.");
            }
            throw illegalStateException;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void n() {
        Object object;
        Object object2 = object = this.a;
        synchronized (object2) {
            if (!this.c) {
                return;
            }
        }
        this.b.k((i)this);
    }
}

