/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.Executor
 */
package b6;

import b6.a;
import b6.c;
import b6.e;
import b6.f;
import b6.i;
import b6.p;
import b6.q;
import java.util.concurrent.Executor;

public final class m
implements p,
f,
e,
c {
    public final /* synthetic */ int q;
    public final Executor r;
    public final a s;
    public final q t;

    public /* synthetic */ m(Executor executor, a a3, q q4, int n2) {
        this.q = n2;
        this.r = executor;
        this.s = a3;
        this.t = q4;
    }

    @Override
    public final void a(i i3) {
        int n2 = this.q;
        Executor executor = this.r;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                executor.execute((Runnable)new u5.e((Object)this, i3, 12));
                return;
            }
        }
        executor.execute((Runnable)new u5.e((Object)this, i3, 13));
    }

    @Override
    public final void g() {
        this.t.l();
    }

    @Override
    public final void i(Object object) {
        this.t.k(object);
    }

    @Override
    public final void p(Exception exception) {
        this.t.j(exception);
    }
}

