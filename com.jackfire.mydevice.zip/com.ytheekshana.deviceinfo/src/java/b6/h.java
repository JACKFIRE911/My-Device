/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b6.q
 *  java.lang.Object
 */
package b6;

import b6.q;

public interface h {
    public q c(Object var1);
}

