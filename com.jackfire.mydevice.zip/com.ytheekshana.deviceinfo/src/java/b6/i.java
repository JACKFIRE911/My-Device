/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b6.q
 *  java.lang.Exception
 *  java.lang.Object
 *  java.util.concurrent.Executor
 */
package b6;

import b6.a;
import b6.e;
import b6.f;
import b6.h;
import b6.q;
import java.util.concurrent.Executor;

public abstract class i {
    public abstract q a(Executor var1, e var2);

    public abstract q b(Executor var1, f var2);

    public abstract q c(Executor var1, a var2);

    public abstract Exception d();

    public abstract Object e();

    public abstract boolean f();

    public abstract boolean g();

    public abstract q h(Executor var1, h var2);
}

