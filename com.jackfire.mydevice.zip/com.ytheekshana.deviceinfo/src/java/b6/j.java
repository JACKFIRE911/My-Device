/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b6.q
 *  com.bumptech.glide.manager.t
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 */
package b6;

import b6.i;
import b6.q;
import com.bumptech.glide.manager.t;

public final class j {
    public final q a = new q();

    public final void a(Object object) {
        this.a.k(object);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void b(Exception exception) {
        Object object;
        q q2 = this.a;
        q2.getClass();
        if (exception == null) {
            throw new NullPointerException("Exception must not be null");
        }
        Object object2 = object = q2.a;
        synchronized (object2) {
            if (q2.c) {
                return;
            }
            q2.c = true;
            q2.f = exception;
        }
        q2.b.k((i)q2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void c(Object object) {
        Object object2;
        q q2 = this.a;
        Object object3 = object2 = q2.a;
        synchronized (object3) {
            if (q2.c) {
                return;
            }
            q2.c = true;
            q2.e = object;
        }
        q2.b.k((i)q2);
    }
}

