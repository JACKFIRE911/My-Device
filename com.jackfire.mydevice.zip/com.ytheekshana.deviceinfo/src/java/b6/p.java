/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b6;

import b6.i;

public interface p {
    public void a(i var1);
}

