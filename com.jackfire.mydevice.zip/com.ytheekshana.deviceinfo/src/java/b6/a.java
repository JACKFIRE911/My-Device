/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b6;

import b6.i;

public interface a {
    public Object h(i var1);
}

