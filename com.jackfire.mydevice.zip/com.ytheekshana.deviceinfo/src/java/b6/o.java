/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.Executor
 */
package b6;

import b6.c;
import b6.d;
import b6.e;
import b6.f;
import b6.h;
import b6.i;
import b6.n;
import b6.p;
import b6.q;
import e.u0;
import java.util.concurrent.Executor;

public final class o
implements p,
f,
e,
c {
    public final /* synthetic */ int q;
    public final Executor r;
    public final Object s;
    public final Object t;

    public o(u0 u02, c c4) {
        this.q = 0;
        this.s = new Object();
        this.r = u02;
        this.t = c4;
    }

    public o(Executor executor, d d4) {
        this.q = 1;
        this.s = new Object();
        this.r = executor;
        this.t = d4;
    }

    public o(Executor executor, e e4) {
        this.q = 2;
        this.s = new Object();
        this.r = executor;
        this.t = e4;
    }

    public o(Executor executor, f f4) {
        this.q = 3;
        this.s = new Object();
        this.r = executor;
        this.t = f4;
    }

    public o(Executor executor, h h3, q q4) {
        this.q = 4;
        this.r = executor;
        this.s = h3;
        this.t = q4;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final void b(i i3) {
        Object object;
        Object object2 = object = this.s;
        synchronized (object2) {
            if ((d)this.t == null) {
                return;
            }
        }
        this.r.execute((Runnable)new u5.e((Object)this, i3, 14));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final void c(i i3) {
        if (!i3.g() && !((q)i3).d) {
            Object object;
            Object object2 = object = this.s;
            synchronized (object2) {
                if ((e)this.t == null) {
                    return;
                }
            }
            this.r.execute((Runnable)new u5.e((Object)this, i3, 15));
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    private final void d(i i3) {
        Object object;
        if (!i3.g()) {
            return;
        }
        Object object2 = object = this.s;
        synchronized (object2) {
            if ((f)this.t == null) {
                return;
            }
        }
        this.r.execute((Runnable)new u5.e((Object)this, i3, 16));
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final void a(i var1_1) {
        switch (this.q) {
            default: {
                ** break;
            }
            case 3: {
                this.d(var1_1);
                return;
            }
            case 2: {
                this.c(var1_1);
                return;
            }
            case 1: {
                this.b(var1_1);
                return;
            }
            case 0: 
        }
        if (((q)var1_1).d == false) return;
        var5_3 = var2_2 = this.s;
        // MONITORENTER : var5_3
        if ((c)this.t == null) {
            // MONITOREXIT : var5_3
            return;
        }
        // MONITOREXIT : var5_3
        this.r.execute((Runnable)new n(0, this));
        return;
lbl23: // 1 sources:
        var4_4 = new u5.e((Object)this, var1_1, 17);
        this.r.execute((Runnable)var4_4);
    }

    @Override
    public final void g() {
        ((q)this.t).l();
    }

    @Override
    public final void i(Object object) {
        ((q)this.t).k(object);
    }

    @Override
    public final void p(Exception exception) {
        ((q)this.t).j(exception);
    }
}

