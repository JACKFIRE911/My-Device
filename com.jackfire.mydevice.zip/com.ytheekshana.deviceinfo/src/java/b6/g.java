/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.RuntimeException
 *  java.lang.Throwable
 */
package b6;

public final class g
extends RuntimeException {
    public g(Exception exception) {
        super((Throwable)exception);
    }
}

