/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.ExecutionException
 */
package b6;

import b6.c;
import b6.e;
import b6.f;
import b6.q;
import java.util.concurrent.ExecutionException;

public final class l
implements f,
e,
c {
    public final Object q = new Object();
    public final int r;
    public final q s;
    public int t;
    public int u;
    public int v;
    public Exception w;
    public boolean x;

    public l(int n2, q q4) {
        this.r = n2;
        this.s = q4;
    }

    public final void a() {
        int n2 = this.t + this.u + this.v;
        int n3 = this.r;
        if (n2 == n3) {
            Exception exception = this.w;
            q q4 = this.s;
            if (exception != null) {
                int n5 = this.u;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(n5);
                stringBuilder.append(" out of ");
                stringBuilder.append(n3);
                stringBuilder.append(" underlying tasks failed");
                q4.j((Exception)((Object)new ExecutionException(stringBuilder.toString(), (Throwable)this.w)));
                return;
            }
            if (this.x) {
                q4.l();
                return;
            }
            q4.k(null);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void g() {
        Object object;
        Object object2 = object = this.q;
        synchronized (object2) {
            this.v = 1 + this.v;
            this.x = true;
            this.a();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void i(Object object) {
        Object object2;
        Object object3 = object2 = this.q;
        synchronized (object3) {
            this.t = 1 + this.t;
            this.a();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void p(Exception exception) {
        Object object;
        Object object2 = object = this.q;
        synchronized (object2) {
            this.u = 1 + this.u;
            this.w = exception;
            this.a();
            return;
        }
    }
}

