/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.media.MediaRecorder
 *  android.os.Handler
 *  android.view.View
 *  android.view.inputmethod.InputMethodManager
 *  b6.o
 *  com.google.android.material.bottomsheet.BottomSheetBehavior
 *  com.google.android.material.progressindicator.LinearProgressIndicator
 *  com.ytheekshana.deviceinfo.tests.MicrophoneTestActivity
 *  j2.i
 *  java.lang.Boolean
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.ThreadLocal
 *  k5.k
 *  n5.b
 *  s7.j
 *  u8.d
 *  v0.d
 *  v8.a
 *  v8.b
 */
package b6;

import android.content.Context;
import android.media.MediaRecorder;
import android.os.Handler;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import b6.c;
import b6.o;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.ytheekshana.deviceinfo.tests.MicrophoneTestActivity;
import j2.i;
import k5.k;
import s7.j;
import u8.d;
import v8.a;
import v8.b;

public final class n
implements Runnable {
    public final /* synthetic */ int q;
    public final /* synthetic */ Object r;

    public /* synthetic */ n(int n2, Object object) {
        this.q = n2;
        this.r = object;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void run() {
        switch (this.q) {
            default: {
                ** break;
            }
            case 4: {
                a2 = (a)this.r;
                a2.r = true;
                b2 = a2.s;
                if (b2 != null) {
                    bl = a2.q;
                    ((d)((n5.b)b2).q).d((View)a2, bl);
                }
                a2.r = false;
                return;
            }
            case 3: {
                ((ThreadLocal)((i)this.r).t).set((Object)Boolean.TRUE);
                return;
            }
            case 2: {
                view = (View)this.r;
                ((InputMethodManager)view.getContext().getSystemService("input_method")).showSoftInput(view, 1);
                return;
            }
            case 1: {
                k2 = (k)this.r;
                k2.c = false;
                d2 = ((BottomSheetBehavior)k2.b).M;
                if (d2 != null && d2.g()) {
                    k2.a(k2.d);
                    return;
                }
                bottomSheetBehavior = (BottomSheetBehavior)k2.b;
                if (bottomSheetBehavior.L != 2) return;
                bottomSheetBehavior.F(k2.d);
                return;
            }
            case 0: 
        }
        object2 = object = ((o)this.r).s;
        // MONITORENTER : object2
        object3 = ((o)this.r).t;
        if ((c)object3 != null) {
            ((c)object3).g();
        }
        // MONITOREXIT : object2
        return;
lbl39: // 1 sources:
        var12_11 = (MicrophoneTestActivity)this.r;
        var13_12 = var12_11.R;
        var14_13 = var13_12 != null ? Integer.valueOf((int)var13_12.getMaxAmplitude()) : null;
        if (var14_13 != null) {
            var17_14 = var12_11.Q;
            if (var17_14 == null) {
                j.I((String)"progressBarAmplitude");
                throw null;
            }
            var17_14.setProgress(var14_13.intValue());
        }
        if ((var15_15 = var12_11.S) != null) {
            var15_15.postDelayed((Runnable)this, 100L);
            return;
        }
        j.I((String)"handler");
        throw null;
    }
}

