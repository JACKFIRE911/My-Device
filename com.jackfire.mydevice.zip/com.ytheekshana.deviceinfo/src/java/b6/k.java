/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.biometric.n
 *  java.lang.Object
 */
package b6;

import androidx.biometric.n;
import e.u0;

public abstract class k {
    public static final n a = new n(3);
    public static final u0 b = new u0(4);
}

