/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.g1;
import a8.l0;
import h8.c;
import h8.d;
import h8.e;

public final class o
implements d {
    public static final o a = new o();
    public static final c b = c.b("name");
    public static final c c = c.b("code");
    public static final c d = c.b("address");

    @Override
    public final void a(Object object, Object object2) {
        g1 g12 = (g1)object;
        e e3 = (e)object2;
        l0 l02 = (l0)g12;
        String string = l02.a;
        e3.f(b, string);
        String string2 = l02.b;
        e3.f(c, string2);
        e3.a(d, l02.c);
    }
}

