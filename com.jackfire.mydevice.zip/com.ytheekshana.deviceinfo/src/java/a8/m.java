/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a8;

import a8.f1;
import a8.g1;
import a8.i0;
import a8.j1;
import a8.s1;
import a8.x0;
import h8.c;
import h8.d;
import h8.e;

public final class m
implements d {
    public static final m a = new m();
    public static final c b = c.b("threads");
    public static final c c = c.b("exception");
    public static final c d = c.b("appExitInfo");
    public static final c e = c.b("signal");
    public static final c f = c.b("binaries");

    @Override
    public final void a(Object object, Object object2) {
        j1 j12 = (j1)object;
        e e3 = (e)object2;
        i0 i02 = (i0)j12;
        s1 s12 = i02.a;
        e3.f(b, s12);
        f1 f12 = i02.b;
        e3.f(c, f12);
        e3.f(d, i02.c);
        e3.f(e, i02.d);
        e3.f(f, i02.e);
    }
}

