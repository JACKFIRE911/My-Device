/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.a1;
import a8.q1;
import a8.r1;
import a8.x0;

public final class w
extends r1 {
    public final String b;
    public final String c;
    public final int d;
    public final String e;
    public final String f;
    public final String g;
    public final q1 h;
    public final a1 i;
    public final x0 j;

    public w(String string, String string2, int n2, String string3, String string4, String string5, q1 q12, a1 a12, x0 x02) {
        this.b = string;
        this.c = string2;
        this.d = n2;
        this.e = string3;
        this.f = string4;
        this.g = string5;
        this.h = q12;
        this.i = a12;
        this.j = x02;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof r1) {
            String string;
            w w2 = (w)((r1)object);
            String string2 = w2.b;
            if (this.b.equals((Object)string2) && this.c.equals((Object)(string = w2.c)) && this.d == w2.d && this.e.equals((Object)w2.e) && this.f.equals((Object)w2.f) && this.g.equals((Object)w2.g)) {
                q1 q12 = w2.h;
                q1 q13 = this.h;
                if (q13 == null ? q12 == null : q13.equals((Object)q12)) {
                    a1 a12 = w2.i;
                    a1 a13 = this.i;
                    if (a13 == null ? a12 == null : a13.equals((Object)a12)) {
                        x0 x02 = w2.j;
                        x0 x03 = this.j;
                        if (x03 == null ? x02 == null : x03.equals((Object)x02)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 * (1000003 * (1000003 * (1000003 * (1000003 ^ this.b.hashCode()) ^ this.c.hashCode()) ^ this.d) ^ this.e.hashCode()) ^ this.f.hashCode()) ^ this.g.hashCode());
        q1 q12 = this.h;
        int n3 = q12 == null ? 0 : q12.hashCode();
        int n5 = 1000003 * (n2 ^ n3);
        a1 a12 = this.i;
        int n6 = a12 == null ? 0 : a12.hashCode();
        int n7 = 1000003 * (n5 ^ n6);
        x0 x02 = this.j;
        int n8 = x02 == null ? 0 : x02.hashCode();
        return n7 ^ n8;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CrashlyticsReport{sdkVersion=");
        stringBuilder.append(this.b);
        stringBuilder.append(", gmpAppId=");
        stringBuilder.append(this.c);
        stringBuilder.append(", platform=");
        stringBuilder.append(this.d);
        stringBuilder.append(", installationUuid=");
        stringBuilder.append(this.e);
        stringBuilder.append(", buildVersion=");
        stringBuilder.append(this.f);
        stringBuilder.append(", displayVersion=");
        stringBuilder.append(this.g);
        stringBuilder.append(", session=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", ndkPayload=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", appExitInfo=");
        stringBuilder.append((Object)this.j);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

