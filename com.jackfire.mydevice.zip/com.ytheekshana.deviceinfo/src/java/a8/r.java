/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Object
 */
package a8;

import a8.l1;
import a8.o0;
import h8.c;
import h8.d;
import h8.e;

public final class r
implements d {
    public static final r a = new r();
    public static final c b = c.b("batteryLevel");
    public static final c c = c.b("batteryVelocity");
    public static final c d = c.b("proximityOn");
    public static final c e = c.b("orientation");
    public static final c f = c.b("ramUsed");
    public static final c g = c.b("diskUsed");

    @Override
    public final void a(Object object, Object object2) {
        l1 l12 = (l1)object;
        e e3 = (e)object2;
        o0 o02 = (o0)l12;
        Double d3 = o02.a;
        e3.f(b, (Object)d3);
        int n3 = o02.b;
        e3.c(c, n3);
        e3.b(d, o02.c);
        e3.c(e, o02.d);
        e3.a(f, o02.e);
        e3.a(g, o02.f);
    }
}

