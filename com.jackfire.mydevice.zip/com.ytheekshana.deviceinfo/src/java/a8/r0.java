/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.p1;

public final class r0
extends p1 {
    public final String a;

    public r0(String string) {
        this.a = string;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof p1) {
            String string = ((r0)((p1)object)).a;
            return this.a.equals((Object)string);
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 ^ this.a.hashCode();
    }

    public final String toString() {
        return s.v(new StringBuilder("User{identifier="), this.a, "}");
    }
}

