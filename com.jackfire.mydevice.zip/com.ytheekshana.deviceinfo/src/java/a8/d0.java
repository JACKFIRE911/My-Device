/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.c1;

public final class d0
extends c1 {
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;
    public final String f;

    public d0(String string, String string2, String string3, String string4, String string5, String string6) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
        this.f = string6;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof c1) {
            c1 c12 = (c1)object;
            String string = ((d0)c12).a;
            if (this.a.equals((Object)string)) {
                d0 d02 = (d0)c12;
                if (this.b.equals((Object)d02.b)) {
                    String string2 = d02.c;
                    String string3 = this.c;
                    if (string3 == null ? string2 == null : string3.equals((Object)string2)) {
                        String string4 = d02.d;
                        String string5 = this.d;
                        if (string5 == null ? string4 == null : string5.equals((Object)string4)) {
                            String string6 = d02.e;
                            String string7 = this.e;
                            if (string7 == null ? string6 == null : string7.equals((Object)string6)) {
                                String string8 = d02.f;
                                String string9 = this.f;
                                if (string9 == null ? string8 == null : string9.equals((Object)string8)) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode());
        String string = this.c;
        int n3 = string == null ? 0 : string.hashCode();
        int n5 = 1000003 * (0 ^ 1000003 * (n2 ^ n3));
        String string2 = this.d;
        int n6 = string2 == null ? 0 : string2.hashCode();
        int n7 = 1000003 * (n5 ^ n6);
        String string3 = this.e;
        int n8 = string3 == null ? 0 : string3.hashCode();
        int n9 = 1000003 * (n7 ^ n8);
        String string4 = this.f;
        int n10 = string4 == null ? 0 : string4.hashCode();
        return n9 ^ n10;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Application{identifier=");
        stringBuilder.append(this.a);
        stringBuilder.append(", version=");
        stringBuilder.append(this.b);
        stringBuilder.append(", displayVersion=");
        stringBuilder.append(this.c);
        stringBuilder.append(", organization=null, installationUuid=");
        stringBuilder.append(this.d);
        stringBuilder.append(", developmentPlatform=");
        stringBuilder.append(this.e);
        stringBuilder.append(", developmentPlatformVersion=");
        return s.v(stringBuilder, this.f, "}");
    }
}

