/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.ads.xe1
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.f1;
import a8.s1;
import com.google.android.gms.internal.ads.xe1;

public final class k0
extends f1 {
    public final String a;
    public final String b;
    public final s1 c;
    public final f1 d;
    public final int e;

    public k0(String string, String string2, s1 s12, f1 f12, int n2) {
        this.a = string;
        this.b = string2;
        this.c = s12;
        this.d = f12;
        this.e = n2;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof f1) {
            s1 s12;
            String string;
            k0 k02 = (k0)((f1)object);
            String string2 = k02.a;
            if (this.a.equals((Object)string2) && ((string = this.b) == null ? k02.b == null : string.equals((Object)k02.b)) && this.c.equals(s12 = k02.c)) {
                f1 f12 = k02.d;
                f1 f13 = this.d;
                if ((f13 == null ? f12 == null : f13.equals((Object)f12)) && this.e == k02.e) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 ^ this.a.hashCode());
        String string = this.b;
        int n3 = string == null ? 0 : string.hashCode();
        int n5 = 1000003 * (1000003 * (n2 ^ n3) ^ this.c.hashCode());
        f1 f12 = this.d;
        int n6 = f12 == null ? 0 : f12.hashCode();
        return 1000003 * (n5 ^ n6) ^ this.e;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Exception{type=");
        stringBuilder.append(this.a);
        stringBuilder.append(", reason=");
        stringBuilder.append(this.b);
        stringBuilder.append(", frames=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", causedBy=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", overflowCount=");
        return xe1.j((StringBuilder)stringBuilder, (int)this.e, (String)"}");
    }
}

