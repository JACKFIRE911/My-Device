/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.g0;
import a8.k1;
import a8.l1;
import a8.m1;
import a8.n1;
import h8.c;
import h8.d;
import h8.e;

public final class s
implements d {
    public static final s a = new s();
    public static final c b = c.b("timestamp");
    public static final c c = c.b("type");
    public static final c d = c.b("app");
    public static final c e = c.b("device");
    public static final c f = c.b("log");

    @Override
    public final void a(Object object, Object object2) {
        n1 n12 = (n1)object;
        e e3 = (e)object2;
        g0 g02 = (g0)n12;
        long l2 = g02.a;
        e3.a(b, l2);
        String string = g02.b;
        e3.f(c, string);
        e3.f(d, g02.c);
        e3.f(e, g02.d);
        e3.f(f, g02.e);
    }
}

