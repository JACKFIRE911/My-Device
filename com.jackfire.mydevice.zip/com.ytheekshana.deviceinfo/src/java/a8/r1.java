/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 */
package a8;

import java.nio.charset.Charset;

public abstract class r1 {
    public static final Charset a = Charset.forName((String)"UTF-8");
}

