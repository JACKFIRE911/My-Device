/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.i1;
import a8.m0;
import a8.s1;
import h8.c;
import h8.d;
import h8.e;

public final class p
implements d {
    public static final p a = new p();
    public static final c b = c.b("name");
    public static final c c = c.b("importance");
    public static final c d = c.b("frames");

    @Override
    public final void a(Object object, Object object2) {
        i1 i12 = (i1)object;
        e e3 = (e)object2;
        m0 m02 = (m0)i12;
        String string = m02.a;
        e3.f(b, string);
        int n3 = m02.b;
        e3.c(c, n3);
        e3.f(d, m02.c);
    }
}

