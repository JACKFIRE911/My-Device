/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.f1;
import a8.g1;
import a8.j1;
import a8.s1;
import a8.x0;

public final class i0
extends j1 {
    public final s1 a;
    public final f1 b;
    public final x0 c;
    public final g1 d;
    public final s1 e;

    public i0(s1 s12, f1 f12, x0 x02, g1 g12, s1 s13) {
        this.a = s12;
        this.b = f12;
        this.c = x02;
        this.d = g12;
        this.e = s13;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof j1) {
            x0 x02;
            f1 f12;
            j1 j12 = (j1)object;
            s1 s12 = this.a;
            if ((s12 == null ? ((i0)j12).a == null : s12.equals(((i0)j12).a)) && ((f12 = this.b) == null ? ((i0)j12).b == null : f12.equals((Object)((i0)j12).b)) && ((x02 = this.c) == null ? ((i0)j12).c == null : x02.equals((Object)((i0)j12).c))) {
                i0 i02 = (i0)j12;
                g1 g12 = i02.d;
                if (this.d.equals((Object)g12) && this.e.equals(i02.e)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        s1 s12 = this.a;
        int n2 = s12 == null ? 0 : s12.hashCode();
        int n3 = 1000003 * (n2 ^ 1000003);
        f1 f12 = this.b;
        int n5 = f12 == null ? 0 : f12.hashCode();
        int n6 = 1000003 * (n3 ^ n5);
        x0 x02 = this.c;
        int n7 = x02 == null ? 0 : x02.hashCode();
        return 1000003 * (1000003 * (n7 ^ n6) ^ this.d.hashCode()) ^ this.e.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Execution{threads=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", exception=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", appExitInfo=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", signal=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", binaries=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

