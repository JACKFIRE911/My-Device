/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.h1;
import a8.n0;
import h8.c;
import h8.d;
import h8.e;

public final class q
implements d {
    public static final q a = new q();
    public static final c b = c.b("pc");
    public static final c c = c.b("symbol");
    public static final c d = c.b("file");
    public static final c e = c.b("offset");
    public static final c f = c.b("importance");

    @Override
    public final void a(Object object, Object object2) {
        h1 h12 = (h1)object;
        e e3 = (e)object2;
        n0 n02 = (n0)h12;
        long l2 = n02.a;
        e3.a(b, l2);
        String string = n02.b;
        e3.f(c, string);
        e3.f(d, n02.c);
        e3.a(e, n02.d);
        e3.c(f, n02.e);
    }
}

