/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 */
package a8;

import a8.c0;
import a8.c1;
import a8.d1;
import a8.o1;
import a8.p1;
import a8.q1;
import a8.r1;
import a8.s1;
import h8.c;
import h8.d;
import h8.e;
import java.nio.charset.Charset;

public final class j
implements d {
    public static final j a = new j();
    public static final c b = c.b("generator");
    public static final c c = c.b("identifier");
    public static final c d = c.b("startedAt");
    public static final c e = c.b("endedAt");
    public static final c f = c.b("crashed");
    public static final c g = c.b("app");
    public static final c h = c.b("user");
    public static final c i = c.b("os");
    public static final c j = c.b("device");
    public static final c k = c.b("events");
    public static final c l = c.b("generatorType");

    @Override
    public final void a(Object object, Object object2) {
        q1 q12 = (q1)object;
        e e3 = (e)object2;
        c0 c02 = (c0)q12;
        String string = c02.a;
        e3.f(b, string);
        Charset charset = r1.a;
        byte[] arrby = c02.b.getBytes(charset);
        e3.f(c, arrby);
        e3.a(d, c02.c);
        e3.f(e, (Object)c02.d);
        e3.b(f, c02.e);
        e3.f(g, c02.f);
        e3.f(h, c02.g);
        e3.f(i, c02.h);
        e3.f(j, c02.i);
        e3.f(k, c02.j);
        e3.c(l, c02.k);
    }
}

