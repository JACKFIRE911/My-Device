/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.d1;
import a8.f0;
import h8.c;
import h8.d;
import h8.e;

public final class i
implements d {
    public static final i a = new i();
    public static final c b = c.b("arch");
    public static final c c = c.b("model");
    public static final c d = c.b("cores");
    public static final c e = c.b("ram");
    public static final c f = c.b("diskSpace");
    public static final c g = c.b("simulator");
    public static final c h = c.b("state");
    public static final c i = c.b("manufacturer");
    public static final c j = c.b("modelClass");

    @Override
    public final void a(Object object, Object object2) {
        d1 d12 = (d1)object;
        e e3 = (e)object2;
        f0 f02 = (f0)d12;
        int n3 = f02.a;
        e3.c(b, n3);
        String string = f02.b;
        e3.f(c, string);
        e3.c(d, f02.c);
        e3.a(e, f02.d);
        e3.a(f, f02.e);
        e3.b(g, f02.f);
        e3.c(h, f02.g);
        e3.f(i, f02.h);
        e3.f(j, f02.i);
    }
}

