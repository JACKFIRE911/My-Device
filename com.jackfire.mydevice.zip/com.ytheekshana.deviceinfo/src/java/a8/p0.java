/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.m1;

public final class p0
extends m1 {
    public final String a;

    public p0(String string) {
        this.a = string;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof m1) {
            String string = ((p0)((m1)object)).a;
            return this.a.equals((Object)string);
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 ^ this.a.hashCode();
    }

    public final String toString() {
        return s.v(new StringBuilder("Log{content="), this.a, "}");
    }
}

