/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j2.e
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import j2.e;

public final class t0 {
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final int e;
    public final e f;

    public t0(String string, String string2, String string3, String string4, int n2, e e2) {
        if (string != null) {
            this.a = string;
            if (string2 != null) {
                this.b = string2;
                if (string3 != null) {
                    this.c = string3;
                    if (string4 != null) {
                        this.d = string4;
                        this.e = n2;
                        if (e2 != null) {
                            this.f = e2;
                            return;
                        }
                        throw new NullPointerException("Null developmentPlatformProvider");
                    }
                    throw new NullPointerException("Null installUuid");
                }
                throw new NullPointerException("Null versionName");
            }
            throw new NullPointerException("Null versionCode");
        }
        throw new NullPointerException("Null appIdentifier");
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof t0) {
            t0 t02 = (t0)object;
            String string = t02.a;
            return this.a.equals((Object)string) && this.b.equals((Object)t02.b) && this.c.equals((Object)t02.c) && this.d.equals((Object)t02.d) && this.e == t02.e && this.f.equals((Object)t02.f);
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 * (1000003 * (1000003 * (1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode()) ^ this.c.hashCode()) ^ this.d.hashCode()) ^ this.e) ^ this.f.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("AppData{appIdentifier=");
        stringBuilder.append(this.a);
        stringBuilder.append(", versionCode=");
        stringBuilder.append(this.b);
        stringBuilder.append(", versionName=");
        stringBuilder.append(this.c);
        stringBuilder.append(", installUuid=");
        stringBuilder.append(this.d);
        stringBuilder.append(", deliveryMechanism=");
        stringBuilder.append(this.e);
        stringBuilder.append(", developmentPlatformProvider=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

