/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.f1;
import a8.k0;
import a8.s1;
import h8.c;
import h8.d;
import h8.e;

public final class n
implements d {
    public static final n a = new n();
    public static final c b = c.b("type");
    public static final c c = c.b("reason");
    public static final c d = c.b("frames");
    public static final c e = c.b("causedBy");
    public static final c f = c.b("overflowCount");

    @Override
    public final void a(Object object, Object object2) {
        f1 f12 = (f1)object;
        e e3 = (e)object2;
        k0 k02 = (k0)f12;
        String string = k02.a;
        e3.f(b, string);
        String string2 = k02.b;
        e3.f(c, string2);
        e3.f(d, k02.c);
        e3.f(e, k02.d);
        e3.c(f, k02.e);
    }
}

