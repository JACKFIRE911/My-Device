/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.b0;
import a8.z0;
import h8.c;
import h8.d;
import h8.e;

public final class f
implements d {
    public static final f a = new f();
    public static final c b = c.b("filename");
    public static final c c = c.b("contents");

    @Override
    public final void a(Object object, Object object2) {
        z0 z02 = (z0)object;
        e e3 = (e)object2;
        b0 b02 = (b0)z02;
        String string = b02.a;
        e3.f(b, string);
        e3.f(c, b02.b);
    }
}

