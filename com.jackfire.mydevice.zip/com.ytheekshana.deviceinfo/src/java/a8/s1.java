/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Iterator
 *  java.util.List
 *  java.util.ListIterator
 *  java.util.RandomAccess
 */
package a8;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.RandomAccess;

public final class s1
implements List,
RandomAccess {
    public final List q;

    public s1(List list) {
        this.q = Collections.unmodifiableList((List)list);
    }

    public final void add(int n2, Object object) {
        this.q.add(n2, object);
    }

    public final boolean add(Object object) {
        return this.q.add(object);
    }

    public final boolean addAll(int n2, Collection collection) {
        return this.q.addAll(n2, collection);
    }

    public final boolean addAll(Collection collection) {
        return this.q.addAll(collection);
    }

    public final void clear() {
        this.q.clear();
    }

    public final boolean contains(Object object) {
        return this.q.contains(object);
    }

    public final boolean containsAll(Collection collection) {
        return this.q.containsAll(collection);
    }

    public final boolean equals(Object object) {
        return this.q.equals(object);
    }

    public final Object get(int n2) {
        return this.q.get(n2);
    }

    public final int hashCode() {
        return this.q.hashCode();
    }

    public final int indexOf(Object object) {
        return this.q.indexOf(object);
    }

    public final boolean isEmpty() {
        return this.q.isEmpty();
    }

    public final Iterator iterator() {
        return this.q.iterator();
    }

    public final int lastIndexOf(Object object) {
        return this.q.lastIndexOf(object);
    }

    public final ListIterator listIterator() {
        return this.q.listIterator();
    }

    public final ListIterator listIterator(int n2) {
        return this.q.listIterator(n2);
    }

    public final Object remove(int n2) {
        return this.q.remove(n2);
    }

    public final boolean remove(Object object) {
        return this.q.remove(object);
    }

    public final boolean removeAll(Collection collection) {
        return this.q.removeAll(collection);
    }

    public final boolean retainAll(Collection collection) {
        return this.q.retainAll(collection);
    }

    public final Object set(int n2, Object object) {
        return this.q.set(n2, object);
    }

    public final int size() {
        return this.q.size();
    }

    public final List subList(int n2, int n3) {
        return this.q.subList(n2, n3);
    }

    public final Object[] toArray() {
        return this.q.toArray();
    }

    public final Object[] toArray(Object[] arrobject) {
        return this.q.toArray(arrobject);
    }
}

