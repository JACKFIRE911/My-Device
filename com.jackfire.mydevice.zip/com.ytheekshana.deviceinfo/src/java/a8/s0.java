/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.t0;
import a8.u0;
import a8.v0;

public final class s0 {
    public final t0 a;
    public final v0 b;
    public final u0 c;

    public s0(t0 t02, v0 v02, u0 u02) {
        this.a = t02;
        this.b = v02;
        this.c = u02;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof s0) {
            s0 s02 = (s0)object;
            t0 t02 = s02.a;
            return this.a.equals(t02) && this.b.equals(s02.b) && this.c.equals(s02.c);
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode()) ^ this.c.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("StaticSessionData{appData=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", osData=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", deviceData=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

