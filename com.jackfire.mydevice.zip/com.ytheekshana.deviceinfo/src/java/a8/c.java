/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.y0;
import a8.z;
import h8.d;
import h8.e;

public final class c
implements d {
    public static final c a = new c();
    public static final h8.c b = h8.c.b("key");
    public static final h8.c c = h8.c.b("value");

    @Override
    public final void a(Object object, Object object2) {
        y0 y02 = (y0)object;
        e e3 = (e)object2;
        z z3 = (z)y02;
        String string = z3.a;
        e3.f(b, string);
        e3.f(c, z3.b);
    }
}

