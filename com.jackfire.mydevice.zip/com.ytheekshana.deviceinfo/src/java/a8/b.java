/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.s1;
import a8.x;
import a8.x0;
import h8.c;
import h8.d;
import h8.e;

public final class b
implements d {
    public static final b a = new b();
    public static final c b = c.b("pid");
    public static final c c = c.b("processName");
    public static final c d = c.b("reasonCode");
    public static final c e = c.b("importance");
    public static final c f = c.b("pss");
    public static final c g = c.b("rss");
    public static final c h = c.b("timestamp");
    public static final c i = c.b("traceFile");
    public static final c j = c.b("buildIdMappingForArch");

    @Override
    public final void a(Object object, Object object2) {
        x0 x02 = (x0)object;
        e e3 = (e)object2;
        x x2 = (x)x02;
        int n3 = x2.a;
        e3.c(b, n3);
        String string = x2.b;
        e3.f(c, string);
        e3.c(d, x2.c);
        e3.c(e, x2.d);
        e3.a(f, x2.e);
        e3.a(g, x2.f);
        e3.a(h, x2.g);
        e3.f(i, x2.h);
        e3.f(j, x2.i);
    }
}

