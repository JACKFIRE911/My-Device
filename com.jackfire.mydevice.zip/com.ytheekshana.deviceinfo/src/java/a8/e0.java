/*
 * Decompiled with CFR 0.0.
 */
package a8;

import a8.b1;

public abstract class e0
extends b1 {
}

