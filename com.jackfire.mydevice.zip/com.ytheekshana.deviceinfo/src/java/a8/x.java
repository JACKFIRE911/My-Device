/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.s1;
import a8.x0;

public final class x
extends x0 {
    public final int a;
    public final String b;
    public final int c;
    public final int d;
    public final long e;
    public final long f;
    public final long g;
    public final String h;
    public final s1 i;

    public x(int n2, String string, int n3, int n5, long l3, long l4, long l6, String string2, s1 s12) {
        this.a = n2;
        this.b = string;
        this.c = n3;
        this.d = n5;
        this.e = l3;
        this.f = l4;
        this.g = l6;
        this.h = string2;
        this.i = s12;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof x0) {
            x0 x02 = (x0)object;
            int n2 = ((x)x02).a;
            if (this.a == n2) {
                x x4 = (x)x02;
                if (this.b.equals((Object)x4.b) && this.c == x4.c && this.d == x4.d && this.e == x4.e && this.f == x4.f && this.g == x4.g) {
                    String string = x4.h;
                    String string2 = this.h;
                    if (string2 == null ? string == null : string2.equals((Object)string)) {
                        s1 s12 = x4.i;
                        s1 s13 = this.i;
                        if (s13 == null ? s12 == null : s13.equals(s12)) {
                            return true;
                        }
                    }
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 * (1000003 * (1000003 ^ this.a) ^ this.b.hashCode()) ^ this.c) ^ this.d);
        long l3 = this.e;
        int n3 = 1000003 * (n2 ^ (int)(l3 ^ l3 >>> 32));
        long l4 = this.f;
        int n5 = 1000003 * (n3 ^ (int)(l4 ^ l4 >>> 32));
        long l6 = this.g;
        int n6 = 1000003 * (n5 ^ (int)(l6 ^ l6 >>> 32));
        String string = this.h;
        int n7 = string == null ? 0 : string.hashCode();
        int n8 = 1000003 * (n6 ^ n7);
        s1 s12 = this.i;
        int n9 = s12 == null ? 0 : s12.hashCode();
        return n8 ^ n9;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("ApplicationExitInfo{pid=");
        stringBuilder.append(this.a);
        stringBuilder.append(", processName=");
        stringBuilder.append(this.b);
        stringBuilder.append(", reasonCode=");
        stringBuilder.append(this.c);
        stringBuilder.append(", importance=");
        stringBuilder.append(this.d);
        stringBuilder.append(", pss=");
        stringBuilder.append(this.e);
        stringBuilder.append(", rss=");
        stringBuilder.append(this.f);
        stringBuilder.append(", timestamp=");
        stringBuilder.append(this.g);
        stringBuilder.append(", traceFile=");
        stringBuilder.append(this.h);
        stringBuilder.append(", buildIdMappingForArch=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

