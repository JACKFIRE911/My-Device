/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.ads.xe1
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.h1;
import com.google.android.gms.internal.ads.xe1;

public final class n0
extends h1 {
    public final long a;
    public final String b;
    public final String c;
    public final long d;
    public final int e;

    public n0(long l3, String string, String string2, long l4, int n2) {
        this.a = l3;
        this.b = string;
        this.c = string2;
        this.d = l4;
        this.e = n2;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof h1) {
            h1 h12 = (h1)object;
            long l3 = ((n0)h12).a;
            if (this.a == l3) {
                n0 n02 = (n0)h12;
                if (this.b.equals((Object)n02.b)) {
                    String string = n02.c;
                    String string2 = this.c;
                    if ((string2 == null ? string == null : string2.equals((Object)string)) && this.d == n02.d && this.e == n02.e) {
                        return true;
                    }
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        long l3 = this.a;
        int n2 = 1000003 * (1000003 * (1000003 ^ (int)(l3 ^ l3 >>> 32)) ^ this.b.hashCode());
        String string = this.c;
        int n3 = string == null ? 0 : string.hashCode();
        int n5 = 1000003 * (n2 ^ n3);
        long l4 = this.d;
        return 1000003 * (n5 ^ (int)(l4 ^ l4 >>> 32)) ^ this.e;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Frame{pc=");
        stringBuilder.append(this.a);
        stringBuilder.append(", symbol=");
        stringBuilder.append(this.b);
        stringBuilder.append(", file=");
        stringBuilder.append(this.c);
        stringBuilder.append(", offset=");
        stringBuilder.append(this.d);
        stringBuilder.append(", importance=");
        return xe1.j((StringBuilder)stringBuilder, (int)this.e, (String)"}");
    }
}

