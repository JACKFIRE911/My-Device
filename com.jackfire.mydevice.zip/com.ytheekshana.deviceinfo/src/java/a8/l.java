/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 */
package a8;

import a8.e1;
import a8.j0;
import a8.r1;
import h8.c;
import h8.d;
import h8.e;
import java.nio.charset.Charset;

public final class l
implements d {
    public static final l a = new l();
    public static final c b = c.b("baseAddress");
    public static final c c = c.b("size");
    public static final c d = c.b("name");
    public static final c e = c.b("uuid");

    @Override
    public final void a(Object object, Object object2) {
        e1 e12 = (e1)object;
        e e3 = (e)object2;
        j0 j02 = (j0)e12;
        long l2 = j02.a;
        e3.a(b, l2);
        long l5 = j02.b;
        e3.a(c, l5);
        e3.f(d, j02.c);
        String string = j02.d;
        byte[] arrby = string != null ? string.getBytes(r1.a) : null;
        e3.f(e, arrby);
    }
}

