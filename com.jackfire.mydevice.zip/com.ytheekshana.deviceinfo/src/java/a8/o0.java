/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.l1;

public final class o0
extends l1 {
    public final Double a;
    public final int b;
    public final boolean c;
    public final int d;
    public final long e;
    public final long f;

    public o0(Double d4, int n2, boolean bl, int n3, long l3, long l4) {
        this.a = d4;
        this.b = n2;
        this.c = bl;
        this.d = n3;
        this.e = l3;
        this.f = l4;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof l1) {
            int n2;
            l1 l12 = (l1)object;
            Double d4 = this.a;
            if ((d4 == null ? ((o0)l12).a == null : d4.equals((Object)((o0)l12).a)) && this.b == (n2 = ((o0)l12).b)) {
                o0 o02 = (o0)l12;
                if (this.c == o02.c && this.d == o02.d && this.e == o02.e && this.f == o02.f) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        Double d4 = this.a;
        int n2 = d4 == null ? 0 : d4.hashCode();
        int n3 = 1000003 * (1000003 * (n2 ^ 1000003) ^ this.b);
        int n5 = this.c ? 1231 : 1237;
        int n6 = 1000003 * (1000003 * (n3 ^ n5) ^ this.d);
        long l3 = this.e;
        int n7 = 1000003 * (n6 ^ (int)(l3 ^ l3 >>> 32));
        long l4 = this.f;
        return n7 ^ (int)(l4 ^ l4 >>> 32);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Device{batteryLevel=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", batteryVelocity=");
        stringBuilder.append(this.b);
        stringBuilder.append(", proximityOn=");
        stringBuilder.append(this.c);
        stringBuilder.append(", orientation=");
        stringBuilder.append(this.d);
        stringBuilder.append(", ramUsed=");
        stringBuilder.append(this.e);
        stringBuilder.append(", diskUsed=");
        stringBuilder.append(this.f);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

