/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.w0;

public final class y
extends w0 {
    public final String a;
    public final String b;
    public final String c;

    public y(String string, String string2, String string3) {
        this.a = string;
        this.b = string2;
        this.c = string3;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof w0) {
            w0 w02 = (w0)object;
            String string = ((y)w02).a;
            if (this.a.equals((Object)string)) {
                y y3 = (y)w02;
                if (this.b.equals((Object)y3.b) && this.c.equals((Object)y3.c)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode()) ^ this.c.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("BuildIdMappingForArch{arch=");
        stringBuilder.append(this.a);
        stringBuilder.append(", libraryName=");
        stringBuilder.append(this.b);
        stringBuilder.append(", buildId=");
        return s.v(stringBuilder, this.c, "}");
    }
}

