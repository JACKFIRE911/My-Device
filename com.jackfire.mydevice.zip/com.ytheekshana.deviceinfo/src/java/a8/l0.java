/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.g1;

public final class l0
extends g1 {
    public final String a;
    public final String b;
    public final long c;

    public l0(String string, String string2, long l3) {
        this.a = string;
        this.b = string2;
        this.c = l3;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof g1) {
            g1 g12 = (g1)object;
            String string = ((l0)g12).a;
            if (this.a.equals((Object)string)) {
                l0 l02 = (l0)g12;
                if (this.b.equals((Object)l02.b) && this.c == l02.c) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode());
        long l3 = this.c;
        return n2 ^ (int)(l3 ^ l3 >>> 32);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Signal{name=");
        stringBuilder.append(this.a);
        stringBuilder.append(", code=");
        stringBuilder.append(this.b);
        stringBuilder.append(", address=");
        stringBuilder.append(this.c);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

