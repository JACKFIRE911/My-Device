/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.d1;

public final class f0
extends d1 {
    public final int a;
    public final String b;
    public final int c;
    public final long d;
    public final long e;
    public final boolean f;
    public final int g;
    public final String h;
    public final String i;

    public f0(int n2, String string, int n3, long l3, long l4, boolean bl, int n5, String string2, String string3) {
        this.a = n2;
        this.b = string;
        this.c = n3;
        this.d = l3;
        this.e = l4;
        this.f = bl;
        this.g = n5;
        this.h = string2;
        this.i = string3;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof d1) {
            d1 d12 = (d1)object;
            int n2 = ((f0)d12).a;
            if (this.a == n2) {
                f0 f02 = (f0)d12;
                if (this.b.equals((Object)f02.b) && this.c == f02.c && this.d == f02.d && this.e == f02.e && this.f == f02.f && this.g == f02.g && this.h.equals((Object)f02.h) && this.i.equals((Object)f02.i)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 * (1000003 ^ this.a) ^ this.b.hashCode()) ^ this.c);
        long l3 = this.d;
        int n3 = 1000003 * (n2 ^ (int)(l3 ^ l3 >>> 32));
        long l4 = this.e;
        int n5 = 1000003 * (n3 ^ (int)(l4 ^ l4 >>> 32));
        int n6 = this.f ? 1231 : 1237;
        return 1000003 * (1000003 * (1000003 * (n5 ^ n6) ^ this.g) ^ this.h.hashCode()) ^ this.i.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Device{arch=");
        stringBuilder.append(this.a);
        stringBuilder.append(", model=");
        stringBuilder.append(this.b);
        stringBuilder.append(", cores=");
        stringBuilder.append(this.c);
        stringBuilder.append(", ram=");
        stringBuilder.append(this.d);
        stringBuilder.append(", diskSpace=");
        stringBuilder.append(this.e);
        stringBuilder.append(", simulator=");
        stringBuilder.append(this.f);
        stringBuilder.append(", state=");
        stringBuilder.append(this.g);
        stringBuilder.append(", manufacturer=");
        stringBuilder.append(this.h);
        stringBuilder.append(", modelClass=");
        return s.v(stringBuilder, this.i, "}");
    }
}

