/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.i1;
import a8.s1;

public final class m0
extends i1 {
    public final String a;
    public final int b;
    public final s1 c;

    public m0(String string, int n2, s1 s12) {
        this.a = string;
        this.b = n2;
        this.c = s12;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof i1) {
            i1 i12 = (i1)object;
            String string = ((m0)i12).a;
            if (this.a.equals((Object)string)) {
                m0 m02 = (m0)i12;
                if (this.b == m02.b && this.c.equals(m02.c)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b) ^ this.c.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Thread{name=");
        stringBuilder.append(this.a);
        stringBuilder.append(", importance=");
        stringBuilder.append(this.b);
        stringBuilder.append(", frames=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

