/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a8;

import a2.s;
import h8.c;
import h8.d;
import h8.e;

public final class h
implements d {
    public static final h a = new h();

    public static {
        c.b("clsId");
    }

    @Override
    public final void a(Object object, Object object2) {
        s.z(object);
        (e)object2;
        throw null;
    }
}

