/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

public final class v0 {
    public final String a;
    public final String b;
    public final boolean c;

    public v0(String string, String string2, boolean bl) {
        if (string != null) {
            this.a = string;
            if (string2 != null) {
                this.b = string2;
                this.c = bl;
                return;
            }
            throw new NullPointerException("Null osCodeName");
        }
        throw new NullPointerException("Null osRelease");
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof v0) {
            v0 v02 = (v0)object;
            String string = v02.a;
            return this.a.equals((Object)string) && this.b.equals((Object)v02.b) && this.c == v02.c;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode());
        int n3 = this.c ? 1231 : 1237;
        return n2 ^ n3;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("OsData{osRelease=");
        stringBuilder.append(this.a);
        stringBuilder.append(", osCodeName=");
        stringBuilder.append(this.b);
        stringBuilder.append(", isRooted=");
        stringBuilder.append(this.c);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

