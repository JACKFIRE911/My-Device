/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.k1;
import a8.l1;
import a8.m1;
import a8.n1;

public final class g0
extends n1 {
    public final long a;
    public final String b;
    public final k1 c;
    public final l1 d;
    public final m1 e;

    public g0(long l3, String string, k1 k12, l1 l12, m1 m12) {
        this.a = l3;
        this.b = string;
        this.c = k12;
        this.d = l12;
        this.e = m12;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof n1) {
            String string;
            g0 g02 = (g0)((n1)object);
            long l3 = g02.a;
            if (this.a == l3 && this.b.equals((Object)(string = g02.b)) && this.c.equals((Object)g02.c) && this.d.equals((Object)g02.d)) {
                m1 m12 = g02.e;
                m1 m13 = this.e;
                if (m13 == null ? m12 == null : m13.equals((Object)m12)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        long l3 = this.a;
        int n2 = 1000003 * (1000003 * (1000003 * (1000003 * (1000003 ^ (int)(l3 ^ l3 >>> 32)) ^ this.b.hashCode()) ^ this.c.hashCode()) ^ this.d.hashCode());
        m1 m12 = this.e;
        int n3 = m12 == null ? 0 : m12.hashCode();
        return n2 ^ n3;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Event{timestamp=");
        stringBuilder.append(this.a);
        stringBuilder.append(", type=");
        stringBuilder.append(this.b);
        stringBuilder.append(", app=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", device=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", log=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

