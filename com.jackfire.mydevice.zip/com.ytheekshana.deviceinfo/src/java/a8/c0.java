/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.ads.xe1
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.c1;
import a8.d1;
import a8.o1;
import a8.p1;
import a8.q1;
import a8.s1;
import com.google.android.gms.internal.ads.xe1;

public final class c0
extends q1 {
    public final String a;
    public final String b;
    public final long c;
    public final Long d;
    public final boolean e;
    public final c1 f;
    public final p1 g;
    public final o1 h;
    public final d1 i;
    public final s1 j;
    public final int k;

    public c0(String string, String string2, long l3, Long l4, boolean bl, c1 c12, p1 p12, o1 o12, d1 d12, s1 s12, int n2) {
        this.a = string;
        this.b = string2;
        this.c = l3;
        this.d = l4;
        this.e = bl;
        this.f = c12;
        this.g = p12;
        this.h = o12;
        this.i = d12;
        this.j = s12;
        this.k = n2;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof q1) {
            String string;
            c0 c02 = (c0)((q1)object);
            String string2 = c02.a;
            if (this.a.equals((Object)string2) && this.b.equals((Object)(string = c02.b)) && this.c == c02.c) {
                Long l3 = c02.d;
                Long l4 = this.d;
                if ((l4 == null ? l3 == null : l4.equals((Object)l3)) && this.e == c02.e && this.f.equals((Object)c02.f)) {
                    p1 p12 = c02.g;
                    p1 p13 = this.g;
                    if (p13 == null ? p12 == null : p13.equals((Object)p12)) {
                        o1 o12 = c02.h;
                        o1 o13 = this.h;
                        if (o13 == null ? o12 == null : o13.equals((Object)o12)) {
                            d1 d12 = c02.i;
                            d1 d13 = this.i;
                            if (d13 == null ? d12 == null : d13.equals((Object)d12)) {
                                s1 s12 = c02.j;
                                s1 s13 = this.j;
                                if ((s13 == null ? s12 == null : s13.equals(s12)) && this.k == c02.k) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode());
        long l3 = this.c;
        int n3 = 1000003 * (n2 ^ (int)(l3 ^ l3 >>> 32));
        Long l4 = this.d;
        int n5 = l4 == null ? 0 : l4.hashCode();
        int n6 = 1000003 * (n3 ^ n5);
        int n7 = this.e ? 1231 : 1237;
        int n8 = 1000003 * (1000003 * (n6 ^ n7) ^ this.f.hashCode());
        p1 p12 = this.g;
        int n9 = p12 == null ? 0 : p12.hashCode();
        int n10 = 1000003 * (n8 ^ n9);
        o1 o12 = this.h;
        int n11 = o12 == null ? 0 : o12.hashCode();
        int n12 = 1000003 * (n10 ^ n11);
        d1 d12 = this.i;
        int n13 = d12 == null ? 0 : d12.hashCode();
        int n14 = 1000003 * (n12 ^ n13);
        s1 s12 = this.j;
        int n15 = s12 == null ? 0 : s12.hashCode();
        return 1000003 * (n14 ^ n15) ^ this.k;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Session{generator=");
        stringBuilder.append(this.a);
        stringBuilder.append(", identifier=");
        stringBuilder.append(this.b);
        stringBuilder.append(", startedAt=");
        stringBuilder.append(this.c);
        stringBuilder.append(", endedAt=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", crashed=");
        stringBuilder.append(this.e);
        stringBuilder.append(", app=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", user=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", os=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", device=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", events=");
        stringBuilder.append((Object)this.j);
        stringBuilder.append(", generatorType=");
        return xe1.j((StringBuilder)stringBuilder, (int)this.k, (String)"}");
    }
}

