/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.p1;
import a8.r0;
import h8.c;
import h8.d;
import h8.e;

public final class v
implements d {
    public static final v a = new v();
    public static final c b = c.b("identifier");

    @Override
    public final void a(Object object, Object object2) {
        p1 p12 = (p1)object;
        e e3 = (e)object2;
        String string = ((r0)p12).a;
        e3.f(b, string);
    }
}

