/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.o1;
import a8.q0;
import h8.c;
import h8.d;
import h8.e;

public final class u
implements d {
    public static final u a = new u();
    public static final c b = c.b("platform");
    public static final c c = c.b("version");
    public static final c d = c.b("buildVersion");
    public static final c e = c.b("jailbroken");

    @Override
    public final void a(Object object, Object object2) {
        o1 o12 = (o1)object;
        e e3 = (e)object2;
        q0 q02 = (q0)o12;
        int n3 = q02.a;
        e3.c(b, n3);
        String string = q02.b;
        e3.f(c, string);
        e3.f(d, q02.c);
        e3.b(e, q02.d);
    }
}

