/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.o1;

public final class q0
extends o1 {
    public final int a;
    public final String b;
    public final String c;
    public final boolean d;

    public q0(int n2, String string, String string2, boolean bl) {
        this.a = n2;
        this.b = string;
        this.c = string2;
        this.d = bl;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof o1) {
            o1 o12 = (o1)object;
            int n2 = ((q0)o12).a;
            if (this.a == n2) {
                q0 q02 = (q0)o12;
                if (this.b.equals((Object)q02.b) && this.c.equals((Object)q02.c) && this.d == q02.d) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 * (1000003 ^ this.a) ^ this.b.hashCode()) ^ this.c.hashCode());
        int n3 = this.d ? 1231 : 1237;
        return n2 ^ n3;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("OperatingSystem{platform=");
        stringBuilder.append(this.a);
        stringBuilder.append(", version=");
        stringBuilder.append(this.b);
        stringBuilder.append(", buildVersion=");
        stringBuilder.append(this.c);
        stringBuilder.append(", jailbroken=");
        stringBuilder.append(this.d);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

