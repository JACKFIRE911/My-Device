/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.m1;
import a8.p0;
import h8.c;
import h8.d;
import h8.e;

public final class t
implements d {
    public static final t a = new t();
    public static final c b = c.b("content");

    @Override
    public final void a(Object object, Object object2) {
        m1 m12 = (m1)object;
        e e3 = (e)object2;
        String string = ((p0)m12).a;
        e3.f(b, string);
    }
}

