/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.ads.xe1
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a8.j1;
import a8.k1;
import a8.s1;
import com.google.android.gms.internal.ads.xe1;

public final class h0
extends k1 {
    public final j1 a;
    public final s1 b;
    public final s1 c;
    public final Boolean d;
    public final int e;

    public h0(j1 j12, s1 s12, s1 s13, Boolean bl, int n2) {
        this.a = j12;
        this.b = s12;
        this.c = s13;
        this.d = bl;
        this.e = n2;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof k1) {
            s1 s12;
            Boolean bl;
            s1 s13;
            h0 h02 = (h0)((k1)object);
            j1 j12 = h02.a;
            return this.a.equals((Object)j12) && ((s13 = this.b) == null ? h02.b == null : s13.equals(h02.b)) && ((s12 = this.c) == null ? h02.c == null : s12.equals(h02.c)) && ((bl = this.d) == null ? h02.d == null : bl.equals((Object)h02.d)) && this.e == h02.e;
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 ^ this.a.hashCode());
        s1 s12 = this.b;
        int n3 = s12 == null ? 0 : s12.hashCode();
        int n5 = 1000003 * (n2 ^ n3);
        s1 s13 = this.c;
        int n6 = s13 == null ? 0 : s13.hashCode();
        int n7 = 1000003 * (n5 ^ n6);
        Boolean bl = this.d;
        int n8 = bl == null ? 0 : bl.hashCode();
        return 1000003 * (n7 ^ n8) ^ this.e;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Application{execution=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", customAttributes=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", internalKeys=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", background=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", uiOrientation=");
        return xe1.j((StringBuilder)stringBuilder, (int)this.e, (String)"}");
    }
}

