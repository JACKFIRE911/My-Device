/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a3.b
 *  a3.d
 *  a3.h0
 *  a3.k
 *  a3.k0
 *  a3.l
 *  a3.q
 *  a3.s
 *  android.app.KeyguardManager
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.AssetFileDescriptor
 *  android.content.res.AssetManager
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Point
 *  android.graphics.Rect
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.Looper
 *  android.os.Parcel
 *  android.os.ParcelFileDescriptor
 *  android.os.Parcelable
 *  android.text.TextUtils
 *  android.util.Base64
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.widget.AdapterView
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  android.widget.ScrollView
 *  b3.c
 *  c.a
 *  com.bumptech.glide.b
 *  com.bumptech.glide.c
 *  com.bumptech.glide.g
 *  com.bumptech.glide.h
 *  com.bumptech.glide.l
 *  com.bumptech.glide.load.data.f
 *  com.bumptech.glide.load.data.h
 *  com.bumptech.glide.load.data.m
 *  com.google.android.gms.internal.ads.a5
 *  com.google.android.gms.internal.ads.ax0
 *  com.google.android.gms.internal.ads.b1
 *  com.google.android.gms.internal.ads.bm
 *  com.google.android.gms.internal.ads.cq0
 *  com.google.android.gms.internal.ads.dx0
 *  com.google.android.gms.internal.ads.ev0
 *  com.google.android.gms.internal.ads.ey0
 *  com.google.android.gms.internal.ads.fk0
 *  com.google.android.gms.internal.ads.fy0
 *  com.google.android.gms.internal.ads.gr
 *  com.google.android.gms.internal.ads.h41
 *  com.google.android.gms.internal.ads.hv0
 *  com.google.android.gms.internal.ads.i5
 *  com.google.android.gms.internal.ads.jm
 *  com.google.android.gms.internal.ads.k1
 *  com.google.android.gms.internal.ads.kl0
 *  com.google.android.gms.internal.ads.ko
 *  com.google.android.gms.internal.ads.l50
 *  com.google.android.gms.internal.ads.lv0
 *  com.google.android.gms.internal.ads.mv0
 *  com.google.android.gms.internal.ads.n4
 *  com.google.android.gms.internal.ads.ng0
 *  com.google.android.gms.internal.ads.o4
 *  com.google.android.gms.internal.ads.oo0
 *  com.google.android.gms.internal.ads.q0
 *  com.google.android.gms.internal.ads.qv0
 *  com.google.android.gms.internal.ads.rd
 *  com.google.android.gms.internal.ads.s
 *  com.google.android.gms.internal.ads.s90
 *  com.google.android.gms.internal.ads.sd
 *  com.google.android.gms.internal.ads.sx0
 *  com.google.android.gms.internal.ads.tl0
 *  com.google.android.gms.internal.ads.ud
 *  com.google.android.gms.internal.ads.vd
 *  com.google.android.gms.internal.ads.vx0
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.gms.internal.ads.yt0
 *  com.google.android.gms.internal.measurement.o3
 *  d3.a
 *  d3.a0
 *  d3.b
 *  d3.c
 *  d3.f
 *  d3.f0
 *  d3.g
 *  d3.l
 *  d3.s
 *  e3.a
 *  e3.d
 *  f3.a
 *  f3.c
 *  f3.j
 *  g2.d
 *  j2.c
 *  j2.l
 *  j2.q
 *  j2.w
 *  java.io.Closeable
 *  java.io.File
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.OutputStream
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.net.URL
 *  java.nio.Buffer
 *  java.nio.BufferUnderflowException
 *  java.nio.ByteBuffer
 *  java.nio.ByteOrder
 *  java.nio.channels.FileChannel
 *  java.nio.charset.Charset
 *  java.security.DigestException
 *  java.security.GeneralSecurityException
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 *  java.security.cert.CertificateException
 *  java.security.cert.CertificateFactory
 *  java.security.cert.X509Certificate
 *  java.text.ParseException
 *  java.text.SimpleDateFormat
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Date
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Set
 *  java.util.SortedSet
 *  java.util.TimeZone
 *  m8.d
 *  o2.k
 *  org.json.JSONException
 *  org.json.JSONObject
 *  q2.b
 *  q2.i
 *  q2.s
 *  t2.a
 *  u2.c
 *  u2.f
 *  u2.m
 *  u2.n
 *  v4.p
 *  v4.r
 *  x2.d
 *  x2.h
 *  x4.b0
 *  x4.g0
 *  x4.x
 *  y0.b
 *  y7.f
 */
package a8;

import a3.c0;
import a3.h0;
import a3.k;
import a3.k0;
import android.app.KeyguardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Point;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Looper;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ScrollView;
import com.bumptech.glide.g;
import com.bumptech.glide.load.data.h;
import com.bumptech.glide.load.data.m;
import com.google.android.gms.internal.ads.a5;
import com.google.android.gms.internal.ads.ax0;
import com.google.android.gms.internal.ads.bm;
import com.google.android.gms.internal.ads.cq0;
import com.google.android.gms.internal.ads.dx0;
import com.google.android.gms.internal.ads.ev0;
import com.google.android.gms.internal.ads.ey0;
import com.google.android.gms.internal.ads.fk0;
import com.google.android.gms.internal.ads.fy0;
import com.google.android.gms.internal.ads.gr;
import com.google.android.gms.internal.ads.h41;
import com.google.android.gms.internal.ads.hv0;
import com.google.android.gms.internal.ads.i5;
import com.google.android.gms.internal.ads.jm;
import com.google.android.gms.internal.ads.k1;
import com.google.android.gms.internal.ads.kl0;
import com.google.android.gms.internal.ads.ko;
import com.google.android.gms.internal.ads.l50;
import com.google.android.gms.internal.ads.lv0;
import com.google.android.gms.internal.ads.mv0;
import com.google.android.gms.internal.ads.n4;
import com.google.android.gms.internal.ads.ng0;
import com.google.android.gms.internal.ads.o4;
import com.google.android.gms.internal.ads.oo0;
import com.google.android.gms.internal.ads.q0;
import com.google.android.gms.internal.ads.qv0;
import com.google.android.gms.internal.ads.rd;
import com.google.android.gms.internal.ads.s90;
import com.google.android.gms.internal.ads.sd;
import com.google.android.gms.internal.ads.sx0;
import com.google.android.gms.internal.ads.tl0;
import com.google.android.gms.internal.ads.ud;
import com.google.android.gms.internal.ads.vd;
import com.google.android.gms.internal.ads.vx0;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.gms.internal.ads.yt0;
import com.google.android.gms.internal.measurement.o3;
import d3.a0;
import d3.e0;
import d3.f0;
import d3.s;
import e3.a;
import e3.d;
import f3.j;
import j2.l;
import j2.q;
import j2.w;
import java.io.Closeable;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.nio.Buffer;
import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.security.DigestException;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TimeZone;
import org.json.JSONException;
import org.json.JSONObject;
import q2.i;
import u2.c;
import u2.f;
import u2.n;
import v4.p;
import v4.r;
import x4.b0;
import x4.g0;
import x4.x;
import y0.b;

public abstract class b1 {
    public static String A = "";
    public static String B = "";
    public static String C = "";
    public static String D = "";
    public static String E = "";
    public static String F = "";
    public static String G = "";
    public static String H = "";
    public static String I = "";
    public static String J = "";
    public static String K = "";
    public static String L = "";
    public static String M = "";
    public static String N = "";
    public static String O = "";
    public static String P = "";
    public static String Q = "";
    public static String R = "";
    public static String S = "";
    public static String T = "";
    public static String U = "";
    public static boolean V = false;
    public static boolean W = false;
    public static boolean X = false;
    public static boolean Y = false;
    public static double Z = 0.0;
    public static final cq0 a = new cq0(4);
    public static double a0 = 0.0;
    public static final cq0 b = new cq0(19);
    public static double b0 = 0.0;
    public static final s90 c = new s90(3);
    public static double c0 = 0.0;
    public static final s90 d = new s90(19);
    public static double d0 = 0.0;
    public static final int[] e = new int[]{96000, 88200, 64000, 48000, 44100, 32000, 24000, 22050, 16000, 12000, 11025, 8000, 7350};
    public static double e0 = 0.0;
    public static final int[] f = new int[]{0, 1, 2, 3, 4, 5, 6, 8, -1, -1, -1, 7, 8, -1, 8, -1};
    public static double f0 = 0.0;
    public static final q g = new q(20);
    public static double g0 = 0.0;
    public static final g2.d h = new g2.d(21);
    public static double h0 = 0.0;
    public static String i = "";
    public static double i0 = 0.0;
    public static String j = "";
    public static double j0 = 0.0;
    public static String k = "";
    public static double k0 = 0.0;
    public static String l = "";
    public static double l0 = 0.0;
    public static String m = "";
    public static double m0 = 0.0;
    public static String n = "";
    public static double n0 = 0.0;
    public static String o = "";
    public static double o0 = 0.0;
    public static String p = "";
    public static int p0 = 0;
    public static String q = "";
    public static int q0 = 0;
    public static String r = "";
    public static int r0 = 0;
    public static String s = "";
    public static int s0 = 25;
    public static String t = "";
    public static int t0 = 0;
    public static String u = "";
    public static String v = "";
    public static String w = "";
    public static String x = "";
    public static String y = "";
    public static String z = "";

    public static void A(Parcel parcel, int n2, Bundle bundle) {
        if (bundle == null) {
            return;
        }
        int n3 = b1.M(parcel, n2);
        parcel.writeBundle(bundle);
        b1.b0(parcel, n3);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static JSONObject A0(View view) {
        ViewParent viewParent;
        JSONObject jSONObject;
        block8 : {
            ViewParent viewParent2;
            block7 : {
                jSONObject = new JSONObject();
                if (view == null) {
                    return jSONObject;
                }
                try {
                    rd rd2 = vd.x6;
                    boolean bl = (Boolean)r.d.c.a((sd)rd2);
                    if (bl) {
                        for (viewParent2 = view.getParent(); viewParent2 != null && !(viewParent2 instanceof ScrollView); viewParent2 = viewParent2.getParent()) {
                        }
                        break block7;
                    }
                    for (viewParent = view.getParent(); viewParent != null && !(viewParent instanceof AdapterView); viewParent = viewParent.getParent()) {
                    }
                    break block8;
                }
                catch (Exception exception) {}
                return jSONObject;
            }
            boolean bl = viewParent2 != null;
            jSONObject.put("contained_in_scroll_view", bl);
            return jSONObject;
        }
        int n2 = viewParent == null ? -1 : ((AdapterView)viewParent).getPositionForView(view);
        boolean bl = false;
        if (n2 != -1) {
            bl = true;
        }
        jSONObject.put("contained_in_scroll_view", bl);
        return jSONObject;
    }

    public static void B(Parcel parcel, int n2, byte[] arrby) {
        if (arrby == null) {
            return;
        }
        int n3 = b1.M(parcel, n2);
        parcel.writeByteArray(arrby);
        b1.b0(parcel, n3);
    }

    public static vx0 B0(byte[] arrby, int n2, int n3) {
        if (n3 >= arrby.length) {
            return dx0.r((Object)"");
        }
        ax0 ax02 = dx0.n();
        int n5 = b1.g0(arrby, n3, n2);
        while (n3 < n5) {
            Charset charset = b1.J0(n2);
            ax02.a((Object)new String(arrby, n3, n5 - n3, charset));
            n3 = n5 + b1.U(n2);
            n5 = b1.g0(arrby, n3, n2);
        }
        vx0 vx02 = ax02.f();
        if (vx02.isEmpty()) {
            vx02 = dx0.r((Object)"");
        }
        return vx02;
    }

    public static void C(Parcel parcel, int n2, IBinder iBinder) {
        if (iBinder == null) {
            return;
        }
        int n3 = b1.M(parcel, n2);
        parcel.writeStrongBinder(iBinder);
        b1.b0(parcel, n3);
    }

    /*
     * Exception decompiling
     */
    public static JSONObject C0(Context var0, View var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl360 : ALOAD_2 : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void D(Parcel parcel, int n2, int n3) {
        parcel.writeInt(n2 | 262144);
        parcel.writeInt(n3);
    }

    public static void D0(byte[] arrby, int n2) {
        arrby[1] = (byte)(n2 & 255);
        arrby[2] = (byte)(255 & n2 >>> 8);
        arrby[3] = (byte)(255 & n2 >>> 16);
        arrby[4] = (byte)(n2 >> 24);
    }

    public static void E(Parcel parcel, int n2, long l2) {
        parcel.writeInt(n2 | 524288);
        parcel.writeLong(l2);
    }

    public static String E0(byte[] arrby, int n2, int n3, Charset charset) {
        if (n3 > n2 && n3 <= arrby.length) {
            return new String(arrby, n2, n3 - n2, charset);
        }
        return "";
    }

    public static void F(Parcel parcel, int n2, Parcelable parcelable, int n3) {
        if (parcelable == null) {
            return;
        }
        int n5 = b1.M(parcel, n2);
        parcelable.writeToParcel(parcel, n3);
        b1.b0(parcel, n5);
    }

    public static boolean F0(Context context, oo0 oo02) {
        if (!oo02.N) {
            return false;
        }
        rd rd2 = vd.C6;
        r r2 = r.d;
        boolean bl = (Boolean)r2.c.a((sd)rd2);
        ud ud2 = r2.c;
        if (bl) {
            return (Boolean)ud2.a((sd)vd.F6);
        }
        String string = (String)ud2.a((sd)vd.D6);
        if (!string.isEmpty()) {
            if (context == null) {
                return false;
            }
            String string2 = context.getPackageName();
            Iterator iterator = h41.S((ev0)new ev0(';')).Y((CharSequence)string);
            while (((qv0)iterator).a()) {
                if (!((String)((qv0)iterator).b()).equals((Object)string2)) continue;
                return true;
            }
        }
        return false;
    }

    public static void G(Parcel parcel, int n2, String string) {
        if (string == null) {
            return;
        }
        int n3 = b1.M(parcel, n2);
        parcel.writeString(string);
        b1.b0(parcel, n3);
    }

    public static String G0(int n2, int n3, int n5, int n6, int n7) {
        if (n2 == 2) {
            Locale locale = Locale.US;
            Object[] arrobject = new Object[]{n3, n5, n6};
            return String.format((Locale)locale, (String)"%c%c%c", (Object[])arrobject);
        }
        Locale locale = Locale.US;
        Object[] arrobject = new Object[]{n3, n5, n6, n7};
        return String.format((Locale)locale, (String)"%c%c%c%c", (Object[])arrobject);
    }

    public static void H(Parcel parcel, int n2, String[] arrstring) {
        if (arrstring == null) {
            return;
        }
        int n3 = b1.M(parcel, n2);
        parcel.writeStringArray(arrstring);
        b1.b0(parcel, n3);
    }

    public static boolean H0(int n2) {
        rd rd2;
        rd rd3 = vd.J2;
        r r2 = r.d;
        return !((Boolean)r2.c.a((sd)rd3)).booleanValue() || ((Boolean)r2.c.a((sd)(rd2 = vd.K2))).booleanValue() || n2 <= 15299999;
        {
        }
    }

    public static void I(Parcel parcel, int n2, List list) {
        if (list == null) {
            return;
        }
        int n3 = b1.M(parcel, n2);
        parcel.writeStringList(list);
        b1.b0(parcel, n3);
    }

    public static byte[] I0(ByteBuffer byteBuffer) {
        int n2 = byteBuffer.getInt();
        if (n2 >= 0) {
            if (n2 <= byteBuffer.remaining()) {
                byte[] arrby = new byte[n2];
                byteBuffer.get(arrby);
                return arrby;
            }
            throw new IOException(xe1.h((String)"Underflow while reading length-prefixed value. Length: ", (int)n2, (String)", available: ", (int)byteBuffer.remaining()));
        }
        throw new IOException("Negative length");
    }

    public static void J(Parcel parcel, int n2, Parcelable[] arrparcelable, int n3) {
        if (arrparcelable == null) {
            return;
        }
        int n5 = b1.M(parcel, n2);
        int n6 = arrparcelable.length;
        parcel.writeInt(n6);
        for (int i2 = 0; i2 < n6; ++i2) {
            Parcelable parcelable = arrparcelable[i2];
            if (parcelable == null) {
                parcel.writeInt(0);
                continue;
            }
            b1.r0(parcel, parcelable, n3);
        }
        b1.b0(parcel, n5);
    }

    public static Charset J0(int n2) {
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    return hv0.b;
                }
                return hv0.c;
            }
            return hv0.d;
        }
        return hv0.f;
    }

    public static void K(Parcel parcel, int n2, List list) {
        if (list == null) {
            return;
        }
        int n3 = b1.M(parcel, n2);
        int n5 = list.size();
        parcel.writeInt(n5);
        for (int i2 = 0; i2 < n5; ++i2) {
            Parcelable parcelable = (Parcelable)list.get(i2);
            if (parcelable == null) {
                parcel.writeInt(0);
                continue;
            }
            b1.r0(parcel, parcelable, 0);
        }
        b1.b0(parcel, n3);
    }

    /*
     * Exception decompiling
     */
    public static X509Certificate[] K0(ByteBuffer var0, HashMap var1_1, CertificateFactory var2_2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Extractable last case doesn't follow previous
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:478)
        // org.benf.cfr.reader.b.a.a.b.as.a(SwitchReplacer.java:61)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:372)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static int L(int n2) {
        int[] arrn = new int[]{1, 2, 3};
        for (int i2 = 0; i2 < 3; ++i2) {
            int n3 = arrn[i2];
            int n5 = n3 - 1;
            if (n3 != 0) {
                if (n5 != n2) continue;
                return n3;
            }
            throw null;
        }
        return 1;
    }

    public static JSONObject L0(Context context, Rect rect) {
        JSONObject jSONObject = new JSONObject();
        int n2 = rect.right - rect.left;
        p p2 = p.f;
        jSONObject.put("width", p2.a.e(context, n2));
        int n3 = rect.bottom - rect.top;
        gr gr2 = p2.a;
        jSONObject.put("height", gr2.e(context, n3));
        jSONObject.put("x", gr2.e(context, rect.left));
        jSONObject.put("y", gr2.e(context, rect.top));
        jSONObject.put("relative_to", (Object)"self");
        return jSONObject;
    }

    public static int M(Parcel parcel, int n2) {
        parcel.writeInt(n2 | -65536);
        parcel.writeInt(0);
        return parcel.dataPosition();
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean M0(fk0 fk02, int n2, int n3, boolean bl) {
        int n5;
        int n6 = fk02.b;
        do {
            long l2;
            int n7;
            int n9;
            int n8;
            block18 : {
                int n10 = fk02.c - fk02.b;
                n5 = 1;
                if (n10 < n3) break;
                if (n2 >= 3) {
                    n7 = fk02.h();
                    l2 = fk02.t();
                    n9 = fk02.p();
                    break block18;
                }
                n7 = fk02.n();
                int n11 = fk02.n();
                l2 = n11;
                n9 = 0;
            }
            if (n7 == 0 && l2 == 0L && n9 == 0) {
                fk02.e(n6);
                return (boolean)n5;
            }
            if (n2 == 4 && !bl) {
                if ((0x808080L & l2) != 0L) {
                    fk02.e(n6);
                    return false;
                }
                long l3 = l2 & 255L;
                long l5 = l2 >> 8;
                long l6 = l2 >> 16;
                long l7 = l2 >> 24;
                long l8 = l5 & 255L;
                long l9 = l6 & 255L;
                l2 = l3 | l8 << 7 | l9 << 14 | l7 << 21;
            }
            if (n2 == 4) {
                if ((n9 & 64) == 0) {
                    n5 = 0;
                }
                int n12 = n9 & 1;
                int n13 = n5;
                n5 = n12;
                n8 = n13;
            } else if (n2 == 3) {
                n8 = (n9 & 32) != 0 ? n5 : 0;
                if ((n9 & 128) == 0) {
                    n5 = 0;
                }
            } else {
                n8 = 0;
                n5 = 0;
            }
            if (n5 != 0) {
                n8 += 4;
            }
            if (l2 < (long)n8) {
                fk02.e(n6);
                return false;
            }
            int n14 = fk02.c;
            int n15 = fk02.b;
            if ((long)(n14 - n15) < l2) {
                fk02.e(n6);
                return false;
            }
            int n16 = (int)l2;
            fk02.f(n16);
            continue;
            break;
        } while (true);
        fk02.e(n6);
        return (boolean)n5;
        catch (Throwable throwable) {
            fk02.e(n6);
            throw throwable;
        }
    }

    public static int N(Set set) {
        Iterator iterator = set.iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            Object object = iterator.next();
            int n3 = object != null ? object.hashCode() : 0;
            n2 += n3;
        }
        return n2;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static byte[][] N0(int[] arrn, n4[] arrn4) {
        String string2;
        int n2;
        String string;
        int n3 = 0;
        long l2 = 0L;
        for (int i2 = 0; i2 < 3; l2 += (1048575L + arrn4[i2].b()) / 0x100000L, ++i2) {
        }
        if (l2 >= 0x1FFFFFL) {
            StringBuilder stringBuilder = new StringBuilder("Too many chunks: ");
            stringBuilder.append(l2);
            throw new DigestException(stringBuilder.toString());
        }
        byte[][] arrarrby = new byte[arrn.length][];
        for (int i3 = 0; i3 < (n2 = arrn.length); ++i3) {
            int n5 = (int)l2;
            byte[] arrby = new byte[5 + n5 * b1.e0(arrn[i3])];
            arrby[0] = 90;
            b1.D0(arrby, n5);
            arrarrby[i3] = arrby;
        }
        byte[] arrby = new byte[5];
        arrby[0] = -91;
        MessageDigest[] arrmessageDigest = new MessageDigest[n2];
        int n6 = 0;
        do {
            int n7 = arrn.length;
            string2 = " digest not supported";
            if (n6 >= n7) break;
            String string3 = b1.p0(arrn[n6]);
            try {
                arrmessageDigest[n6] = MessageDigest.getInstance((String)string3);
                ++n6;
            }
            catch (NoSuchAlgorithmException noSuchAlgorithmException) {
                throw new RuntimeException(string3.concat(string2), (Throwable)noSuchAlgorithmException);
            }
        } while (true);
        long l3 = 0x100000L;
        int n8 = 3;
        long l5 = 0L;
        int n9 = 0;
        int n10 = 0;
        do {
            long l6;
            if (n3 >= n8) break;
            n4 n42 = arrn4[n3];
            long l7 = n42.b();
            String string4 = string2;
            long l8 = l3;
            long l9 = l5;
            int n11 = n3;
            int n12 = n9;
            for (long i4 = l7; i4 > l5; l9 += l6, i4 -= l6, ++n10) {
                int n13 = (int)Math.min((long)i4, (long)l8);
                b1.D0(arrby, n13);
                for (int i5 = 0; i5 < n2; ++i5) {
                    arrmessageDigest[i5].update(arrby);
                }
                try {
                    n42.r(arrmessageDigest, l9, n13);
                }
                catch (IOException iOException) {
                    throw new DigestException(xe1.h((String)"Failed to digest chunk #", (int)n10, (String)" of section #", (int)n12), (Throwable)iOException);
                }
                for (int i6 = 0; i6 < arrn.length; ++i6) {
                    int n14 = arrn[i6];
                    byte[] arrby2 = arrarrby[i6];
                    int n15 = b1.e0(n14);
                    byte[] arrby3 = arrby;
                    MessageDigest messageDigest = arrmessageDigest[i6];
                    int n16 = n10 * n15;
                    MessageDigest[] arrmessageDigest2 = arrmessageDigest;
                    int n17 = messageDigest.digest(arrby2, n16 + 5, n15);
                    if (n17 != n15) {
                        String string5 = messageDigest.getAlgorithm();
                        StringBuilder stringBuilder = new StringBuilder("Unexpected output size of ");
                        stringBuilder.append(string5);
                        stringBuilder.append(" digest: ");
                        stringBuilder.append(n17);
                        throw new RuntimeException(stringBuilder.toString());
                    }
                    arrby = arrby3;
                    arrmessageDigest = arrmessageDigest2;
                }
                byte[] arrby4 = arrby;
                MessageDigest[] arrmessageDigest3 = arrmessageDigest;
                l6 = n13;
                l5 = 0L;
                l8 = 0x100000L;
                arrby = arrby4;
                arrmessageDigest = arrmessageDigest3;
                continue;
            }
            byte[] arrby5 = arrby;
            n9 = n12 + 1;
            n3 = n11 + 1;
            l5 = 0L;
            n8 = 3;
            l3 = 0x100000L;
            string2 = string4;
            arrby = arrby5;
        } while (true);
        String string6 = string2;
        byte[][] arrarrby2 = new byte[arrn.length][];
        int n18 = 0;
        while (n18 < arrn.length) {
            int n19 = arrn[n18];
            byte[] arrby6 = arrarrby[n18];
            string = b1.p0(n19);
            MessageDigest messageDigest = MessageDigest.getInstance((String)string);
            arrarrby2[n18] = messageDigest.digest(arrby6);
            ++n18;
        }
        return arrarrby2;
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            throw new RuntimeException(string.concat(string6), (Throwable)noSuchAlgorithmException);
        }
    }

    public static long O(String string) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)"GMT"));
            long l2 = simpleDateFormat.parse(string).getTime();
            return l2;
        }
        catch (ParseException parseException) {
            if (!"0".equals((Object)string) && !"-1".equals((Object)string)) {
                Log.e((String)"Volley", (String)i5.d((String)"Unable to parse dateStr: %s, falling back to 0", (Object[])new Object[]{string}), (Throwable)parseException);
            } else {
                i5.c((String)"Unable to parse dateStr: %s, falling back to 0", (Object[])new Object[]{string});
            }
            return 0L;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static X509Certificate[][] O0(FileChannel fileChannel, o4 o42) {
        ByteBuffer byteBuffer;
        int n3;
        int n2;
        CertificateFactory certificateFactory;
        HashMap hashMap = new HashMap();
        ArrayList arrayList = new ArrayList();
        try {
            certificateFactory = CertificateFactory.getInstance((String)"X.509");
        }
        catch (CertificateException certificateException) {
            throw new RuntimeException("Failed to obtain X.509 CertificateFactory", (Throwable)certificateException);
        }
        try {
            byteBuffer = b1.z0((ByteBuffer)o42.d);
            n2 = 0;
            n3 = 0;
        }
        catch (IOException iOException) {
            throw new SecurityException("Failed to read list of signers", (Throwable)iOException);
        }
        while (byteBuffer.hasRemaining()) {
            void var35_11;
            ++n3;
            try {
                arrayList.add((Object)b1.K0(b1.z0(byteBuffer), hashMap, certificateFactory));
                continue;
            }
            catch (SecurityException securityException) {
                throw new SecurityException(xe1.g((String)"Failed to parse/verify signer #", (int)n3, (String)" block"), (Throwable)var35_11);
            }
            catch (BufferUnderflowException bufferUnderflowException) {
                throw new SecurityException(xe1.g((String)"Failed to parse/verify signer #", (int)n3, (String)" block"), (Throwable)var35_11);
            }
            catch (IOException iOException) {
                // empty catch block
            }
            throw new SecurityException(xe1.g((String)"Failed to parse/verify signer #", (int)n3, (String)" block"), (Throwable)var35_11);
        }
        if (n3 <= 0) throw new SecurityException("No signers found");
        if (hashMap.isEmpty()) throw new SecurityException("No content digests found");
        long l2 = o42.a;
        long l3 = o42.b;
        long l5 = o42.c;
        ByteBuffer byteBuffer2 = (ByteBuffer)o42.e;
        if (hashMap.isEmpty()) throw new SecurityException("No digests provided");
        x x2 = new x(fileChannel, 0L, l2);
        long l6 = l5 - l3;
        x x3 = new x(fileChannel, l3, l6);
        ByteBuffer byteBuffer3 = byteBuffer2.duplicate();
        byteBuffer3.order(ByteOrder.LITTLE_ENDIAN);
        y7.f.A0((ByteBuffer)byteBuffer3);
        int n5 = 16 + byteBuffer3.position();
        if (l2 >= 0L && l2 <= 0xFFFFFFFFL) {
            byte[][] arrby;
            byteBuffer3.putInt(n5 + byteBuffer3.position(), (int)l2);
            tl0 tl02 = new tl0(byteBuffer3);
            int n6 = hashMap.size();
            int[] arrn = new int[n6];
            Iterator iterator = hashMap.keySet().iterator();
            int n7 = 0;
            while (iterator.hasNext()) {
                arrn[n7] = (Integer)iterator.next();
                ++n7;
            }
            try {
                arrby = b1.N0(arrn, new n4[]{x2, x3, tl02});
            }
            catch (DigestException digestException) {
                throw new SecurityException("Failed to compute digest(s) of contents", (Throwable)digestException);
            }
            while (n2 < n6) {
                int n8 = arrn[n2];
                if (!MessageDigest.isEqual((byte[])((byte[])hashMap.get((Object)n8)), (byte[])arrby[n2])) throw new SecurityException(b1.p0(n8).concat(" digest of contents did not verify"));
                ++n2;
            }
            return (X509Certificate[][])arrayList.toArray((Object[])new X509Certificate[arrayList.size()][]);
        }
        StringBuilder stringBuilder = new StringBuilder("uint32 value of out range: ");
        stringBuilder.append(l2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static String P(byte[] arrby) {
        int n2 = arrby.length;
        StringBuilder stringBuilder = new StringBuilder(n2 + n2);
        for (int i2 = 0; i2 < n2; ++i2) {
            int n3 = 255 & arrby[i2];
            stringBuilder.append("0123456789abcdef".charAt(n3 >> 4));
            stringBuilder.append("0123456789abcdef".charAt(n3 & 15));
        }
        return stringBuilder.toString();
    }

    public static final void Q(ByteBuffer byteBuffer, ByteBuffer byteBuffer2, ByteBuffer byteBuffer3, int n2) {
        if (n2 >= 0 && byteBuffer2.remaining() >= n2 && byteBuffer3.remaining() >= n2 && byteBuffer.remaining() >= n2) {
            for (int i2 = 0; i2 < n2; ++i2) {
                byteBuffer.put((byte)(byteBuffer2.get() ^ byteBuffer3.get()));
            }
            return;
        }
        throw new IllegalArgumentException("That combination of buffers, offsets and length to xor result in out-of-bond accesses.");
    }

    /*
     * Exception decompiling
     */
    public static boolean R(int var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl30 : ALOAD_2 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Exception decompiling
     */
    public static X509Certificate[][] S(String var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static int T(int n2) {
        int[] arrn = new int[]{1, 2, 3, 4, 5, 6};
        for (int i2 = 0; i2 < 6; ++i2) {
            int n3 = arrn[i2];
            int n5 = n3 - 1;
            if (n3 != 0) {
                if (n5 != n2) continue;
                return n3;
            }
            throw null;
        }
        return 1;
    }

    public static int U(int n2) {
        if (n2 != 0 && n2 != 3) {
            return 2;
        }
        return 1;
    }

    public static long V(fk0 fk02, int n2, int n3) {
        fk02.e(n2);
        if (fk02.c - fk02.b < 5) {
            return -9223372036854775807L;
        }
        int n5 = fk02.h();
        if ((8388608 & n5) != 0) {
            return -9223372036854775807L;
        }
        if ((8191 & n5 >> 8) != n3) {
            return -9223372036854775807L;
        }
        if ((n5 & 32) != 0 && fk02.m() >= 7 && fk02.c - fk02.b >= 7 && (16 & fk02.m()) == 16) {
            byte[] arrby = new byte[6];
            fk02.a(arrby, 0, 6);
            long l2 = arrby[0];
            long l3 = arrby[1];
            long l5 = arrby[2];
            long l6 = arrby[3];
            long l7 = arrby[4];
            long l8 = l2 & 255L;
            long l9 = l3 & 255L;
            long l10 = l5 & 255L;
            long l11 = l7 & 255L;
            long l12 = l6 & 255L;
            return l8 << 25 | l9 << 17 | l10 << 9 | l12 + l12 | l11 >> 7;
        }
        return -9223372036854775807L;
    }

    public static WindowManager.LayoutParams W() {
        WindowManager.LayoutParams layoutParams = new WindowManager.LayoutParams(-2, -2, 0, 0, -2);
        rd rd2 = vd.E6;
        layoutParams.flags = (Integer)r.d.c.a((sd)rd2);
        layoutParams.type = 2;
        layoutParams.gravity = 8388659;
        return layoutParams;
    }

    public static jm X(List list) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < list.size(); ++i2) {
            String string = (String)list.get(i2);
            String[] arrstring = string.split("=", 2);
            if (arrstring.length != 2) {
                ng0.d((String)"VorbisUtil", (String)"Failed to parse Vorbis comment: ".concat(string));
                continue;
            }
            if (arrstring[0].equals((Object)"METADATA_BLOCK_PICTURE")) {
                try {
                    arrayList.add((Object)q0.a((fk0)new fk0(Base64.decode((String)arrstring[1], (int)0))));
                }
                catch (RuntimeException runtimeException) {
                    ng0.e((String)"VorbisUtil", (String)"Failed to parse vorbis picture", (Exception)((Object)runtimeException));
                }
                continue;
            }
            arrayList.add((Object)new k1(arrstring[0], arrstring[1]));
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return new jm((List)arrayList);
    }

    public static ey0 Y(Set set, lv0 lv02) {
        if (set instanceof SortedSet) {
            SortedSet sortedSet = (SortedSet)set;
            if (sortedSet instanceof ey0) {
                ey0 ey02 = (ey0)sortedSet;
                lv0 lv03 = ey02.r;
                lv03.getClass();
                mv0 mv02 = new mv0(Arrays.asList((Object[])new lv0[]{lv03, lv02}));
                return new fy0((SortedSet)ey02.q, (lv0)mv02);
            }
            sortedSet.getClass();
            return new fy0(sortedSet, lv02);
        }
        if (set instanceof ey0) {
            ey0 ey03 = (ey0)set;
            lv0 lv04 = ey03.r;
            lv04.getClass();
            mv0 mv03 = new mv0(Arrays.asList((Object[])new lv0[]{lv04, lv02}));
            return new ey0((Set)ey03.q, (lv0)mv03);
        }
        set.getClass();
        return new ey0(set, lv02);
    }

    /*
     * Exception decompiling
     */
    public static q2.b Z(a5 var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void a(String string, boolean bl) {
        if (bl) {
            return;
        }
        throw new IllegalArgumentException(string);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static b a0(com.google.android.gms.internal.ads.s s2, boolean bl) {
        int n2;
        int n3;
        int n5;
        String string;
        block24 : {
            boolean bl2;
            int n6;
            int n7;
            int n8;
            block26 : {
                block25 : {
                    n7 = s2.d(5);
                    if (n7 == 31) {
                        n7 = 32 + s2.d(6);
                    }
                    n5 = b1.n0(s2);
                    n3 = s2.d(4);
                    string = xe1.f((String)"mp4a.40.", (int)n7);
                    n6 = 22;
                    if (n7 == 5 || n7 == 29) {
                        n5 = b1.n0(s2);
                        int n9 = s2.d(5);
                        if (n9 == 31) {
                            n9 = 32 + s2.d(6);
                        }
                        if ((n7 = n9) == n6) {
                            n3 = s2.d(4);
                        }
                    }
                    if (!bl) break block24;
                    n8 = 3;
                    if (n7 != 1 && n7 != 2 && n7 != n8 && n7 != 4 && n7 != 6 && n7 != 7 && n7 != 17) {
                        switch (n7) {
                            default: {
                                StringBuilder stringBuilder = new StringBuilder("Unsupported audio object type: ");
                                stringBuilder.append(n7);
                                throw ko.b((String)stringBuilder.toString());
                            }
                            case 19: 
                            case 20: 
                            case 21: 
                            case 22: 
                            case 23: 
                        }
                    }
                    if (s2.l()) {
                        ng0.d((String)"AacUtil", (String)"Unexpected frameLengthFlag = 1");
                    }
                    if (s2.l()) {
                        s2.j(14);
                    }
                    bl2 = s2.l();
                    if (n3 == 0) throw new UnsupportedOperationException();
                    if (n7 == 6) break block25;
                    if (n7 != 20) break block26;
                    n7 = 20;
                }
                s2.j(n8);
            }
            if (bl2) {
                if (n7 == n6) {
                    s2.j(16);
                } else {
                    n6 = n7;
                }
                if (n6 == 17 || n6 == 19 || n6 == 20 || n6 == 23) {
                    s2.j(n8);
                }
                s2.j(1);
            }
            switch (n7) {
                default: {
                    break;
                }
                case 17: 
                case 19: 
                case 20: 
                case 21: 
                case 22: 
                case 23: {
                    int n10 = s2.d(2);
                    if (n10 != 2) {
                        if (n10 != n8) {
                            break;
                        }
                    } else {
                        n8 = n10;
                    }
                    StringBuilder stringBuilder = new StringBuilder("Unsupported epConfig: ");
                    stringBuilder.append(n8);
                    throw ko.b((String)stringBuilder.toString());
                }
            }
        }
        if ((n2 = f[n3]) == -1) throw ko.a(null, null);
        return new b(n5, n2, string);
    }

    public static void b(boolean bl) {
        if (bl) {
            return;
        }
        throw new IllegalArgumentException();
    }

    public static void b0(Parcel parcel, int n2) {
        int n3 = parcel.dataPosition();
        parcel.setDataPosition(n2 - 4);
        parcel.writeInt(n3 - n2);
        parcel.setDataPosition(n3);
    }

    public static void c(String string, boolean bl) {
        if (bl) {
            return;
        }
        throw new IllegalArgumentException(string);
    }

    public static boolean c0(Object object, Map map) {
        if (map == object) {
            return true;
        }
        if (object instanceof Map) {
            Map map2 = (Map)object;
            return map.entrySet().equals((Object)map2.entrySet());
        }
        return false;
    }

    public static void d(yt0 yt02) {
        Looper looper = Looper.myLooper();
        if (looper != yt02.getLooper()) {
            String string = looper != null ? looper.getThread().getName() : "null current looper";
            String string2 = yt02.getLooper().getThread().getName();
            StringBuilder stringBuilder = new StringBuilder("Must be called on ");
            stringBuilder.append(string2);
            stringBuilder.append(" thread, but got ");
            stringBuilder.append(string);
            stringBuilder.append(".");
            throw new IllegalStateException(stringBuilder.toString());
        }
    }

    public static /* varargs */ byte[] d0(byte[] ... arrby) {
        int n2;
        int n3 = 0;
        for (int i2 = 0; i2 < (n2 = arrby.length); ++i2) {
            int n5 = arrby[i2].length;
            if (n3 <= Integer.MAX_VALUE - n5) {
                n3 += n5;
                continue;
            }
            throw new GeneralSecurityException("exceeded size limit");
        }
        byte[] arrby2 = new byte[n3];
        int n6 = 0;
        for (int i3 = 0; i3 < n2; ++i3) {
            byte[] arrby3 = arrby[i3];
            int n7 = arrby3.length;
            System.arraycopy((Object)arrby3, (int)0, (Object)arrby2, (int)n6, (int)n7);
            n6 += n7;
        }
        return arrby2;
    }

    public static void e(String string) {
        boolean bl = Looper.getMainLooper() == Looper.myLooper();
        if (bl) {
            return;
        }
        throw new IllegalStateException(string);
    }

    public static int e0(int n2) {
        if (n2 != 1) {
            if (n2 == 2) {
                return 64;
            }
            throw new IllegalArgumentException(xe1.f((String)"Unknown content digest algorthm: ", (int)n2));
        }
        return 32;
    }

    public static void f(String string, String string2) {
        if (!TextUtils.isEmpty((CharSequence)string2)) {
            return;
        }
        throw new IllegalArgumentException(string);
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int f0(int n2) {
        if (n2 == 513) return 1;
        if (n2 == 514) return 2;
        if (n2 == 769) return 1;
        switch (n2) {
            default: {
                throw new IllegalArgumentException("Unknown signature algorithm: 0x".concat(String.valueOf((Object)Long.toHexString((long)n2))));
            }
            case 258: 
            case 260: {
                return 2;
            }
            case 257: 
            case 259: 
        }
        return 1;
    }

    public static void g(String string) {
        if (!TextUtils.isEmpty((CharSequence)string)) {
            return;
        }
        throw new IllegalArgumentException("Given String is empty or null");
    }

    public static int g0(byte[] arrby, int n2, int n3) {
        int n5 = b1.m0(n2, arrby);
        if (n3 != 0 && n3 != 3) {
            int n6;
            while (n5 < (n6 = arrby.length) - 1) {
                if ((n5 - n2) % 2 == 0 && arrby[n5 + 1] == 0) {
                    return n5;
                }
                n5 = b1.m0(n5 + 1, arrby);
            }
            return n6;
        }
        return n5;
    }

    public static void h(String string) {
        boolean bl = Looper.getMainLooper() == Looper.myLooper();
        if (!bl) {
            return;
        }
        throw new IllegalStateException(string);
    }

    public static l50 h0(fk0 fk02, boolean bl, boolean bl2) {
        int n2 = 0;
        if (bl) {
            b1.s0(3, fk02, false);
        }
        String string = fk02.y((int)fk02.r(), hv0.c);
        long l2 = fk02.r();
        String[] arrstring = new String[(int)l2];
        while ((long)n2 < l2) {
            arrstring[n2] = fk02.y((int)fk02.r(), hv0.c);
            ++n2;
        }
        if (bl2 && (1 & fk02.m()) == 0) {
            throw ko.a((String)"framing bit expected to be set", null);
        }
        return new l50(string, arrstring);
    }

    public static void i(Object object) {
        if (object != null) {
            return;
        }
        throw new NullPointerException("Argument must not be null");
    }

    public static ArrayList i0(byte[] arrby) {
        int n2 = 255 & arrby[11];
        int n3 = 255 & arrby[10];
        ArrayList arrayList = new ArrayList(3);
        arrayList.add((Object)arrby);
        long l2 = 1000000000L * (long)(n3 | n2 << 8) / 48000L;
        arrayList.add((Object)ByteBuffer.allocate((int)8).order(ByteOrder.nativeOrder()).putLong(l2).array());
        arrayList.add((Object)ByteBuffer.allocate((int)8).order(ByteOrder.nativeOrder()).putLong(80000000L).array());
        return arrayList;
    }

    public static void j(Object object, String string) {
        if (object != null) {
            return;
        }
        throw new NullPointerException(string);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static JSONObject j0(String string, Context context, Point point, Point point2) {
        JSONObject jSONObject;
        void var7_15;
        block6 : {
            jSONObject = null;
            JSONObject jSONObject2 = new JSONObject();
            try {
                JSONObject jSONObject3 = new JSONObject();
                try {
                    int n2 = point2.x;
                    p p2 = p.f;
                    jSONObject3.put("x", p2.a.e(context, n2));
                    int n3 = point2.y;
                    jSONObject3.put("y", p2.a.e(context, n3));
                    int n5 = point.x;
                    jSONObject3.put("start_x", p2.a.e(context, n5));
                    int n6 = point.y;
                    jSONObject3.put("start_y", p2.a.e(context, n6));
                    jSONObject = jSONObject3;
                }
                catch (JSONException jSONException) {
                    b0.h((String)"Error occurred while putting signals into JSON object.", (Throwable)jSONException);
                }
                jSONObject2.put("click_point", (Object)jSONObject);
                jSONObject2.put("asset_id", (Object)string);
                return jSONObject2;
            }
            catch (Exception exception) {
                jSONObject = jSONObject2;
            }
            break block6;
            catch (Exception exception) {
                // empty catch block
            }
        }
        b0.h((String)"Error occurred while grabbing click signals.", (Throwable)var7_15);
        return jSONObject;
    }

    public static void k(Object object) {
        if (object != null) {
            return;
        }
        throw new NullPointerException("null reference");
    }

    /*
     * Exception decompiling
     */
    public static boolean k0(Set var0, Object var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl25.1 : ICONST_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void l(String string, boolean bl) {
        if (bl) {
            return;
        }
        throw new IllegalStateException(String.valueOf((Object)string));
    }

    public static final byte[] l0(byte[] arrby, byte[] arrby2) {
        int n2 = arrby.length;
        if (n2 == arrby2.length) {
            return b1.u0(arrby, 0, arrby2, 0, n2);
        }
        throw new IllegalArgumentException("The lengths of x and y should match.");
    }

    public static void m(boolean bl) {
        if (bl) {
            return;
        }
        throw new IllegalStateException();
    }

    public static int m0(int n2, byte[] arrby) {
        int n3;
        while (n2 < (n3 = arrby.length)) {
            if (arrby[n2] == 0) {
                return n2;
            }
            ++n2;
        }
        return n3;
    }

    /*
     * Exception decompiling
     */
    public static void n(Closeable var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static int n0(com.google.android.gms.internal.ads.s s2) {
        int n2 = s2.d(4);
        if (n2 == 15) {
            if (s2.a() >= 24) {
                return s2.d(24);
            }
            throw ko.a((String)"AAC header insufficient data", null);
        }
        if (n2 < 13) {
            return e[n2];
        }
        throw ko.a((String)"AAC header wrong Sampling Frequency Index", null);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static long o(InputStream inputStream, OutputStream outputStream, boolean bl) {
        byte[] arrby = new byte[1024];
        long l2 = 0L;
        try {
            int n2;
            while ((n2 = inputStream.read(arrby, 0, 1024)) != -1) {
                l2 += (long)n2;
                outputStream.write(arrby, 0, n2);
            }
            if (!bl) return l2;
        }
        catch (Throwable throwable) {
            if (!bl) {
                throw throwable;
            }
            b1.n((Closeable)inputStream);
            b1.n((Closeable)outputStream);
            throw throwable;
        }
        b1.n((Closeable)inputStream);
        b1.n((Closeable)outputStream);
        return l2;
    }

    public static long o0(byte by, byte by2) {
        int n2;
        int n3 = by & 255;
        int n5 = n3 & 3;
        if (n5 != 0) {
            n2 = 2;
            if (n5 != 1 && n5 != n2) {
                n2 = by2 & 63;
            }
        } else {
            n2 = 1;
        }
        int n6 = n3 >> 3;
        int n7 = n6 & 3;
        int n8 = n6 >= 16 ? 2500 << n7 : (n6 >= 12 ? 10000 << (n7 & 1) : (n7 == 3 ? 60000 : 10000 << n7));
        return (long)n2 * (long)n8;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static com.bumptech.glide.l p(com.bumptech.glide.b b2, List list, o3 o32) {
        Resources resources;
        d3.f f2;
        int n2;
        o2.k k2;
        int n5;
        String string;
        d3.g g2;
        x2.d d2 = b2.q;
        g g3 = b2.s;
        Context context = g3.getApplicationContext();
        com.bumptech.glide.h h2 = g3.h;
        com.bumptech.glide.l l2 = new com.bumptech.glide.l();
        d3.l l3 = new d3.l();
        o2.k k3 = k2 = l2.g;
        synchronized (k3) {
            k2.a.add((Object)l3);
        }
        int n3 = Build.VERSION.SDK_INT;
        if (n3 >= 27) {
            l2.k((f)new s());
        }
        Resources resources2 = context.getResources();
        ArrayList arrayList = l2.f();
        x2.h h3 = b2.t;
        f3.a a2 = new f3.a(context, arrayList, d2, h3);
        f0 f02 = new f0(d2, (e0)new q(12));
        d3.p p2 = new d3.p(l2.f(), resources2.getDisplayMetrics(), d2, h3);
        if (n3 >= 28 && h2.a.containsKey(com.bumptech.glide.c.class)) {
            g2 = new d3.g(1);
            f2 = new d3.g(0);
        } else {
            f2 = new d3.f(p2, 0);
            g2 = new d3.a((Object)p2, 2, (Object)h3);
        }
        if (n3 >= 28) {
            n5 = n3;
            resources = resources2;
            l2.d((u2.m)new a(new l((Object)arrayList, 9, (Object)h3), 1), InputStream.class, Drawable.class, "Animation");
            l2.d((u2.m)new a(new l((Object)arrayList, 9, (Object)h3), 0), ByteBuffer.class, Drawable.class, "Animation");
        } else {
            n5 = n3;
            resources = resources2;
        }
        d d3 = new d(context);
        d3.b b3 = new d3.b(h3);
        kl0 kl02 = new kl0(5);
        g2.d d4 = new g2.d(14);
        ContentResolver contentResolver = context.getContentResolver();
        l2.b(ByteBuffer.class, (c)new q(8));
        l2.b(InputStream.class, (c)new c.a(20, (Object)h3));
        l2.d((u2.m)f2, ByteBuffer.class, Bitmap.class, "Bitmap");
        l2.d((u2.m)g2, InputStream.class, Bitmap.class, "Bitmap");
        String string2 = Build.FINGERPRINT;
        if (true ^ "robolectric".equals((Object)string2)) {
            string = "Animation";
            l2.d((u2.m)new d3.f(p2, 1), ParcelFileDescriptor.class, Bitmap.class, "Bitmap");
        } else {
            string = "Animation";
        }
        l2.d((u2.m)f02, ParcelFileDescriptor.class, Bitmap.class, "Bitmap");
        l2.d((u2.m)new f0(d2, (e0)new g2.d(null)), AssetFileDescriptor.class, Bitmap.class, "Bitmap");
        bm bm2 = bm.q;
        l2.a(Bitmap.class, Bitmap.class, (c0)bm2);
        l2.d((u2.m)new a0(0), Bitmap.class, Bitmap.class, "Bitmap");
        l2.c(Bitmap.class, (n)b3);
        Resources resources3 = resources;
        l2.d((u2.m)new d3.a(resources3, (u2.m)f2), ByteBuffer.class, BitmapDrawable.class, "BitmapDrawable");
        l2.d((u2.m)new d3.a(resources3, (u2.m)g2), InputStream.class, BitmapDrawable.class, "BitmapDrawable");
        l2.d((u2.m)new d3.a(resources3, (u2.m)f02), ParcelFileDescriptor.class, BitmapDrawable.class, "BitmapDrawable");
        l2.c(BitmapDrawable.class, (n)new j2.c((Object)d2, (Object)b3, 9));
        j j2 = new j(arrayList, a2, h3);
        String string3 = string;
        l2.d((u2.m)j2, InputStream.class, f3.c.class, string3);
        l2.d((u2.m)a2, ByteBuffer.class, f3.c.class, string3);
        l2.c(f3.c.class, (n)new q(13));
        l2.a(t2.a.class, t2.a.class, (c0)bm2);
        l2.d((u2.m)new d3.c(d2), t2.a.class, Bitmap.class, "Bitmap");
        l2.d((u2.m)d3, Uri.class, Drawable.class, "legacy_append");
        l2.d((u2.m)new d3.a((Object)d3, 1, (Object)d2), Uri.class, Bitmap.class, "legacy_append");
        l2.i((com.bumptech.glide.load.data.f)new h(2));
        l2.a(File.class, ByteBuffer.class, (c0)new a3.d(2));
        l2.a(File.class, InputStream.class, (c0)new a3.q(1));
        l2.d((u2.m)new a0(2), File.class, File.class, "legacy_append");
        l2.a(File.class, ParcelFileDescriptor.class, (c0)new a3.q(0));
        l2.a(File.class, File.class, (c0)bm2);
        l2.i((com.bumptech.glide.load.data.f)new m(h3));
        if (true ^ "robolectric".equals((Object)string2)) {
            l2.i((com.bumptech.glide.load.data.f)new h(1));
        }
        a3.l l5 = new a3.l(context, 2);
        a3.l l6 = new a3.l(context, 0);
        a3.l l7 = new a3.l(context, 1);
        Class class_ = Integer.TYPE;
        l2.a(class_, InputStream.class, (c0)l5);
        l2.a(Integer.class, InputStream.class, (c0)l5);
        l2.a(class_, AssetFileDescriptor.class, (c0)l6);
        l2.a(Integer.class, AssetFileDescriptor.class, (c0)l6);
        l2.a(class_, Drawable.class, (c0)l7);
        l2.a(Integer.class, Drawable.class, (c0)l7);
        l2.a(Uri.class, InputStream.class, (c0)new a3.l(context, 5));
        l2.a(Uri.class, AssetFileDescriptor.class, (c0)new a3.l(context, 4));
        h0 h02 = new h0(resources3, 2);
        h0 h03 = new h0(resources3, 0);
        h0 h04 = new h0(resources3, 1);
        l2.a(Integer.class, Uri.class, (c0)h02);
        l2.a(class_, Uri.class, (c0)h02);
        l2.a(Integer.class, AssetFileDescriptor.class, (c0)h03);
        l2.a(class_, AssetFileDescriptor.class, (c0)h03);
        l2.a(Integer.class, InputStream.class, (c0)h04);
        l2.a(class_, InputStream.class, (c0)h04);
        l2.a(String.class, InputStream.class, (c0)new k(0));
        l2.a(Uri.class, InputStream.class, (c0)new k(0));
        l2.a(String.class, InputStream.class, (c0)new a3.d(5));
        l2.a(String.class, ParcelFileDescriptor.class, (c0)new a3.d(4));
        l2.a(String.class, AssetFileDescriptor.class, (c0)new a3.d(3));
        l2.a(Uri.class, InputStream.class, (c0)new a3.b(context.getAssets(), 1));
        l2.a(Uri.class, AssetFileDescriptor.class, (c0)new a3.b(context.getAssets(), 0));
        l2.a(Uri.class, InputStream.class, (c0)new a3.l(context, 6));
        l2.a(Uri.class, InputStream.class, (c0)new a3.l(context, 7));
        if (n5 >= 29) {
            n2 = 1;
            l2.a(Uri.class, InputStream.class, (c0)new b3.c(context, n2));
            l2.a(Uri.class, ParcelFileDescriptor.class, (c0)new b3.c(context, 0));
        } else {
            n2 = 1;
        }
        l2.a(Uri.class, InputStream.class, (c0)new k0(contentResolver, 2));
        l2.a(Uri.class, ParcelFileDescriptor.class, (c0)new k0(contentResolver, n2));
        l2.a(Uri.class, AssetFileDescriptor.class, (c0)new k0(contentResolver, 0));
        l2.a(Uri.class, InputStream.class, (c0)new a3.d(6));
        l2.a(URL.class, InputStream.class, (c0)new a3.d(7));
        l2.a(Uri.class, File.class, (c0)new a3.l(context, 3));
        l2.a(a3.s.class, InputStream.class, (c0)new k(1));
        l2.a(byte[].class, ByteBuffer.class, (c0)new a3.d(0));
        l2.a(byte[].class, InputStream.class, (c0)new a3.d(1));
        l2.a(Uri.class, Uri.class, (c0)bm2);
        l2.a(Drawable.class, Drawable.class, (c0)bm2);
        l2.d((u2.m)new a0(1), Drawable.class, Drawable.class, "legacy_append");
        l2.j(Bitmap.class, BitmapDrawable.class, (g3.a)new c.a(resources3));
        l2.j(Bitmap.class, byte[].class, (g3.a)kl02);
        w w2 = new w((Object)d2, (Object)kl02, (Object)d4, 19, 0);
        l2.j(Drawable.class, byte[].class, (g3.a)w2);
        l2.j(f3.c.class, byte[].class, (g3.a)d4);
        f0 f03 = new f0(d2, (e0)new q(11));
        l2.d((u2.m)f03, ByteBuffer.class, Bitmap.class, "legacy_append");
        l2.d((u2.m)new d3.a(resources3, (u2.m)f03), ByteBuffer.class, BitmapDrawable.class, "legacy_append");
        Iterator iterator = list.iterator();
        if (iterator.hasNext()) {
            a2.s.z(iterator.next());
            throw null;
        }
        if (o32 != null) {
            o32.w(context, b2, l2);
        }
        return l2;
    }

    public static String p0(int n2) {
        if (n2 != 1) {
            if (n2 == 2) {
                return "SHA-512";
            }
            throw new IllegalArgumentException(xe1.f((String)"Unknown content digest algorthm: ", (int)n2));
        }
        return "SHA-256";
    }

    public static void q(Object object, String string, String string2) {
        String string3 = b1.s(string);
        if (Log.isLoggable((String)string3, (int)3)) {
            Log.d((String)string3, (String)String.format((String)string2, (Object[])new Object[]{object}));
        }
    }

    /*
     * Exception decompiling
     */
    public static JSONObject q0(Context var0, Map var1, Map var2, View var3, ImageView.ScaleType var4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void r(String string, String string2, Exception exception) {
        String string3 = b1.s(string);
        if (Log.isLoggable((String)string3, (int)6)) {
            Log.e((String)string3, (String)string2, (Throwable)exception);
        }
    }

    public static void r0(Parcel parcel, Parcelable parcelable, int n2) {
        int n3 = parcel.dataPosition();
        parcel.writeInt(1);
        int n5 = parcel.dataPosition();
        parcelable.writeToParcel(parcel, n2);
        int n6 = parcel.dataPosition();
        parcel.setDataPosition(n3);
        parcel.writeInt(n6 - n5);
        parcel.setDataPosition(n6);
    }

    public static String s(String string) {
        if (Build.VERSION.SDK_INT < 26) {
            String string2 = "TRuntime.".concat(string);
            if (string2.length() > 23) {
                string2 = string2.substring(0, 23);
            }
            return string2;
        }
        return "TRuntime.".concat(string);
    }

    public static boolean s0(int n2, fk0 fk02, boolean bl) {
        int n3 = fk02.c - fk02.b;
        if (n3 < 7) {
            if (bl) {
                return false;
            }
            StringBuilder stringBuilder = new StringBuilder("too short header: ");
            stringBuilder.append(n3);
            throw ko.a((String)stringBuilder.toString(), null);
        }
        if (fk02.m() != n2) {
            if (bl) {
                return false;
            }
            throw ko.a((String)"expected header type ".concat(String.valueOf((Object)Integer.toHexString((int)n2))), null);
        }
        if (fk02.m() == 118 && fk02.m() == 111 && fk02.m() == 114 && fk02.m() == 98 && fk02.m() == 105 && fk02.m() == 115) {
            return true;
        }
        if (bl) {
            return false;
        }
        throw ko.a((String)"expected characters 'vorbis'", null);
    }

    public static boolean t() {
        return Build.VERSION.SDK_INT >= 26;
    }

    public static boolean t0(Set set, Collection collection) {
        collection.getClass();
        if (collection instanceof sx0) {
            collection = ((sx0)collection).b();
        }
        boolean bl = collection instanceof Set;
        boolean bl2 = false;
        if (bl && collection.size() > set.size()) {
            Iterator iterator = set.iterator();
            while (iterator.hasNext()) {
                if (!collection.contains(iterator.next())) continue;
                iterator.remove();
                bl2 = true;
            }
            return bl2;
        }
        Iterator iterator = collection.iterator();
        while (iterator.hasNext()) {
            bl2 |= set.remove(iterator.next());
        }
        return bl2;
    }

    public static boolean u() {
        return Build.VERSION.SDK_INT >= 30;
    }

    public static final byte[] u0(byte[] arrby, int n2, byte[] arrby2, int n3, int n5) {
        if (arrby.length - n5 >= n2 && arrby2.length - n5 >= n3) {
            byte[] arrby3 = new byte[n5];
            for (int i2 = 0; i2 < n5; ++i2) {
                arrby3[i2] = (byte)(arrby[i2 + n2] ^ arrby2[i2 + n3]);
            }
            return arrby3;
        }
        throw new IllegalArgumentException("That combination of buffers, offsets and length to xor result in out-of-bond accesses.");
    }

    public static boolean v(Uri uri) {
        return uri != null && "content".equals((Object)uri.getScheme()) && "media".equals((Object)uri.getAuthority());
    }

    public static int v0(int n2, fk0 fk02) {
        int n3;
        int n5;
        byte[] arrby = fk02.a;
        int n6 = n5 = fk02.b;
        while ((n3 = n6 + 1) < n5 + n2) {
            if ((255 & arrby[n6]) == 255 && arrby[n3] == 0) {
                int n7 = n6 - n5;
                System.arraycopy((Object)arrby, (int)(n6 + 2), (Object)arrby, (int)n3, (int)(-2 + (n2 - n7)));
                --n2;
            }
            n6 = n3;
        }
        return n2;
    }

    /*
     * Exception decompiling
     */
    public static q2.b w(i var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static ByteBuffer w0(int n2, ByteBuffer byteBuffer) {
        int n3 = byteBuffer.limit();
        int n5 = byteBuffer.position();
        int n6 = n2 + n5;
        if (n6 >= n5 && n6 <= n3) {
            byteBuffer.limit(n6);
            try {
                ByteBuffer byteBuffer2 = byteBuffer.slice();
                byteBuffer2.order(byteBuffer.order());
                byteBuffer.position(n6);
                return byteBuffer2;
            }
            finally {
                byteBuffer.limit(n3);
            }
        }
        throw new BufferUnderflowException();
    }

    public static String x(Map map) {
        if (map == null) {
            return "utf-8";
        }
        String string = (String)map.get((Object)"Content-Type");
        if (string != null) {
            String[] arrstring = string.split(";", 0);
            for (int i2 = 1; i2 < arrstring.length; ++i2) {
                String[] arrstring2 = arrstring[i2].trim().split("=", 0);
                if (arrstring2.length != 2 || !arrstring2[0].equals((Object)"charset")) continue;
                return arrstring2[1];
            }
        }
        return "utf-8";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static JSONObject x0(Context context, View view) {
        boolean bl;
        JSONObject jSONObject = new JSONObject();
        if (view == null) {
            return jSONObject;
        }
        try {
            KeyguardManager keyguardManager;
            Object object;
            jSONObject.put("can_show_on_lock_screen", g0.y((View)view));
            bl = context != null && (keyguardManager = (object = context.getSystemService("keyguard")) != null && object instanceof KeyguardManager ? (KeyguardManager)object : null) != null && keyguardManager.isKeyguardLocked();
        }
        catch (JSONException jSONException) {
            b0.j((String)"Unable to get lock screen information");
            return jSONObject;
        }
        jSONObject.put("is_keyguard_locked", bl);
        return jSONObject;
    }

    public static long y(String string) {
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss zzz", Locale.US);
            simpleDateFormat.setTimeZone(TimeZone.getTimeZone((String)"GMT"));
            long l2 = simpleDateFormat.parse(string).getTime();
            return l2;
        }
        catch (ParseException parseException) {
            if (!"0".equals((Object)string) && !"-1".equals((Object)string)) {
                Log.e((String)"Volley", (String)q2.s.a((String)"Unable to parse dateStr: %s, falling back to 0", (Object[])new Object[]{string}), (Throwable)parseException);
            } else {
                q2.s.d((String)"Unable to parse dateStr: %s, falling back to 0", (Object[])new Object[]{string});
            }
            return 0L;
        }
    }

    /*
     * Exception decompiling
     */
    public static com.google.android.gms.internal.ads.b1 y0(int var0, fk0 var1_1, boolean var2_2, int var3_3, m8.d var4_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [7[TRYBLOCK]], but top level block is 14[FORLOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void z(Parcel parcel, int n2, boolean bl) {
        parcel.writeInt(n2 | 262144);
        parcel.writeInt((int)bl);
    }

    public static ByteBuffer z0(ByteBuffer byteBuffer) {
        if (byteBuffer.remaining() >= 4) {
            int n2 = byteBuffer.getInt();
            if (n2 >= 0) {
                if (n2 <= byteBuffer.remaining()) {
                    return b1.w0(n2, byteBuffer);
                }
                throw new IOException(xe1.h((String)"Length-prefixed field longer than remaining buffer. Field length: ", (int)n2, (String)", remaining: ", (int)byteBuffer.remaining()));
            }
            throw new IllegalArgumentException("Negative length");
        }
        throw new IOException(xe1.f((String)"Remaining buffer too short to contain length of length-prefixed field. Remaining: ", (int)byteBuffer.remaining()));
    }
}

