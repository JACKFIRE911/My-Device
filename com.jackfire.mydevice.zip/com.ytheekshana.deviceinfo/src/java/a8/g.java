/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.c1;
import a8.d0;
import h8.c;
import h8.d;
import h8.e;

public final class g
implements d {
    public static final g a = new g();
    public static final c b = c.b("identifier");
    public static final c c = c.b("version");
    public static final c d = c.b("displayVersion");
    public static final c e = c.b("organization");
    public static final c f = c.b("installationUuid");
    public static final c g = c.b("developmentPlatform");
    public static final c h = c.b("developmentPlatformVersion");

    @Override
    public final void a(Object object, Object object2) {
        c1 c12 = (c1)object;
        e e3 = (e)object2;
        d0 d02 = (d0)c12;
        String string = d02.a;
        e3.f(b, string);
        String string2 = d02.b;
        e3.f(c, string2);
        e3.f(d, d02.c);
        e3.f(e, null);
        e3.f(f, d02.d);
        e3.f(g, d02.e);
        e3.f(h, d02.f);
    }
}

