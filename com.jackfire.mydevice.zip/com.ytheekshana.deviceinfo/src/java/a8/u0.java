/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;

public final class u0 {
    public final int a;
    public final String b;
    public final int c;
    public final long d;
    public final long e;
    public final boolean f;
    public final int g;
    public final String h;
    public final String i;

    public u0(int n2, String string, int n3, long l2, long l3, boolean bl, int n5, String string2, String string3) {
        this.a = n2;
        if (string != null) {
            this.b = string;
            this.c = n3;
            this.d = l2;
            this.e = l3;
            this.f = bl;
            this.g = n5;
            if (string2 != null) {
                this.h = string2;
                if (string3 != null) {
                    this.i = string3;
                    return;
                }
                throw new NullPointerException("Null modelClass");
            }
            throw new NullPointerException("Null manufacturer");
        }
        throw new NullPointerException("Null model");
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof u0) {
            u0 u02 = (u0)object;
            int n2 = u02.a;
            return this.a == n2 && this.b.equals((Object)u02.b) && this.c == u02.c && this.d == u02.d && this.e == u02.e && this.f == u02.f && this.g == u02.g && this.h.equals((Object)u02.h) && this.i.equals((Object)u02.i);
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 * (1000003 * (1000003 ^ this.a) ^ this.b.hashCode()) ^ this.c);
        long l2 = this.d;
        int n3 = 1000003 * (n2 ^ (int)(l2 ^ l2 >>> 32));
        long l3 = this.e;
        int n5 = 1000003 * (n3 ^ (int)(l3 ^ l3 >>> 32));
        int n6 = this.f ? 1231 : 1237;
        return 1000003 * (1000003 * (1000003 * (n5 ^ n6) ^ this.g) ^ this.h.hashCode()) ^ this.i.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("DeviceData{arch=");
        stringBuilder.append(this.a);
        stringBuilder.append(", model=");
        stringBuilder.append(this.b);
        stringBuilder.append(", availableProcessors=");
        stringBuilder.append(this.c);
        stringBuilder.append(", totalRam=");
        stringBuilder.append(this.d);
        stringBuilder.append(", diskSpace=");
        stringBuilder.append(this.e);
        stringBuilder.append(", isEmulator=");
        stringBuilder.append(this.f);
        stringBuilder.append(", state=");
        stringBuilder.append(this.g);
        stringBuilder.append(", manufacturer=");
        stringBuilder.append(this.h);
        stringBuilder.append(", modelClass=");
        return s.v(stringBuilder, this.i, "}");
    }
}

