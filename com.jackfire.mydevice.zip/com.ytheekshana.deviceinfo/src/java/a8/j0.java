/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.e1;

public final class j0
extends e1 {
    public final long a;
    public final long b;
    public final String c;
    public final String d;

    public j0(long l3, long l4, String string, String string2) {
        this.a = l3;
        this.b = l4;
        this.c = string;
        this.d = string2;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof e1) {
            e1 e12 = (e1)object;
            long l3 = ((j0)e12).a;
            if (this.a == l3) {
                j0 j02 = (j0)e12;
                if (this.b == j02.b && this.c.equals((Object)j02.c)) {
                    String string = j02.d;
                    String string2 = this.d;
                    if (string2 == null ? string == null : string2.equals((Object)string)) {
                        return true;
                    }
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        long l3 = this.a;
        int n2 = 1000003 * (1000003 ^ (int)(l3 ^ l3 >>> 32));
        long l4 = this.b;
        int n3 = 1000003 * (1000003 * (n2 ^ (int)(l4 ^ l4 >>> 32)) ^ this.c.hashCode());
        String string = this.d;
        int n5 = string == null ? 0 : string.hashCode();
        return n3 ^ n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("BinaryImage{baseAddress=");
        stringBuilder.append(this.a);
        stringBuilder.append(", size=");
        stringBuilder.append(this.b);
        stringBuilder.append(", name=");
        stringBuilder.append(this.c);
        stringBuilder.append(", uuid=");
        return s.v(stringBuilder, this.d, "}");
    }
}

