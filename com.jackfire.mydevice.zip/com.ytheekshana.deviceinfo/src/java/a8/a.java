/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.w0;
import a8.y;
import h8.c;
import h8.d;
import h8.e;

public final class a
implements d {
    public static final a a = new a();
    public static final c b = c.b("arch");
    public static final c c = c.b("libraryName");
    public static final c d = c.b("buildId");

    @Override
    public final void a(Object object, Object object2) {
        w0 w02 = (w0)object;
        e e3 = (e)object2;
        y y2 = (y)w02;
        String string = y2.a;
        e3.f(b, string);
        String string2 = y2.b;
        e3.f(c, string2);
        e3.f(d, y2.c);
    }
}

