/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.a0;
import a8.a1;
import a8.s1;
import h8.c;
import h8.d;

public final class e
implements d {
    public static final e a = new e();
    public static final c b = c.b("files");
    public static final c c = c.b("orgId");

    @Override
    public final void a(Object object, Object object2) {
        a1 a12 = (a1)object;
        h8.e e3 = (h8.e)object2;
        a0 a02 = (a0)a12;
        s1 s12 = a02.a;
        e3.f(b, s12);
        e3.f(c, a02.b);
    }
}

