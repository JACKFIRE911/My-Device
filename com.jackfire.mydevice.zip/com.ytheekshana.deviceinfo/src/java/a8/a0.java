/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.a1;
import a8.s1;

public final class a0
extends a1 {
    public final s1 a;
    public final String b;

    public a0(s1 s12, String string) {
        this.a = s12;
        this.b = string;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof a1) {
            String string;
            a1 a12 = (a1)object;
            s1 s12 = ((a0)a12).a;
            return this.a.equals(s12) && ((string = this.b) == null ? ((a0)a12).b == null : string.equals((Object)((a0)a12).b));
        }
        return false;
    }

    public final int hashCode() {
        int n2 = 1000003 * (1000003 ^ this.a.hashCode());
        String string = this.b;
        int n3 = string == null ? 0 : string.hashCode();
        return n2 ^ n3;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("FilesPayload{files=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", orgId=");
        return s.v(stringBuilder, this.b, "}");
    }
}

