/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package a8;

import a8.a1;
import a8.q1;
import a8.r1;
import a8.w;
import a8.x0;
import h8.c;
import h8.e;

public final class d
implements h8.d {
    public static final d a = new d();
    public static final c b = c.b("sdkVersion");
    public static final c c = c.b("gmpAppId");
    public static final c d = c.b("platform");
    public static final c e = c.b("installationUuid");
    public static final c f = c.b("buildVersion");
    public static final c g = c.b("displayVersion");
    public static final c h = c.b("session");
    public static final c i = c.b("ndkPayload");
    public static final c j = c.b("appExitInfo");

    @Override
    public final void a(Object object, Object object2) {
        r1 r12 = (r1)object;
        e e3 = (e)object2;
        w w3 = (w)r12;
        String string = w3.b;
        e3.f(b, string);
        String string2 = w3.c;
        e3.f(c, string2);
        e3.c(d, w3.d);
        e3.f(e, w3.e);
        e3.f(f, w3.f);
        e3.f(g, w3.g);
        e3.f(h, w3.h);
        e3.f(i, w3.i);
        e3.f(j, w3.j);
    }
}

