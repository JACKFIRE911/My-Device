/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 */
package a8;

import a8.h0;
import a8.j1;
import a8.k1;
import a8.s1;
import h8.c;
import h8.d;
import h8.e;

public final class k
implements d {
    public static final k a = new k();
    public static final c b = c.b("execution");
    public static final c c = c.b("customAttributes");
    public static final c d = c.b("internalKeys");
    public static final c e = c.b("background");
    public static final c f = c.b("uiOrientation");

    @Override
    public final void a(Object object, Object object2) {
        k1 k12 = (k1)object;
        e e3 = (e)object2;
        h0 h02 = (h0)k12;
        j1 j12 = h02.a;
        e3.f(b, j12);
        s1 s12 = h02.b;
        e3.f(c, s12);
        e3.f(d, h02.c);
        e3.f(e, (Object)h02.d);
        e3.c(f, h02.e);
    }
}

