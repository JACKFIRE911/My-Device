/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 */
package a8;

import a8.z0;
import java.util.Arrays;

public final class b0
extends z0 {
    public final String a;
    public final byte[] b;

    public b0(String string, byte[] arrby) {
        this.a = string;
        this.b = arrby;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof z0) {
            z0 z02 = (z0)object;
            String string = ((b0)z02).a;
            if (this.a.equals((Object)string)) {
                b0 b02 = z02 instanceof b0 ? (b0)z02 : (b0)z02;
                byte[] arrby = b02.b;
                if (Arrays.equals((byte[])this.b, (byte[])arrby)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 * (1000003 ^ this.a.hashCode()) ^ Arrays.hashCode((byte[])this.b);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("File{filename=");
        stringBuilder.append(this.a);
        stringBuilder.append(", contents=");
        stringBuilder.append(Arrays.toString((byte[])this.b));
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

