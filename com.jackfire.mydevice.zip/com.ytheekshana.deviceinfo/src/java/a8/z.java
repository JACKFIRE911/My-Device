/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a8;

import a2.s;
import a8.y0;

public final class z
extends y0 {
    public final String a;
    public final String b;

    public z(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof y0) {
            y0 y02 = (y0)object;
            String string = ((z)y02).a;
            if (this.a.equals((Object)string)) {
                z z2 = (z)y02;
                if (this.b.equals((Object)z2.b)) {
                    return true;
                }
            }
            return false;
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 * (1000003 ^ this.a.hashCode()) ^ this.b.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CustomAttribute{key=");
        stringBuilder.append(this.a);
        stringBuilder.append(", value=");
        return s.v(stringBuilder, this.b, "}");
    }
}

