/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  c2.b
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  t8.c
 */
package c2;

import a2.r;
import c2.b;
import java.util.HashMap;
import t8.c;

public final class a {
    public static final String d = r.f("DelayedWorkTracker");
    public final b a;
    public final c b;
    public final HashMap c;

    public a(b b4, c c2) {
        this.a = b4;
        this.b = c2;
        this.c = new HashMap();
    }
}

