/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.text.TextUtils
 *  androidx.appcompat.widget.j
 *  j2.l
 *  j2.o
 *  j2.w
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  t8.c
 */
package c2;

import a2.d;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.text.TextUtils;
import b2.a0;
import b2.c;
import b2.p;
import b2.r;
import b2.t;
import c2.a;
import j2.f;
import j2.j;
import j2.l;
import j2.o;
import j2.s;
import j2.w;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import k2.m;

public final class b
implements r,
f2.b,
c {
    public static final String z = a2.r.f("GreedyScheduler");
    public final Context q;
    public final a0 r;
    public final f2.c s;
    public final HashSet t = new HashSet();
    public final a u;
    public boolean v;
    public final Object w;
    public final l x = new l(3);
    public Boolean y;

    public b(Context context, a2.b b4, o o5, a0 a02) {
        this.q = context;
        this.r = a02;
        this.s = new f2.c(o5, this);
        this.u = new a(this, b4.e);
        this.w = new Object();
    }

    @Override
    public final void a(String string) {
        Runnable runnable;
        Boolean bl = this.y;
        a0 a02 = this.r;
        if (bl == null) {
            a2.b b4 = a02.r;
            this.y = m.a(this.q, b4);
        }
        boolean bl2 = this.y;
        String string2 = z;
        if (!bl2) {
            a2.r.d().e(string2, "Ignoring schedule request in non-main process");
            return;
        }
        if (!this.v) {
            a02.v.a(this);
            this.v = true;
        }
        a2.r r4 = a2.r.d();
        StringBuilder stringBuilder = new StringBuilder("Cancelling work ID ");
        stringBuilder.append(string);
        r4.a(string2, stringBuilder.toString());
        a a3 = this.u;
        if (a3 != null && (runnable = (Runnable)a3.c.remove((Object)string)) != null) {
            ((Handler)a3.b.r).removeCallbacks(runnable);
        }
        Iterator iterator = this.x.u(string).iterator();
        while (iterator.hasNext()) {
            a02.d0((t)iterator.next());
        }
    }

    @Override
    public final void b(ArrayList arrayList) {
        Iterator iterator = arrayList.iterator();
        while (iterator.hasNext()) {
            j j3 = f.d((s)iterator.next());
            a2.r r4 = a2.r.d();
            StringBuilder stringBuilder = new StringBuilder("Constraints not met: Cancelling work ID ");
            stringBuilder.append((Object)j3);
            String string = stringBuilder.toString();
            r4.a(z, string);
            t t2 = this.x.t(j3);
            if (t2 == null) continue;
            this.r.d0(t2);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void c(j j3, boolean bl) {
        Object object;
        this.x.t(j3);
        Object object2 = object = this.w;
        synchronized (object2) {
            for (s s3 : this.t) {
                if (!f.d(s3).equals(j3)) continue;
                a2.r r4 = a2.r.d();
                String string = z;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Stopping tracking for ");
                stringBuilder.append((Object)j3);
                r4.a(string, stringBuilder.toString());
                this.t.remove((Object)s3);
                this.s.c((Iterable)this.t);
                break;
            }
            return;
        }
    }

    @Override
    public final void d(List list) {
        Iterator iterator = ((ArrayList)list).iterator();
        while (iterator.hasNext()) {
            l l3 = this.x;
            j j3 = f.d((s)iterator.next());
            if (l3.m(j3)) continue;
            a2.r r4 = a2.r.d();
            StringBuilder stringBuilder = new StringBuilder("Constraints met: Scheduling work ID ");
            stringBuilder.append((Object)j3);
            String string = stringBuilder.toString();
            r4.a(z, string);
            t t2 = l3.v(j3);
            this.r.c0(t2, null);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final /* varargs */ void e(s ... arrs) {
        Object object;
        if (this.y == null) {
            a2.b b4 = this.r.r;
            this.y = m.a(this.q, b4);
        }
        if (!this.y.booleanValue()) {
            a2.r.d().e(z, "Ignoring schedule request in a secondary process");
            return;
        }
        if (!this.v) {
            this.r.v.a(this);
            this.v = true;
        }
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        for (s s3 : arrs) {
            j j3 = f.d(s3);
            if (this.x.m(j3)) continue;
            long l3 = s3.a();
            long l6 = System.currentTimeMillis();
            if (s3.b != 1) continue;
            if (l6 < l3) {
                a a3 = this.u;
                if (a3 == null) continue;
                HashMap hashMap = a3.c;
                Runnable runnable = (Runnable)hashMap.remove((Object)s3.a);
                t8.c c4 = a3.b;
                if (runnable != null) {
                    ((Handler)c4.r).removeCallbacks(runnable);
                }
                androidx.appcompat.widget.j j5 = new androidx.appcompat.widget.j((Object)a3, 8, (Object)s3);
                hashMap.put((Object)s3.a, (Object)j5);
                long l7 = System.currentTimeMillis();
                long l8 = s3.a() - l7;
                ((Handler)c4.r).postDelayed((Runnable)j5, l8);
                continue;
            }
            if (s3.c()) {
                int n5 = Build.VERSION.SDK_INT;
                d d4 = s3.j;
                if (d4.c) {
                    a2.r r4 = a2.r.d();
                    String string = z;
                    StringBuilder stringBuilder = new StringBuilder("Ignoring ");
                    stringBuilder.append((Object)s3);
                    stringBuilder.append(". Requires device idle.");
                    r4.a(string, stringBuilder.toString());
                    continue;
                }
                if (n5 >= 24 && true ^ ((Collection)d4.h).isEmpty()) {
                    a2.r r5 = a2.r.d();
                    String string = z;
                    StringBuilder stringBuilder = new StringBuilder("Ignoring ");
                    stringBuilder.append((Object)s3);
                    stringBuilder.append(". Requires ContentUri triggers.");
                    r5.a(string, stringBuilder.toString());
                    continue;
                }
                hashSet.add((Object)s3);
                hashSet2.add((Object)s3.a);
                continue;
            }
            if (this.x.m(f.d(s3))) continue;
            a2.r r6 = a2.r.d();
            String string = z;
            StringBuilder stringBuilder = new StringBuilder("Starting work for ");
            stringBuilder.append(s3.a);
            r6.a(string, stringBuilder.toString());
            a0 a02 = this.r;
            l l9 = this.x;
            l9.getClass();
            a02.c0(l9.v(f.d(s3)), null);
        }
        Object object2 = object = this.w;
        synchronized (object2) {
            if (!hashSet.isEmpty()) {
                String string = TextUtils.join((CharSequence)",", (Iterable)hashSet2);
                a2.r r7 = a2.r.d();
                String string2 = z;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Starting tracking for ");
                stringBuilder.append(string);
                r7.a(string2, stringBuilder.toString());
                this.t.addAll((Collection)hashSet);
                this.s.c((Iterable)this.t);
            }
            return;
        }
    }

    @Override
    public final boolean f() {
        return false;
    }
}

