/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IInterface
 *  java.lang.Object
 */
package a;

import android.os.IInterface;

public interface e
extends IInterface {
}

