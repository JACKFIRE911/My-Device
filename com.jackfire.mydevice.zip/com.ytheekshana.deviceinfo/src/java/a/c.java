/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  java.lang.Object
 */
package a;

import a.e;
import android.os.IBinder;

public final class c
implements e {
    public final IBinder q;

    public c(IBinder iBinder) {
        this.q = iBinder;
    }

    public final IBinder asBinder() {
        return this.q;
    }
}

