/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Binder
 */
package a;

import a.e;
import android.os.Binder;

public abstract class d
extends Binder
implements e {
    public static final /* synthetic */ int q;
}

