/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.net.URL
 */
package c4;

import java.net.URL;

public final class c {
    public final int a;
    public final URL b;
    public final long c;

    public c(int n2, URL uRL, long l2) {
        this.a = n2;
        this.b = uRL;
        this.c = l2;
    }
}

