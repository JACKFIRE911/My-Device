/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 *  java.util.regex.Pattern
 */
package c4;

import b4.b;
import e4.k;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.regex.Pattern;
import y7.f;

public final class a
implements k {
    public static final String c;
    public static final Set d;
    public static final a e;
    public final String a;
    public final String b;

    public static {
        String string;
        c = string = f.x("hts/frbslgiggolai.o/0clgbthfra=snpoo", "tp:/ieaeogn.ogepscmvc/o/ac?omtjo_rt3");
        f.x("hts/frbslgigp.ogepscmv/ieo/eaybtho", "tp:/ieaeogn-agolai.o/1frlglgc/aclg");
        f.x("AzSCki82AwsLzKd5O8zo", "IayckHiZRO1EFl1aGoK");
        Object[] arrobject = new b[]{new b("proto"), new b("json")};
        d = Collections.unmodifiableSet((Set)new HashSet((Collection)Arrays.asList((Object[])arrobject)));
        e = new a(string, null);
    }

    public a(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public static a a(byte[] arrby) {
        String string = new String(arrby, Charset.forName((String)"UTF-8"));
        if (string.startsWith("1$")) {
            String[] arrstring = string.substring(2).split(Pattern.quote((String)"\\"), 2);
            if (arrstring.length == 2) {
                String string2 = arrstring[0];
                if (!string2.isEmpty()) {
                    String string3 = arrstring[1];
                    if (string3.isEmpty()) {
                        string3 = null;
                    }
                    return new a(string2, string3);
                }
                throw new IllegalArgumentException("Missing endpoint in CCTDestination extras");
            }
            throw new IllegalArgumentException("Extra is not a valid encoded LegacyFlgDestination");
        }
        throw new IllegalArgumentException("Version marker missing from extras");
    }
}

