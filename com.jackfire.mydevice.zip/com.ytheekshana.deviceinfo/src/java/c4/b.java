/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.net.URL
 */
package c4;

import d4.p;
import java.net.URL;

public final class b {
    public final URL a;
    public final p b;
    public final String c;

    public b(URL uRL, p p2, String string) {
        this.a = uRL;
        this.b = p2;
        this.c = string;
    }
}

