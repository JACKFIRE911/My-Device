/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.net.ConnectivityManager
 *  android.net.NetworkInfo
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.telephony.TelephonyManager
 *  android.util.SparseArray
 *  androidx.fragment.app.t
 *  com.google.android.gms.internal.ads.bm
 *  j8.d
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.net.MalformedURLException
 *  java.net.URL
 *  java.util.Calendar
 *  java.util.Locale
 *  java.util.Map
 *  java.util.TimeZone
 */
package c4;

import a8.b1;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.telephony.TelephonyManager;
import android.util.SparseArray;
import androidx.fragment.app.t;
import c4.a;
import c8.b;
import com.google.android.gms.internal.ads.bm;
import d4.u;
import e4.h;
import f4.g;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Calendar;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import u7.c;

public final class d
implements g {
    public final t a;
    public final ConnectivityManager b;
    public final Context c;
    public final URL d;
    public final m4.a e;
    public final m4.a f;
    public final int g;

    public d(Context context, m4.a a3, m4.a a4) {
        URL uRL;
        j8.d d4 = new j8.d();
        bm.E.q((i8.a)d4);
        d4.d = true;
        this.a = new t((Object)d4);
        this.c = context;
        this.b = (ConnectivityManager)context.getSystemService("connectivity");
        String string = a.c;
        try {}
        catch (MalformedURLException malformedURLException) {
            throw new IllegalArgumentException(c.c("Invalid url: ", string), (Throwable)malformedURLException);
        }
        this.d = uRL = new URL(string);
        this.e = a4;
        this.f = a3;
        this.g = 130000;
    }

    public final h a(h h3) {
        int n5;
        int n6;
        b b4;
        block6 : {
            block4 : {
                block5 : {
                    NetworkInfo networkInfo = this.b.getActiveNetworkInfo();
                    b4 = h3.c();
                    int n7 = Build.VERSION.SDK_INT;
                    b4.h().put((Object)"sdk-version", (Object)String.valueOf((int)n7));
                    b4.a("model", Build.MODEL);
                    b4.a("hardware", Build.HARDWARE);
                    b4.a("device", Build.DEVICE);
                    b4.a("product", Build.PRODUCT);
                    b4.a("os-uild", Build.ID);
                    b4.a("manufacturer", Build.MANUFACTURER);
                    b4.a("fingerprint", Build.FINGERPRINT);
                    Calendar.getInstance();
                    long l3 = TimeZone.getDefault().getOffset(Calendar.getInstance().getTimeInMillis()) / 1000;
                    b4.h().put((Object)"tz-offset", (Object)String.valueOf((long)l3));
                    n5 = -1;
                    int n8 = networkInfo == null ? n5 : networkInfo.getType();
                    b4.h().put((Object)"net-type", (Object)String.valueOf((int)n8));
                    if (networkInfo == null) break block4;
                    n6 = networkInfo.getSubtype();
                    if (n6 != n5) break block5;
                    n6 = 100;
                    break block6;
                }
                if ((u)((Object)u.q.get(n6)) != null) break block6;
            }
            n6 = 0;
        }
        b4.h().put((Object)"mobile-subtype", (Object)String.valueOf((int)n6));
        b4.a("country", Locale.getDefault().getCountry());
        b4.a("locale", Locale.getDefault().getLanguage());
        Context context = this.c;
        b4.a("mcc_mnc", ((TelephonyManager)context.getSystemService("phone")).getSimOperator());
        try {
            n5 = context.getPackageManager().getPackageInfo((String)context.getPackageName(), (int)0).versionCode;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            b1.r("CctTransportBackend", "Unable to find version code for package", (Exception)((Object)nameNotFoundException));
        }
        b4.a("application_build", Integer.toString((int)n5));
        return b4.e();
    }
}

