/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  java.io.File
 *  java.lang.Class
 *  java.lang.Object
 */
package b3;

import a3.b0;
import a3.c0;
import a3.g0;
import android.content.Context;
import android.net.Uri;
import b3.e;
import java.io.File;

public abstract class b
implements c0 {
    public final Context q;
    public final Class r;

    public b(Context context, Class class_) {
        this.q = context;
        this.r = class_;
    }

    @Override
    public final b0 i(g0 g02) {
        Class class_ = this.r;
        b0 b02 = g02.c(File.class, class_);
        b0 b03 = g02.c(Uri.class, class_);
        return new e(this.q, b02, b03, class_);
    }
}

