/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  com.bumptech.glide.load.data.e
 *  java.lang.Class
 *  java.lang.Object
 *  l3.b
 *  u2.k
 */
package b3;

import a3.a0;
import a3.b0;
import a8.b1;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import b3.d;
import l3.b;
import u2.h;
import u2.k;

public final class e
implements b0 {
    public final Context a;
    public final b0 b;
    public final b0 c;
    public final Class d;

    public e(Context context, b0 b02, b0 b03, Class class_) {
        this.a = context.getApplicationContext();
        this.b = b02;
        this.c = b03;
        this.d = class_;
    }

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        Uri uri = (Uri)object;
        b b4 = new b((Object)uri);
        d d4 = new d(this.a, this.b, this.c, uri, n2, n3, k3, this.d);
        return new a0((h)b4, d4);
    }

    @Override
    public final boolean b(Object object) {
        Uri uri = (Uri)object;
        return Build.VERSION.SDK_INT >= 29 && b1.v(uri);
    }
}

