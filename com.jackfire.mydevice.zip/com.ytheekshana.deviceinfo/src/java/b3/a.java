/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.bumptech.glide.load.data.e
 *  com.bumptech.glide.load.data.l
 *  java.lang.Integer
 *  java.lang.Object
 *  java.util.ArrayDeque
 *  u2.k
 *  u7.e
 */
package b3;

import a3.a0;
import a3.b0;
import a3.s;
import a3.z;
import com.bumptech.glide.load.data.l;
import java.util.ArrayDeque;
import m3.i;
import u2.h;
import u2.j;
import u2.k;
import u7.e;

public final class a
implements b0 {
    public static final j b = j.a(2500, "com.bumptech.glide.load.model.stream.HttpGlideUrlLoader.Timeout");
    public final e a;

    public a(e e4) {
        this.a = e4;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        ArrayDeque arrayDeque;
        s s3 = (s)object;
        e e4 = this.a;
        if (e4 == null) return new a0(s3, (com.bumptech.glide.load.data.e)new l(s3, ((Integer)k3.c(b)).intValue()));
        z z2 = z.a(s3);
        Object object2 = ((i)e4.r).a(z2);
        ArrayDeque arrayDeque2 = arrayDeque = z.d;
        synchronized (arrayDeque2) {
            arrayDeque.offer((Object)z2);
        }
        s s4 = (s)object2;
        if (s4 == null) {
            z z3 = z.a(s3);
            ((i)e4.r).d(z3, s3);
            return new a0(s3, (com.bumptech.glide.load.data.e)new l(s3, ((Integer)k3.c(b)).intValue()));
        }
        s3 = s4;
        return new a0(s3, (com.bumptech.glide.load.data.e)new l(s3, ((Integer)k3.c(b)).intValue()));
    }
}

