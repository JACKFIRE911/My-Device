/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.text.TextUtils
 *  androidx.appcompat.widget.o1
 *  com.bumptech.glide.i
 *  com.bumptech.glide.load.data.d
 *  com.bumptech.glide.load.data.e
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  u2.k
 */
package b3;

import a3.a0;
import a3.b0;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import androidx.appcompat.widget.o1;
import com.bumptech.glide.i;
import com.bumptech.glide.load.data.e;
import java.io.File;
import java.io.FileNotFoundException;
import u2.a;
import u2.k;

public final class d
implements e {
    public static final String[] A = new String[]{"_data"};
    public final Context q;
    public final b0 r;
    public final b0 s;
    public final Uri t;
    public final int u;
    public final int v;
    public final k w;
    public final Class x;
    public volatile boolean y;
    public volatile e z;

    public d(Context context, b0 b02, b0 b03, Uri uri, int n2, int n3, k k3, Class class_) {
        this.q = context.getApplicationContext();
        this.r = b02;
        this.s = b03;
        this.t = uri;
        this.u = n2;
        this.v = n3;
        this.w = k3;
        this.x = class_;
    }

    public final Class a() {
        return this.x;
    }

    public final void b() {
        e e4 = this.z;
        if (e4 != null) {
            e4.b();
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final e c() {
        block8 : {
            block7 : {
                block9 : {
                    block6 : {
                        var1_1 = o1.w();
                        var2_2 = null;
                        var3_3 = this.w;
                        var4_4 = this.v;
                        var5_5 = this.u;
                        var6_6 = this.q;
                        if (!var1_1) break block7;
                        var11_7 = this.t;
                        var13_8 = var6_6.getContentResolver().query(var11_7, d.A, null, null, null);
                        if (var13_8 == null) ** GOTO lbl25
                        if (!var13_8.moveToFirst()) ** GOTO lbl25
                        var16_9 = var13_8.getString(var13_8.getColumnIndexOrThrow("_data"));
                        if (TextUtils.isEmpty((CharSequence)var16_9)) break block6;
                        var17_10 = new File(var16_9);
                        var13_8.close();
                        var9_11 = this.r.a((Object)var17_10, var5_5, var4_4, var3_3);
                        break block8;
                    }
                    try {
                        var18_12 = new StringBuilder("File path was empty in media store for: ");
                        var18_12.append((Object)var11_7);
                        throw new FileNotFoundException(var18_12.toString());
lbl25: // 2 sources:
                        var14_13 = new StringBuilder("Failed to media store entry for: ");
                        var14_13.append((Object)var11_7);
                        throw new FileNotFoundException(var14_13.toString());
                    }
                    catch (Throwable var12_14) {
                        var2_2 = var13_8;
                    }
                    break block9;
                    catch (Throwable var12_15) {
                        // empty catch block
                    }
                }
                if (var2_2 == null) throw var12_16;
                var2_2.close();
                throw var12_16;
            }
            var7_17 = var6_6.checkSelfPermission("android.permission.ACCESS_MEDIA_LOCATION") == 0;
            var8_18 = this.t;
            if (var7_17) {
                var8_18 = o1.k((Uri)var8_18);
            }
            var9_11 = this.s.a((Object)var8_18, var5_5, var4_4, var3_3);
        }
        var10_19 = null;
        if (var9_11 == null) return var10_19;
        return var9_11.c;
    }

    public final void cancel() {
        this.y = true;
        e e4 = this.z;
        if (e4 != null) {
            e4.cancel();
        }
    }

    public final a d() {
        return a.q;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void f(i i3, com.bumptech.glide.load.data.d d4) {
        try {
            e e4 = this.c();
            if (e4 == null) {
                StringBuilder stringBuilder = new StringBuilder("Failed to build fetcher for: ");
                stringBuilder.append((Object)this.t);
                d4.c((Exception)((Object)new IllegalArgumentException(stringBuilder.toString())));
                return;
            }
            this.z = e4;
            if (this.y) {
                this.cancel();
                return;
            }
            e4.f(i3, d4);
            return;
        }
        catch (FileNotFoundException fileNotFoundException) {
            d4.c((Exception)((Object)fileNotFoundException));
            return;
        }
    }
}

