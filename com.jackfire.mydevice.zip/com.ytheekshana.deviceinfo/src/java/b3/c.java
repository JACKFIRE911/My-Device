/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.ParcelFileDescriptor
 *  java.io.InputStream
 *  java.lang.Class
 */
package b3;

import android.content.Context;
import android.os.ParcelFileDescriptor;
import b3.b;
import java.io.InputStream;

public final class c
extends b {
    public c(Context context, int n3) {
        if (n3 != 1) {
            super(context, ParcelFileDescriptor.class);
            return;
        }
        super(context, InputStream.class);
    }
}

