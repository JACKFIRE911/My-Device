/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a8.a0
 *  a8.c0
 *  a8.d0
 *  a8.f0
 *  a8.g0
 *  a8.h0
 *  a8.i0
 *  a8.k0
 *  a8.l0
 *  a8.n0
 *  a8.o0
 *  a8.p0
 *  a8.q0
 *  a8.r0
 *  a8.w
 *  a8.x
 *  a8.z
 *  android.util.Base64
 *  android.util.JsonReader
 *  androidx.biometric.u
 *  androidx.fragment.app.t
 *  com.google.android.gms.internal.measurement.c
 *  com.google.android.gms.internal.measurement.n3
 *  i8.a
 *  j2.i
 *  j2.p
 *  j4.l
 *  j8.d
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.List
 *  m8.d
 */
package b8;

import a4.g;
import a8.a0;
import a8.c0;
import a8.d0;
import a8.f0;
import a8.f1;
import a8.g0;
import a8.g1;
import a8.h0;
import a8.i0;
import a8.j1;
import a8.k0;
import a8.l0;
import a8.n0;
import a8.o0;
import a8.p0;
import a8.q0;
import a8.r0;
import a8.r1;
import a8.s1;
import a8.w;
import a8.x;
import a8.x0;
import a8.z;
import android.util.Base64;
import android.util.JsonReader;
import androidx.biometric.u;
import androidx.fragment.app.t;
import c8.b;
import com.google.android.gms.internal.measurement.c;
import com.google.android.gms.internal.measurement.n3;
import j2.i;
import j2.p;
import j4.l;
import j8.d;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.List;

public final class a {
    public static final t a;

    public static {
        d d2 = new d();
        m8.d.t.r((i8.a)d2);
        d2.d = true;
        a = new t((Object)d2);
    }

    public static n0 a(JsonReader jsonReader) {
        u u2 = new u(10);
        jsonReader.beginObject();
        block14 : while (jsonReader.hasNext()) {
            String string = jsonReader.nextName();
            string.getClass();
            int n2 = string.hashCode();
            int n3 = -1;
            switch (n2) {
                default: {
                    break;
                }
                case 2125650548: {
                    if (!string.equals((Object)"importance")) break;
                    n3 = 4;
                    break;
                }
                case 3143036: {
                    if (!string.equals((Object)"file")) break;
                    n3 = 3;
                    break;
                }
                case 3571: {
                    if (!string.equals((Object)"pc")) break;
                    n3 = 2;
                    break;
                }
                case -887523944: {
                    if (!string.equals((Object)"symbol")) break;
                    n3 = 1;
                    break;
                }
                case -1019779949: {
                    if (!string.equals((Object)"offset")) break;
                    n3 = 0;
                }
            }
            switch (n3) {
                default: {
                    jsonReader.skipValue();
                    continue block14;
                }
                case 4: {
                    u2.u = jsonReader.nextInt();
                    continue block14;
                }
                case 3: {
                    u2.s = jsonReader.nextString();
                    continue block14;
                }
                case 2: {
                    u2.q = jsonReader.nextLong();
                    continue block14;
                }
                case 1: {
                    String string2 = jsonReader.nextString();
                    if (string2 != null) {
                        u2.r = string2;
                        continue block14;
                    }
                    throw new NullPointerException("Null symbol");
                }
                case 0: 
            }
            u2.t = jsonReader.nextLong();
        }
        jsonReader.endObject();
        return u2.c();
    }

    public static z b(JsonReader jsonReader) {
        n3 n32 = new n3(23);
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String string = jsonReader.nextName();
            string.getClass();
            if (!string.equals((Object)"key")) {
                if (!string.equals((Object)"value")) {
                    jsonReader.skipValue();
                    continue;
                }
                String string2 = jsonReader.nextString();
                if (string2 != null) {
                    n32.s = string2;
                    continue;
                }
                throw new NullPointerException("Null value");
            }
            String string3 = jsonReader.nextString();
            if (string3 != null) {
                n32.r = string3;
                continue;
            }
            throw new NullPointerException("Null key");
        }
        jsonReader.endObject();
        return n32.d();
    }

    public static x c(JsonReader jsonReader) {
        l l2 = new l(6);
        jsonReader.beginObject();
        block22 : while (jsonReader.hasNext()) {
            String string = jsonReader.nextName();
            string.getClass();
            int n2 = string.hashCode();
            int n5 = -1;
            switch (n2) {
                default: {
                    break;
                }
                case 2125650548: {
                    if (!string.equals((Object)"importance")) break;
                    n5 = 8;
                    break;
                }
                case 723857505: {
                    if (!string.equals((Object)"traceFile")) break;
                    n5 = 7;
                    break;
                }
                case 722137681: {
                    if (!string.equals((Object)"reasonCode")) break;
                    n5 = 6;
                    break;
                }
                case 202325402: {
                    if (!string.equals((Object)"processName")) break;
                    n5 = 5;
                    break;
                }
                case 55126294: {
                    if (!string.equals((Object)"timestamp")) break;
                    n5 = 4;
                    break;
                }
                case 113234: {
                    if (!string.equals((Object)"rss")) break;
                    n5 = 3;
                    break;
                }
                case 111312: {
                    if (!string.equals((Object)"pss")) break;
                    n5 = 2;
                    break;
                }
                case 110987: {
                    if (!string.equals((Object)"pid")) break;
                    n5 = 1;
                    break;
                }
                case -1516200806: {
                    if (!string.equals((Object)"buildIdMappingForArch")) break;
                    n5 = 0;
                }
            }
            switch (n5) {
                default: {
                    jsonReader.skipValue();
                    continue block22;
                }
                case 8: {
                    l2.t = jsonReader.nextInt();
                    continue block22;
                }
                case 7: {
                    l2.x = jsonReader.nextString();
                    continue block22;
                }
                case 6: {
                    l2.s = jsonReader.nextInt();
                    continue block22;
                }
                case 5: {
                    String string2 = jsonReader.nextString();
                    if (string2 != null) {
                        l2.r = string2;
                        continue block22;
                    }
                    throw new NullPointerException("Null processName");
                }
                case 4: {
                    l2.w = jsonReader.nextLong();
                    continue block22;
                }
                case 3: {
                    l2.v = jsonReader.nextLong();
                    continue block22;
                }
                case 2: {
                    l2.u = jsonReader.nextLong();
                    continue block22;
                }
                case 1: {
                    l2.q = jsonReader.nextInt();
                    continue block22;
                }
                case 0: 
            }
            l2.y = a.d(jsonReader, new p(23));
        }
        jsonReader.endObject();
        return l2.b();
    }

    public static s1 d(JsonReader jsonReader, p p2) {
        ArrayList arrayList = new ArrayList();
        jsonReader.beginArray();
        while (jsonReader.hasNext()) {
            arrayList.add(p2.d(jsonReader));
        }
        jsonReader.endArray();
        return new s1((List)arrayList);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static g0 e(JsonReader var0) {
        var1_1 = new u(6);
        var0.beginObject();
        block68 : do {
            block80 : {
                if (!var0.hasNext()) {
                    var0.endObject();
                    return var1_1.a();
                }
                var2_2 = var0.nextName();
                var2_2.getClass();
                switch (var2_2.hashCode()) {
                    case 55126294: {
                        if (!var2_2.equals((Object)"timestamp")) break;
                        var4_3 = 4;
                        ** break;
                    }
                    case 3575610: {
                        if (!var2_2.equals((Object)"type")) break;
                        var4_3 = 3;
                        ** break;
                    }
                    case 107332: {
                        if (!var2_2.equals((Object)"log")) break;
                        var4_3 = 2;
                        ** break;
                    }
                    case 96801: {
                        if (!var2_2.equals((Object)"app")) break;
                        var4_3 = 1;
                        ** break;
                    }
                    case -1335157162: {
                        if (var2_2.equals((Object)"device")) break block80;
                    }
                }
                var4_3 = -1;
                ** break;
            }
            var4_3 = 0;
lbl32: // 6 sources:
            var5_4 = "";
            var6_5 = null;
            switch (var4_3) {
                default: {
                    var0.skipValue();
                    continue block68;
                }
                case 4: {
                    var1_1.q = var0.nextLong();
                    continue block68;
                }
                case 3: {
                    var38_32 = var0.nextString();
                    if (var38_32 == null) throw new NullPointerException("Null type");
                    var1_1.r = var38_32;
                    continue block68;
                }
                case 2: {
                    var0.beginObject();
                    while (var0.hasNext()) {
                        var36_31 = var0.nextName();
                        var36_31.getClass();
                        if (!var36_31.equals((Object)"content")) {
                            var0.skipValue();
                            continue;
                        }
                        var6_5 = var0.nextString();
                        if (var6_5 == null) throw new NullPointerException("Null content");
                    }
                    var0.endObject();
                    if (var6_5 == null) {
                        var5_4 = " content";
                    }
                    if (var5_4.isEmpty() == false) throw new IllegalStateException("Missing required properties:".concat(var5_4));
                    var1_1.u = new p0(var6_5);
                    continue block68;
                }
                case 1: {
                    var0.beginObject();
                    var11_9 = null;
                    var12_10 = null;
                    var13_11 = null;
                    var14_12 = null;
                    var15_13 = null;
                    block70 : while (var0.hasNext()) {
                        var17_15 = var0.nextName();
                        var17_15.getClass();
                        switch (var17_15.hashCode()) {
                            case 928737948: {
                                if (!var17_15.equals((Object)"uiOrientation")) break;
                                var19_16 = 4;
                                ** break;
                            }
                            case 555169704: {
                                if (!var17_15.equals((Object)"customAttributes")) break;
                                var19_16 = 3;
                                ** break;
                            }
                            case -80231855: {
                                if (!var17_15.equals((Object)"internalKeys")) break;
                                var19_16 = 2;
                                ** break;
                            }
                            case -1090974952: {
                                if (!var17_15.equals((Object)"execution")) break;
                                var19_16 = 1;
                                ** break;
                            }
                            case -1332194002: {
                                if (var17_15.equals((Object)"background")) ** GOTO lbl94
                            }
                        }
                        var19_16 = -1;
                        ** break;
lbl94: // 1 sources:
                        var19_16 = 0;
lbl95: // 6 sources:
                        switch (var19_16) {
                            default: {
                                var0.skipValue();
                                continue block70;
                            }
                            case 4: {
                                var12_10 = var0.nextInt();
                                continue block70;
                            }
                            case 3: {
                                var13_11 = a.d(var0, new p(21));
                                continue block70;
                            }
                            case 2: {
                                var14_12 = a.d(var0, new p(22));
                                continue block70;
                            }
                            case 1: {
                                var0.beginObject();
                                var20_17 = null;
                                var21_18 = null;
                                var22_19 = null;
                                var23_20 = null;
                                var24_21 = null;
                                block71 : while (var0.hasNext()) {
                                    var27_24 = var0.nextName();
                                    var27_24.getClass();
                                    switch (var27_24.hashCode()) {
                                        case 1481625679: {
                                            if (!var27_24.equals((Object)"exception")) break;
                                            var29_25 = 4;
                                            ** break;
                                        }
                                        case 937615455: {
                                            if (!var27_24.equals((Object)"binaries")) break;
                                            var29_25 = 3;
                                            ** break;
                                        }
                                        case -902467928: {
                                            if (!var27_24.equals((Object)"signal")) break;
                                            var29_25 = 2;
                                            ** break;
                                        }
                                        case -1337936983: {
                                            if (!var27_24.equals((Object)"threads")) break;
                                            var29_25 = 1;
                                            ** break;
                                        }
                                        case -1375141843: {
                                            if (var27_24.equals((Object)"appExitInfo")) ** GOTO lbl139
                                        }
                                    }
                                    var29_25 = -1;
                                    ** break;
lbl139: // 1 sources:
                                    var29_25 = 0;
lbl140: // 6 sources:
                                    switch (var29_25) {
                                        default: {
                                            var0.skipValue();
                                            continue block71;
                                        }
                                        case 4: {
                                            var23_20 = a.f(var0);
                                            continue block71;
                                        }
                                        case 3: {
                                            var21_18 = a.d(var0, new p(25));
                                            continue block71;
                                        }
                                        case 2: {
                                            var30_26 = new c(9);
                                            var0.beginObject();
                                            block72 : while (var0.hasNext()) {
                                                var31_27 = var0.nextName();
                                                var31_27.getClass();
                                                switch (var31_27.hashCode()) {
                                                    case 3373707: {
                                                        if (!var31_27.equals((Object)"name")) break;
                                                        var33_28 = 2;
                                                        ** break;
                                                    }
                                                    case 3059181: {
                                                        if (!var31_27.equals((Object)"code")) break;
                                                        var33_28 = 1;
                                                        ** break;
                                                    }
                                                    case -1147692044: {
                                                        if (var31_27.equals((Object)"address")) ** GOTO lbl169
                                                    }
                                                }
                                                var33_28 = -1;
                                                ** break;
lbl169: // 1 sources:
                                                var33_28 = 0;
lbl170: // 4 sources:
                                                switch (var33_28) {
                                                    default: {
                                                        var0.skipValue();
                                                        continue block72;
                                                    }
                                                    case 2: {
                                                        var35_30 = var0.nextString();
                                                        if (var35_30 == null) throw new NullPointerException("Null name");
                                                        var30_26.r = var35_30;
                                                        continue block72;
                                                    }
                                                    case 1: {
                                                        var34_29 = var0.nextString();
                                                        if (var34_29 == null) throw new NullPointerException("Null code");
                                                        var30_26.s = var34_29;
                                                        continue block72;
                                                    }
                                                    case 0: 
                                                }
                                                var30_26.t = var0.nextLong();
                                            }
                                            var0.endObject();
                                            var20_17 = var30_26.i();
                                            continue block71;
                                        }
                                        case 1: {
                                            var22_19 = a.d(var0, new p(24));
                                            continue block71;
                                        }
                                        case 0: 
                                    }
                                    var24_21 = a.c(var0);
                                }
                                var0.endObject();
                                var25_22 = (g1)var20_17 == null ? " signal" : var5_4;
                                if ((s1)var21_18 == null) {
                                    var25_22 = var25_22.concat(" binaries");
                                }
                                if (var25_22.isEmpty() == false) throw new IllegalStateException("Missing required properties:".concat(var25_22));
                                var11_9 = var26_23 = new i0(var22_19, (f1)var23_20, (x0)var24_21, (g1)var20_17, var21_18);
                                continue block70;
                            }
                            case 0: 
                        }
                        var15_13 = var0.nextBoolean();
                    }
                    var0.endObject();
                    if ((j1)var11_9 == null) {
                        var5_4 = " execution";
                    }
                    if ((Integer)var12_10 == null) {
                        var5_4 = var5_4.concat(" uiOrientation");
                    }
                    if (var5_4.isEmpty() == false) throw new IllegalStateException("Missing required properties:".concat(var5_4));
                    var16_14 = new h0((j1)var11_9, var13_11, var14_12, var15_13, var12_10.intValue());
                    var1_1.s = var16_14;
                    continue block68;
                }
                case 0: 
            }
            var7_6 = new b(7);
            var0.beginObject();
            block73 : while (var0.hasNext()) {
                block81 : {
                    var8_7 = var0.nextName();
                    var8_7.getClass();
                    switch (var8_7.hashCode()) {
                        case 1516795582: {
                            if (!var8_7.equals((Object)"proximityOn")) break;
                            var10_8 = 5;
                            ** break;
                        }
                        case 976541947: {
                            if (!var8_7.equals((Object)"ramUsed")) break;
                            var10_8 = 4;
                            ** break;
                        }
                        case 279795450: {
                            if (!var8_7.equals((Object)"diskUsed")) break;
                            var10_8 = 3;
                            ** break;
                        }
                        case -1439500848: {
                            if (!var8_7.equals((Object)"orientation")) break;
                            var10_8 = 2;
                            ** break;
                        }
                        case -1455558134: {
                            if (!var8_7.equals((Object)"batteryVelocity")) break;
                            var10_8 = 1;
                            ** break;
                        }
                        case -1708606089: {
                            if (var8_7.equals((Object)"batteryLevel")) break block81;
                        }
                    }
                    var10_8 = -1;
                    ** break;
                }
                var10_8 = 0;
lbl248: // 7 sources:
                switch (var10_8) {
                    default: {
                        var0.skipValue();
                        continue block73;
                    }
                    case 5: {
                        var7_6.c = var0.nextBoolean();
                        continue block73;
                    }
                    case 4: {
                        var7_6.e = var0.nextLong();
                        continue block73;
                    }
                    case 3: {
                        var7_6.f = var0.nextLong();
                        continue block73;
                    }
                    case 2: {
                        var7_6.d = var0.nextInt();
                        continue block73;
                    }
                    case 1: {
                        var7_6.b = var0.nextInt();
                        continue block73;
                    }
                    case 0: 
                }
                var7_6.a = var0.nextDouble();
            }
            var0.endObject();
            var1_1.t = var7_6.d();
        } while (true);
    }

    public static k0 f(JsonReader jsonReader) {
        u u2 = new u(9);
        jsonReader.beginObject();
        block14 : while (jsonReader.hasNext()) {
            String string = jsonReader.nextName();
            string.getClass();
            int n2 = string.hashCode();
            int n5 = -1;
            switch (n2) {
                default: {
                    break;
                }
                case 581754413: {
                    if (!string.equals((Object)"overflowCount")) break;
                    n5 = 4;
                    break;
                }
                case 91997906: {
                    if (!string.equals((Object)"causedBy")) break;
                    n5 = 3;
                    break;
                }
                case 3575610: {
                    if (!string.equals((Object)"type")) break;
                    n5 = 2;
                    break;
                }
                case -934964668: {
                    if (!string.equals((Object)"reason")) break;
                    n5 = 1;
                    break;
                }
                case -1266514778: {
                    if (!string.equals((Object)"frames")) break;
                    n5 = 0;
                }
            }
            switch (n5) {
                default: {
                    jsonReader.skipValue();
                    continue block14;
                }
                case 4: {
                    u2.u = jsonReader.nextInt();
                    continue block14;
                }
                case 3: {
                    u2.t = a.f(jsonReader);
                    continue block14;
                }
                case 2: {
                    String string2 = jsonReader.nextString();
                    if (string2 != null) {
                        u2.q = string2;
                        continue block14;
                    }
                    throw new NullPointerException("Null type");
                }
                case 1: {
                    u2.r = jsonReader.nextString();
                    continue block14;
                }
                case 0: 
            }
            u2.s = a.d(jsonReader, new p(27));
        }
        jsonReader.endObject();
        return u2.b();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static w g(JsonReader var0) {
        var2_1 = new l(5);
        var0.beginObject();
        block98 : do {
            block111 : {
                if (!var0.hasNext()) {
                    var0.endObject();
                    return var2_1.a();
                }
                var3_2 = var0.nextName();
                var3_2.getClass();
                switch (var3_2.hashCode()) {
                    case 1984987798: {
                        if (!var3_2.equals((Object)"session")) break;
                        var5_3 = 8;
                        ** break;
                    }
                    case 1975623094: {
                        if (!var3_2.equals((Object)"displayVersion")) break;
                        var5_3 = 7;
                        ** break;
                    }
                    case 1874684019: {
                        if (!var3_2.equals((Object)"platform")) break;
                        var5_3 = 6;
                        ** break;
                    }
                    case 719853845: {
                        if (!var3_2.equals((Object)"installationUuid")) break;
                        var5_3 = 5;
                        ** break;
                    }
                    case 344431858: {
                        if (!var3_2.equals((Object)"gmpAppId")) break;
                        var5_3 = 4;
                        ** break;
                    }
                    case -911706486: {
                        if (!var3_2.equals((Object)"buildVersion")) break;
                        var5_3 = 3;
                        ** break;
                    }
                    case -1375141843: {
                        if (!var3_2.equals((Object)"appExitInfo")) break;
                        var5_3 = 2;
                        ** break;
                    }
                    case -1962630338: {
                        if (!var3_2.equals((Object)"sdkVersion")) break;
                        var5_3 = 1;
                        ** break;
                    }
                    case -2118372775: {
                        if (var3_2.equals((Object)"ndkPayload")) break block111;
                    }
                }
                var5_3 = -1;
                ** break;
            }
            var5_3 = 0;
lbl48: // 10 sources:
            var6_4 = "";
            var7_5 = null;
            switch (var5_3) {
                default: {
                    var0.skipValue();
                    continue block98;
                }
                case 8: {
                    var17_14 = new g();
                    var17_14.e = Boolean.FALSE;
                    var0.beginObject();
                    block99 : while (var0.hasNext()) {
                        var18_15 = var0.nextName();
                        var18_15.getClass();
                        switch (var18_15.hashCode()) {
                            default: {
                                break;
                            }
                            case 2047016109: {
                                if (!var18_15.equals((Object)"generatorType")) break;
                                var20_16 = 10;
                                ** GOTO lbl109
                            }
                            case 1025385094: {
                                if (!var18_15.equals((Object)"crashed")) break;
                                var20_16 = 9;
                                ** GOTO lbl109
                            }
                            case 286956243: {
                                if (!var18_15.equals((Object)"generator")) break;
                                var20_16 = 8;
                                ** GOTO lbl109
                            }
                            case 3599307: {
                                if (!var18_15.equals((Object)"user")) break;
                                var20_16 = 7;
                                ** GOTO lbl109
                            }
                            case 96801: {
                                if (!var18_15.equals((Object)"app")) break;
                                var20_16 = 6;
                                ** GOTO lbl109
                            }
                            case 3556: {
                                if (!var18_15.equals((Object)"os")) break;
                                var20_16 = 5;
                                ** GOTO lbl109
                            }
                            case -1291329255: {
                                if (!var18_15.equals((Object)"events")) break;
                                var20_16 = 4;
                                ** GOTO lbl109
                            }
                            case -1335157162: {
                                if (!var18_15.equals((Object)"device")) break;
                                var20_16 = 3;
                                ** GOTO lbl109
                            }
                            case -1606742899: {
                                if (!var18_15.equals((Object)"endedAt")) break;
                                var20_16 = 2;
                                ** GOTO lbl109
                            }
                            case -1618432855: {
                                if (!var18_15.equals((Object)"identifier")) break;
                                var20_16 = 1;
                                ** GOTO lbl109
                            }
                            case -2128794476: {
                                if (!var18_15.equals((Object)"startedAt")) break;
                                var20_16 = 0;
                                ** GOTO lbl109
                            }
                        }
                        var20_16 = -1;
lbl109: // 12 sources:
                        switch (var20_16) {
                            default: {
                                var0.skipValue();
                                continue block99;
                            }
                            case 10: {
                                var17_14.k = var0.nextInt();
                                continue block99;
                            }
                            case 9: {
                                var17_14.e = var0.nextBoolean();
                                continue block99;
                            }
                            case 8: {
                                var49_41 = var0.nextString();
                                if (var49_41 == null) throw new NullPointerException("Null generator");
                                var17_14.a = var49_41;
                                continue block99;
                            }
                            case 7: {
                                var0.beginObject();
                                var45_38 = null;
                                while (var0.hasNext()) {
                                    var47_40 = var0.nextName();
                                    var47_40.getClass();
                                    if (!var47_40.equals((Object)"identifier")) {
                                        var0.skipValue();
                                        continue;
                                    }
                                    var45_38 = var0.nextString();
                                    if (var45_38 == null) throw new NullPointerException("Null identifier");
                                }
                                var0.endObject();
                                var46_39 = var45_38 == null ? " identifier" : var6_4;
                                if (var46_39.isEmpty() == false) throw new IllegalStateException("Missing required properties:".concat(var46_39));
                                var17_14.g = new r0(var45_38);
                                continue block99;
                            }
                            case 6: {
                                var0.beginObject();
                                var34_28 = null;
                                var35_29 = null;
                                var36_30 = null;
                                var37_31 = null;
                                var38_32 = null;
                                var39_33 = null;
                                block101 : while (var0.hasNext()) {
                                    var42_36 = var0.nextName();
                                    var42_36.getClass();
                                    switch (var42_36.hashCode()) {
                                        case 1975623094: {
                                            if (!var42_36.equals((Object)"displayVersion")) break;
                                            var44_37 = 5;
                                            ** break;
                                        }
                                        case 719853845: {
                                            if (!var42_36.equals((Object)"installationUuid")) break;
                                            var44_37 = 4;
                                            ** break;
                                        }
                                        case 351608024: {
                                            if (!var42_36.equals((Object)"version")) break;
                                            var44_37 = 3;
                                            ** break;
                                        }
                                        case 213652010: {
                                            if (!var42_36.equals((Object)"developmentPlatformVersion")) break;
                                            var44_37 = 2;
                                            ** break;
                                        }
                                        case -519438642: {
                                            if (!var42_36.equals((Object)"developmentPlatform")) break;
                                            var44_37 = 1;
                                            ** break;
                                        }
                                        case -1618432855: {
                                            if (var42_36.equals((Object)"identifier")) ** GOTO lbl177
                                        }
                                    }
                                    var44_37 = -1;
                                    ** break;
lbl177: // 1 sources:
                                    var44_37 = 0;
lbl178: // 7 sources:
                                    switch (var44_37) {
                                        default: {
                                            var0.skipValue();
                                            continue block101;
                                        }
                                        case 5: {
                                            var36_30 = var0.nextString();
                                            continue block101;
                                        }
                                        case 4: {
                                            var37_31 = var0.nextString();
                                            continue block101;
                                        }
                                        case 3: {
                                            var35_29 = var0.nextString();
                                            if (var35_29 == null) throw new NullPointerException("Null version");
                                            continue block101;
                                        }
                                        case 2: {
                                            var39_33 = var0.nextString();
                                            continue block101;
                                        }
                                        case 1: {
                                            var38_32 = var0.nextString();
                                            continue block101;
                                        }
                                        case 0: 
                                    }
                                    var34_28 = var0.nextString();
                                    if (var34_28 == null) throw new NullPointerException("Null identifier");
                                }
                                var0.endObject();
                                var40_34 = (String)var34_28 == null ? " identifier" : var6_4;
                                if ((String)var35_29 == null) {
                                    var40_34 = var40_34.concat(" version");
                                }
                                if (var40_34.isEmpty() == false) throw new IllegalStateException("Missing required properties:".concat(var40_34));
                                var41_35 = new d0(var34_28, var35_29, var36_30, var37_31, var38_32, var39_33);
                                var17_14.f = var41_35;
                                continue block99;
                            }
                            case 5: {
                                var28_23 = new i(12);
                                var0.beginObject();
                                block102 : while (var0.hasNext()) {
                                    var29_24 = var0.nextName();
                                    var29_24.getClass();
                                    switch (var29_24.hashCode()) {
                                        case 1874684019: {
                                            if (!var29_24.equals((Object)"platform")) break;
                                            var31_25 = 3;
                                            ** break;
                                        }
                                        case 351608024: {
                                            if (!var29_24.equals((Object)"version")) break;
                                            var31_25 = 2;
                                            ** break;
                                        }
                                        case -293026577: {
                                            if (!var29_24.equals((Object)"jailbroken")) break;
                                            var31_25 = 1;
                                            ** break;
                                        }
                                        case -911706486: {
                                            if (var29_24.equals((Object)"buildVersion")) ** GOTO lbl233
                                        }
                                    }
                                    var31_25 = -1;
                                    ** break;
lbl233: // 1 sources:
                                    var31_25 = 0;
lbl234: // 5 sources:
                                    switch (var31_25) {
                                        default: {
                                            var0.skipValue();
                                            continue block102;
                                        }
                                        case 3: {
                                            var28_23.q = var0.nextInt();
                                            continue block102;
                                        }
                                        case 2: {
                                            var33_27 = var0.nextString();
                                            if (var33_27 == null) throw new NullPointerException("Null version");
                                            var28_23.r = var33_27;
                                            continue block102;
                                        }
                                        case 1: {
                                            var28_23.t = var0.nextBoolean();
                                            continue block102;
                                        }
                                        case 0: 
                                    }
                                    var32_26 = var0.nextString();
                                    if (var32_26 == null) throw new NullPointerException("Null buildVersion");
                                    var28_23.s = var32_26;
                                }
                                var0.endObject();
                                var17_14.h = var28_23.e();
                                continue block99;
                            }
                            case 4: {
                                var17_14.j = a.d(var0, new p(19));
                                continue block99;
                            }
                            case 3: {
                                var21_17 = new l(7);
                                var0.beginObject();
                                block103 : while (var0.hasNext()) {
                                    var22_18 = var0.nextName();
                                    var22_18.getClass();
                                    switch (var22_18.hashCode()) {
                                        case 2078953423: {
                                            if (!var22_18.equals((Object)"modelClass")) break;
                                            var24_19 = 8;
                                            ** break;
                                        }
                                        case 109757585: {
                                            if (!var22_18.equals((Object)"state")) break;
                                            var24_19 = 7;
                                            ** break;
                                        }
                                        case 104069929: {
                                            if (!var22_18.equals((Object)"model")) break;
                                            var24_19 = 6;
                                            ** break;
                                        }
                                        case 94848180: {
                                            if (!var22_18.equals((Object)"cores")) break;
                                            var24_19 = 5;
                                            ** break;
                                        }
                                        case 81784169: {
                                            if (!var22_18.equals((Object)"diskSpace")) break;
                                            var24_19 = 4;
                                            ** break;
                                        }
                                        case 3002454: {
                                            if (!var22_18.equals((Object)"arch")) break;
                                            var24_19 = 3;
                                            ** break;
                                        }
                                        case 112670: {
                                            if (!var22_18.equals((Object)"ram")) break;
                                            var24_19 = 2;
                                            ** break;
                                        }
                                        case -1969347631: {
                                            if (!var22_18.equals((Object)"manufacturer")) break;
                                            var24_19 = 1;
                                            ** break;
                                        }
                                        case -1981332476: {
                                            if (var22_18.equals((Object)"simulator")) ** GOTO lbl303
                                        }
                                    }
                                    var24_19 = -1;
                                    ** break;
lbl303: // 1 sources:
                                    var24_19 = 0;
lbl304: // 10 sources:
                                    switch (var24_19) {
                                        default: {
                                            var0.skipValue();
                                            continue block103;
                                        }
                                        case 8: {
                                            var27_22 = var0.nextString();
                                            if (var27_22 == null) throw new NullPointerException("Null modelClass");
                                            var21_17.y = var27_22;
                                            continue block103;
                                        }
                                        case 7: {
                                            var21_17.w = var0.nextInt();
                                            continue block103;
                                        }
                                        case 6: {
                                            var26_21 = var0.nextString();
                                            if (var26_21 == null) throw new NullPointerException("Null model");
                                            var21_17.r = var26_21;
                                            continue block103;
                                        }
                                        case 5: {
                                            var21_17.s = var0.nextInt();
                                            continue block103;
                                        }
                                        case 4: {
                                            var21_17.u = var0.nextLong();
                                            continue block103;
                                        }
                                        case 3: {
                                            var21_17.q = var0.nextInt();
                                            continue block103;
                                        }
                                        case 2: {
                                            var21_17.t = var0.nextLong();
                                            continue block103;
                                        }
                                        case 1: {
                                            var25_20 = var0.nextString();
                                            if (var25_20 == null) throw new NullPointerException("Null manufacturer");
                                            var21_17.x = var25_20;
                                            continue block103;
                                        }
                                        case 0: 
                                    }
                                    var21_17.v = var0.nextBoolean();
                                }
                                var0.endObject();
                                var17_14.i = var21_17.c();
                                continue block99;
                            }
                            case 2: {
                                var17_14.d = var0.nextLong();
                                continue block99;
                            }
                            case 1: {
                                var17_14.b = new String(Base64.decode((String)var0.nextString(), (int)2), r1.a);
                                continue block99;
                            }
                            case 0: 
                        }
                        var17_14.c = var0.nextLong();
                    }
                    var0.endObject();
                    var2_1.w = var17_14.a();
                    continue block98;
                }
                case 7: {
                    var16_13 = var0.nextString();
                    if (var16_13 == null) throw new NullPointerException("Null displayVersion");
                    var2_1.v = var16_13;
                    continue block98;
                }
                case 6: {
                    var2_1.s = var0.nextInt();
                    continue block98;
                }
                case 5: {
                    var15_12 = var0.nextString();
                    if (var15_12 == null) throw new NullPointerException("Null installationUuid");
                    var2_1.t = var15_12;
                    continue block98;
                }
                case 4: {
                    var14_11 = var0.nextString();
                    if (var14_11 == null) throw new NullPointerException("Null gmpAppId");
                    var2_1.r = var14_11;
                    continue block98;
                }
                case 3: {
                    var13_10 = var0.nextString();
                    if (var13_10 == null) throw new NullPointerException("Null buildVersion");
                    var2_1.u = var13_10;
                    continue block98;
                }
                case 2: {
                    var2_1.y = a.c(var0);
                    continue block98;
                }
                case 1: {
                    var12_9 = var0.nextString();
                    if (var12_9 == null) throw new NullPointerException("Null sdkVersion");
                    var2_1.q = var12_9;
                    continue block98;
                }
                case 0: 
            }
            var0.beginObject();
            var8_6 = null;
            while (var0.hasNext()) {
                var10_8 = var0.nextName();
                var10_8.getClass();
                if (!var10_8.equals((Object)"files")) {
                    if (!var10_8.equals((Object)"orgId")) {
                        var0.skipValue();
                        continue;
                    }
                    var8_6 = var0.nextString();
                    continue;
                }
                var7_5 = a.d(var0, new p(20));
            }
            var0.endObject();
            if ((s1)var7_5 == null) {
                var6_4 = " files";
            }
            if ((var9_7 = var6_4).isEmpty() == false) throw new IllegalStateException("Missing required properties:".concat(var9_7));
            var2_1.x = new a0(var7_5, var8_6);
        } while (true);
    }

    /*
     * Exception decompiling
     */
    public static w h(String var0) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Started 2 blocks at once
        // org.benf.cfr.reader.b.a.a.j.b(Op04StructuredStatement.java:409)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:487)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }
}

