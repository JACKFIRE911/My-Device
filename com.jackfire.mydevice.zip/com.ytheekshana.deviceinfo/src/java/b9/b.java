/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  java.lang.Object
 *  p2.a
 */
package b9;

import android.content.Context;
import android.content.DialogInterface;
import com.ytheekshana.deviceinfo.libs.permissions.PermissionsActivity;
import p2.a;

public final class b
implements DialogInterface.OnCancelListener {
    public final /* synthetic */ PermissionsActivity q;

    public /* synthetic */ b(PermissionsActivity permissionsActivity) {
        this.q = permissionsActivity;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        a a2 = PermissionsActivity.t;
        PermissionsActivity permissionsActivity = this.q;
        permissionsActivity.finish();
        if (a2 != null) {
            a2.b(permissionsActivity.getApplicationContext());
        }
    }
}

