/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.net.Uri
 *  e.k
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  p2.a
 */
package b9;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import com.ytheekshana.deviceinfo.libs.permissions.PermissionsActivity;
import e.k;

public final class a
implements DialogInterface.OnClickListener {
    public final /* synthetic */ int q;
    public final /* synthetic */ Object r;

    public /* synthetic */ a(int n2, Object object) {
        this.q = n2;
        this.r = object;
    }

    public final void onClick(DialogInterface dialogInterface, int n2) {
        int n5 = this.q;
        Object object = this.r;
        switch (n5) {
            default: {
                break;
            }
            case 1: {
                PermissionsActivity permissionsActivity = (PermissionsActivity)((Object)object);
                p2.a a2 = PermissionsActivity.t;
                permissionsActivity.finish();
                if (a2 != null) {
                    a2.b(permissionsActivity.getApplicationContext());
                }
                return;
            }
            case 0: {
                PermissionsActivity permissionsActivity = (PermissionsActivity)((Object)object);
                permissionsActivity.getClass();
                permissionsActivity.startActivityForResult(new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts((String)"package", (String)permissionsActivity.getPackageName(), null)), 6739);
                return;
            }
        }
        ((k)object).dismiss();
    }
}

