/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a1;

public abstract class a {
    public static final int[] a = new int[]{16842755, 16842960, 16842961};
    public static final int[] b = new int[]{16842755, 16842961};
}

