/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a9.c
 *  android.view.View
 *  android.view.View$OnClickListener
 *  java.lang.Object
 */
package a9;

import a9.b;
import a9.c;
import android.view.View;

public final class a
implements View.OnClickListener {
    public final /* synthetic */ c q;
    public final /* synthetic */ int r;

    public /* synthetic */ a(c c2, int n2) {
        this.q = c2;
        this.r = n2;
    }

    public final void onClick(View view) {
        c c2 = this.q;
        b b2 = c2.D0;
        if (b2 != null) {
            b2.f(this.r);
        }
        c2.a0(false, false);
    }
}

