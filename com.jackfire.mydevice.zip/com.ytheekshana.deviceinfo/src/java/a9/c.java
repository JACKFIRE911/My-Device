/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Dialog
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.widget.GridLayout
 *  android.widget.ImageView
 *  androidx.fragment.app.a0
 *  androidx.fragment.app.d0
 *  androidx.fragment.app.p
 *  java.lang.String
 */
package a9;

import a9.a;
import a9.b;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridLayout;
import android.widget.ImageView;
import androidx.fragment.app.a0;
import androidx.fragment.app.d0;
import androidx.fragment.app.p;
import ba.x;
import e.f;
import e.j;
import e.k;

public class c
extends p {
    public static final /* synthetic */ int F0;
    public GridLayout C0;
    public b D0;
    public int E0;

    public final void B(Context context) {
        super.B(context);
        if (context instanceof b) {
            this.D0 = (b)context;
            this.g0();
            return;
        }
        this.g0();
    }

    public final void C(Bundle bundle) {
        super.C(bundle);
        Bundle bundle2 = ((a0)this).v;
        if (bundle2 != null) {
            this.E0 = bundle2.getInt("selected_color");
        }
    }

    public final void L() {
        super.L();
    }

    public final Dialog b0() {
        View view = this.n().inflate(2131558474, null);
        this.C0 = (GridLayout)view.findViewById(2131362110);
        if (this.T().getResources().getConfiguration().orientation == 2) {
            this.C0.setColumnCount(10);
        } else {
            this.C0.setColumnCount(6);
        }
        this.g0();
        p6.b b3 = new p6.b((Context)this.R());
        b3.a.p = view;
        return b3.a();
    }

    public final void g0() {
        if (this.D0 != null) {
            GridLayout gridLayout = this.C0;
            if (gridLayout == null) {
                return;
            }
            Context context = gridLayout.getContext();
            this.C0.removeAllViews();
            String[] arrstring = context.getResources().getStringArray(2130903040);
            int[] arrn = context.getResources().getIntArray(2130903040);
            boolean bl = arrstring[0] != null;
            int n3 = bl ? arrstring.length : arrn.length;
            int[] arrn2 = new int[n3];
            for (int i4 = 0; i4 < n3; ++i4) {
                int n5 = bl ? Color.parseColor((String)arrstring[i4]) : arrn[i4];
                arrn2[i4] = n5;
            }
            for (int i5 = 0; i5 < n3; ++i5) {
                int n6 = arrn2[i5];
                View view = this.n().inflate(2131558475, (ViewGroup)this.C0, false);
                ImageView imageView = (ImageView)view.findViewById(2131362111);
                boolean bl2 = n6 == this.E0;
                x.r(imageView, n6, bl2);
                view.setClickable(true);
                view.setFocusable(true);
                view.setOnClickListener((View.OnClickListener)new a(this, n6));
                this.C0.addView(view);
            }
        }
    }
}

