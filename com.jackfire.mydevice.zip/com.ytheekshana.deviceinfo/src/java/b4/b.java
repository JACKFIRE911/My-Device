/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b4;

import a2.s;

public final class b {
    public final String a;

    public b(String string) {
        if (string != null) {
            this.a = string;
            return;
        }
        throw new NullPointerException("name is null");
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        String string = ((b)object).a;
        return this.a.equals((Object)string);
    }

    public final int hashCode() {
        return 1000003 ^ this.a.hashCode();
    }

    public final String toString() {
        return s.v(new StringBuilder("Encoding{name=\""), this.a, "\"}");
    }
}

