/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b4;

import b4.c;

public final class a {
    public final Object a;
    public final c b;

    public a(Object object, c c2) {
        if (object != null) {
            this.a = object;
            this.b = c2;
            return;
        }
        throw new NullPointerException("Null payload");
    }

    public final boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (object instanceof a) {
            a a2 = (a)object;
            a2.getClass();
            Object object2 = a2.a;
            return this.a.equals(object2) && this.b.equals((Object)a2.b);
        }
        return false;
    }

    public final int hashCode() {
        return 1000003 * (-721379959 ^ this.a.hashCode()) ^ this.b.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Event{code=null, payload=");
        stringBuilder.append(this.a);
        stringBuilder.append(", priority=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

