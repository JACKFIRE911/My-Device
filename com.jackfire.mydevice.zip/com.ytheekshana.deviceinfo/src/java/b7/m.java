/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package b7;

import a7.a;
import android.graphics.Canvas;
import android.graphics.Matrix;
import b7.s;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class m
extends s {
    public final /* synthetic */ List c;
    public final /* synthetic */ Matrix d;

    public m(ArrayList arrayList, Matrix matrix) {
        this.c = arrayList;
        this.d = matrix;
    }

    @Override
    public final void a(Matrix matrix, a a3, int n2, Canvas canvas) {
        Iterator iterator = this.c.iterator();
        while (iterator.hasNext()) {
            ((s)iterator.next()).a(this.d, a3, n2, canvas);
        }
    }
}

