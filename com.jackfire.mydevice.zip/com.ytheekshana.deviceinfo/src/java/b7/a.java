/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.RectF
 *  java.lang.Float
 *  java.lang.Object
 *  java.util.Arrays
 */
package b7;

import android.graphics.RectF;
import b7.c;
import java.util.Arrays;

public final class a
implements c {
    public final float a;

    public a(float f4) {
        this.a = f4;
    }

    @Override
    public final float a(RectF rectF) {
        return this.a;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof a)) {
            return false;
        }
        a a3 = (a)object;
        return this.a == a3.a;
    }

    public final int hashCode() {
        Object[] arrobject = new Object[]{Float.valueOf((float)this.a)};
        return Arrays.hashCode((Object[])arrobject);
    }
}

