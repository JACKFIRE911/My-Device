/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b7;

import b7.j;

public interface u {
    public void setShapeAppearanceModel(j var1);
}

