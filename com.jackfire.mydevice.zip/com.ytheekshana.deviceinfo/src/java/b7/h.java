/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.RectF
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.Arrays
 */
package b7;

import android.graphics.RectF;
import b7.c;
import java.util.Arrays;

public final class h
implements c {
    public final float a;

    public h(float f4) {
        this.a = f4;
    }

    @Override
    public final float a(RectF rectF) {
        return Math.min((float)rectF.width(), (float)rectF.height()) * this.a;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof h)) {
            return false;
        }
        h h3 = (h)object;
        return this.a == h3.a;
    }

    public final int hashCode() {
        Object[] arrobject = new Object[]{Float.valueOf((float)this.a)};
        return Arrays.hashCode((Object[])arrobject);
    }
}

