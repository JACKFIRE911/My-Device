/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.ArrayList
 */
package b7;

import b7.n;
import b7.p;
import b7.t;
import java.util.ArrayList;
import k.e;

public final class i
extends e {
    public i() {
        super(7);
    }

    @Override
    public final void e(float f4, float f6, t t2) {
        t2.d(f6 * f4, 180.0f, 90.0f);
        float f7 = f4 * (f6 * 2.0f);
        p p2 = new p(0.0f, 0.0f, f7, f7);
        p2.f = 180.0f;
        p2.g = 90.0f;
        t2.g.add((Object)p2);
        n n2 = new n(p2);
        t2.a(180.0f);
        t2.h.add((Object)n2);
        t2.e = 270.0f;
        float f8 = 0.5f * (f7 + 0.0f);
        float f9 = (f7 - 0.0f) / 2.0f;
        double d4 = 270.0f;
        t2.c = f8 + f9 * (float)Math.cos((double)Math.toRadians((double)d4));
        t2.d = f8 + f9 * (float)Math.sin((double)Math.toRadians((double)d4));
    }
}

