/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  android.graphics.Path$Direction
 *  android.graphics.Path$Op
 *  android.graphics.PointF
 *  android.graphics.RectF
 *  androidx.fragment.app.t
 *  b7.e
 *  b7.g
 *  b7.m
 *  java.lang.Class
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.BitSet
 *  java.util.Collection
 *  k.e
 */
package b7;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import b7.c;
import b7.e;
import b7.g;
import b7.j;
import b7.m;
import b7.s;
import b7.t;
import java.util.ArrayList;
import java.util.BitSet;
import java.util.Collection;

public final class l {
    public final t[] a = new t[4];
    public final Matrix[] b = new Matrix[4];
    public final Matrix[] c = new Matrix[4];
    public final PointF d = new PointF();
    public final Path e = new Path();
    public final Path f = new Path();
    public final t g = new t();
    public final float[] h = new float[2];
    public final float[] i = new float[2];
    public final Path j = new Path();
    public final Path k = new Path();
    public final boolean l = true;

    public l() {
        for (int i2 = 0; i2 < 4; ++i2) {
            this.a[i2] = new t();
            this.b[i2] = new Matrix();
            this.c[i2] = new Matrix();
        }
    }

    public final void a(j j2, float f2, RectF rectF, androidx.fragment.app.t t2, Path path) {
        float[] arrf;
        Matrix[] arrmatrix;
        Matrix[] arrmatrix2;
        int n2;
        t[] arrt;
        l l2 = this;
        androidx.fragment.app.t t3 = t2;
        Path path2 = path;
        path.rewind();
        Path path3 = l2.e;
        path3.rewind();
        Path path4 = l2.f;
        path4.rewind();
        path4.addRect(rectF, Path.Direction.CW);
        int n3 = 0;
        do {
            n2 = 4;
            arrmatrix = l2.c;
            arrf = l2.h;
            arrmatrix2 = l2.b;
            arrt = l2.a;
            if (n3 >= n2) break;
            c c2 = n3 != 1 ? (n3 != 2 ? (n3 != 3 ? j2.f : j2.e) : j2.h) : j2.g;
            k.e e2 = n3 != 1 ? (n3 != 2 ? (n3 != 3 ? j2.b : j2.a) : j2.d) : j2.c;
            t t4 = arrt[n3];
            e2.getClass();
            e2.e(f2, c2.a(rectF), t4);
            int n5 = n3 + 1;
            float f4 = 90 * (n5 % 4);
            arrmatrix2[n3].reset();
            PointF pointF = l2.d;
            if (n3 != 1) {
                if (n3 != 2) {
                    if (n3 != 3) {
                        pointF.set(rectF.right, rectF.top);
                    } else {
                        pointF.set(rectF.left, rectF.top);
                    }
                } else {
                    pointF.set(rectF.left, rectF.bottom);
                }
            } else {
                pointF.set(rectF.right, rectF.bottom);
            }
            arrmatrix2[n3].setTranslate(pointF.x, pointF.y);
            arrmatrix2[n3].preRotate(f4);
            t t5 = arrt[n3];
            arrf[0] = t5.c;
            arrf[1] = t5.d;
            arrmatrix2[n3].mapPoints(arrf);
            arrmatrix[n3].reset();
            arrmatrix[n3].setTranslate(arrf[0], arrf[1]);
            arrmatrix[n3].preRotate(f4);
            n3 = n5;
        } while (true);
        int n6 = 1;
        int n7 = 0;
        while (n7 < n2) {
            Path path5;
            androidx.fragment.app.t t6;
            t t7 = arrt[n7];
            arrf[0] = t7.a;
            arrf[n6] = t7.b;
            arrmatrix2[n7].mapPoints(arrf);
            if (n7 == 0) {
                path2.moveTo(arrf[0], arrf[n6]);
            } else {
                path2.lineTo(arrf[0], arrf[n6]);
            }
            arrt[n7].b(arrmatrix2[n7], path2);
            if (t3 != null) {
                t t8 = arrt[n7];
                Matrix matrix = arrmatrix2[n7];
                BitSet bitSet = ((g)t3.q).t;
                t8.getClass();
                bitSet.set(n7, false);
                s[] arrs = ((g)t3.q).r;
                t8.a(t8.f);
                Matrix matrix2 = new Matrix(matrix);
                arrs[n7] = new m(new ArrayList((Collection)t8.h), matrix2);
            }
            int n8 = n7 + 1;
            int n9 = n8 % 4;
            t t9 = arrt[n7];
            arrf[0] = t9.c;
            arrf[1] = t9.d;
            arrmatrix2[n7].mapPoints(arrf);
            t t10 = arrt[n9];
            float f5 = t10.a;
            float[] arrf2 = l2.i;
            arrf2[0] = f5;
            arrf2[1] = t10.b;
            arrmatrix2[n9].mapPoints(arrf2);
            float f6 = Math.max((float)((float)Math.hypot((double)(arrf[0] - arrf2[0]), (double)(arrf[1] - arrf2[1])) - 0.001f), (float)0.0f);
            t t11 = arrt[n7];
            arrf[0] = t11.c;
            arrf[1] = t11.d;
            arrmatrix2[n7].mapPoints(arrf);
            if (n7 != 1 && n7 != 3) {
                Math.abs((float)(rectF.centerY() - arrf[1]));
            } else {
                Math.abs((float)(rectF.centerX() - arrf[0]));
            }
            t t12 = l2.g;
            t12.d(0.0f, 270.0f, 0.0f);
            e e3 = n7 != 1 ? (n7 != 2 ? (n7 != 3 ? j2.j : j2.i) : j2.l) : j2.k;
            e3.getClass();
            t12.c(f6, 0.0f);
            Path path6 = l2.j;
            path6.reset();
            t12.b(arrmatrix[n7], path6);
            if (l2.l && (l2.b(path6, n7) || l2.b(path6, n9))) {
                path6.op(path6, path4, Path.Op.DIFFERENCE);
                arrf[0] = t12.a;
                arrf[1] = t12.b;
                arrmatrix[n7].mapPoints(arrf);
                path3.moveTo(arrf[0], arrf[1]);
                t12.b(arrmatrix[n7], path3);
                t6 = t2;
                path5 = path;
            } else {
                Matrix matrix = arrmatrix[n7];
                path5 = path;
                t12.b(matrix, path5);
                t6 = t2;
            }
            if (t6 != null) {
                Matrix matrix = arrmatrix[n7];
                ((g)t6.q).t.set(n7 + 4, false);
                s[] arrs = ((g)t6.q).s;
                t12.a(t12.f);
                Matrix matrix3 = new Matrix(matrix);
                arrs[n7] = new m(new ArrayList((Collection)t12.h), matrix3);
            }
            path2 = path5;
            n7 = n8;
            n6 = 1;
            n2 = 4;
            l2 = this;
            t3 = t6;
        }
        Path path7 = path2;
        path.close();
        path3.close();
        if (!path3.isEmpty()) {
            path7.op(path3, Path.Op.UNION);
        }
    }

    public final boolean b(Path path, int n2) {
        Path path2 = this.k;
        path2.reset();
        this.a[n2].b(this.b[n2], path2);
        RectF rectF = new RectF();
        boolean bl = true;
        path.computeBounds(rectF, bl);
        path2.computeBounds(rectF, bl);
        path.op(path2, Path.Op.INTERSECT);
        path.computeBounds(rectF, bl);
        if (rectF.isEmpty()) {
            if (rectF.width() > 1.0f && rectF.height() > 1.0f) {
                return bl;
            }
            bl = false;
        }
        return bl;
    }
}

