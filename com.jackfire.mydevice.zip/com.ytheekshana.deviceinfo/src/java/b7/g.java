/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.ColorFilter
 *  android.graphics.Matrix
 *  android.graphics.Outline
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffColorFilter
 *  android.graphics.PorterDuffXfermode
 *  android.graphics.Rect
 *  android.graphics.RectF
 *  android.graphics.Region
 *  android.graphics.Region$Op
 *  android.graphics.Xfermode
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$ConstantState
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Looper
 *  android.util.AttributeSet
 *  android.util.Log
 *  androidx.fragment.app.t
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Thread
 *  java.util.BitSet
 */
package b7;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Xfermode;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Looper;
import android.util.AttributeSet;
import android.util.Log;
import androidx.fragment.app.t;
import b7.b;
import b7.c;
import b7.f;
import b7.h;
import b7.j;
import b7.k;
import b7.l;
import b7.s;
import b7.u;
import e0.e;
import java.util.BitSet;
import r.a;

public class g
extends Drawable
implements u {
    public static final Paint M;
    public final Region A = new Region();
    public final Region B = new Region();
    public j C;
    public final Paint D;
    public final Paint E;
    public final a7.a F;
    public final t G;
    public final l H;
    public PorterDuffColorFilter I;
    public PorterDuffColorFilter J;
    public final RectF K;
    public boolean L;
    public f q;
    public final s[] r = new s[4];
    public final s[] s = new s[4];
    public final BitSet t = new BitSet(8);
    public boolean u;
    public final Matrix v = new Matrix();
    public final Path w = new Path();
    public final Path x = new Path();
    public final RectF y = new RectF();
    public final RectF z = new RectF();

    static {
        Paint paint;
        M = paint = new Paint(1);
        paint.setColor(-1);
        paint.setXfermode((Xfermode)new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
    }

    public g() {
        this(new j());
    }

    public g(Context context, AttributeSet attributeSet, int n2, int n5) {
        this(j.b(context, attributeSet, n2, n5).a());
    }

    public g(f f4) {
        Paint paint;
        Paint paint2;
        this.D = paint = new Paint(1);
        this.E = paint2 = new Paint(1);
        this.F = new a7.a();
        l l3 = Looper.getMainLooper().getThread() == Thread.currentThread() ? k.a : new l();
        this.H = l3;
        this.K = new RectF();
        this.L = true;
        this.q = f4;
        paint2.setStyle(Paint.Style.STROKE);
        paint.setStyle(Paint.Style.FILL);
        this.q();
        this.p(this.getState());
        this.G = new t((Object)this);
    }

    public g(j j3) {
        this(new f(j3));
    }

    public final void b(RectF rectF, Path path) {
        l l3 = this.H;
        f f4 = this.q;
        l3.a(f4.a, f4.j, rectF, this.G, path);
        if (this.q.i != 1.0f) {
            Matrix matrix = this.v;
            matrix.reset();
            float f6 = this.q.i;
            matrix.setScale(f6, f6, rectF.width() / 2.0f, rectF.height() / 2.0f);
            path.transform(matrix);
        }
        path.computeBounds(this.K, true);
    }

    public final PorterDuffColorFilter c(ColorStateList colorStateList, PorterDuff.Mode mode, Paint paint, boolean bl) {
        int n2;
        int n5;
        if (colorStateList != null && mode != null) {
            int n6 = colorStateList.getColorForState(this.getState(), 0);
            if (bl) {
                n6 = this.d(n6);
            }
            return new PorterDuffColorFilter(n6, mode);
        }
        PorterDuffColorFilter porterDuffColorFilter = bl && (n2 = this.d(n5 = paint.getColor())) != n5 ? new PorterDuffColorFilter(n2, PorterDuff.Mode.SRC_IN) : null;
        return porterDuffColorFilter;
    }

    public final int d(int n2) {
        boolean bl;
        f f4 = this.q;
        float f6 = f4.n + f4.o + f4.m;
        r6.a a3 = f4.b;
        if (a3 != null && a3.a && (bl = e.c(n2, 255) == a3.d)) {
            int n5;
            float f7 = a3.e;
            float f8 = !(f7 <= 0.0f) && !(f6 <= 0.0f) ? Math.min((float)((2.0f + 4.5f * (float)Math.log1p((double)(f6 / f7))) / 100.0f), (float)1.0f) : 0.0f;
            int n6 = Color.alpha((int)n2);
            int n7 = a.q(e.c(n2, 255), f8, a3.b);
            if (f8 > 0.0f && (n5 = a3.c) != 0) {
                n7 = e.b(e.c(n5, r6.a.f), n7);
            }
            n2 = e.c(n7, n6);
        }
        return n2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public void draw(Canvas var1_1) {
        var2_2 = this.D;
        var2_2.setColorFilter((ColorFilter)this.I);
        var4_3 = var2_2.getAlpha();
        var5_4 = this.q.l;
        var2_2.setAlpha(var4_3 * (var5_4 + (var5_4 >>> 7)) >>> 8);
        var6_5 = this.E;
        var6_5.setColorFilter((ColorFilter)this.J);
        var6_5.setStrokeWidth(this.q.k);
        var8_6 = var6_5.getAlpha();
        var9_7 = this.q.l;
        var6_5.setAlpha(var8_6 * (var9_7 + (var9_7 >>> 7)) >>> 8);
        var10_8 = this.u;
        var11_9 = this.w;
        if (var10_8) {
            var34_10 = this.q.u;
            var35_11 = (var34_10 == Paint.Style.FILL_AND_STROKE || var34_10 == Paint.Style.STROKE) && var6_5.getStrokeWidth() > 0.0f;
            var36_12 = var35_11 != false ? var6_5.getStrokeWidth() / 2.0f : 0.0f;
            var37_13 = -var36_12;
            var38_14 = this.q.a;
            var38_14.getClass();
            var40_15 = new d4.h(var38_14);
            var41_16 = var38_14.e;
            if (!(var41_16 instanceof h)) {
                var41_16 = new b(var37_13, var41_16);
            }
            var40_15.e = var41_16;
            var42_17 = var38_14.f;
            if (!(var42_17 instanceof h)) {
                var42_17 = new b(var37_13, var42_17);
            }
            var40_15.f = var42_17;
            var43_18 = var38_14.h;
            if (!(var43_18 instanceof h)) {
                var43_18 = new b(var37_13, var43_18);
            }
            var40_15.h = var43_18;
            var44_19 = var38_14.g;
            if (!(var44_19 instanceof h)) {
                var44_19 = new b(var37_13, var44_19);
            }
            var40_15.g = var44_19;
            this.C = var45_20 = new j(var40_15);
            var46_21 = this.q.j;
            var47_22 = this.z;
            var47_22.set(this.h());
            var48_23 = this.q.u;
            var49_24 = (var48_23 == Paint.Style.FILL_AND_STROKE || var48_23 == Paint.Style.STROKE) && var6_5.getStrokeWidth() > 0.0f;
            var50_25 = var49_24 != false ? var6_5.getStrokeWidth() / 2.0f : 0.0f;
            var47_22.inset(var50_25, var50_25);
            var51_26 = this.x;
            this.H.a(var45_20, var46_21, var47_22, null, var51_26);
            this.b(this.h(), var11_9);
            this.u = false;
        }
        var12_27 = this.q;
        var13_28 = var12_27.p;
        if (var13_28 == 1 || var12_27.q <= 0) ** GOTO lbl-1000
        if (var13_28 == 2) ** GOTO lbl-1000
        var32_29 = Build.VERSION.SDK_INT;
        var33_30 = this.k() == false && var11_9.isConvex() == false && var32_29 < 29;
        if (var33_30) lbl-1000: // 2 sources:
        {
            var14_31 = true;
        } else lbl-1000: // 2 sources:
        {
            var14_31 = false;
        }
        if (var14_31) {
            var1_1.save();
            var16_32 = this.q;
            var17_33 = (int)((double)var16_32.r * Math.sin((double)Math.toRadians((double)var16_32.s)));
            var18_34 = this.q;
            var19_35 = (int)((double)var18_34.r * Math.cos((double)Math.toRadians((double)var18_34.s)));
            var1_1.translate((float)var17_33, (float)var19_35);
            if (!this.L) {
                this.e(var1_1);
                var1_1.restore();
            } else {
                var20_36 = this.K;
                var21_37 = (int)(var20_36.width() - (float)this.getBounds().width());
                var22_38 = (int)(var20_36.height() - (float)this.getBounds().height());
                if (var21_37 < 0) throw new IllegalStateException("Invalid shadow bounds. Check that the treatments result in a valid path.");
                if (var22_38 < 0) throw new IllegalStateException("Invalid shadow bounds. Check that the treatments result in a valid path.");
                var23_39 = Bitmap.createBitmap((int)(var21_37 + ((int)var20_36.width() + 2 * this.q.q)), (int)(var22_38 + ((int)var20_36.height() + 2 * this.q.q)), (Bitmap.Config)Bitmap.Config.ARGB_8888);
                var24_40 = new Canvas(var23_39);
                var25_41 = this.getBounds().left - this.q.q - var21_37;
                var26_42 = this.getBounds().top - this.q.q - var22_38;
                var24_40.translate(-var25_41, -var26_42);
                this.e(var24_40);
                var1_1.drawBitmap(var23_39, var25_41, var26_42, null);
                var23_39.recycle();
                var1_1.restore();
            }
        }
        var27_43 = this.q;
        var28_44 = var27_43.u;
        var29_45 = var28_44 == Paint.Style.FILL_AND_STROKE || var28_44 == Paint.Style.FILL;
        if (var29_45) {
            this.f(var1_1, var2_2, var11_9, var27_43.a, this.h());
        }
        if (var31_47 = ((var30_46 = this.q.u) == Paint.Style.FILL_AND_STROKE || var30_46 == Paint.Style.STROKE) && var6_5.getStrokeWidth() > 0.0f) {
            this.g(var1_1);
        }
        var2_2.setAlpha(var4_3);
        var6_5.setAlpha(var8_6);
    }

    public final void e(Canvas canvas) {
        if (this.t.cardinality() > 0) {
            Log.w((String)"g", (String)"Compatibility shadow requested but can't be drawn for all operations in this shape.");
        }
        int n2 = this.q.r;
        Path path = this.w;
        a7.a a3 = this.F;
        if (n2 != 0) {
            canvas.drawPath(path, a3.a);
        }
        for (int i3 = 0; i3 < 4; ++i3) {
            s s3 = this.r[i3];
            int n5 = this.q.q;
            Matrix matrix = s.b;
            s3.a(matrix, a3, n5, canvas);
            this.s[i3].a(matrix, a3, this.q.q, canvas);
        }
        if (this.L) {
            f f4 = this.q;
            int n6 = (int)((double)f4.r * Math.sin((double)Math.toRadians((double)f4.s)));
            f f6 = this.q;
            int n7 = (int)((double)f6.r * Math.cos((double)Math.toRadians((double)f6.s)));
            canvas.translate((float)(-n6), (float)(-n7));
            canvas.drawPath(path, M);
            canvas.translate((float)n6, (float)n7);
        }
    }

    public final void f(Canvas canvas, Paint paint, Path path, j j3, RectF rectF) {
        if (j3.e(rectF)) {
            float f4 = j3.f.a(rectF) * this.q.j;
            canvas.drawRoundRect(rectF, f4, f4, paint);
            return;
        }
        canvas.drawPath(path, paint);
    }

    public void g(Canvas canvas) {
        Paint paint = this.E;
        Path path = this.x;
        j j3 = this.C;
        RectF rectF = this.z;
        rectF.set(this.h());
        Paint.Style style = this.q.u;
        boolean bl = (style == Paint.Style.FILL_AND_STROKE || style == Paint.Style.STROKE) && paint.getStrokeWidth() > 0.0f;
        float f4 = 0.0f;
        if (bl) {
            f4 = paint.getStrokeWidth() / 2.0f;
        }
        rectF.inset(f4, f4);
        this.f(canvas, paint, path, j3, rectF);
    }

    public int getAlpha() {
        return this.q.l;
    }

    public final Drawable.ConstantState getConstantState() {
        return this.q;
    }

    public int getOpacity() {
        return -3;
    }

    /*
     * Exception decompiling
     */
    public void getOutline(Outline var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public final boolean getPadding(Rect rect) {
        Rect rect2 = this.q.h;
        if (rect2 != null) {
            rect.set(rect2);
            return true;
        }
        return super.getPadding(rect);
    }

    public final Region getTransparentRegion() {
        Rect rect = this.getBounds();
        Region region = this.A;
        region.set(rect);
        RectF rectF = this.h();
        Path path = this.w;
        this.b(rectF, path);
        Region region2 = this.B;
        region2.setPath(path, region);
        region.op(region2, Region.Op.DIFFERENCE);
        return region;
    }

    public final RectF h() {
        RectF rectF = this.y;
        rectF.set(this.getBounds());
        return rectF;
    }

    public final float i() {
        return this.q.a.e.a(this.h());
    }

    public final void invalidateSelf() {
        this.u = true;
        super.invalidateSelf();
    }

    public boolean isStateful() {
        ColorStateList colorStateList;
        ColorStateList colorStateList2;
        ColorStateList colorStateList3;
        ColorStateList colorStateList4;
        return super.isStateful() || (colorStateList4 = this.q.f) != null && colorStateList4.isStateful() || (colorStateList3 = this.q.e) != null && colorStateList3.isStateful() || (colorStateList2 = this.q.d) != null && colorStateList2.isStateful() || (colorStateList = this.q.c) != null && colorStateList.isStateful();
        {
        }
    }

    public final void j(Context context) {
        this.q.b = new r6.a(context);
        this.r();
    }

    public final boolean k() {
        return this.q.a.e(this.h());
    }

    public final void l(float f4) {
        f f6 = this.q;
        if (f6.n != f4) {
            f6.n = f4;
            this.r();
        }
    }

    public final void m(ColorStateList colorStateList) {
        f f4 = this.q;
        if (f4.c != colorStateList) {
            f4.c = colorStateList;
            this.onStateChange(this.getState());
        }
    }

    public Drawable mutate() {
        this.q = new f(this.q);
        return this;
    }

    public final void n(float f4) {
        f f6 = this.q;
        if (f6.j != f4) {
            f6.j = f4;
            this.u = true;
            this.invalidateSelf();
        }
    }

    public final void o() {
        this.F.a(-12303292);
        this.q.t = false;
        super.invalidateSelf();
    }

    public final void onBoundsChange(Rect rect) {
        this.u = true;
        super.onBoundsChange(rect);
    }

    public boolean onStateChange(int[] arrn) {
        boolean bl = this.p(arrn);
        boolean bl2 = this.q();
        boolean bl3 = bl || bl2;
        if (bl3) {
            this.invalidateSelf();
        }
        return bl3;
    }

    public final boolean p(int[] arrn) {
        int n2;
        int n5;
        Paint paint;
        Paint paint2;
        int n6;
        boolean bl;
        int n7;
        if (this.q.c != null && (n2 = (paint = this.D).getColor()) != (n6 = this.q.c.getColorForState(arrn, n2))) {
            paint.setColor(n6);
            bl = true;
        } else {
            bl = false;
        }
        if (this.q.d != null && (n5 = (paint2 = this.E).getColor()) != (n7 = this.q.d.getColorForState(arrn, n5))) {
            paint2.setColor(n7);
            return true;
        }
        return bl;
    }

    public final boolean q() {
        PorterDuffColorFilter porterDuffColorFilter = this.I;
        PorterDuffColorFilter porterDuffColorFilter2 = this.J;
        f f4 = this.q;
        ColorStateList colorStateList = f4.f;
        PorterDuff.Mode mode = f4.g;
        Paint paint = this.D;
        boolean bl = true;
        this.I = this.c(colorStateList, mode, paint, bl);
        f f6 = this.q;
        this.J = this.c(f6.e, f6.g, this.E, false);
        f f7 = this.q;
        if (f7.t) {
            int n2 = f7.f.getColorForState(this.getState(), 0);
            this.F.a(n2);
        }
        if (m0.b.a((Object)porterDuffColorFilter, (Object)this.I)) {
            if (!m0.b.a((Object)porterDuffColorFilter2, (Object)this.J)) {
                return bl;
            }
            bl = false;
        }
        return bl;
    }

    public final void r() {
        f f4 = this.q;
        float f6 = f4.n + f4.o;
        f4.q = (int)Math.ceil((double)(0.75f * f6));
        this.q.r = (int)Math.ceil((double)(f6 * 0.25f));
        this.q();
        super.invalidateSelf();
    }

    public void setAlpha(int n2) {
        f f4 = this.q;
        if (f4.l != n2) {
            f4.l = n2;
            super.invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.q.getClass();
        super.invalidateSelf();
    }

    @Override
    public final void setShapeAppearanceModel(j j3) {
        this.q.a = j3;
        this.invalidateSelf();
    }

    public final void setTint(int n2) {
        this.setTintList(ColorStateList.valueOf((int)n2));
    }

    public void setTintList(ColorStateList colorStateList) {
        this.q.f = colorStateList;
        this.q();
        super.invalidateSelf();
    }

    public void setTintMode(PorterDuff.Mode mode) {
        f f4 = this.q;
        if (f4.g != mode) {
            f4.g = mode;
            this.q();
            super.invalidateSelf();
        }
    }
}

