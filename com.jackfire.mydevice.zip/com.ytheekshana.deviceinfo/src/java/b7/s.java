/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  java.lang.Object
 */
package b7;

import a7.a;
import android.graphics.Canvas;
import android.graphics.Matrix;

public abstract class s {
    public static final Matrix b = new Matrix();
    public final Matrix a = new Matrix();

    public abstract void a(Matrix var1, a var2, int var3, Canvas var4);
}

