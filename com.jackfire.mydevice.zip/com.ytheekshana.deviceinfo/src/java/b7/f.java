/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ColorStateList
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.Rect
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.Drawable$ConstantState
 *  b7.g
 *  r6.a
 */
package b7;

import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import b7.g;
import b7.j;
import r6.a;

public class f
extends Drawable.ConstantState {
    public j a;
    public a b;
    public ColorStateList c = null;
    public ColorStateList d = null;
    public final ColorStateList e = null;
    public ColorStateList f = null;
    public PorterDuff.Mode g = PorterDuff.Mode.SRC_IN;
    public Rect h = null;
    public final float i = 1.0f;
    public float j = 1.0f;
    public float k;
    public int l = 255;
    public float m = 0.0f;
    public float n = 0.0f;
    public final float o = 0.0f;
    public final int p = 0;
    public int q = 0;
    public int r = 0;
    public int s = 0;
    public boolean t = false;
    public final Paint.Style u = Paint.Style.FILL_AND_STROKE;

    public f(f f2) {
        this.a = f2.a;
        this.b = f2.b;
        this.k = f2.k;
        this.c = f2.c;
        this.d = f2.d;
        this.g = f2.g;
        this.f = f2.f;
        this.l = f2.l;
        this.i = f2.i;
        this.r = f2.r;
        this.p = f2.p;
        this.t = f2.t;
        this.j = f2.j;
        this.m = f2.m;
        this.n = f2.n;
        this.o = f2.o;
        this.q = f2.q;
        this.s = f2.s;
        this.e = f2.e;
        this.u = f2.u;
        if (f2.h != null) {
            this.h = new Rect(f2.h);
        }
    }

    public f(j j2) {
        this.a = j2;
        this.b = null;
    }

    public final int getChangingConfigurations() {
        return 0;
    }

    public Drawable newDrawable() {
        g g2 = new g(this);
        g2.u = true;
        return g2;
    }
}

