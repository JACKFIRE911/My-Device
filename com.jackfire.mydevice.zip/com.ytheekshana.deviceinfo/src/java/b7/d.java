/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Math
 */
package b7;

import b7.t;
import k.e;

public final class d
extends e {
    public d() {
        super(7);
    }

    @Override
    public final void e(float f4, float f6, t t2) {
        t2.d(f6 * f4, 180.0f, 90.0f);
        double d4 = Math.sin((double)Math.toRadians((double)90.0f));
        double d6 = f6;
        double d7 = d4 * d6;
        double d8 = f4;
        t2.c((float)(d7 * d8), (float)(d8 * (d6 * Math.sin((double)Math.toRadians((double)0.0f)))));
    }
}

