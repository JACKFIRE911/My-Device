/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b7;

import b7.l;

public abstract class k {
    public static final l a = new l();
}

