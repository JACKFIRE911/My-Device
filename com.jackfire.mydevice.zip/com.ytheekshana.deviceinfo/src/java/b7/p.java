/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  android.graphics.RectF
 */
package b7;

import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import b7.r;

public final class p
extends r {
    public static final RectF h = new RectF();
    public float b;
    public float c;
    public float d;
    public float e;
    public float f;
    public float g;

    public p(float f4, float f6, float f7, float f8) {
        this.b = f4;
        this.c = f6;
        this.d = f7;
        this.e = f8;
    }

    @Override
    public final void a(Matrix matrix, Path path) {
        Matrix matrix2 = this.a;
        matrix.invert(matrix2);
        path.transform(matrix2);
        RectF rectF = h;
        rectF.set(this.b, this.c, this.d, this.e);
        path.arcTo(rectF, this.f, this.g, false);
        path.transform(matrix);
    }
}

