/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.Path
 *  android.graphics.RadialGradient
 *  android.graphics.RectF
 *  android.graphics.Region
 *  android.graphics.Region$Op
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  java.lang.Class
 */
package b7;

import a7.a;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.Shader;
import b7.p;
import b7.s;

public final class n
extends s {
    public final p c;

    public n(p p2) {
        this.c = p2;
    }

    @Override
    public final void a(Matrix matrix, a a3, int n2, Canvas canvas) {
        p p2 = this.c;
        float f4 = p2.f;
        float f6 = p2.g;
        RectF rectF = new RectF(p2.b, p2.c, p2.d, p2.e);
        a3.getClass();
        boolean bl = f6 < 0.0f;
        Path path = a3.g;
        int[] arrn = a.k;
        if (bl) {
            arrn[0] = 0;
            arrn[1] = a3.f;
            arrn[2] = a3.e;
            arrn[3] = a3.d;
        } else {
            path.rewind();
            path.moveTo(rectF.centerX(), rectF.centerY());
            path.arcTo(rectF, f4, f6);
            path.close();
            float f7 = -n2;
            rectF.inset(f7, f7);
            arrn[0] = 0;
            arrn[1] = a3.d;
            arrn[2] = a3.e;
            arrn[3] = a3.f;
        }
        float f8 = rectF.width() / 2.0f;
        if (f8 <= 0.0f) {
            return;
        }
        float f9 = 1.0f - (float)n2 / f8;
        float f10 = f9 + (1.0f - f9) / 2.0f;
        float[] arrf = a.l;
        arrf[1] = f9;
        arrf[2] = f10;
        RadialGradient radialGradient = new RadialGradient(rectF.centerX(), rectF.centerY(), f8, arrn, arrf, Shader.TileMode.CLAMP);
        Paint paint = a3.b;
        paint.setShader((Shader)radialGradient);
        canvas.save();
        canvas.concat(matrix);
        canvas.scale(1.0f, rectF.height() / rectF.width());
        if (!bl) {
            canvas.clipPath(path, Region.Op.DIFFERENCE);
            canvas.drawPath(path, a3.h);
        }
        canvas.drawArc(rectF, f4, f6, true, paint);
        canvas.restore();
    }
}

