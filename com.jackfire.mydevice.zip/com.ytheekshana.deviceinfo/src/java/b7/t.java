/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  b7.n
 *  b7.o
 *  b7.p
 *  b7.q
 *  java.lang.Object
 *  java.util.ArrayList
 */
package b7;

import android.graphics.Matrix;
import android.graphics.Path;
import b7.n;
import b7.o;
import b7.p;
import b7.q;
import b7.r;
import java.util.ArrayList;

public final class t {
    public float a;
    public float b;
    public float c;
    public float d;
    public float e;
    public float f;
    public final ArrayList g = new ArrayList();
    public final ArrayList h = new ArrayList();

    public t() {
        this.d(0.0f, 270.0f, 0.0f);
    }

    public final void a(float f2) {
        float f4 = this.e;
        if (f4 == f2) {
            return;
        }
        float f5 = (360.0f + (f2 - f4)) % 360.0f;
        if (f5 > 180.0f) {
            return;
        }
        float f6 = this.c;
        float f7 = this.d;
        p p2 = new p(f6, f7, f6, f7);
        p2.f = this.e;
        p2.g = f5;
        this.h.add((Object)new n(p2));
        this.e = f2;
    }

    public final void b(Matrix matrix, Path path) {
        ArrayList arrayList = this.g;
        int n2 = arrayList.size();
        for (int i2 = 0; i2 < n2; ++i2) {
            ((r)arrayList.get(i2)).a(matrix, path);
        }
    }

    public final void c(float f2, float f4) {
        q q2 = new q();
        q2.b = f2;
        q2.c = f4;
        this.g.add((Object)q2);
        o o2 = new o(q2, this.c, this.d);
        float f5 = 270.0f + o2.b();
        float f6 = 270.0f + o2.b();
        this.a(f5);
        this.h.add((Object)o2);
        this.e = f6;
        this.c = f2;
        this.d = f4;
    }

    public final void d(float f2, float f4, float f5) {
        this.a = 0.0f;
        this.b = f2;
        this.c = 0.0f;
        this.d = f2;
        this.e = f4;
        this.f = (f4 + f5) % 360.0f;
        this.g.clear();
        this.h.clear();
    }
}

