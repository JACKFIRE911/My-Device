/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.RectF
 *  java.lang.Object
 */
package b7;

import android.graphics.RectF;

public interface c {
    public float a(RectF var1);
}

