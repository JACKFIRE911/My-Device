/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  java.lang.Object
 */
package b7;

import android.graphics.Matrix;
import android.graphics.Path;

public abstract class r {
    public final Matrix a = new Matrix();

    public abstract void a(Matrix var1, Path var2);
}

