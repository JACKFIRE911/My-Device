/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.ValueAnimator
 *  android.app.Activity
 *  android.app.Fragment
 *  android.app.FragmentManager
 *  android.app.FragmentTransaction
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.Signature
 *  android.database.sqlite.SQLiteDatabase
 *  android.graphics.Path
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.text.Editable
 *  android.text.InputFilter
 *  android.text.TextUtils
 *  android.text.method.TransformationMethod
 *  android.view.inputmethod.InputConnection
 *  androidx.appcompat.widget.o1
 *  androidx.appcompat.widget.p4
 *  androidx.lifecycle.j0
 *  androidx.lifecycle.k0
 *  androidx.lifecycle.l0
 *  androidx.lifecycle.m
 *  androidx.lifecycle.u
 *  androidx.lifecycle.v0
 *  androidx.lifecycle.w
 *  androidx.lifecycle.x0
 *  androidx.preference.EditTextPreference
 *  androidx.preference.Preference
 *  com.google.android.gms.internal.ads.aa1
 *  com.google.android.gms.internal.ads.c
 *  com.google.android.gms.internal.ads.eb1
 *  com.google.android.gms.internal.ads.eq0
 *  com.google.android.gms.internal.ads.ew
 *  com.google.android.gms.internal.ads.f41
 *  com.google.android.gms.internal.ads.fk1
 *  com.google.android.gms.internal.ads.fo
 *  com.google.android.gms.internal.ads.g21
 *  com.google.android.gms.internal.ads.g30
 *  com.google.android.gms.internal.ads.h21
 *  com.google.android.gms.internal.ads.hn
 *  com.google.android.gms.internal.ads.i21
 *  com.google.android.gms.internal.ads.i41
 *  com.google.android.gms.internal.ads.jf1
 *  com.google.android.gms.internal.ads.ka1
 *  com.google.android.gms.internal.ads.l2
 *  com.google.android.gms.internal.ads.m31
 *  com.google.android.gms.internal.ads.o2
 *  com.google.android.gms.internal.ads.p1
 *  com.google.android.gms.internal.ads.p4
 *  com.google.android.gms.internal.ads.p61
 *  com.google.android.gms.internal.ads.pk1
 *  com.google.android.gms.internal.ads.sv0
 *  com.google.android.gms.internal.ads.t00
 *  com.google.android.gms.internal.ads.tr
 *  com.google.android.gms.internal.ads.un0
 *  com.google.android.gms.internal.ads.vo1
 *  com.google.android.gms.internal.ads.yj
 *  com.google.android.gms.internal.ads.yo1
 *  com.google.android.gms.internal.measurement.o3
 *  com.google.android.gms.internal.play_billing.g2
 *  com.google.android.gms.internal.play_billing.r1
 *  com.google.firebase.analytics.connector.internal.AnalyticsConnectorRegistrar
 *  j.o
 *  java.io.File
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.InstantiationException
 *  java.lang.Integer
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.security.GeneralSecurityException
 *  java.security.InvalidAlgorithmParameterException
 *  java.security.MessageDigest
 *  java.security.cert.X509Certificate
 *  java.util.Arrays
 *  java.util.Map
 *  o1.c
 *  org.json.JSONObject
 *  u7.e
 */
package b7;

import a2.s;
import a8.b1;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Path;
import android.net.Uri;
import android.os.Build;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextUtils;
import android.text.method.TransformationMethod;
import android.view.inputmethod.InputConnection;
import androidx.appcompat.widget.o1;
import androidx.appcompat.widget.p4;
import androidx.lifecycle.j0;
import androidx.lifecycle.k0;
import androidx.lifecycle.l0;
import androidx.lifecycle.m;
import androidx.lifecycle.u;
import androidx.lifecycle.v0;
import androidx.lifecycle.w;
import androidx.lifecycle.x0;
import androidx.preference.EditTextPreference;
import androidx.preference.Preference;
import com.google.android.gms.internal.ads.aa1;
import com.google.android.gms.internal.ads.eb1;
import com.google.android.gms.internal.ads.eq0;
import com.google.android.gms.internal.ads.ew;
import com.google.android.gms.internal.ads.f41;
import com.google.android.gms.internal.ads.fk1;
import com.google.android.gms.internal.ads.fo;
import com.google.android.gms.internal.ads.g21;
import com.google.android.gms.internal.ads.g30;
import com.google.android.gms.internal.ads.h21;
import com.google.android.gms.internal.ads.hn;
import com.google.android.gms.internal.ads.i21;
import com.google.android.gms.internal.ads.i41;
import com.google.android.gms.internal.ads.jf1;
import com.google.android.gms.internal.ads.ka1;
import com.google.android.gms.internal.ads.l2;
import com.google.android.gms.internal.ads.m31;
import com.google.android.gms.internal.ads.o2;
import com.google.android.gms.internal.ads.p1;
import com.google.android.gms.internal.ads.p61;
import com.google.android.gms.internal.ads.pk1;
import com.google.android.gms.internal.ads.sv0;
import com.google.android.gms.internal.ads.t00;
import com.google.android.gms.internal.ads.tr;
import com.google.android.gms.internal.ads.un0;
import com.google.android.gms.internal.ads.vo1;
import com.google.android.gms.internal.ads.yj;
import com.google.android.gms.internal.ads.yo1;
import com.google.android.gms.internal.measurement.o3;
import com.google.android.gms.internal.play_billing.g2;
import com.google.android.gms.internal.play_billing.r1;
import com.google.firebase.analytics.connector.internal.AnalyticsConnectorRegistrar;
import j.b0;
import j.o;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Map;
import m9.g;
import o1.c;
import org.json.JSONObject;
import s.h;
import s7.d;
import s7.f;
import s7.j;

/*
 * Duplicate member names - consider using --renamedupmembers true
 */
public class e
implements b0,
f1.o,
g1.d,
x0,
g,
tr,
com.google.android.gms.internal.ads.c,
g30,
o4.o,
yj,
eq0,
m31,
sv0,
pk1,
vo1,
b4.d,
f,
y5.d {
    public static final byte[] A;
    public static final byte[] B;
    public static final e C;
    public static final /* synthetic */ e D;
    public static final /* synthetic */ e E;
    public static final /* synthetic */ e F;
    public static final /* synthetic */ e G;
    public static final /* synthetic */ e H;
    public static final /* synthetic */ e I;
    public static final /* synthetic */ e J;
    public static final /* synthetic */ e K;
    public static e q;
    public static e r;
    public static e s;
    public static final /* synthetic */ e t;
    public static final /* synthetic */ e u;
    public static final /* synthetic */ e v;
    public static final /* synthetic */ e w;
    public static final /* synthetic */ e x;
    public static final /* synthetic */ e y;
    public static final /* synthetic */ e z;

    static /* synthetic */ {
        t = new e();
        u = new e();
        v = new e();
        w = new e();
        x = new e();
        y = new e();
        z = new e();
        A = new byte[]{61, 122, 18, 35, 1, -102, -93, -99, -98, -96, -29, 67, 106, -73, -64, -119, 107, -5, 79, -74, 121, -12, -34, 95, -25, -62, 63, 50, 108, -113, -103, 74};
        B = new byte[]{-110, -13, -34, 70, -83, 43, 97, 21, -44, 16, -54, -125, -28, -57, -125, -127, -7, 17, 102, -69, 116, -121, -79, 43, -13, 120, 58, 55, -29, -108, 95, 83};
        C = new e();
        D = new e();
        E = new e();
        F = new e();
        G = new e();
        H = new e();
        I = new e();
        J = new e();
        K = new e();
    }

    public /* synthetic */ e() {
    }

    public /* synthetic */ e(Object object) {
    }

    public e(int[] arrn, ValueAnimator valueAnimator) {
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static boolean B(File file) {
        void var3_9;
        X509Certificate[][] arrx509Certificate;
        String string = file.getAbsolutePath();
        try {
            arrx509Certificate = b1.S(string);
        }
        catch (RuntimeException runtimeException) {
            throw new GeneralSecurityException("Failed to verify signatures", (Throwable)var3_9);
        }
        catch (IOException iOException) {
            // empty catch block
        }
        boolean bl = arrx509Certificate.length;
        boolean bl2 = true;
        if (bl != bl2) throw new GeneralSecurityException("APK has more than one signature.");
        X509Certificate x509Certificate = arrx509Certificate[0][0];
        byte[] arrby = MessageDigest.getInstance((String)"SHA-256").digest(x509Certificate.getEncoded());
        if (Arrays.equals((byte[])A, (byte[])arrby)) return bl2;
        if ("user".equals((Object)Build.TYPE)) return false;
        if (!Arrays.equals((byte[])B, (byte[])arrby)) return false;
        return bl2;
        throw new GeneralSecurityException("Failed to verify signatures", (Throwable)var3_9);
        catch (com.google.android.gms.internal.ads.p4 p42) {
            throw new GeneralSecurityException("Package is not signed", (Throwable)p42);
        }
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static boolean D(byte[] arrby, int n2, int n5) {
        while (n2 < n5 && arrby[n2] >= 0) {
            ++n2;
        }
        if (n2 >= n5) return true;
        do {
            int n6;
            block8 : {
                int n7;
                block10 : {
                    block13 : {
                        block11 : {
                            block12 : {
                                block9 : {
                                    if (n2 >= n5) {
                                        return true;
                                    }
                                    n6 = n2 + 1;
                                    n7 = arrby[n2];
                                    if (n7 >= 0) break block8;
                                    if (n7 >= -32) break block9;
                                    if (n6 < n5) {
                                        if (n7 < -62) return false;
                                        n2 = n6 + 1;
                                        if (arrby[n6] <= -65) continue;
                                        return false;
                                    }
                                    break block10;
                                }
                                if (n7 >= -16) break block11;
                                if (n6 < n5 - 1) break block12;
                                n7 = r1.a((byte[])arrby, (int)n6, (int)n5);
                                break block10;
                            }
                            int n8 = n6 + 1;
                            byte by = arrby[n6];
                            if (by > -65) return false;
                            if (n7 == -32) {
                                if (by < -96) return false;
                            }
                            if (n7 == -19) {
                                if (by >= -96) return false;
                            }
                            n2 = n8 + 1;
                            if (arrby[n8] <= -65) continue;
                            return false;
                        }
                        if (n6 < n5 - 2) break block13;
                        n7 = r1.a((byte[])arrby, (int)n6, (int)n5);
                        break block10;
                    }
                    int n9 = n6 + 1;
                    byte by = arrby[n6];
                    if (by > -65) return false;
                    if ((n7 << 28) + (by + 112) >> 30 != 0) return false;
                    int n10 = n9 + 1;
                    if (arrby[n9] > -65) return false;
                    n6 = n10 + 1;
                    if (arrby[n10] > -65) {
                        return false;
                    }
                    break block8;
                }
                boolean bl = false;
                if (n7 != 0) return bl;
                return true;
            }
            n2 = n6;
        } while (true);
    }

    public static void i(Activity activity, m m4) {
        w w2;
        j.i((Object)activity, "activity");
        j.i((Object)m4, "event");
        if (activity instanceof u && (w2 = ((u)activity).k()) instanceof w) {
            w2.e(m4);
        }
    }

    public static Path r(float f4, float f6, float f7, float f8) {
        Path path = new Path();
        path.moveTo(f4, f6);
        path.lineTo(f7, f8);
        return path;
    }

    public static String t(String string, String string2) {
        j.i(string, "tableName");
        j.i(string2, "triggerType");
        StringBuilder stringBuilder = new StringBuilder("`room_table_modification_trigger_");
        stringBuilder.append(string);
        stringBuilder.append('_');
        stringBuilder.append(string2);
        stringBuilder.append('`');
        return stringBuilder.toString();
    }

    public static c u(u7.e e4, SQLiteDatabase sQLiteDatabase) {
        j.i((Object)e4, "refHolder");
        j.i((Object)sQLiteDatabase, "sqLiteDatabase");
        c c4 = (c)e4.r;
        if (c4 == null || !j.b((Object)c4.q, (Object)sQLiteDatabase)) {
            c4 = new c(sQLiteDatabase);
            e4.r = c4;
        }
        return c4;
    }

    /*
     * Exception decompiling
     */
    public static boolean v(InputConnection var0, Editable var1_1, int var2_2, int var3_3, boolean var4_4) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Tried to end blocks [0[UNCONDITIONALDOLOOP]], but top level block is 1[WHILELOOP]
        // org.benf.cfr.reader.b.a.a.j.a(Op04StructuredStatement.java:432)
        // org.benf.cfr.reader.b.a.a.j.d(Op04StructuredStatement.java:484)
        // org.benf.cfr.reader.b.a.a.i.a(Op03SimpleStatement.java:607)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:692)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static void w(Activity activity) {
        FragmentManager fragmentManager;
        j.i((Object)activity, "activity");
        if (Build.VERSION.SDK_INT >= 29) {
            k0.Companion.getClass();
            o1.o((Activity)activity, (k0)new k0());
        }
        if ((fragmentManager = activity.getFragmentManager()).findFragmentByTag("androidx.lifecycle.LifecycleDispatcher.report_fragment_tag") == null) {
            fragmentManager.beginTransaction().add((Fragment)new l0(), "androidx.lifecycle.LifecycleDispatcher.report_fragment_tag").commit();
            fragmentManager.executePendingTransactions();
        }
    }

    public TransformationMethod A(TransformationMethod transformationMethod) {
        return transformationMethod;
    }

    public yo1[] C() {
        yo1[] arryo1 = new yo1[]{new o2(), new p1(), new l2()};
        return arryo1;
    }

    public v0 a(Class class_) {
        try {
            Object object = class_.getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
            j.h(object, "{\n                modelC\u2026wInstance()\n            }");
            v0 v02 = (v0)object;
            return v02;
        }
        catch (IllegalAccessException illegalAccessException) {
            StringBuilder stringBuilder = new StringBuilder("Cannot create an instance of ");
            stringBuilder.append((Object)class_);
            throw new RuntimeException(stringBuilder.toString(), (Throwable)illegalAccessException);
        }
        catch (InstantiationException instantiationException) {
            StringBuilder stringBuilder = new StringBuilder("Cannot create an instance of ");
            stringBuilder.append((Object)class_);
            throw new RuntimeException(stringBuilder.toString(), (Throwable)instantiationException);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            StringBuilder stringBuilder = new StringBuilder("Cannot create an instance of ");
            stringBuilder.append((Object)class_);
            throw new RuntimeException(stringBuilder.toString(), (Throwable)noSuchMethodException);
        }
    }

    @Override
    public Object apply(Object object) {
        return ((g2)object).b();
    }

    public Object b() {
        return new jf1();
    }

    public Constructor b() {
        return Class.forName((String)"androidx.media3.decoder.midi.MidiExtractor").asSubclass(yo1.class).getConstructor(new Class[0]);
    }

    public void b() {
    }

    @Override
    public void c(o o5, boolean bl) {
    }

    @Override
    public String d(String string, String string2) {
        return null;
    }

    @Override
    public void e() {
    }

    @Override
    public Object f(p4 p42) {
        return AnalyticsConnectorRegistrar.lambda$getComponents$0((d)p42);
    }

    public int g(Object object) {
        fk1 fk12 = (fk1)object;
        String string = fk12.a;
        boolean bl = string.startsWith("OMX.google");
        int n2 = 1;
        if (!bl) {
            if (string.startsWith("c2.android")) {
                return n2;
            }
            if (un0.a < 26) {
                if (string.equals((Object)"OMX.MTK.AUDIO.DECODER.RAW")) {
                    return -1;
                }
                return 0;
            }
            n2 = 0;
        }
        return n2;
    }

    public Object g(Object object) {
        JSONObject jSONObject = (JSONObject)object;
        x4.b0.a("GMS AdRequest Signals: ");
        x4.b0.a(jSONObject.toString(2));
        return jSONObject;
    }

    public void g(Object object) {
        ((t00)object).c();
    }

    @Override
    public boolean h(o o5) {
        return false;
    }

    public v0 j(Class class_, d1.e e4) {
        return this.a(class_);
    }

    @Override
    public void k() {
    }

    public yo1[] l(Uri uri, Map map) {
        return this.C();
    }

    @Override
    public CharSequence m(Preference preference) {
        EditTextPreference editTextPreference = (EditTextPreference)preference;
        if (TextUtils.isEmpty((CharSequence)editTextPreference.j0)) {
            return editTextPreference.q.getString(2131952207);
        }
        return editTextPreference.j0;
    }

    public Object n(JSONObject jSONObject) {
        return new fo(jSONObject);
    }

    @Override
    public void o(int n2, Object object) {
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public o3 p(i41 var1_1) {
        if (((f41)var1_1).q.equals((Object)"type.googleapis.com/google.crypto.tink.AesGcmSivKey") == false) throw new IllegalArgumentException("Wrong type URL in call to AesGcmSivParameters.parseParameters");
        try {
            var3_2 = p61.z((aa1)((f41)var1_1).s, (ka1)ka1.b);
            var4_3 = var3_2.w();
            if (var4_3 != 0) throw new GeneralSecurityException("Only version 0 keys are accepted");
            var5_4 = h21.d;
            var6_5 = var3_2.A().k();
            if (var6_5 != 16 && var6_5 != 32) {
                var15_6 = new Object[]{var6_5};
                throw new InvalidAlgorithmParameterException(String.format((String)"Invalid key size %d; only 16-byte and 32-byte AES keys are supported", (Object[])var15_6));
            }
            var7_7 = var6_5;
            var8_8 = ((f41)var1_1).u;
            var9_9 = h.c(var8_8);
            if (var9_9 != 1) {
                if (var9_9 != 2) {
                    if (var9_9 != 3) {
                        if (var9_9 != 4) {
                            var12_10 = s.e(var8_8);
                            var13_11 = new StringBuilder("Unable to parse OutputPrefixType: ");
                            var13_11.append(var12_10);
                            throw new GeneralSecurityException(var13_11.toString());
                        } else {
                            ** GOTO lbl-1000
                        }
                    }
                } else lbl-1000: // 3 sources:
                {
                    var5_4 = h21.c;
                }
            } else {
                var5_4 = h21.b;
            }
            if (var7_7 == null) throw new GeneralSecurityException("Key size is not set");
            var10_12 = new i21(var7_7.intValue(), var5_4);
            var11_13 = new hn(15);
            var11_13.r = var10_12;
            var11_13.s = ew.f((byte[])var3_2.A().g());
            var11_13.t = ((f41)var1_1).v;
            return var11_13.m();
        }
        catch (eb1 v0) {
            throw new GeneralSecurityException("Parsing AesGcmSivKey failed");
        }
    }

    public InputFilter[] q(InputFilter[] arrinputFilter) {
        return arrinputFilter;
    }

    public Signature[] s(PackageManager packageManager, String string) {
        return packageManager.getPackageInfo((String)string, (int)64).signatures;
    }

    public boolean x() {
        return false;
    }

    public void y(boolean bl) {
    }

    public void z(boolean bl) {
    }
}

