/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.RectF
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.util.Arrays
 */
package b7;

import android.graphics.RectF;
import b7.c;
import java.util.Arrays;

public final class b
implements c {
    public final c a;
    public final float b;

    public b(float f4, c c4) {
        while (c4 instanceof b) {
            c4 = ((b)c4).a;
            f4 += ((b)c4).b;
        }
        this.a = c4;
        this.b = f4;
    }

    @Override
    public final float a(RectF rectF) {
        return Math.max((float)0.0f, (float)(this.a.a(rectF) + this.b));
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b4 = (b)object;
        c c4 = b4.a;
        return this.a.equals((Object)c4) && this.b == b4.b;
    }

    public final int hashCode() {
        Object[] arrobject = new Object[]{this.a, Float.valueOf((float)this.b)};
        return Arrays.hashCode((Object[])arrobject);
    }
}

