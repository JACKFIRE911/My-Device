/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.TypedArray
 *  android.graphics.RectF
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.util.TypedValue
 *  android.view.ContextThemeWrapper
 *  b7.a
 *  b7.e
 *  b7.h
 *  b7.i
 *  java.lang.Class
 *  java.lang.Object
 *  k.e
 *  y6.e
 */
package b7;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import b7.a;
import b7.c;
import b7.e;
import b7.h;
import b7.i;

public final class j {
    public static final h m = new h(0.5f);
    public final k.e a;
    public final k.e b;
    public final k.e c;
    public final k.e d;
    public final c e;
    public final c f;
    public final c g;
    public final c h;
    public final e i;
    public final e j;
    public final e k;
    public final e l;

    public j() {
        this.a = new i();
        this.b = new i();
        this.c = new i();
        this.d = new i();
        this.e = new a(0.0f);
        this.f = new a(0.0f);
        this.g = new a(0.0f);
        this.h = new a(0.0f);
        this.i = new e();
        this.j = new e();
        this.k = new e();
        this.l = new e();
    }

    public j(d4.h h2) {
        this.a = (k.e)h2.a;
        this.b = (k.e)h2.b;
        this.c = (k.e)h2.c;
        this.d = (k.e)h2.d;
        this.e = (c)h2.e;
        this.f = (c)h2.f;
        this.g = (c)h2.g;
        this.h = (c)h2.h;
        this.i = (e)h2.i;
        this.j = (e)h2.j;
        this.k = (e)h2.k;
        this.l = (e)h2.l;
    }

    public static d4.h a(Context context, int n2, int n3, c c2) {
        ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(context, n2);
        if (n3 != 0) {
            contextThemeWrapper = new ContextThemeWrapper((Context)contextThemeWrapper, n3);
        }
        TypedArray typedArray = contextThemeWrapper.obtainStyledAttributes(c6.a.I);
        try {
            int n5 = typedArray.getInt(0, 0);
            int n6 = typedArray.getInt(3, n5);
            int n7 = typedArray.getInt(4, n5);
            int n8 = typedArray.getInt(2, n5);
            int n9 = typedArray.getInt(1, n5);
            c c3 = j.d(typedArray, 5, c2);
            c c4 = j.d(typedArray, 8, c3);
            c c6 = j.d(typedArray, 9, c3);
            c c7 = j.d(typedArray, 7, c3);
            c c8 = j.d(typedArray, 6, c3);
            d4.h h2 = new d4.h(1);
            k.e e2 = y6.e.t((int)n6);
            h2.a = e2;
            d4.h.b(e2);
            h2.e = c4;
            k.e e3 = y6.e.t((int)n7);
            h2.b = e3;
            d4.h.b(e3);
            h2.f = c6;
            k.e e4 = y6.e.t((int)n8);
            h2.c = e4;
            d4.h.b(e4);
            h2.g = c7;
            k.e e5 = y6.e.t((int)n9);
            h2.d = e5;
            d4.h.b(e5);
            h2.h = c8;
            return h2;
        }
        finally {
            typedArray.recycle();
        }
    }

    public static d4.h b(Context context, AttributeSet attributeSet, int n2, int n3) {
        return j.c(context, attributeSet, n2, n3, (c)new a((float)false));
    }

    public static d4.h c(Context context, AttributeSet attributeSet, int n2, int n3, c c2) {
        TypedArray typedArray = context.obtainStyledAttributes(attributeSet, c6.a.C, n2, n3);
        int n5 = typedArray.getResourceId(0, 0);
        int n6 = typedArray.getResourceId(1, 0);
        typedArray.recycle();
        return j.a(context, n5, n6, c2);
    }

    public static c d(TypedArray typedArray, int n2, c c2) {
        TypedValue typedValue = typedArray.peekValue(n2);
        if (typedValue == null) {
            return c2;
        }
        int n3 = typedValue.type;
        if (n3 == 5) {
            return new a((float)TypedValue.complexToDimensionPixelSize((int)typedValue.data, (DisplayMetrics)typedArray.getResources().getDisplayMetrics()));
        }
        if (n3 == 6) {
            return new h(typedValue.getFraction(1.0f, 1.0f));
        }
        return c2;
    }

    public final boolean e(RectF rectF) {
        boolean bl = this.l.getClass().equals(e.class) && this.j.getClass().equals(e.class) && this.i.getClass().equals(e.class) && this.k.getClass().equals(e.class);
        float f2 = this.e.a(rectF);
        boolean bl2 = this.f.a(rectF) == f2 && this.h.a(rectF) == f2 && this.g.a(rectF) == f2;
        boolean bl3 = this.b instanceof i && this.a instanceof i && this.c instanceof i && this.d instanceof i;
        return bl && bl2 && bl3;
    }

    public final j f(float f2) {
        d4.h h2 = new d4.h(this);
        h2.c(f2);
        return new j(h2);
    }
}

