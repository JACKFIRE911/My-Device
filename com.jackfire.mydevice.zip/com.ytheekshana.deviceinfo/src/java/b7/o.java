/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Canvas
 *  android.graphics.LinearGradient
 *  android.graphics.Matrix
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  java.lang.Class
 *  java.lang.Math
 */
package b7;

import a7.a;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import b7.q;
import b7.s;

public final class o
extends s {
    public final q c;
    public final float d;
    public final float e;

    public o(q q4, float f4, float f6) {
        this.c = q4;
        this.d = f4;
        this.e = f6;
    }

    @Override
    public final void a(Matrix matrix, a a3, int n2, Canvas canvas) {
        q q4 = this.c;
        float f4 = q4.c;
        float f6 = this.e;
        float f7 = f4 - f6;
        float f8 = q4.b;
        float f9 = this.d;
        float f10 = f8 - f9;
        RectF rectF = new RectF(0.0f, 0.0f, (float)Math.hypot((double)f7, (double)f10), 0.0f);
        Matrix matrix2 = this.a;
        matrix2.set(matrix);
        matrix2.preTranslate(f9, f6);
        matrix2.preRotate(this.b());
        a3.getClass();
        rectF.bottom += (float)n2;
        rectF.offset(0.0f, (float)(-n2));
        int[] arrn = a.i;
        arrn[0] = a3.f;
        arrn[1] = a3.e;
        arrn[2] = a3.d;
        Paint paint = a3.c;
        float f11 = rectF.left;
        LinearGradient linearGradient = new LinearGradient(f11, rectF.top, f11, rectF.bottom, arrn, a.j, Shader.TileMode.CLAMP);
        paint.setShader((Shader)linearGradient);
        canvas.save();
        canvas.concat(matrix2);
        canvas.drawRect(rectF, paint);
        canvas.restore();
    }

    public final float b() {
        q q4 = this.c;
        return (float)Math.toDegrees((double)Math.atan((double)((q4.c - this.e) / (q4.b - this.d))));
    }
}

