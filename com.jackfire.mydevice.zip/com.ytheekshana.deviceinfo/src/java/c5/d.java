/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  w2.l
 */
package c5;

import w2.l;

public final class d {
    public boolean a;
    public int b;
    public boolean c;
    public int d;
    public l e;
    public boolean f;
    public boolean g;
    public int h;

    public d() {
        this.a = false;
        this.b = 0;
        this.c = false;
        this.d = 1;
        this.f = false;
        this.g = false;
        this.h = 0;
    }

    public /* synthetic */ d(d d2) {
        this.a = d2.a;
        this.b = d2.b;
        this.c = d2.c;
        this.d = d2.d;
        this.e = d2.e;
        this.f = d2.f;
        this.g = d2.g;
        this.h = d2.h;
    }
}

