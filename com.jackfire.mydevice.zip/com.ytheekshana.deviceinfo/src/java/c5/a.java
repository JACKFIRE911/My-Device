/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.widget.RelativeLayout
 */
package c5;

import android.widget.RelativeLayout;

public abstract class a
extends RelativeLayout {
}

