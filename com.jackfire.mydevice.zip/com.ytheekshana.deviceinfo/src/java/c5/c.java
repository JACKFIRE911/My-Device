/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package c5;

public abstract class c {
    public abstract void a();

    public abstract String b();

    public abstract String c();
}

