/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.ads.pm
 *  java.lang.Object
 */
package c5;

import com.google.android.gms.internal.ads.pm;

public interface b {
    public void d(pm var1);
}

