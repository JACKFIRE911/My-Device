/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a8.o0
 *  android.content.Context
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.graphics.Bitmap
 *  android.graphics.Bitmap$Config
 *  android.graphics.Canvas
 *  android.graphics.ColorFilter
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.drawable.BitmapDrawable
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.LayerDrawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  androidx.appcompat.widget.b3
 *  androidx.appcompat.widget.b4
 *  androidx.appcompat.widget.w
 *  b6.q
 *  com.google.android.gms.internal.ads.eh1
 *  com.google.android.gms.internal.ads.xe1
 *  j2.i
 *  j2.q
 *  java.io.File
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.NullPointerException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collections
 *  java.util.List
 *  java.util.Map
 *  java.util.TreeMap
 *  java.util.concurrent.Callable
 *  java.util.concurrent.atomic.AtomicMarkableReference
 *  java.util.concurrent.atomic.AtomicReference
 *  k2.g
 *  o2.k
 *  o6.t
 *  o6.u
 *  org.json.JSONArray
 *  org.json.JSONObject
 *  q2.o
 *  q5.b
 *  x4.b0
 *  z7.b
 *  z7.d
 */
package c8;

import a2.s;
import a8.o0;
import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.Log;
import androidx.appcompat.widget.b3;
import androidx.appcompat.widget.b4;
import androidx.appcompat.widget.w;
import b0.e;
import com.google.android.gms.internal.ads.eh1;
import com.google.android.gms.internal.ads.xe1;
import e4.h;
import e4.l;
import j2.i;
import j2.q;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicMarkableReference;
import java.util.concurrent.atomic.AtomicReference;
import k2.g;
import o2.k;
import o6.t;
import o6.u;
import org.json.JSONArray;
import org.json.JSONObject;
import q2.o;
import x4.b0;
import z7.d;

public final class b {
    public Object a;
    public Object b;
    public Object c;
    public Object d;
    public Object e;
    public Object f;

    public b(int n2) {
        if (n2 != 3) {
            if (n2 != 5) {
                if (n2 != 7) {
                    this.a = new int[]{2131230903, 2131230901, 2131230827};
                    this.b = new int[]{2131230851, 2131230886, 2131230858, 2131230853, 2131230854, 2131230857, 2131230856};
                    this.c = new int[]{2131230900, 2131230902, 2131230844, 2131230896, 2131230897, 2131230898, 2131230899};
                    this.d = new int[]{2131230876, 2131230842, 2131230875};
                    this.e = new int[]{2131230894, 2131230904};
                    this.f = new int[]{2131230830, 2131230836, 2131230831, 2131230837};
                    return;
                }
                super();
                return;
            }
            super();
            return;
        }
        super();
    }

    public b(Context context) {
        String string;
        this.a = context.getFilesDir();
        boolean bl = Build.VERSION.SDK_INT >= 28;
        if (bl) {
            StringBuilder stringBuilder = new StringBuilder(".com.google.firebase.crashlytics.files.v2");
            stringBuilder.append(File.pathSeparator);
            stringBuilder.append(eh1.p().replaceAll("[^a-zA-Z0-9.]", "_"));
            string = stringBuilder.toString();
        } else {
            string = ".com.google.firebase.crashlytics.files.v1";
        }
        File file = new File((File)this.a, string);
        b.n(file);
        this.b = file;
        File file2 = new File((File)this.b, "open-sessions");
        b.n(file2);
        this.c = file2;
        File file3 = new File((File)this.b, "reports");
        b.n(file3);
        this.d = file3;
        File file4 = new File((File)this.b, "priority-reports");
        b.n(file4);
        this.e = file4;
        File file5 = new File((File)this.b, "native-reports");
        b.n(file5);
        this.f = file5;
    }

    public b(Context context, String string) {
        String string2;
        this.a = context.getApplicationContext();
        this.b = string;
        this.c = new TreeMap();
        String string3 = context.getPackageName();
        try {
            String string4 = q5.b.a((Context)context).b((String)context.getPackageName(), (int)0).versionName;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string3);
            stringBuilder.append("-");
            stringBuilder.append(string4);
            string2 = stringBuilder.toString();
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            b0.h((String)"Unable to get package version name for reporting", (Throwable)nameNotFoundException);
            string2 = String.valueOf((Object)string3).concat("-missing");
        }
        this.f = string2;
    }

    public b(String string, b b4, i i2) {
        this.d = new o(this, false);
        this.e = new o(this, true);
        this.f = new AtomicMarkableReference(null, false);
        this.c = string;
        this.a = new d(b4);
        this.b = i2;
    }

    public b(JSONObject jSONObject) {
        this.a = jSONObject.optString("basePlanId");
        String string = jSONObject.optString("offerId");
        if (string.isEmpty()) {
            string = null;
        }
        this.b = string;
        this.c = jSONObject.getString("offerIdToken");
        this.d = new k(jSONObject.getJSONArray("pricingPhases"));
        JSONObject jSONObject2 = jSONObject.optJSONObject("installmentPlanDetails");
        q q2 = jSONObject2 == null ? null : new q(jSONObject2);
        this.f = q2;
        ArrayList arrayList = new ArrayList();
        JSONArray jSONArray = jSONObject.optJSONArray("offerTags");
        if (jSONArray != null) {
            for (int i2 = 0; i2 < jSONArray.length(); ++i2) {
                arrayList.add((Object)jSONArray.getString(i2));
            }
        }
        this.e = arrayList;
    }

    public static boolean b(int[] arrn, int n2) {
        int n5 = arrn.length;
        for (int i2 = 0; i2 < n5; ++i2) {
            if (arrn[i2] != n2) continue;
            return true;
        }
        return false;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int c(t t2, int n2, int[] arrn) {
        int n5;
        int n6;
        if (n2 == 0) throw null;
        int n7 = n2 - 1;
        if (n7 != 0) {
            if (n7 != 1) {
                if (n7 != 2) throw new IllegalArgumentException("unexpected direction ".concat(xe1.y((int)n2)));
                n5 = -arrn[b.i(t2.b, t2.d, t2.e)] + arrn[b.i(t2.b, t2.c, t2.e)] + arrn[b.i(t2.a, t2.d, t2.e)];
                n6 = arrn[b.i(t2.a, t2.c, t2.e)];
                do {
                    return n5 - n6;
                    break;
                } while (true);
            }
            n5 = -arrn[b.i(t2.b, t2.c, t2.f)] + arrn[b.i(t2.b, t2.c, t2.e)] + arrn[b.i(t2.a, t2.c, t2.f)];
            n6 = arrn[b.i(t2.a, t2.c, t2.e)];
            return n5 - n6;
        }
        n5 = -arrn[b.i(t2.a, t2.d, t2.f)] + arrn[b.i(t2.a, t2.d, t2.e)] + arrn[b.i(t2.a, t2.c, t2.f)];
        n6 = arrn[b.i(t2.a, t2.c, t2.e)];
        return n5 - n6;
    }

    public static void f(File file) {
        if (file.exists() && b.o(file)) {
            StringBuilder stringBuilder = new StringBuilder("Deleted previous Crashlytics file system: ");
            stringBuilder.append(file.getPath());
            String string = stringBuilder.toString();
            if (Log.isLoggable((String)"FirebaseCrashlytics", (int)3)) {
                Log.d((String)"FirebaseCrashlytics", (String)string, null);
            }
        }
    }

    public static ColorStateList g(Context context, int n2) {
        int[][] arrarrn = new int[4][];
        int[] arrn = new int[4];
        int n5 = b4.c((Context)context, (int)2130968865);
        int n6 = b4.b((Context)context, (int)2130968861);
        arrarrn[0] = b4.b;
        arrn[0] = n6;
        arrarrn[1] = b4.d;
        arrn[1] = e0.e.b(n5, n2);
        arrarrn[2] = b4.c;
        arrn[2] = e0.e.b(n5, n2);
        arrarrn[3] = b4.f;
        arrn[3] = n2;
        return new ColorStateList((int[][])arrarrn, arrn);
    }

    public static int i(int n2, int n5, int n6) {
        return n6 + (n5 + (n2 + ((n2 << 10) + (n2 << 6)) + (n5 << 5)));
    }

    public static LayerDrawable j(b3 b32, Context context, int n2) {
        BitmapDrawable bitmapDrawable;
        BitmapDrawable bitmapDrawable2;
        BitmapDrawable bitmapDrawable3;
        int n5 = context.getResources().getDimensionPixelSize(n2);
        Drawable drawable = b32.f(context, 2131230890);
        Drawable drawable2 = b32.f(context, 2131230891);
        if (drawable instanceof BitmapDrawable && drawable.getIntrinsicWidth() == n5 && drawable.getIntrinsicHeight() == n5) {
            bitmapDrawable3 = (BitmapDrawable)drawable;
            bitmapDrawable2 = new BitmapDrawable(bitmapDrawable3.getBitmap());
        } else {
            Bitmap bitmap = Bitmap.createBitmap((int)n5, (int)n5, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable.setBounds(0, 0, n5, n5);
            drawable.draw(canvas);
            bitmapDrawable3 = new BitmapDrawable(bitmap);
            bitmapDrawable2 = new BitmapDrawable(bitmap);
        }
        bitmapDrawable2.setTileModeX(Shader.TileMode.REPEAT);
        if (drawable2 instanceof BitmapDrawable && drawable2.getIntrinsicWidth() == n5 && drawable2.getIntrinsicHeight() == n5) {
            bitmapDrawable = (BitmapDrawable)drawable2;
        } else {
            Bitmap bitmap = Bitmap.createBitmap((int)n5, (int)n5, (Bitmap.Config)Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            drawable2.setBounds(0, 0, n5, n5);
            drawable2.draw(canvas);
            bitmapDrawable = new BitmapDrawable(bitmap);
        }
        LayerDrawable layerDrawable = new LayerDrawable(new Drawable[]{bitmapDrawable3, bitmapDrawable, bitmapDrawable2});
        layerDrawable.setId(0, 16908288);
        layerDrawable.setId(1, 16908303);
        layerDrawable.setId(2, 16908301);
        return layerDrawable;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void n(File file) {
        Class<b> class_ = b.class;
        synchronized (b.class) {
            if (file.exists()) {
                boolean bl = file.isDirectory();
                if (bl) {
                    // ** MonitorExit[var12_1] (shouldn't be in output)
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder("Unexpected non-directory file: ");
                stringBuilder.append((Object)file);
                stringBuilder.append("; deleting file and creating new directory.");
                String string = stringBuilder.toString();
                if (Log.isLoggable((String)"FirebaseCrashlytics", (int)3)) {
                    Log.d((String)"FirebaseCrashlytics", (String)string, null);
                }
                file.delete();
            }
            if (!file.mkdirs()) {
                StringBuilder stringBuilder = new StringBuilder("Could not create Crashlytics-specific directory: ");
                stringBuilder.append((Object)file);
                Log.e((String)"FirebaseCrashlytics", (String)stringBuilder.toString(), null);
            }
            // ** MonitorExit[var12_1] (shouldn't be in output)
            return;
        }
    }

    public static boolean o(File file) {
        File[] arrfile = file.listFiles();
        if (arrfile != null) {
            int n2 = arrfile.length;
            for (int i2 = 0; i2 < n2; ++i2) {
                b.o(arrfile[i2]);
            }
        }
        return file.delete();
    }

    public static List p(Object[] arrobject) {
        if (arrobject == null) {
            return Collections.emptyList();
        }
        return Arrays.asList((Object[])arrobject);
    }

    public static void s(Drawable drawable, int n2, PorterDuff.Mode mode) {
        Drawable drawable2 = drawable.mutate();
        if (mode == null) {
            mode = w.b;
        }
        drawable2.setColorFilter((ColorFilter)w.c((int)n2, (PorterDuff.Mode)mode));
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public static int u(t t2, int n2, int n5, int[] arrn) {
        int n6;
        int n7;
        if (n2 == 0) throw null;
        int n8 = n2 - 1;
        if (n8 != 0) {
            if (n8 != 1) {
                if (n8 != 2) throw new IllegalArgumentException("unexpected direction ".concat(xe1.y((int)n2)));
                n6 = arrn[b.i(t2.b, t2.d, n5)] - arrn[b.i(t2.b, t2.c, n5)] - arrn[b.i(t2.a, t2.d, n5)];
                n7 = arrn[b.i(t2.a, t2.c, n5)];
                do {
                    return n6 + n7;
                    break;
                } while (true);
            }
            n6 = arrn[b.i(t2.b, n5, t2.f)] - arrn[b.i(t2.b, n5, t2.e)] - arrn[b.i(t2.a, n5, t2.f)];
            n7 = arrn[b.i(t2.a, n5, t2.e)];
            return n6 + n7;
        }
        n6 = arrn[b.i(n5, t2.d, t2.f)] - arrn[b.i(n5, t2.d, t2.e)] - arrn[b.i(n5, t2.c, t2.f)];
        n7 = arrn[b.i(n5, t2.c, t2.e)];
        return n6 + n7;
    }

    public static int w(t t2, int[] arrn) {
        return arrn[b.i(t2.b, t2.d, t2.f)] - arrn[b.i(t2.b, t2.d, t2.e)] - arrn[b.i(t2.b, t2.c, t2.f)] + arrn[b.i(t2.b, t2.c, t2.e)] - arrn[b.i(t2.a, t2.d, t2.f)] + arrn[b.i(t2.a, t2.d, t2.e)] + arrn[b.i(t2.a, t2.c, t2.f)] - arrn[b.i(t2.a, t2.c, t2.e)];
    }

    public final void a(String string, String string2) {
        this.h().put((Object)string, (Object)string2);
    }

    public final o0 d() {
        String string = (Integer)this.b == null ? " batteryVelocity" : "";
        if ((Boolean)this.c == null) {
            string = string.concat(" proximityOn");
        }
        if ((Integer)this.d == null) {
            string = s.t(string, " orientation");
        }
        if ((Long)this.e == null) {
            string = s.t(string, " ramUsed");
        }
        if ((Long)this.f == null) {
            string = s.t(string, " diskUsed");
        }
        if (string.isEmpty()) {
            o0 o02 = new o0((Double)this.a, ((Integer)this.b).intValue(), ((Boolean)this.c).booleanValue(), ((Integer)this.d).intValue(), ((Long)this.e).longValue(), ((Long)this.f).longValue());
            return o02;
        }
        throw new IllegalStateException("Missing required properties:".concat(string));
    }

    public final h e() {
        String string = (String)this.a == null ? " transportName" : "";
        if ((l)this.c == null) {
            string = string.concat(" encodedPayload");
        }
        if ((Long)this.d == null) {
            string = s.t(string, " eventMillis");
        }
        if ((Long)this.e == null) {
            string = s.t(string, " uptimeMillis");
        }
        if ((Map)this.f == null) {
            string = s.t(string, " autoMetadata");
        }
        if (string.isEmpty()) {
            h h2 = new h((String)this.a, (Integer)this.b, (l)this.c, (Long)this.d, (Long)this.e, (Map)this.f);
            return h2;
        }
        throw new IllegalStateException("Missing required properties:".concat(string));
    }

    public final Map h() {
        Object object = this.f;
        if ((Map)object != null) {
            return (Map)object;
        }
        throw new IllegalStateException("Property \"autoMetadata\" has not been set");
    }

    public final File k(String string, String string2) {
        File file = new File((File)this.c, string);
        file.mkdirs();
        return new File(file, string2);
    }

    public final ColorStateList l(Context context, int n2) {
        if (n2 == 2131230847) {
            return e.b(context, 2131099671);
        }
        if (n2 == 2131230893) {
            return e.b(context, 2131099674);
        }
        if (n2 == 2131230892) {
            int[][] arrarrn = new int[3][];
            int[] arrn = new int[3];
            ColorStateList colorStateList = b4.d((Context)context, (int)2130968916);
            if (colorStateList != null && colorStateList.isStateful()) {
                int[] arrn2 = b4.b;
                arrarrn[0] = arrn2;
                arrn[0] = colorStateList.getColorForState(arrn2, 0);
                arrarrn[1] = b4.e;
                arrn[1] = b4.c((Context)context, (int)2130968864);
                arrarrn[2] = b4.f;
                arrn[2] = colorStateList.getDefaultColor();
            } else {
                arrarrn[0] = b4.b;
                arrn[0] = b4.b((Context)context, (int)2130968916);
                arrarrn[1] = b4.e;
                arrn[1] = b4.c((Context)context, (int)2130968864);
                arrarrn[2] = b4.f;
                arrn[2] = b4.c((Context)context, (int)2130968916);
            }
            return new ColorStateList((int[][])arrarrn, arrn);
        }
        if (n2 == 2131230835) {
            return b.g(context, b4.c((Context)context, (int)2130968861));
        }
        if (n2 == 2131230829) {
            return b.g(context, 0);
        }
        if (n2 == 2131230834) {
            return b.g(context, b4.c((Context)context, (int)2130968859));
        }
        if (n2 != 2131230888 && n2 != 2131230889) {
            if (b.b((int[])this.b, n2)) {
                return b4.d((Context)context, (int)2130968866);
            }
            if (b.b((int[])this.e, n2)) {
                return e.b(context, 2131099670);
            }
            if (b.b((int[])this.f, n2)) {
                return e.b(context, 2131099669);
            }
            if (n2 == 2131230885) {
                return e.b(context, 2131099672);
            }
            return null;
        }
        return e.b(context, 2131099673);
    }

    public final u m(t t2, int n2, int n5, int n6, int n7, int n8, int n9, int n10) {
        b b5 = this;
        t t3 = t2;
        int n11 = n2;
        int n12 = b.c(t3, n11, (int[])b5.b);
        int n13 = b.c(t3, n11, (int[])b5.c);
        int n14 = b.c(t3, n11, (int[])b5.d);
        int n15 = b.c(t3, n11, (int[])b5.a);
        int n16 = -1;
        double d2 = 0.0;
        for (int i2 = n5; i2 < n6; ++i2) {
            int n17;
            int n18 = n12 + b.u(t3, n11, i2, (int[])b5.b);
            int n19 = n13 + b.u(t3, n11, i2, (int[])b5.c);
            int n20 = n14 + b.u(t3, n11, i2, (int[])b5.d);
            int n21 = n15 + b.u(t3, n11, i2, (int[])b5.a);
            if (n21 == 0) {
                n17 = n12;
            } else {
                double d3;
                double d4 = n18 * n18 + n19 * n19 + n20 * n20;
                n17 = n12;
                double d5 = d4 / (double)n21;
                int n22 = n7 - n18;
                int n23 = n8 - n19;
                int n24 = n9 - n20;
                int n25 = n10 - n21;
                if (n25 != 0 && (d3 = d5 + (double)(n22 * n22 + n23 * n23 + n24 * n24) / (double)n25) > d2) {
                    d2 = d3;
                    n16 = i2;
                }
            }
            b5 = this;
            t3 = t2;
            n11 = n2;
            n12 = n17;
        }
        return new u(d2, n16);
    }

    public final void q(l l2) {
        if (l2 != null) {
            this.c = l2;
            return;
        }
        throw new NullPointerException("Null encodedPayload");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void r(String string) {
        o o2;
        int n2;
        o o5 = o2 = (o)this.e;
        synchronized (o5) {
            if (!((z7.b)((AtomicMarkableReference)o2.r).getReference()).c(string)) {
                return;
            }
            Object object = o2.r;
            AtomicMarkableReference atomicMarkableReference = (AtomicMarkableReference)object;
            z7.b b5 = (z7.b)((AtomicMarkableReference)object).getReference();
            n2 = 1;
            atomicMarkableReference.set((Object)b5, (boolean)n2);
        }
        g g2 = new g(n2, (Object)o2);
        AtomicReference atomicReference = (AtomicReference)o2.s;
        while (!atomicReference.compareAndSet(null, (Object)g2)) {
            if (atomicReference.get() == null) continue;
            return;
        }
        if (n2 == 0) return;
        ((i)((b)o2.t).b).n((Callable)g2);
    }

    public final void t(String string) {
        if (string != null) {
            this.a = string;
            return;
        }
        throw new NullPointerException("Null transportName");
    }

    public final double v(t t2) {
        int n2 = b.w(t2, (int[])this.b);
        int n5 = b.w(t2, (int[])this.c);
        int n6 = b.w(t2, (int[])this.d);
        double d2 = ((double[])this.e)[b.i(t2.b, t2.d, t2.f)] - ((double[])this.e)[b.i(t2.b, t2.d, t2.e)] - ((double[])this.e)[b.i(t2.b, t2.c, t2.f)] + ((double[])this.e)[b.i(t2.b, t2.c, t2.e)] - ((double[])this.e)[b.i(t2.a, t2.d, t2.f)] + ((double[])this.e)[b.i(t2.a, t2.d, t2.e)] + ((double[])this.e)[b.i(t2.a, t2.c, t2.f)] - ((double[])this.e)[b.i(t2.a, t2.c, t2.e)];
        int n7 = n2 * n2 + n5 * n5 + n6 * n6;
        int n8 = b.w(t2, (int[])this.a);
        return d2 - (double)n7 / (double)n8;
    }
}

