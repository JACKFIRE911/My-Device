/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a8.g0
 *  android.util.Log
 *  androidx.fragment.app.t
 *  j4.l
 *  java.io.ByteArrayOutputStream
 *  java.io.File
 *  java.io.FileInputStream
 *  java.io.FileOutputStream
 *  java.io.FilenameFilter
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.Comparator
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.concurrent.atomic.AtomicInteger
 *  k0.b
 *  n0.x
 *  y7.g
 */
package c8;

import a2.s;
import a8.g0;
import android.util.Log;
import androidx.fragment.app.t;
import c8.b;
import j4.l;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicInteger;
import n0.x;
import y7.g;

public final class a {
    public static final Charset d = Charset.forName((String)"UTF-8");
    public static final int e = 15;
    public static final b8.a f = new b8.a();
    public static final k0.b g = new k0.b(4);
    public static final g h = new g(2);
    public final AtomicInteger a = new AtomicInteger(0);
    public final b b;
    public final l c;

    public a(b b4, l l2) {
        this.b = b4;
        this.c = l2;
    }

    public static void a(List list) {
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            ((File)iterator.next()).delete();
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static String d(File file) {
        String string;
        byte[] arrby = new byte[8192];
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            int n2;
            while ((n2 = fileInputStream.read(arrby)) > 0) {
                byteArrayOutputStream.write(arrby, 0, n2);
            }
            string = new String(byteArrayOutputStream.toByteArray(), d);
        }
        catch (Throwable throwable) {
            try {
                fileInputStream.close();
                throw throwable;
            }
            catch (Throwable throwable2) {
                throwable.addSuppressed(throwable2);
            }
            throw throwable;
        }
        fileInputStream.close();
        return string;
    }

    public static void e(File file, String string) {
        OutputStreamWriter outputStreamWriter = new OutputStreamWriter((OutputStream)new FileOutputStream(file), d);
        try {
            outputStreamWriter.write(string);
        }
        catch (Throwable throwable) {
            try {
                outputStreamWriter.close();
            }
            catch (Throwable throwable2) {
                throwable.addSuppressed(throwable2);
            }
            throw throwable;
        }
        outputStreamWriter.close();
    }

    public final ArrayList b() {
        ArrayList arrayList = new ArrayList();
        b b4 = this.b;
        arrayList.addAll((Collection)b.p((Object[])((File)b4.e).listFiles()));
        arrayList.addAll((Collection)b.p((Object[])((File)b4.f).listFiles()));
        k0.b b5 = g;
        Collections.sort((List)arrayList, (Comparator)b5);
        List list = b.p((Object[])((File)b4.d).listFiles());
        Collections.sort((List)list, (Comparator)b5);
        arrayList.addAll((Collection)list);
        return arrayList;
    }

    public final void c(g0 g02, String string, boolean bl) {
        int n2;
        b b4;
        StringWriter stringWriter;
        b4 = this.b;
        n2 = this.c.e().a.q;
        f.getClass();
        t t2 = b8.a.a;
        t2.getClass();
        stringWriter = new StringWriter();
        try {
            t2.w((Object)g02, (Writer)stringWriter);
        }
        catch (IOException iOException) {}
        String string2 = stringWriter.toString();
        int n5 = this.a.getAndIncrement();
        Locale locale = Locale.US;
        Object[] arrobject = new Object[]{n5};
        String string3 = String.format((Locale)locale, (String)"%010d", (Object[])arrobject);
        String string4 = bl ? "_" : "";
        String string5 = s.u("event", string3, string4);
        try {
            a.e(b4.k(string, string5), string2);
        }
        catch (IOException iOException) {
            StringBuilder stringBuilder = new StringBuilder("Could not persist event for session ");
            stringBuilder.append(string);
            Log.w((String)"FirebaseCrashlytics", (String)stringBuilder.toString(), (Throwable)iOException);
        }
        g g2 = new g(1);
        b4.getClass();
        File file = new File((File)b4.c, string);
        file.mkdirs();
        List list = b.p((Object[])file.listFiles((FilenameFilter)g2));
        Collections.sort((List)list, (Comparator)new k0.b(3));
        int n6 = list.size();
        for (File file2 : list) {
            if (n6 <= n2) {
                return;
            }
            b.o(file2);
            --n6;
        }
    }
}

