/*
 * Decompiled with CFR 0.0.
 */
package a4;

import a4.e;
import a4.f;

public final class d
extends e {
    public static final f t;
    public float r;
    public float s;

    public static {
        f f4;
        t = f4 = f.a(32, new d(0));
        f4.f = 0.5f;
    }

    public d() {
    }

    public d(int n2) {
        this.r = 0.0f;
        this.s = 0.0f;
    }

    public static d b(float f4, float f6) {
        d d4 = (d)t.b();
        d4.r = f4;
        d4.s = f6;
        return d4;
    }

    public static void c(d d4) {
        t.c(d4);
    }

    @Override
    public final e a() {
        return new d(0);
    }
}

