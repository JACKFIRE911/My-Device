/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a4.b
 *  android.graphics.Paint
 *  android.graphics.Paint$FontMetrics
 *  android.graphics.Rect
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  t3.b
 */
package a4;

import a4.b;
import android.graphics.Paint;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;

public abstract class h {
    public static DisplayMetrics a;
    public static int b = 50;
    public static int c = 8000;
    public static final float d;
    public static final Rect e;
    public static final Paint.FontMetrics f;
    public static final Rect g;
    public static final t3.b h;
    public static final Rect i;
    public static final Paint.FontMetrics j;

    public static {
        Double.longBitsToDouble((long)1L);
        d = Float.intBitsToFloat((int)1);
        e = new Rect();
        f = new Paint.FontMetrics();
        g = new Rect();
        h = new t3.b(1);
        new Rect();
        i = new Rect();
        j = new Paint.FontMetrics();
    }

    public static int a(Paint paint, String string) {
        Rect rect = e;
        rect.set(0, 0, 0, 0);
        paint.getTextBounds(string, 0, string.length(), rect);
        return rect.height();
    }

    public static b b(Paint paint, String string) {
        b b2 = b.b((float)0.0f, (float)0.0f);
        Rect rect = g;
        rect.set(0, 0, 0, 0);
        paint.getTextBounds(string, 0, string.length(), rect);
        b2.r = rect.width();
        b2.s = rect.height();
        return b2;
    }

    public static float c(float f2) {
        DisplayMetrics displayMetrics = a;
        if (displayMetrics == null) {
            Log.e((String)"MPChartLib-Utils", (String)"Utils NOT INITIALIZED. You need to call Utils.init(...) at least once before calling Utils.convertDpToPixel(...). Otherwise conversion does not take place.");
            return f2;
        }
        return f2 * displayMetrics.density;
    }

    public static float d(double d2) {
        if (!Double.isInfinite((double)d2) && !Double.isNaN((double)d2) && d2 != 0.0) {
            double d3 = d2 < 0.0 ? -d2 : d2;
            float f2 = (float)Math.pow((double)10.0, (double)(1 - (int)Math.ceil((double)((float)Math.log10((double)d3)))));
            return (float)Math.round((double)(d2 * (double)f2)) / f2;
        }
        return 0.0f;
    }
}

