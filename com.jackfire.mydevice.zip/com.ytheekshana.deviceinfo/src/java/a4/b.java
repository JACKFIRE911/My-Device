/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a4;

import a4.e;
import a4.f;

public final class b
extends e {
    public static final f t;
    public float r = 0.0f;
    public float s = 0.0f;

    public static {
        f f4;
        t = f4 = f.a(256, new b());
        f4.f = 0.5f;
    }

    public static b b(float f4, float f6) {
        b b4 = (b)t.b();
        b4.r = f4;
        b4.s = f6;
        return b4;
    }

    @Override
    public final e a() {
        return new b();
    }

    public final boolean equals(Object object) {
        if (object == null) {
            return false;
        }
        if (this == object) {
            return true;
        }
        boolean bl = object instanceof b;
        boolean bl2 = false;
        if (bl) {
            b b4 = (b)object;
            float f4 = this.r FCMPL b4.r;
            bl2 = false;
            if (f4 == false) {
                float f6 = this.s FCMPL b4.s;
                bl2 = false;
                if (f6 == false) {
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    public final int hashCode() {
        return Float.floatToIntBits((float)this.r) ^ Float.floatToIntBits((float)this.s);
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.r);
        stringBuilder.append("x");
        stringBuilder.append(this.s);
        return stringBuilder.toString();
    }
}

