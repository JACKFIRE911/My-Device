/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a4.c
 *  a8.c0
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.graphics.Matrix
 *  android.graphics.Path
 *  android.graphics.RectF
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  com.google.android.gms.internal.ads.bf1
 *  com.google.android.gms.internal.ads.c5
 *  com.google.android.gms.internal.ads.cq0
 *  com.google.android.gms.internal.ads.dp0
 *  com.google.android.gms.internal.ads.f01
 *  com.google.android.gms.internal.ads.gm0
 *  com.google.android.gms.internal.ads.gq0
 *  com.google.android.gms.internal.ads.k40
 *  com.google.android.gms.internal.ads.k90
 *  com.google.android.gms.internal.ads.lq0
 *  com.google.android.gms.internal.ads.m5
 *  com.google.android.gms.internal.ads.mr
 *  com.google.android.gms.internal.ads.nq0
 *  com.google.android.gms.internal.ads.pe1
 *  com.google.android.gms.internal.ads.qv
 *  com.google.android.gms.internal.ads.s4
 *  com.google.android.gms.internal.ads.s90
 *  com.google.android.gms.internal.ads.se1
 *  com.google.android.gms.internal.ads.sz0
 *  com.google.android.gms.internal.ads.te1
 *  com.google.android.gms.internal.ads.u8
 *  com.google.android.gms.internal.ads.ue1
 *  com.google.android.gms.internal.ads.ui0
 *  com.google.android.gms.internal.ads.w7
 *  com.google.android.gms.internal.ads.x4
 *  com.google.android.gms.internal.ads.xo0
 *  com.google.android.gms.internal.ads.y4
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  java.util.concurrent.Callable
 *  java.util.concurrent.PriorityBlockingQueue
 *  java.util.concurrent.atomic.AtomicInteger
 *  r.a
 *  s5.g
 *  v4.f3
 *  x4.e0
 *  y7.f
 */
package a4;

import a2.s;
import a4.c;
import a4.i;
import a8.c0;
import a8.c1;
import a8.d1;
import a8.o1;
import a8.p1;
import a8.q1;
import a8.s1;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.graphics.Matrix;
import android.graphics.Path;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import ba.x;
import com.google.android.gms.internal.ads.bf1;
import com.google.android.gms.internal.ads.c5;
import com.google.android.gms.internal.ads.cq0;
import com.google.android.gms.internal.ads.dp0;
import com.google.android.gms.internal.ads.f01;
import com.google.android.gms.internal.ads.gm0;
import com.google.android.gms.internal.ads.gq0;
import com.google.android.gms.internal.ads.k40;
import com.google.android.gms.internal.ads.k90;
import com.google.android.gms.internal.ads.lq0;
import com.google.android.gms.internal.ads.m5;
import com.google.android.gms.internal.ads.mr;
import com.google.android.gms.internal.ads.nq0;
import com.google.android.gms.internal.ads.pe1;
import com.google.android.gms.internal.ads.qv;
import com.google.android.gms.internal.ads.s4;
import com.google.android.gms.internal.ads.s90;
import com.google.android.gms.internal.ads.se1;
import com.google.android.gms.internal.ads.sz0;
import com.google.android.gms.internal.ads.te1;
import com.google.android.gms.internal.ads.u8;
import com.google.android.gms.internal.ads.ue1;
import com.google.android.gms.internal.ads.ui0;
import com.google.android.gms.internal.ads.w7;
import com.google.android.gms.internal.ads.x4;
import com.google.android.gms.internal.ads.xo0;
import com.google.android.gms.internal.ads.y4;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.PriorityBlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;
import r.a;
import v4.f3;
import x4.e0;
import y7.f;

public final class g {
    public Object a;
    public Object b;
    public Object c;
    public Object d;
    public Object e;
    public Object f;
    public Object g;
    public Object h;
    public Object i;
    public Object j;
    public Object k;

    public g() {
    }

    public g(i i2) {
        this.a = new Matrix();
        this.b = new Matrix();
        this.g = new float[1];
        this.h = new float[1];
        this.i = new float[1];
        this.j = new float[1];
        this.c = new Matrix();
        this.k = new float[2];
        this.d = new Matrix();
        this.e = new Matrix();
        this.f = i2;
    }

    public g(q1 q12) {
        c0 c02 = (c0)q12;
        this.a = c02.a;
        this.b = c02.b;
        this.c = c02.c;
        this.d = c02.d;
        this.e = c02.e;
        this.f = c02.f;
        this.g = c02.g;
        this.h = c02.h;
        this.i = c02.i;
        this.j = c02.j;
        this.k = c02.k;
    }

    public g(m5 m52, dp0 dp02) {
        w7 w72 = new w7(new Handler(Looper.getMainLooper()));
        this.a = new AtomicInteger();
        this.b = new HashSet();
        this.c = new PriorityBlockingQueue();
        this.d = new PriorityBlockingQueue();
        this.i = new ArrayList();
        this.j = new ArrayList();
        this.e = m52;
        this.f = dp02;
        this.g = new y4[4];
        this.k = w72;
    }

    public g(nq0 nq02, mr mr2, ApplicationInfo applicationInfo, String string, ArrayList arrayList, PackageInfo packageInfo, pe1 pe12, e0 e02, String string2, gm0 gm02, xo0 xo02) {
        this.a = nq02;
        this.b = mr2;
        this.c = applicationInfo;
        this.d = string;
        this.e = arrayList;
        this.f = packageInfo;
        this.g = pe12;
        this.h = string2;
        this.i = gm02;
        this.j = e02;
        this.k = xo02;
    }

    public /* synthetic */ g(qv qv2, Context context, String string, f3 f32) {
        this.e = this;
        this.d = qv2;
        this.a = context;
        this.b = f32;
        this.c = string;
        this.f = ue1.a((Object)context);
        this.g = ue1.a((Object)f32);
        this.h = se1.b((te1)new k40(((qv)this.d).g, 21));
        this.i = se1.b((te1)a.e);
        bf1 bf12 = se1.b((te1)x.k);
        this.j = bf12;
        bf1 bf13 = (bf1)this.f;
        qv qv3 = (qv)this.d;
        bf1 bf14 = qv3.h;
        bf1 bf15 = (bf1)this.g;
        ue1 ue12 = qv3.y;
        bf1 bf16 = (bf1)this.h;
        bf1 bf17 = (bf1)this.i;
        s90 s902 = f.i;
        k90 k902 = new k90(bf13, bf14, bf15, (bf1)ue12, bf16, bf17, (bf1)s902, bf12, 3);
        this.k = se1.b((te1)k902);
    }

    public final c0 a() {
        String string = (String)this.a == null ? " generator" : "";
        if ((String)this.b == null) {
            string = string.concat(" identifier");
        }
        if ((Long)this.c == null) {
            string = s.t(string, " startedAt");
        }
        if ((Boolean)this.e == null) {
            string = s.t(string, " crashed");
        }
        if ((c1)this.f == null) {
            string = s.t(string, " app");
        }
        if ((Integer)this.k == null) {
            string = s.t(string, " generatorType");
        }
        if (string.isEmpty()) {
            c0 c02 = new c0((String)this.a, (String)this.b, ((Long)this.c).longValue(), (Long)this.d, ((Boolean)this.e).booleanValue(), (c1)this.f, (p1)this.g, (o1)this.h, (d1)this.i, (s1)this.j, ((Integer)this.k).intValue());
            return c02;
        }
        throw new IllegalStateException("Missing required properties:".concat(string));
    }

    public final c b(float f2, float f4) {
        float[] arrf = (float[])this.k;
        arrf[0] = f2;
        arrf[1] = f4;
        this.f(arrf);
        float[] arrf2 = (float[])this.k;
        return c.b((double)arrf2[0], (double)arrf2[1]);
    }

    public final void c(float f2, float f4, c c2) {
        Object object = this.k;
        ((float[])object)[0] = f2;
        ((float[])object)[1] = f4;
        this.e((float[])object);
        Object object2 = this.k;
        c2.r = ((float[])object2)[0];
        c2.s = ((float[])object2)[1];
    }

    public final void d(Path path) {
        path.transform((Matrix)this.a);
        path.transform(((i)this.f).a);
        path.transform((Matrix)this.b);
    }

    public final void e(float[] arrf) {
        Matrix matrix = (Matrix)this.c;
        matrix.reset();
        ((Matrix)this.b).invert(matrix);
        matrix.mapPoints(arrf);
        ((i)this.f).a.invert(matrix);
        matrix.mapPoints(arrf);
        ((Matrix)this.a).invert(matrix);
        matrix.mapPoints(arrf);
    }

    public final void f(float[] arrf) {
        ((Matrix)this.a).mapPoints(arrf);
        ((i)this.f).a.mapPoints(arrf);
        ((Matrix)this.b).mapPoints(arrf);
    }

    public final void g() {
        ((Matrix)this.b).reset();
        Matrix matrix = (Matrix)this.b;
        i i2 = (i)this.f;
        RectF rectF = i2.b;
        float f2 = rectF.left;
        float f4 = i2.d;
        matrix.postTranslate(f2, f4 - (f4 - rectF.bottom));
    }

    public final void h(float f2, float f4, float f5, float f6) {
        float f7 = ((i)this.f).b.width() / f4;
        float f8 = ((i)this.f).b.height() / f5;
        if (Float.isInfinite((float)f7)) {
            f7 = 0.0f;
        }
        if (Float.isInfinite((float)f8)) {
            f8 = 0.0f;
        }
        ((Matrix)this.a).reset();
        ((Matrix)this.a).postTranslate(-f2, -f6);
        ((Matrix)this.a).postScale(f7, -f8);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void i(c5 c52) {
        Set set;
        c52.x = this;
        Set set2 = set = (Set)this.b;
        synchronized (set2) {
            ((Set)this.b).add((Object)c52);
        }
        c52.w = ((AtomicInteger)this.a).incrementAndGet();
        c52.d("add-to-queue");
        this.k();
        ((PriorityBlockingQueue)this.c).add((Object)c52);
    }

    public final gq0 j() {
        nq0 nq02 = (nq0)this.a;
        lq0 lq02 = lq0.r;
        gq0 gq02 = s5.g.E((f01)((gm0)this.i).g((Object)new Bundle()), (lq0)lq02, (nq0)nq02).h();
        nq0 nq03 = (nq0)this.a;
        lq0 lq03 = lq0.s;
        f01[] arrf01 = new f01[]{gq02, (f01)((pe1)this.g).c()};
        return nq03.a(lq03, arrf01).f((Callable)new u8((Object)this, 3, (Object)gq02)).h();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void k() {
        List list;
        List list2 = list = (List)this.j;
        synchronized (list2) {
            Iterator iterator = ((List)this.j).iterator();
            if (!iterator.hasNext()) {
                return;
            }
            s.z(iterator.next());
            throw null;
        }
    }

    public final void l() {
        s4 s42 = (s4)this.h;
        if (s42 != null) {
            s42.t = true;
            s42.interrupt();
        }
        y4[] arry4 = (y4[])this.g;
        int n2 = 0;
        for (int i2 = 0; i2 < 4; ++i2) {
            y4 y42 = arry4[i2];
            if (y42 == null) continue;
            y42.t = true;
            y42.interrupt();
        }
        s4 s43 = new s4((PriorityBlockingQueue)this.c, (PriorityBlockingQueue)this.d, (m5)this.e, (w7)this.k);
        this.h = s43;
        s43.start();
        while (n2 < 4) {
            y4 y43;
            ((y4[])this.g)[n2] = y43 = new y4((PriorityBlockingQueue)this.d, (x4)this.f, (m5)this.e, (w7)this.k);
            y43.start();
            ++n2;
        }
    }
}

