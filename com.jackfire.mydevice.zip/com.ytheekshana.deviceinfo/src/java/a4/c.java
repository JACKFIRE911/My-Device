/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a4;

import a4.e;
import a4.f;

public final class c
extends e {
    public static final f t;
    public double r = 0.0;
    public double s = 0.0;

    public static {
        f f4;
        t = f4 = f.a(64, new c());
        f4.f = 0.5f;
    }

    public static c b(double d4, double d6) {
        c c4 = (c)t.b();
        c4.r = d4;
        c4.s = d6;
        return c4;
    }

    @Override
    public final e a() {
        return new c();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("MPPointD, x: ");
        stringBuilder.append(this.r);
        stringBuilder.append(", y: ");
        stringBuilder.append(this.s);
        return stringBuilder.toString();
    }
}

