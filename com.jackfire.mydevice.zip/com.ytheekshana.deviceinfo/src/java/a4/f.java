/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a4;

import a4.e;

public final class f {
    public static int g;
    public int a;
    public int b;
    public Object[] c;
    public int d;
    public final e e;
    public float f;

    public f(int n2, e e2) {
        if (n2 > 0) {
            this.b = n2;
            this.c = new Object[n2];
            this.d = 0;
            this.e = e2;
            this.f = 1.0f;
            this.d();
            return;
        }
        throw new IllegalArgumentException("Object Pool must be instantiated with a capacity greater than 0!");
    }

    public static f a(int n2, e e2) {
        Class<f> class_ = f.class;
        synchronized (f.class) {
            int n3;
            f f2 = new f(n2, e2);
            f2.a = n3 = g;
            g = n3 + 1;
            // ** MonitorExit[var5_2] (shouldn't be in output)
            return f2;
        }
    }

    public final e b() {
        f f2 = this;
        synchronized (f2) {
            if (this.d == -1 && this.f > 0.0f) {
                this.d();
            }
            Object[] arrobject = this.c;
            int n2 = this.d;
            e e2 = (e)arrobject[n2];
            e2.q = -1;
            this.d = n2 - 1;
            return e2;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void c(e e2) {
        f f2 = this;
        synchronized (f2) {
            int n2;
            int n3 = e2.q;
            if (n3 != -1) {
                if (n3 == this.a) {
                    throw new IllegalArgumentException("The object passed is already stored in this pool!");
                }
                StringBuilder stringBuilder = new StringBuilder("The object to recycle already belongs to poolId ");
                stringBuilder.append(e2.q);
                stringBuilder.append(".  Object cannot belong to two different pool instances simultaneously!");
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            this.d = n2 = 1 + this.d;
            if (n2 >= this.c.length) {
                int n5;
                int n6 = this.b;
                this.b = n5 = n6 * 2;
                Object[] arrobject = new Object[n5];
                for (int i2 = 0; i2 < n6; ++i2) {
                    arrobject[i2] = this.c[i2];
                }
                this.c = arrobject;
            }
            e2.q = this.a;
            this.c[this.d] = e2;
            return;
        }
    }

    public final void d() {
        float f2 = this.f;
        int n2 = this.b;
        int n3 = (int)(f2 * (float)n2);
        if (n3 < 1) {
            n2 = 1;
        } else if (n3 <= n2) {
            n2 = n3;
        }
        for (int i2 = 0; i2 < n2; ++i2) {
            this.c[i2] = this.e.a();
        }
        this.d = n2 - 1;
    }
}

