/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a4;

public abstract class e {
    public int q = -1;

    public abstract e a();
}

