/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Matrix
 *  android.graphics.RectF
 *  android.view.View
 *  java.lang.Math
 *  java.lang.Object
 */
package a4;

import android.graphics.Matrix;
import android.graphics.RectF;
import android.view.View;

public final class i {
    public final Matrix a = new Matrix();
    public final RectF b = new RectF();
    public float c = 0.0f;
    public float d = 0.0f;
    public final float e = 1.0f;
    public final float f = Float.MAX_VALUE;
    public float g = 1.0f;
    public float h = Float.MAX_VALUE;
    public float i = 1.0f;
    public float j = 1.0f;
    public float k = 0.0f;
    public float l = 0.0f;
    public float m = 0.0f;
    public final Matrix n = new Matrix();
    public final float[] o = new float[9];

    public final void a(float[] arrf, View view) {
        Matrix matrix = this.n;
        matrix.reset();
        matrix.set(this.a);
        float f2 = arrf[0];
        RectF rectF = this.b;
        float f4 = f2 - rectF.left;
        float f5 = arrf[1] - rectF.top;
        matrix.postTranslate(-f4, -f5);
        this.e(matrix, view, true);
    }

    public final boolean b(float f2) {
        return this.b.left <= f2 + 1.0f;
    }

    public final boolean c(float f2) {
        float f4 = (float)((int)(f2 * 100.0f)) / 100.0f;
        return this.b.right >= f4 - 1.0f;
    }

    public final void d(Matrix matrix, RectF rectF) {
        float f2;
        float f4;
        float[] arrf = this.o;
        matrix.getValues(arrf);
        float f5 = arrf[2];
        float f6 = arrf[0];
        float f7 = arrf[5];
        float f8 = arrf[4];
        this.i = Math.min((float)Math.max((float)this.g, (float)f6), (float)this.h);
        this.j = Math.min((float)Math.max((float)this.e, (float)f8), (float)this.f);
        if (rectF != null) {
            f2 = rectF.width();
            f4 = rectF.height();
        } else {
            f2 = 0.0f;
            f4 = 0.0f;
        }
        this.k = Math.min((float)Math.max((float)f5, (float)(-f2 * (this.i - 1.0f) - this.l)), (float)this.l);
        float f9 = Math.max((float)Math.min((float)f7, (float)(f4 * (this.j - 1.0f) + this.m)), (float)(-this.m));
        arrf[2] = this.k;
        arrf[0] = this.i;
        arrf[5] = f9;
        arrf[4] = this.j;
        matrix.setValues(arrf);
    }

    public final void e(Matrix matrix, View view, boolean bl) {
        Matrix matrix2 = this.a;
        matrix2.set(matrix);
        this.d(matrix2, this.b);
        if (bl) {
            view.invalidate();
        }
        matrix.set(matrix2);
    }
}

