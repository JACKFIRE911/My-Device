/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  java.lang.CharSequence
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 */
package a4;

import android.graphics.Color;

public abstract class a {
    public static final int[] a;
    public static final int[] b;
    public static final int[] c;

    public static {
        Color.rgb((int)207, (int)248, (int)246);
        Color.rgb((int)148, (int)212, (int)212);
        Color.rgb((int)136, (int)180, (int)187);
        Color.rgb((int)118, (int)174, (int)175);
        Color.rgb((int)42, (int)109, (int)130);
        Color.rgb((int)217, (int)80, (int)138);
        Color.rgb((int)254, (int)149, (int)7);
        Color.rgb((int)254, (int)247, (int)120);
        Color.rgb((int)106, (int)167, (int)134);
        Color.rgb((int)53, (int)194, (int)209);
        int[] arrn = new int[]{Color.rgb((int)64, (int)89, (int)128), Color.rgb((int)149, (int)165, (int)124), Color.rgb((int)217, (int)184, (int)162), Color.rgb((int)191, (int)134, (int)134), Color.rgb((int)179, (int)48, (int)80)};
        a = arrn;
        int[] arrn2 = new int[]{Color.rgb((int)193, (int)37, (int)82), Color.rgb((int)255, (int)102, (int)0), Color.rgb((int)245, (int)199, (int)0), Color.rgb((int)106, (int)150, (int)31), Color.rgb((int)179, (int)100, (int)53)};
        b = arrn2;
        int[] arrn3 = new int[]{Color.rgb((int)192, (int)255, (int)140), Color.rgb((int)255, (int)247, (int)140), Color.rgb((int)255, (int)208, (int)140), Color.rgb((int)140, (int)234, (int)255), Color.rgb((int)255, (int)140, (int)157)};
        c = arrn3;
        a.a("#2ecc71");
        a.a("#f1c40f");
        a.a("#e74c3c");
        a.a("#3498db");
    }

    public static void a(String string) {
        int n2 = (int)Long.parseLong((String)string.replace((CharSequence)"#", (CharSequence)""), (int)16);
        Color.rgb((int)(255 & n2 >> 16), (int)(255 & n2 >> 8), (int)(255 & n2 >> 0));
    }
}

