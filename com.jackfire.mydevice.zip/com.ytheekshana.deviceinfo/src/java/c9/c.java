/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 */
package c9;

import a2.s;
import s7.j;

public final class c {
    public final String a;

    public c(String string) {
        this.a = string;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof c)) {
            return false;
        }
        c c2 = (c)object;
        return j.b((Object)this.a, (Object)c2.a);
    }

    public final int hashCode() {
        String string = this.a;
        if (string == null) {
            return 0;
        }
        return string.hashCode();
    }

    public final String toString() {
        return s.v(new StringBuilder("AppsInfo(name="), this.a, ")");
    }
}

