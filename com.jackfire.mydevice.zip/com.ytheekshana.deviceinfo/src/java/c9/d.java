/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 */
package c9;

import s7.j;

public final class d {
    public final String a;
    public final String b;

    public d(String string, String string2) {
        this.a = string;
        this.b = string2;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof d)) {
            return false;
        }
        d d2 = (d)object;
        String string = d2.a;
        if (!j.b((Object)this.a, (Object)string)) {
            return false;
        }
        return j.b((Object)this.b, (Object)d2.b);
    }

    public final int hashCode() {
        String string = this.a;
        int n2 = string == null ? 0 : string.hashCode();
        int n5 = n2 * 31;
        String string2 = this.b;
        int n6 = string2 == null ? 0 : string2.hashCode();
        return n5 + n6;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CPUCoreInfo(coreName=");
        stringBuilder.append(this.a);
        stringBuilder.append(", coreValue=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

