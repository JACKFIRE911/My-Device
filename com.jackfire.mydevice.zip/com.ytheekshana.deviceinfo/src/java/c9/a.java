/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 */
package c9;

import a2.s;
import android.graphics.drawable.Drawable;
import s7.j;

public final class a {
    public final String a;
    public final String b;
    public final String c;
    public final Drawable d;
    public final int e;
    public final String f;
    public final String g;

    public a(String string, String string2, String string3, Drawable drawable, int n2, String string4, String string5) {
        j.i((Object)string, (String)"name");
        j.i((Object)string3, (String)"count");
        j.i((Object)string4, (String)"filterType");
        j.i((Object)string5, (String)"sortValue");
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = drawable;
        this.e = n2;
        this.f = string4;
        this.g = string5;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof a)) {
            return false;
        }
        a a2 = (a)object;
        String string = a2.a;
        if (!j.b((Object)this.a, (Object)string)) {
            return false;
        }
        if (!j.b((Object)this.b, (Object)a2.b)) {
            return false;
        }
        if (!j.b((Object)this.c, (Object)a2.c)) {
            return false;
        }
        if (!j.b((Object)this.d, (Object)a2.d)) {
            return false;
        }
        if (this.e != a2.e) {
            return false;
        }
        if (!j.b((Object)this.f, (Object)a2.f)) {
            return false;
        }
        return j.b((Object)this.g, (Object)a2.g);
    }

    public final int hashCode() {
        int n2 = 31 * this.a.hashCode();
        String string = this.b;
        int n5 = string == null ? 0 : string.hashCode();
        int n6 = 31 * (31 * (n2 + n5) + this.c.hashCode());
        Drawable drawable = this.d;
        int n7 = drawable == null ? 0 : drawable.hashCode();
        return 31 * (31 * (31 * (n6 + n7) + this.e) + this.f.hashCode()) + this.g.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("AppAnalyzerInfo(name=");
        stringBuilder.append(this.a);
        stringBuilder.append(", commonValue=");
        stringBuilder.append(this.b);
        stringBuilder.append(", count=");
        stringBuilder.append(this.c);
        stringBuilder.append(", icon=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(", totalCount=");
        stringBuilder.append(this.e);
        stringBuilder.append(", filterType=");
        stringBuilder.append(this.f);
        stringBuilder.append(", sortValue=");
        return s.v(stringBuilder, this.g, ")");
    }
}

