/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 */
package c9;

import s7.j;

public final class i {
    public final String a;
    public final String b;

    public i(String string, String string2) {
        j.i((Object)string, (String)"thermalName");
        j.i((Object)string2, (String)"thermalValue");
        this.a = string;
        this.b = string2;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof i)) {
            return false;
        }
        i i2 = (i)object;
        String string = i2.a;
        if (!j.b((Object)this.a, (Object)string)) {
            return false;
        }
        return j.b((Object)this.b, (Object)i2.b);
    }

    public final int hashCode() {
        return 31 * this.a.hashCode() + this.b.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("ThermalInfo(thermalName=");
        stringBuilder.append(this.a);
        stringBuilder.append(", thermalValue=");
        stringBuilder.append(this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

