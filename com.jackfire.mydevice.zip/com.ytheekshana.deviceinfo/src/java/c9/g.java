/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 */
package c9;

import s7.j;

public final class g {
    public final String a;
    public final String b;
    public final String c;
    public final String d;
    public final String e;
    public final Integer f;
    public final Integer g;
    public final Float h;
    public final Float i;
    public final Boolean j;
    public final Boolean k;

    public g(String string, String string2, String string3, String string4, String string5, Integer n2, Integer n5, Float f2, Float f4, Boolean bl, Boolean bl2) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = string4;
        this.e = string5;
        this.f = n2;
        this.g = n5;
        this.h = f2;
        this.i = f4;
        this.j = bl;
        this.k = bl2;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof g)) {
            return false;
        }
        g g2 = (g)object;
        String string = g2.a;
        if (!j.b((Object)this.a, (Object)string)) {
            return false;
        }
        if (!j.b((Object)this.b, (Object)g2.b)) {
            return false;
        }
        if (!j.b((Object)this.c, (Object)g2.c)) {
            return false;
        }
        if (!j.b((Object)this.d, (Object)g2.d)) {
            return false;
        }
        if (!j.b((Object)this.e, (Object)g2.e)) {
            return false;
        }
        if (!j.b((Object)this.f, (Object)g2.f)) {
            return false;
        }
        if (!j.b((Object)this.g, (Object)g2.g)) {
            return false;
        }
        if (!j.b((Object)this.h, (Object)g2.h)) {
            return false;
        }
        if (!j.b((Object)this.i, (Object)g2.i)) {
            return false;
        }
        if (!j.b((Object)this.j, (Object)g2.j)) {
            return false;
        }
        return j.b((Object)this.k, (Object)g2.k);
    }

    public final int hashCode() {
        String string = this.a;
        int n2 = string == null ? 0 : string.hashCode();
        int n5 = n2 * 31;
        String string2 = this.b;
        int n6 = string2 == null ? 0 : string2.hashCode();
        int n7 = 31 * (n5 + n6);
        String string3 = this.c;
        int n8 = string3 == null ? 0 : string3.hashCode();
        int n9 = 31 * (n7 + n8);
        String string4 = this.d;
        int n10 = string4 == null ? 0 : string4.hashCode();
        int n11 = 31 * (n9 + n10);
        String string5 = this.e;
        int n12 = string5 == null ? 0 : string5.hashCode();
        int n13 = 31 * (n11 + n12);
        Integer n14 = this.f;
        int n15 = n14 == null ? 0 : n14.hashCode();
        int n16 = 31 * (n13 + n15);
        Integer n17 = this.g;
        int n18 = n17 == null ? 0 : n17.hashCode();
        int n19 = 31 * (n16 + n18);
        Float f2 = this.h;
        int n20 = f2 == null ? 0 : f2.hashCode();
        int n21 = 31 * (n19 + n20);
        Float f4 = this.i;
        int n22 = f4 == null ? 0 : f4.hashCode();
        int n23 = 31 * (n21 + n22);
        Boolean bl = this.j;
        int n24 = bl == null ? 0 : bl.hashCode();
        int n25 = 31 * (n23 + n24);
        Boolean bl2 = this.k;
        int n26 = bl2 == null ? 0 : bl2.hashCode();
        return n25 + n26;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("SensorInfo(vendorNameOnly=");
        stringBuilder.append(this.a);
        stringBuilder.append(", sensorName=");
        stringBuilder.append(this.b);
        stringBuilder.append(", vendorName=");
        stringBuilder.append(this.c);
        stringBuilder.append(", sensorType=");
        stringBuilder.append(this.d);
        stringBuilder.append(", sensorPower=");
        stringBuilder.append(this.e);
        stringBuilder.append(", sensorImage=");
        stringBuilder.append((Object)this.f);
        stringBuilder.append(", sensorTypeInt=");
        stringBuilder.append((Object)this.g);
        stringBuilder.append(", resolution=");
        stringBuilder.append((Object)this.h);
        stringBuilder.append(", maximumRange=");
        stringBuilder.append((Object)this.i);
        stringBuilder.append(", isWakeUpSensor=");
        stringBuilder.append((Object)this.j);
        stringBuilder.append(", isDynamicSensor=");
        stringBuilder.append((Object)this.k);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

