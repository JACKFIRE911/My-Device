/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.ads.xe1
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 */
package c9;

import com.google.android.gms.internal.ads.xe1;
import s7.j;

public final class h {
    public final String a;
    public final int b;
    public final int c;

    public h(int n2, int n5, String string) {
        this.a = string;
        this.b = n2;
        this.c = n5;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof h)) {
            return false;
        }
        h h2 = (h)object;
        String string = h2.a;
        if (!j.b((Object)this.a, (Object)string)) {
            return false;
        }
        if (this.b != h2.b) {
            return false;
        }
        return this.c == h2.c;
    }

    public final int hashCode() {
        return 31 * (31 * this.a.hashCode() + this.b) + this.c;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("TestInfo(testName=");
        stringBuilder.append(this.a);
        stringBuilder.append(", testIcon=");
        stringBuilder.append(this.b);
        stringBuilder.append(", testStatus=");
        return xe1.j((StringBuilder)stringBuilder, (int)this.c, (String)")");
    }
}

