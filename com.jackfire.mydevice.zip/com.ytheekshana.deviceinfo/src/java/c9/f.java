/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.ActivityManager$MemoryInfo
 *  android.content.Context
 *  android.os.Environment
 *  android.os.StatFs
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 *  y6.e
 */
package c9;

import a8.b1;
import android.app.ActivityManager;
import android.content.Context;
import android.os.Environment;
import android.os.StatFs;
import c0.b;
import s7.j;
import y6.e;

public final class f {
    public final Context a;
    public final ActivityManager b;
    public double c;
    public double d;
    public double e;
    public double f;
    public double g;
    public double h;
    public double i;
    public double j;
    public String k;
    public String l;
    public String m;
    public double n;
    public double o;
    public double p;
    public double q;
    public double r;
    public double s;
    public double t;
    public double u;

    public f(Context context) {
        Object object = context.getSystemService("activity");
        j.g((Object)object, (String)"null cannot be cast to non-null type android.app.ActivityManager");
        ActivityManager activityManager = (ActivityManager)object;
        j.i((Object)context, (String)"context");
        this.a = context;
        this.b = activityManager;
        this.k = "";
        this.l = "";
        this.m = "";
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void a() {
        boolean bl = j.b((Object)Environment.getExternalStorageState(), (Object)"mounted");
        Context context = this.a;
        boolean bl2 = bl && b.b(context, null).length >= 2;
        b1.X = bl2;
        if (!bl2) return;
        String string = e.T((Context)context)[0];
        StatFs statFs = new StatFs(string);
        double d2 = statFs.getBlockSizeLong();
        double d3 = d2 * (double)statFs.getAvailableBlocksLong();
        double d4 = 1024;
        try {
            double d5;
            double d6;
            this.s = d3 / d4 / d4 / d4;
            this.r = d5 = d2 * (double)statFs.getBlockCountLong() / d4 / d4 / d4;
            this.t = d6 = d5 - this.s;
            this.u = d6 * (double)100 / d5;
            j.h((Object)string, (String)"path");
            this.m = string;
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public final void b() {
        String string;
        double d2;
        StatFs statFs;
        double d3;
        double d4;
        double d5;
        try {
            string = Environment.getDataDirectory().getAbsolutePath();
            statFs = new StatFs(string);
            d5 = statFs.getBlockSizeLong();
            d3 = d5 * (double)statFs.getAvailableBlocksLong();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        double d6 = 1024;
        this.o = d3 / d6 / d6 / d6;
        this.n = d4 = d5 * (double)statFs.getBlockCountLong() / d6 / d6 / d6;
        this.p = d2 = d4 - this.o;
        this.q = d2 * (double)100 / d4;
        j.h((Object)string, (String)"path");
        this.l = string;
    }

    public final void c() {
        ActivityManager.MemoryInfo memoryInfo;
        double d2;
        long l2;
        double d3;
        try {
            memoryInfo = new ActivityManager.MemoryInfo();
            this.b.getMemoryInfo(memoryInfo);
            l2 = memoryInfo.availMem;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        long l3 = 1024;
        this.d = d3 = (double)(l2 / l3 / l3);
        this.c = d2 = (double)(memoryInfo.totalMem / l3 / l3);
        double d4 = d2 - d3;
        this.e = d4;
        this.f = d4 * (double)100 / d2;
    }

    public final void d() {
        String string;
        double d2;
        StatFs statFs;
        double d3;
        double d4;
        double d5;
        try {
            string = Environment.getRootDirectory().getAbsolutePath();
            statFs = new StatFs(string);
            d5 = statFs.getBlockSizeLong();
            d3 = d5 * (double)statFs.getAvailableBlocksLong();
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        double d6 = 1024;
        this.h = d3 / d6 / d6 / d6;
        this.g = d4 = d5 * (double)statFs.getBlockCountLong() / d6 / d6 / d6;
        this.i = d2 = d4 - this.h;
        this.j = d2 * (double)100 / d4;
        j.h((Object)string, (String)"path");
        this.k = string;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof f)) {
            return false;
        }
        f f2 = (f)object;
        Context context = f2.a;
        if (!j.b((Object)this.a, (Object)context)) {
            return false;
        }
        return j.b((Object)this.b, (Object)f2.b);
    }

    public final int hashCode() {
        return 31 * this.a.hashCode() + this.b.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("MemoryInfo(context=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append(", activityManager=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

