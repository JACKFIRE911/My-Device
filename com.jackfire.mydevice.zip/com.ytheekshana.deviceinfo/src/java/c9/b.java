/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 */
package c9;

import s7.j;

public final class b {
    public final String a;
    public final String b;
    public final String c;
    public final Long d;

    public b(String string, String string2, String string3, Long l2) {
        this.a = string;
        this.b = string2;
        this.c = string3;
        this.d = l2;
    }

    public final String a() {
        return this.a;
    }

    public final String b() {
        return this.b;
    }

    public final String c() {
        return this.c;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b5 = (b)object;
        String string = b5.a;
        if (!j.b((Object)this.a, (Object)string)) {
            return false;
        }
        if (!j.b((Object)this.b, (Object)b5.b)) {
            return false;
        }
        if (!j.b((Object)this.c, (Object)b5.c)) {
            return false;
        }
        return j.b((Object)this.d, (Object)b5.d);
    }

    public final int hashCode() {
        String string = this.a;
        int n2 = string == null ? 0 : string.hashCode();
        int n5 = n2 * 31;
        String string2 = this.b;
        int n6 = string2 == null ? 0 : string2.hashCode();
        int n7 = 31 * (n5 + n6);
        String string3 = this.c;
        int n8 = string3 == null ? 0 : string3.hashCode();
        int n9 = 31 * (n7 + n8);
        Long l2 = this.d;
        int n10 = l2 == null ? 0 : l2.hashCode();
        return n9 + n10;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("AppInfo(appName=");
        stringBuilder.append(this.a);
        stringBuilder.append(", packageName=");
        stringBuilder.append(this.b);
        stringBuilder.append(", versionName=");
        stringBuilder.append(this.c);
        stringBuilder.append(", size=");
        stringBuilder.append((Object)this.d);
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

