/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.t
 *  androidx.work.impl.WorkDatabase
 *  b2.p
 *  j2.s
 *  j2.u
 *  j2.w
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.concurrent.Callable
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Future
 *  t7.e
 */
package b2;

import androidx.fragment.app.t;
import androidx.work.impl.WorkDatabase;
import b2.p;
import e.s0;
import j2.s;
import j2.u;
import j2.w;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;
import t7.e;

public final class n
implements Callable {
    public final /* synthetic */ int a;
    public final /* synthetic */ Object b;
    public final /* synthetic */ Object c;
    public final /* synthetic */ Object d;

    public /* synthetic */ n(Object object, Object object2, Object object3, int n2) {
        this.a = n2;
        this.b = object;
        this.c = object2;
        this.d = object3;
    }

    public final Object call() {
        int n2 = this.a;
        Object object = this.d;
        Object object2 = this.c;
        Object object3 = this.b;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                p p2 = (p)object3;
                ArrayList arrayList = (ArrayList)object2;
                String string = (String)object;
                WorkDatabase workDatabase = p2.u;
                arrayList.addAll((Collection)workDatabase.x().q(string));
                return workDatabase.w().i(string);
            }
        }
        e e2 = (e)object3;
        Callable callable = (Callable)object2;
        t t2 = (t)object;
        e2.getClass();
        s0 s02 = new s0((Object)callable, 17, (Object)t2);
        return e2.q.submit((Runnable)s02);
    }
}

