/*
 * Decompiled with CFR 0.0.
 */
package b2;

import j1.x;

public final class b
extends x {
    public static final b a = new b();
}

