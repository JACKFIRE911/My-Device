/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j2.s
 *  java.lang.Object
 *  java.lang.String
 */
package b2;

import j2.s;

public interface r {
    public void a(String var1);

    public /* varargs */ void e(s ... var1);

    public boolean f();
}

