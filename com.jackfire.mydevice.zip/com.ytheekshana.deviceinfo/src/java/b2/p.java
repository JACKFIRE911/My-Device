/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.PowerManager
 *  android.os.PowerManager$WakeLock
 *  androidx.work.impl.WorkDatabase
 *  androidx.work.impl.foreground.SystemForegroundService
 *  com.google.android.gms.internal.ads.zp
 *  j2.w
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Set
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Executor
 *  l2.h
 *  l2.j
 */
package b2;

import a2.b;
import a2.i;
import a2.q;
import a2.r;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.PowerManager;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.foreground.SystemForegroundService;
import b2.c;
import b2.e0;
import b2.n;
import b2.o;
import b2.t;
import c0.f;
import com.google.android.gms.internal.ads.zp;
import j2.s;
import j2.w;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.Executor;
import l2.h;
import l2.j;
import m2.a;

public final class p
implements c,
i2.a {
    public static final String C = r.f("Processor");
    public final ArrayList A;
    public final Object B;
    public PowerManager.WakeLock q;
    public final Context r;
    public final b s;
    public final a t;
    public final WorkDatabase u;
    public final HashMap v;
    public final HashMap w;
    public final HashMap x;
    public final List y;
    public final HashSet z;

    public p(Context context, b b4, w w2, WorkDatabase workDatabase, List list) {
        this.r = context;
        this.s = b4;
        this.t = w2;
        this.u = workDatabase;
        this.w = new HashMap();
        this.v = new HashMap();
        this.y = list;
        this.z = new HashSet();
        this.A = new ArrayList();
        this.q = null;
        this.B = new Object();
        this.x = new HashMap();
    }

    public static boolean d(String string, e0 e02) {
        if (e02 != null) {
            e02.H = true;
            e02.h();
            e02.G.cancel(true);
            if (e02.v != null && e02.G.q instanceof l2.a) {
                e02.v.stop();
            } else {
                StringBuilder stringBuilder = new StringBuilder("WorkSpec ");
                stringBuilder.append((Object)e02.u);
                stringBuilder.append(" is already done. Not interrupting.");
                String string2 = stringBuilder.toString();
                r.d().a(e0.I, string2);
            }
            r r4 = r.d();
            String string3 = C;
            StringBuilder stringBuilder = new StringBuilder("WorkerWrapper interrupted for ");
            stringBuilder.append(string);
            r4.a(string3, stringBuilder.toString());
            return true;
        }
        r r5 = r.d();
        String string4 = C;
        StringBuilder stringBuilder = new StringBuilder("WorkerWrapper could not be found for ");
        stringBuilder.append(string);
        r5.a(string4, stringBuilder.toString());
        return false;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a(c c4) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            this.A.add((Object)c4);
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final s b(String string) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            e0 e02 = (e0)this.v.get((Object)string);
            if (e02 == null) {
                e02 = (e0)this.w.get((Object)string);
            }
            if (e02 == null) return null;
            return e02.u;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void c(j2.j j3, boolean bl) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            e0 e02 = (e0)this.w.get((Object)j3.a);
            if (e02 != null && j3.equals(j2.f.d(e02.u))) {
                this.w.remove((Object)j3.a);
            }
            r r4 = r.d();
            String string = C;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(p.class.getSimpleName());
            stringBuilder.append(" ");
            stringBuilder.append(j3.a);
            stringBuilder.append(" executed; reschedule = ");
            stringBuilder.append(bl);
            r4.a(string, stringBuilder.toString());
            Iterator iterator = this.A.iterator();
            while (iterator.hasNext()) {
                ((c)iterator.next()).c(j3, bl);
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final boolean e(String string) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            return this.z.contains((Object)string);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final boolean f(String string) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            if (this.w.containsKey((Object)string)) return true;
            if (!this.v.containsKey((Object)string)) return false;
            return true;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void g(c c4) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            this.A.remove((Object)c4);
            return;
        }
    }

    public final void h(j2.j j3) {
        ((Executor)((w)this.t).t).execute((Runnable)new o(this, j3));
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void i(String string, i i3) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            r r4 = r.d();
            String string2 = C;
            StringBuilder stringBuilder = new StringBuilder("Moving WorkSpec (");
            stringBuilder.append(string);
            stringBuilder.append(") to the foreground");
            r4.e(string2, stringBuilder.toString());
            e0 e02 = (e0)this.w.remove((Object)string);
            if (e02 != null) {
                if (this.q == null) {
                    PowerManager.WakeLock wakeLock;
                    this.q = wakeLock = k2.p.a(this.r, "ProcessorForegroundLck");
                    wakeLock.acquire();
                }
                this.v.put((Object)string, (Object)e02);
                Intent intent = i2.c.e(this.r, j2.f.d(e02.u), i3);
                Context context = this.r;
                if (Build.VERSION.SDK_INT >= 26) {
                    f.b(context, intent);
                } else {
                    context.startService(intent);
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final boolean j(t t2, w w2) {
        Object object;
        e0 e02;
        j2.j j3 = t2.a;
        ArrayList arrayList = new ArrayList();
        String string = j3.a;
        s s3 = (s)this.u.o(new n(this, (Object)arrayList, string, 0));
        if (s3 == null) {
            r r4 = r.d();
            String string2 = C;
            StringBuilder stringBuilder = new StringBuilder("Didn't find WorkSpec for id ");
            stringBuilder.append((Object)j3);
            r4.g(string2, stringBuilder.toString());
            this.h(j3);
            return false;
        }
        Object object2 = object = this.B;
        synchronized (object2) {
            if (this.f(string)) {
                Set set = (Set)this.x.get((Object)string);
                if (((t)set.iterator().next()).a.b == j3.b) {
                    set.add((Object)t2);
                    r r5 = r.d();
                    String string3 = C;
                    StringBuilder stringBuilder = new StringBuilder("Work ");
                    stringBuilder.append((Object)j3);
                    stringBuilder.append(" is already enqueued for processing");
                    r5.a(string3, stringBuilder.toString());
                } else {
                    this.h(j3);
                }
                return false;
            }
            if (s3.t != j3.b) {
                this.h(j3);
                return false;
            }
            zp zp2 = new zp(this.r, this.s, this.t, (i2.a)this, this.u, s3, arrayList);
            zp2.h = this.y;
            if (w2 != null) {
                zp2.j = w2;
            }
            e02 = new e0(zp2);
            j j4 = e02.F;
            k0.a a3 = new k0.a(this, t2.a, (Object)j4, 5, 0);
            j4.b((Runnable)a3, (Executor)((w)this.t).t);
            this.w.put((Object)string, (Object)e02);
            HashSet hashSet = new HashSet();
            hashSet.add((Object)t2);
            this.x.put((Object)string, (Object)hashSet);
        }
        ((k2.n)((w)this.t).r).execute(e02);
        r r6 = r.d();
        String string4 = C;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(p.class.getSimpleName());
        stringBuilder.append(": processing ");
        stringBuilder.append((Object)j3);
        r6.a(string4, stringBuilder.toString());
        return true;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void k(String string) {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            this.v.remove((Object)string);
            this.l();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void l() {
        Object object;
        Object object2 = object = this.B;
        synchronized (object2) {
            if (!(true ^ this.v.isEmpty())) {
                Context context = this.r;
                Intent intent = new Intent(context, SystemForegroundService.class);
                intent.setAction("ACTION_STOP_FOREGROUND");
                try {
                    this.r.startService(intent);
                }
                catch (Throwable throwable) {
                    r.d().c(C, "Unable to stop foreground service", throwable);
                }
                PowerManager.WakeLock wakeLock = this.q;
                if (wakeLock != null) {
                    wakeLock.release();
                    this.q = null;
                }
            }
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final boolean m(t t2) {
        Object object;
        String string = t2.a.a;
        Object object2 = object = this.B;
        synchronized (object2) {
            r r4 = r.d();
            String string2 = C;
            StringBuilder stringBuilder = new StringBuilder("Processor stopping foreground work ");
            stringBuilder.append(string);
            r4.a(string2, stringBuilder.toString());
            e0 e02 = (e0)this.v.remove((Object)string);
            if (e02 != null) {
                this.x.remove((Object)string);
            }
            return p.d(string, e02);
        }
    }
}

