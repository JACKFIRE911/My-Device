/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  o1.c
 */
package b2;

import k1.a;
import o1.c;

public final class i
extends a {
    public static final i c = new i();

    public i() {
        super(4, 5);
    }

    @Override
    public final void a(c c4) {
        c4.h("ALTER TABLE workspec ADD COLUMN `trigger_content_update_delay` INTEGER NOT NULL DEFAULT -1");
        c4.h("ALTER TABLE workspec ADD COLUMN `trigger_max_content_delay` INTEGER NOT NULL DEFAULT -1");
    }
}

