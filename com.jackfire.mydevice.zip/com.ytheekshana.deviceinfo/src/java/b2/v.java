/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  o1.g
 */
package b2;

import android.content.Context;
import n1.c;
import n1.d;
import n1.e;
import n1.f;
import o1.g;
import s7.j;

public final class v
implements e {
    public final /* synthetic */ Context q;

    public /* synthetic */ v(Context context) {
        this.q = context;
    }

    @Override
    public final f c(d d4) {
        Context context = this.q;
        j.i((Object)context, "$context");
        String string = d4.b;
        c c4 = d4.c;
        j.i(c4, "callback");
        boolean bl = string == null || string.length() == 0;
        if (true ^ bl) {
            g g4 = new g(context, string, c4, true, true);
            return g4;
        }
        throw new IllegalArgumentException("Must set a non-null database name to a configuration that uses the no backup directory.".toString());
    }
}

