/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.b0
 *  java.lang.Object
 *  java.lang.Throwable
 *  l2.j
 */
package b2;

import a2.v;
import a2.w;
import a2.x;
import a2.y;
import a8.b1;
import androidx.lifecycle.b0;
import l2.j;

public final class m
implements y {
    public final b0 c = new b0();
    public final j d = new j();

    public m() {
        this.a(y.b);
    }

    public final void a(b1 b12) {
        this.c.f((Object)b12);
        boolean bl = b12 instanceof x;
        j j3 = this.d;
        if (bl) {
            j3.j((Object)((x)b12));
            return;
        }
        if (b12 instanceof v) {
            j3.k(((v)b12).u0);
        }
    }
}

