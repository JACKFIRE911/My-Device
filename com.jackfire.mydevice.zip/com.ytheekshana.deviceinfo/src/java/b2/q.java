/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentValues
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  java.lang.Class
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  m8.d
 *  o1.c
 */
package b2;

import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import k1.a;
import m8.d;
import o1.c;

public final class q
extends a {
    public final /* synthetic */ int c;
    public final Object d;

    public q() {
        this.c = 2;
        super(14, 15);
        this.d = new d(null);
    }

    public q(Context context) {
        this.c = 1;
        super(9, 10);
        this.d = context;
    }

    public q(Context context, int n2, int n3) {
        this.c = 0;
        super(n2, n3);
        this.d = context;
    }

    @Override
    public final void a(c c4) {
        int n2 = this.c;
        Object object = this.d;
        switch (n2) {
            default: {
                break;
            }
            case 1: {
                SharedPreferences sharedPreferences;
                c4.h("CREATE TABLE IF NOT EXISTS `Preference` (`key` TEXT NOT NULL, `long_value` INTEGER, PRIMARY KEY(`key`))");
                Context context = (Context)object;
                SharedPreferences sharedPreferences2 = context.getSharedPreferences("androidx.work.util.preferences", 0);
                if (sharedPreferences2.contains("reschedule_needed") || sharedPreferences2.contains("last_cancel_all_time_ms")) {
                    long l3 = 0L;
                    long l6 = sharedPreferences2.getLong("last_cancel_all_time_ms", l3);
                    if (sharedPreferences2.getBoolean("reschedule_needed", false)) {
                        l3 = 1L;
                    }
                    c4.d();
                    Object[] arrobject = new Object[]{"last_cancel_all_time_ms", l6};
                    c4.t("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", arrobject);
                    Object[] arrobject2 = new Object[]{"reschedule_needed", l3};
                    c4.t("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", arrobject2);
                    sharedPreferences2.edit().clear().apply();
                    c4.r();
                }
                if ((sharedPreferences = context.getSharedPreferences("androidx.work.util.id", 0)).contains("next_job_scheduler_id") || sharedPreferences.contains("next_job_scheduler_id")) {
                    int n3 = sharedPreferences.getInt("next_job_scheduler_id", 0);
                    int n5 = sharedPreferences.getInt("next_alarm_manager_id", 0);
                    c4.d();
                    Object[] arrobject = new Object[]{"next_job_scheduler_id", n3};
                    c4.t("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", arrobject);
                    Object[] arrobject3 = new Object[]{"next_alarm_manager_id", n5};
                    c4.t("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", arrobject3);
                    sharedPreferences.edit().clear().apply();
                    c4.r();
                }
                return;
                finally {
                    c4.c();
                }
                finally {
                    c4.c();
                }
            }
            case 0: {
                if (this.b >= 10) {
                    Object[] arrobject = new Object[]{"reschedule_needed", 1};
                    c4.t("INSERT OR REPLACE INTO `Preference` (`key`, `long_value`) VALUES (@key, @long_value)", arrobject);
                    return;
                }
                ((Context)object).getSharedPreferences("androidx.work.util.preferences", 0).edit().putBoolean("reschedule_needed", true).apply();
                return;
            }
        }
        c4.h("CREATE TABLE IF NOT EXISTS `_new_WorkSpec` (`id` TEXT NOT NULL, `state` INTEGER NOT NULL, `worker_class_name` TEXT NOT NULL, `input_merger_class_name` TEXT, `input` BLOB NOT NULL, `output` BLOB NOT NULL, `initial_delay` INTEGER NOT NULL, `interval_duration` INTEGER NOT NULL, `flex_duration` INTEGER NOT NULL, `run_attempt_count` INTEGER NOT NULL, `backoff_policy` INTEGER NOT NULL, `backoff_delay_duration` INTEGER NOT NULL, `last_enqueue_time` INTEGER NOT NULL, `minimum_retention_duration` INTEGER NOT NULL, `schedule_requested_at` INTEGER NOT NULL, `run_in_foreground` INTEGER NOT NULL, `out_of_quota_policy` INTEGER NOT NULL, `period_count` INTEGER NOT NULL DEFAULT 0, `required_network_type` INTEGER NOT NULL, `requires_charging` INTEGER NOT NULL, `requires_device_idle` INTEGER NOT NULL, `requires_battery_not_low` INTEGER NOT NULL, `requires_storage_not_low` INTEGER NOT NULL, `trigger_content_update_delay` INTEGER NOT NULL, `trigger_max_content_delay` INTEGER NOT NULL, `content_uri_triggers` BLOB NOT NULL, PRIMARY KEY(`id`))");
        c4.h("INSERT INTO `_new_WorkSpec` (`id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`last_enqueue_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers`) SELECT `id`,`state`,`worker_class_name`,`input_merger_class_name`,`input`,`output`,`initial_delay`,`interval_duration`,`flex_duration`,`run_attempt_count`,`backoff_policy`,`backoff_delay_duration`,`period_start_time`,`minimum_retention_duration`,`schedule_requested_at`,`run_in_foreground`,`out_of_quota_policy`,`required_network_type`,`requires_charging`,`requires_device_idle`,`requires_battery_not_low`,`requires_storage_not_low`,`trigger_content_update_delay`,`trigger_max_content_delay`,`content_uri_triggers` FROM `WorkSpec`");
        c4.h("DROP TABLE `WorkSpec`");
        c4.h("ALTER TABLE `_new_WorkSpec` RENAME TO `WorkSpec`");
        c4.h("CREATE INDEX IF NOT EXISTS `index_WorkSpec_schedule_requested_at` ON `WorkSpec` (`schedule_requested_at`)");
        c4.h("CREATE INDEX IF NOT EXISTS `index_WorkSpec_last_enqueue_time` ON `WorkSpec` (`last_enqueue_time`)");
        ((d)object).getClass();
        c4.h("UPDATE workspec SET period_count = 1 WHERE last_enqueue_time <> 0 AND interval_duration <> 0");
        ContentValues contentValues = new ContentValues(1);
        contentValues.put("last_enqueue_time", Long.valueOf((long)System.currentTimeMillis()));
        c4.b("WorkSpec", 3, contentValues, "last_enqueue_time = 0 AND interval_duration <> 0 ", new Object[0]);
    }
}

