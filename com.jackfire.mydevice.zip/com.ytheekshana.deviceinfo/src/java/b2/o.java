/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  b2.p
 *  j2.j
 *  java.lang.Object
 *  java.lang.Runnable
 */
package b2;

import b2.p;
import j2.j;

public final class o
implements Runnable {
    public final /* synthetic */ p q;
    public final /* synthetic */ j r;
    public final /* synthetic */ boolean s;

    public /* synthetic */ o(p p2, j j2) {
        this.q = p2;
        this.r = j2;
        this.s = false;
    }

    public final void run() {
        this.q.c(this.r, this.s);
    }
}

