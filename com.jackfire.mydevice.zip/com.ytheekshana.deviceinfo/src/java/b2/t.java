/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j2.j
 *  java.lang.Object
 */
package b2;

import j2.j;

public final class t {
    public final j a;

    public t(j j2) {
        this.a = j2;
    }
}

