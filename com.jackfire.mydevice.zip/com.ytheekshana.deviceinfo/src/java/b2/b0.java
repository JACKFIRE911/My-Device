/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a2.v
 *  a2.x
 *  androidx.work.impl.WorkDatabase
 *  b2.a0
 *  b2.d0
 *  b2.m
 *  b2.p
 *  com.bumptech.glide.d
 *  j2.r
 *  j2.s
 *  j2.u
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.UnsupportedOperationException
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Set
 *  s7.j
 *  t9.a
 */
package b2;

import a2.b;
import a2.v;
import a2.x;
import a2.y;
import a8.b1;
import androidx.work.impl.WorkDatabase;
import b2.a0;
import b2.d0;
import b2.m;
import b2.p;
import com.bumptech.glide.d;
import j2.r;
import j2.s;
import j2.u;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import s7.j;
import t9.a;

public final class b0
implements Runnable {
    public final /* synthetic */ a0 q;
    public final /* synthetic */ String r;
    public final /* synthetic */ m s;
    public final /* synthetic */ a t;
    public final /* synthetic */ a2.d0 u;

    public /* synthetic */ b0(a0 a02, String string, m m2, d0 d02, a2.d0 d03) {
        this.q = a02;
        this.r = string;
        this.s = m2;
        this.t = d02;
        this.u = d03;
    }

    public final void run() {
        a0 a02 = this.q;
        j.i((Object)a02, (String)"$this_enqueueUniquelyNamedPeriodic");
        String string = this.r;
        j.i((Object)string, (String)"$name");
        m m2 = this.s;
        j.i((Object)m2, (String)"$operation");
        a a2 = this.t;
        j.i((Object)a2, (String)"$enqueueNew");
        a2.d0 d02 = this.u;
        j.i((Object)d02, (String)"$workRequest");
        u u2 = a02.s.w();
        ArrayList arrayList = u2.j(string);
        if (arrayList.size() > 1) {
            m2.a((b1)new v((Throwable)new UnsupportedOperationException("Can't apply UPDATE policy to the chains of work.")));
            return;
        }
        Object object = arrayList.isEmpty() ? null : arrayList.get(0);
        r r2 = (r)object;
        if (r2 == null) {
            a2.b();
            return;
        }
        String string2 = r2.a;
        s s2 = u2.i(string2);
        if (s2 == null) {
            StringBuilder stringBuilder = new StringBuilder("WorkSpec with ");
            stringBuilder.append(string2);
            stringBuilder.append(", that matches a name \"");
            stringBuilder.append(string);
            stringBuilder.append("\", wasn't found");
            m2.a((b1)new v((Throwable)new IllegalStateException(stringBuilder.toString())));
            return;
        }
        if (!s2.d()) {
            m2.a((b1)new v((Throwable)new UnsupportedOperationException("Can't update OneTimeWorker to Periodic Worker. Update operation must preserve worker's type.")));
            return;
        }
        if (r2.b == 6) {
            u2.a(string2);
            a2.b();
            return;
        }
        s s3 = s.b((s)d02.b, (String)r2.a, (int)0, null, null, (int)0, (long)0L, (int)0, (int)1048574);
        try {
            p p2 = a02.v;
            j.h((Object)p2, (String)"processor");
            WorkDatabase workDatabase = a02.s;
            j.h((Object)workDatabase, (String)"workDatabase");
            b b2 = a02.r;
            j.h((Object)b2, (String)"configuration");
            List list = a02.u;
            j.h((Object)list, (String)"schedulers");
            d.w((p)p2, (WorkDatabase)workDatabase, (b)b2, (List)list, (s)s3, (Set)d02.c);
            m2.a((b1)y.a);
            return;
        }
        catch (Throwable throwable) {
            m2.a((b1)new v(throwable));
            return;
        }
    }
}

