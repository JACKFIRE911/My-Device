/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  o1.c
 */
package b2;

import k1.a;
import o1.c;

public final class e
extends a {
    public static final e c = new e();

    public e() {
        super(12, 13);
    }

    @Override
    public final void a(c c4) {
        c4.h("UPDATE workspec SET required_network_type = 0 WHERE required_network_type IS NULL ");
        c4.h("UPDATE workspec SET content_uri_triggers = x'' WHERE content_uri_triggers is NULL");
    }
}

