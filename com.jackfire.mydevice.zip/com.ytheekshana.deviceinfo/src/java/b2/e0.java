/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a2.e0
 *  a2.m
 *  a2.n
 *  a2.o
 *  android.content.Context
 *  android.database.Cursor
 *  androidx.appcompat.widget.j
 *  androidx.work.WorkerParameters
 *  androidx.work.impl.WorkDatabase
 *  androidx.work.impl.background.systemalarm.RescheduleReceiver
 *  b2.p
 *  com.bumptech.glide.d
 *  com.google.android.gms.internal.ads.zp
 *  i2.a
 *  j1.b0
 *  j1.y
 *  j2.c
 *  j2.o
 *  j2.s
 *  j2.u
 *  j2.w
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.LinkedList
 *  java.util.List
 *  java.util.UUID
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  k2.l
 *  k2.n
 *  k2.r
 *  k2.s
 *  k2.t
 *  l2.j
 *  m2.a
 *  m8.d
 *  u7.c
 */
package b2;

import a2.b;
import a2.h;
import a2.k;
import a2.m;
import a2.q;
import android.content.Context;
import android.database.Cursor;
import androidx.appcompat.widget.j;
import androidx.work.WorkerParameters;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemalarm.RescheduleReceiver;
import b2.p;
import b2.r;
import b2.s;
import com.bumptech.glide.d;
import com.google.android.gms.internal.ads.zp;
import e.s0;
import e.u0;
import j1.b0;
import j1.y;
import j2.c;
import j2.o;
import j2.u;
import j2.w;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import k2.l;
import k2.n;
import k2.t;
import m2.a;

public final class e0
implements Runnable {
    public static final String I = a2.r.f("WorkerWrapper");
    public final WorkDatabase A;
    public final u B;
    public final c C;
    public final List D;
    public String E;
    public final l2.j F = new l2.j();
    public final l2.j G = new l2.j();
    public volatile boolean H;
    public final Context q;
    public final String r;
    public final List s;
    public final w t;
    public final j2.s u;
    public q v;
    public final a w;
    public a2.p x = new m();
    public final b y;
    public final i2.a z;

    public e0(zp zp2) {
        j2.s s2;
        WorkDatabase workDatabase;
        this.q = (Context)zp2.a;
        this.w = (a)zp2.d;
        this.z = (i2.a)zp2.c;
        this.u = s2 = (j2.s)zp2.g;
        this.r = s2.a;
        this.s = (List)zp2.h;
        this.t = (w)zp2.j;
        this.v = (q)zp2.b;
        this.y = (b)zp2.e;
        this.A = workDatabase = (WorkDatabase)zp2.f;
        this.B = workDatabase.w();
        this.C = workDatabase.r();
        this.D = (List)zp2.i;
    }

    public final void a(a2.p p2) {
        boolean bl = p2 instanceof a2.o;
        j2.s s2 = this.u;
        String string = I;
        if (bl) {
            a2.r r2 = a2.r.d();
            StringBuilder stringBuilder = new StringBuilder("Worker result SUCCESS for ");
            stringBuilder.append(this.E);
            r2.e(string, stringBuilder.toString());
            if (s2.d()) {
                this.d();
                return;
            }
            c c2 = this.C;
            String string2 = this.r;
            u u2 = this.B;
            WorkDatabase workDatabase = this.A;
            workDatabase.c();
            try {
                u2.r(3, string2);
                u2.q(string2, ((a2.o)this.x).a);
                long l2 = System.currentTimeMillis();
                for (String string3 : c2.i(string2)) {
                    if (u2.f(string3) != 5 || !c2.l(string3)) continue;
                    a2.r r3 = a2.r.d();
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("Setting status to enqueued for ");
                    stringBuilder2.append(string3);
                    r3.e(string, stringBuilder2.toString());
                    u2.r(1, string3);
                    u2.p(string3, l2);
                }
                workDatabase.p();
                return;
            }
            finally {
                workDatabase.l();
                this.e(false);
            }
        }
        if (p2 instanceof a2.n) {
            a2.r r4 = a2.r.d();
            StringBuilder stringBuilder = new StringBuilder("Worker result RETRY for ");
            stringBuilder.append(this.E);
            r4.e(string, stringBuilder.toString());
            this.c();
            return;
        }
        a2.r r5 = a2.r.d();
        StringBuilder stringBuilder = new StringBuilder("Worker result FAILURE for ");
        stringBuilder.append(this.E);
        r5.e(string, stringBuilder.toString());
        if (s2.d()) {
            this.d();
            return;
        }
        this.g();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void b() {
        String string;
        WorkDatabase workDatabase;
        List list;
        boolean bl = this.h();
        string = this.r;
        workDatabase = this.A;
        if (!bl) {
            workDatabase.c();
            try {
                int n2 = this.B.f(string);
                workDatabase.v().e(string);
                if (n2 == 0) {
                    this.e(false);
                } else if (n2 == 2) {
                    this.a(this.x);
                } else if (!a2.s.d(n2)) {
                    this.c();
                }
                workDatabase.p();
            }
            finally {
                workDatabase.l();
            }
        }
        if ((list = this.s) != null) {
            Iterator iterator = list.iterator();
            while (iterator.hasNext()) {
                ((r)iterator.next()).a(string);
            }
            s.a(this.y, workDatabase, list);
        }
    }

    public final void c() {
        String string = this.r;
        u u2 = this.B;
        WorkDatabase workDatabase = this.A;
        workDatabase.c();
        try {
            u2.r(1, string);
            u2.p(string, System.currentTimeMillis());
            u2.n(string, -1L);
            workDatabase.p();
            return;
        }
        finally {
            workDatabase.l();
            this.e(true);
        }
    }

    public final void d() {
        String string = this.r;
        u u2 = this.B;
        WorkDatabase workDatabase = this.A;
        workDatabase.c();
        try {
            u2.p(string, System.currentTimeMillis());
            u2.r(1, string);
            u2.o(string);
            u2.l(string);
            u2.n(string, -1L);
            workDatabase.p();
            return;
        }
        finally {
            workDatabase.l();
            this.e(false);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void e(boolean var1_1) {
        this.A.c();
        try {
            if (!this.A.w().k()) {
                l.a((Context)this.q, RescheduleReceiver.class, (boolean)false);
            }
            if (var1_1) {
                this.B.r(1, this.r);
                this.B.n(this.r, -1L);
            }
            if (this.u == null || this.v == null) ** GOTO lbl-1000
            var4_2 = this.z;
            var5_3 = this.r;
            var6_4 = (p)var4_2;
            var12_6 = var7_5 = var6_4.B;
            // MONITORENTER : var12_6
        }
        catch (Throwable var2_10) {
            this.A.l();
            throw var2_10;
        }
        var9_7 = var6_4.v.containsKey((Object)var5_3);
        // MONITOREXIT : var12_6
        if (!var9_7) ** GOTO lbl-1000
        var10_8 = this.z;
        var11_9 = this.r;
        ((p)var10_8).k(var11_9);
lbl-1000: // 3 sources:
        {
            this.A.p();
        }
        this.A.l();
        this.F.j((Object)var1_1);
    }

    public final void f() {
        u u2 = this.B;
        String string = this.r;
        int n2 = u2.f(string);
        String string2 = I;
        if (n2 == 2) {
            a2.r r2 = a2.r.d();
            StringBuilder stringBuilder = new StringBuilder("Status for ");
            stringBuilder.append(string);
            stringBuilder.append(" is RUNNING; not doing any work and rescheduling for later execution");
            r2.a(string2, stringBuilder.toString());
            this.e(true);
            return;
        }
        a2.r r3 = a2.r.d();
        StringBuilder stringBuilder = new StringBuilder("Status for ");
        stringBuilder.append(string);
        stringBuilder.append(" is ");
        stringBuilder.append(a2.s.E(n2));
        stringBuilder.append(" ; not doing any work");
        r3.a(string2, stringBuilder.toString());
        this.e(false);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void g() {
        String string = this.r;
        WorkDatabase workDatabase = this.A;
        workDatabase.c();
        try {
            u u2;
            LinkedList linkedList = new LinkedList();
            linkedList.add((Object)string);
            do {
                boolean bl = linkedList.isEmpty();
                u2 = this.B;
                if (bl) break;
                String string2 = (String)linkedList.remove();
                if (u2.f(string2) != 6) {
                    u2.r(4, string2);
                }
                linkedList.addAll((Collection)this.C.i(string2));
            } while (true);
            u2.q(string, ((m)this.x).a);
            workDatabase.p();
            return;
        }
        finally {
            workDatabase.l();
            this.e(false);
        }
    }

    public final boolean h() {
        if (this.H) {
            a2.r r2 = a2.r.d();
            String string = I;
            StringBuilder stringBuilder = new StringBuilder("Work interrupted for ");
            stringBuilder.append(this.E);
            r2.a(string, stringBuilder.toString());
            int n2 = this.B.f(this.r);
            if (n2 == 0) {
                this.e(false);
                return true;
            }
            this.e(true ^ a2.s.d(n2));
            return true;
        }
        return false;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void run() {
        block35 : {
            block36 : {
                block34 : {
                    block33 : {
                        stringBuilder = new StringBuilder("Work [ id=");
                        string = this.r;
                        stringBuilder.append(string);
                        stringBuilder.append(", tags={ ");
                        list = this.D;
                        iterator = list.iterator();
                        bl3 = true;
                        while (iterator.hasNext()) {
                            string4 = (String)iterator.next();
                            if (bl3) {
                                bl3 = false;
                            } else {
                                stringBuilder.append(", ");
                            }
                            stringBuilder.append(string4);
                        }
                        stringBuilder.append(" } ]");
                        this.E = stringBuilder.toString();
                        s2 = this.u;
                        if (this.h()) {
                            return;
                        }
                        workDatabase = this.A;
                        workDatabase.c();
                        n2 = s2.b;
                        string3 = s2.c;
                        string2 = e0.I;
                        if (n2 == 1) break block33;
                        this.f();
                        workDatabase.p();
                        r2 = a2.r.d();
                        stringBuilder2 = new StringBuilder();
                        stringBuilder2.append(string3);
                        stringBuilder2.append(" is not in ENQUEUED state. Nothing more to do");
                        r2.a(string2, stringBuilder2.toString());
                        break block34;
                    }
                    if (!s2.d() && !(bl2 = s2.b == 1 && s2.k > 0) || System.currentTimeMillis() >= s2.a()) break block36;
                    a2.r.d().a(string2, String.format((String)"Delaying execution for %s because it is being executed before schedule.", (Object[])new Object[]{string3}));
                    this.e(true);
                    workDatabase.p();
                }
                workDatabase.l();
                return;
            }
            ** try [egrp 2[TRYBLOCK] [4 : 302->307)] { 
lbl48: // 1 sources:
            workDatabase.p();
            bl4 = s2.d();
            u2 = this.B;
            b2 = this.y;
            if (bl4) {
                h2 = s2.e;
            } else {
                d2 = b2.d;
                string5 = s2.d;
                d2.getClass();
                try {
                    k2 = (k)Class.forName((String)string5).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
                }
                catch (Exception exception) {
                    r3 = a2.r.d();
                    string6 = u7.c.c((String)"Trouble instantiating + ", (String)string5);
                    r3.c(k.a, string6, exception);
                    k2 = null;
                }
                if (k2 == null) {
                    r4 = a2.r.d();
                    stringBuilder = new StringBuilder("Could not create Input Merger ");
                    stringBuilder.append(s2.d);
                    r4.b(string2, stringBuilder.toString());
                    this.g();
                    return;
                }
                arrayList = new ArrayList();
                arrayList.add((Object)s2.e);
                u2.getClass();
                b02 = b0.e((String)"SELECT output FROM workspec WHERE id IN\n             (SELECT prerequisite_id FROM dependency WHERE work_spec_id=?)", (int)1);
                if (string == null) {
                    b02.l(1);
                } else {
                    b02.y(string, 1);
                }
                y2 = (y)u2.b;
                y2.b();
                cursor = d.s((y)y2, (b0)b02);
                arrayList2 = new ArrayList(cursor.getCount());
                while (cursor.moveToNext()) {
                    arrby = cursor.isNull(0) != false ? null : cursor.getBlob(0);
                    arrayList2.add((Object)h.a(arrby));
                }
                arrayList.addAll((Collection)arrayList2);
                h2 = k2.a(arrayList);
            }
            h3 = h2;
            uUID = UUID.fromString((String)string);
            w2 = this.t;
            n3 = s2.k;
            executorService = b2.a;
            a3 = this.w;
            e02 = b2.c;
            a2 = this.w;
            t2 = new t(workDatabase, a2);
            s3 = new k2.s(workDatabase, this.z, a2);
            workerParameters = new WorkerParameters(uUID, h3, list, w2, n3, executorService, a3, e02, t2, s3);
            if (this.v == null) {
                this.v = e02.a(this.q, string3, workerParameters);
            }
            if ((q2 = this.v) == null) {
                r5 = a2.r.d();
                stringBuilder = new StringBuilder("Could not create Worker ");
                stringBuilder.append(string3);
                r5.b(string2, stringBuilder.toString());
                this.g();
                return;
            }
            if (q2.isUsed()) {
                r6 = a2.r.d();
                stringBuilder = new StringBuilder("Received an already-used Worker ");
                stringBuilder.append(string3);
                stringBuilder.append("; Worker Factory should return new instances");
                r6.b(string2, stringBuilder.toString());
                this.g();
                return;
            }
            this.v.setUsed();
            workDatabase.c();
            if (u2.f(string) == 1) {
                u2.r(2, string);
                u2.m(string);
                bl = true;
            } else {
                bl = false;
            }
            workDatabase.p();
            if (bl) break block35;
            this.f();
            return;
        }
        if (this.h()) {
            return;
        }
        r7 = new k2.r(this.q, this.u, this.v, workerParameters.j, this.w);
        w3 = (w)a2;
        ((Executor)w3.t).execute((Runnable)r7);
        j2 = r7.q;
        s02 = new s0(this, 8, (Object)j2);
        u02 = new u0(1);
        j3 = this.G;
        j3.b((Runnable)s02, (Executor)u02);
        j2.b((Runnable)new j((Object)this, 6, (Object)j2), (Executor)w3.t);
        j3.b((Runnable)new j((Object)this, 7, (Object)this.E), (Executor)((n)w3.r));
        return;
        finally {
            workDatabase.l();
        }
        finally {
            cursor.close();
            b02.m();
        }
lbl154: // 1 sources:
        finally {
            workDatabase.l();
        }
    }
}

