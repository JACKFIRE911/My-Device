/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  s7.j
 */
package b2;

import a2.r;
import s7.j;

public abstract class x {
    public static final String a;
    public static final String[] b;

    public static {
        String string = r.f("WrkDbPathHelper");
        j.h((Object)string, (String)"tagWithPrefix(\"WrkDbPathHelper\")");
        a = string;
        b = new String[]{"-journal", "-shm", "-wal"};
    }
}

