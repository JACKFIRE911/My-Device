/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package b2;

import b2.a0;
import b2.m;
import b2.u;
import j9.g;
import java.util.List;
import t9.a;
import u9.f;
import y6.e;

public final class d0
extends f
implements a {
    public final /* synthetic */ a2.d0 r;
    public final /* synthetic */ a0 s;
    public final /* synthetic */ String t;
    public final /* synthetic */ m u;

    public d0(a2.d0 d02, a0 a02, String string, m m3) {
        this.r = d02;
        this.s = a02;
        this.t = string;
        this.u = m3;
        super(0);
    }

    @Override
    public final Object b() {
        List list = e.h0(this.r);
        new k2.e(new u(this.s, this.t, 2, list), this.u).run();
        return g.a;
    }
}

