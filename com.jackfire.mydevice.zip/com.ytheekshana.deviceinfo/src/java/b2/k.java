/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  o1.c
 */
package b2;

import k1.a;
import o1.c;

public final class k
extends a {
    public static final k c = new k();

    public k() {
        super(7, 8);
    }

    @Override
    public final void a(c c4) {
        c4.h("\n    CREATE INDEX IF NOT EXISTS `index_WorkSpec_period_start_time` ON `workspec`(`period_start_time`)\n    ");
    }
}

