/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  androidx.work.impl.WorkDatabase
 *  androidx.work.impl.workers.ConstraintTrackingWorker
 *  j.d
 *  j1.y
 *  j2.o
 *  j2.s
 *  j2.t
 *  j2.u
 *  j2.w
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Set
 *  n1.i
 *  s7.j
 */
package b2;

import a2.d;
import a2.g;
import a2.h;
import android.os.Build;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.workers.ConstraintTrackingWorker;
import j1.y;
import j2.o;
import j2.s;
import j2.t;
import j2.u;
import j2.w;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import n1.i;
import s7.j;

public final class c0
implements Runnable {
    public final /* synthetic */ WorkDatabase q;
    public final /* synthetic */ s r;
    public final /* synthetic */ s s;
    public final /* synthetic */ List t;
    public final /* synthetic */ String u;
    public final /* synthetic */ Set v;
    public final /* synthetic */ boolean w;

    public /* synthetic */ c0(WorkDatabase workDatabase, s s2, s s3, List list, String string, Set set, boolean bl) {
        this.q = workDatabase;
        this.r = s2;
        this.s = s3;
        this.t = list;
        this.u = string;
        this.v = set;
        this.w = bl;
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void run() {
        WorkDatabase workDatabase = this.q;
        j.i((Object)workDatabase, (String)"$workDatabase");
        s s2 = this.r;
        j.i((Object)s2, (String)"$newWorkSpec");
        s s3 = this.s;
        j.i((Object)s3, (String)"$oldWorkSpec");
        j.i((Object)this.t, (String)"$schedulers");
        String string = this.u;
        j.i((Object)string, (String)"$workSpecId");
        Set set = this.v;
        j.i((Object)set, (String)"$tags");
        u u2 = workDatabase.w();
        w w2 = workDatabase.x();
        s s5 = s.b((s)s2, null, (int)s3.b, null, null, (int)s3.k, (long)s3.n, (int)(1 + s3.t), (int)515069);
        boolean bl = Build.VERSION.SDK_INT < 26;
        if (bl) {
            d d2 = s5.j;
            String string2 = s5.c;
            String string3 = ConstraintTrackingWorker.class.getName();
            if (!j.b((Object)string2, (Object)string3) && (d2.d || d2.e)) {
                g g2 = new g(0);
                g2.b(s5.e.a);
                g2.a.put((Object)"androidx.work.impl.workers.ConstraintTrackingWorker.ARGUMENT_CLASS_NAME", (Object)string2);
                h h2 = new h(g2.a);
                h.c(h2);
                String string4 = ConstraintTrackingWorker.class.getName();
                s5 = s.b((s)s5, null, (int)0, (String)string4, (h)h2, (int)0, (long)0L, (int)0, (int)1048555);
            }
        }
        Object object = u2.b;
        y y2 = (y)object;
        y2.b();
        y2.c();
        t t2 = (t)u2.d;
        i i3 = t2.c();
        {
            catch (Throwable throwable) {
                throw throwable;
            }
        }
        try {
            t2.u(i3, (Object)s5);
            i3.j();
        }
        catch (Throwable throwable) {
            t2.j(i3);
            throw throwable;
        }
        t2.j(i3);
        ((y)object).p();
        ((y)w2.r).b();
        i i2 = ((j.d)w2.t).c();
        i2.y(string, 1);
        ((y)w2.r).c();
        i2.j();
        ((y)w2.r).p();
        w2.u(string, set);
        if (this.w) return;
        u2.n(string, -1L);
        workDatabase.v().e(string);
        return;
        finally {
            ((y)w2.r).l();
            ((j.d)w2.t).j(i2);
        }
        finally {
            y2.l();
        }
    }
}

