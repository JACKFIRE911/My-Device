/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.TimeUnit
 */
package b2;

import java.util.concurrent.TimeUnit;

public abstract class w {
    public static final long a = TimeUnit.DAYS.toMillis(1L);
}

