/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.ActivityManager
 *  android.app.job.JobInfo
 *  android.app.job.JobScheduler
 *  android.content.BroadcastReceiver
 *  android.content.BroadcastReceiver$PendingResult
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  androidx.work.impl.WorkDatabase
 *  androidx.work.impl.background.systemjob.SystemJobService
 *  b2.d0
 *  com.google.android.gms.internal.ads.bm
 *  com.google.android.gms.internal.ads.xe1
 *  j1.c0
 *  j1.d
 *  j2.o
 *  j2.w
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.InstantiationException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Package
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayDeque
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.BitSet
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.LinkedHashSet
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  k.b
 *  k2.c
 *  n1.i
 *  u7.e
 *  x9.c
 */
package b2;

import android.app.ActivityManager;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Build;
import androidx.work.impl.WorkDatabase;
import androidx.work.impl.background.systemjob.SystemJobService;
import b2.b;
import b2.b0;
import b2.d;
import b2.d0;
import b2.e;
import b2.f;
import b2.g;
import b2.h;
import b2.i;
import b2.j;
import b2.k;
import b2.l;
import b2.m;
import b2.p;
import b2.q;
import b2.r;
import b2.s;
import b2.t;
import b2.u;
import b2.v;
import b2.z;
import com.google.android.gms.internal.ads.bm;
import com.google.android.gms.internal.ads.xe1;
import j1.c0;
import j1.y;
import j2.o;
import j2.w;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import k2.c;
import k2.n;
import r.a;

public final class a0
extends a {
    public static a0 A;
    public static a0 B;
    public static final Object C;
    public Context q;
    public a2.b r;
    public WorkDatabase s;
    public m2.a t;
    public List u;
    public p v;
    public u7.e w;
    public boolean x;
    public BroadcastReceiver.PendingResult y;
    public final o z;

    public static {
        a2.r.f("WorkManagerImpl");
        A = null;
        B = null;
        C = new Object();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public a0(Context context, a2.b b4, w w2) {
        Object object;
        y y4;
        o o5;
        Context context2;
        block59 : {
            int n2;
            List list;
            int n3;
            LinkedHashMap linkedHashMap;
            j1.e e4;
            block58 : {
                j1.w w3;
                boolean bl;
                String string;
                int n5;
                int n6;
                n1.e e5;
                boolean bl2 = context.getResources().getBoolean(2131034120);
                Context context3 = context.getApplicationContext();
                n n7 = (n)w2.r;
                s7.j.i((Object)context3, "context");
                s7.j.i(n7, "queryExecutor");
                if (bl2) {
                    w3 = new j1.w(context3, null);
                    w3.j = true;
                } else {
                    boolean bl3;
                    x9.c c4 = new x9.c(0, 19);
                    if (!(c4 instanceof Collection) || !((Collection)c4).isEmpty()) {
                        Iterator iterator = c4.iterator();
                        while (((x9.b)iterator).s) {
                            char c5 = "androidx.work.workdb".charAt(((x9.b)iterator).b());
                            boolean bl4 = Character.isWhitespace((char)c5) || Character.isSpaceChar((char)c5);
                            if (bl4) continue;
                            bl3 = false;
                            break;
                        }
                    } else {
                        bl3 = true;
                    }
                    if (!(bl3 ^ true)) {
                        throw new IllegalArgumentException("Cannot build a database with null or empty name. If you are trying to create an in memory database, use Room.inMemoryDatabaseBuilder".toString());
                    }
                    w3 = new j1.w(context3, "androidx.work.workdb");
                    w3.i = new v(context3);
                }
                w3.g = n7;
                b b5 = b.a;
                ArrayList arrayList = w3.d;
                arrayList.add((Object)b5);
                k1.a[] arra = new k1.a[]{g.c};
                w3.a(arra);
                k1.a[] arra2 = new k1.a[]{new q(context3, 2, 3)};
                w3.a(arra2);
                k1.a[] arra3 = new k1.a[]{h.c};
                w3.a(arra3);
                k1.a[] arra4 = new k1.a[]{i.c};
                w3.a(arra4);
                k1.a[] arra5 = new k1.a[]{new q(context3, 5, 6)};
                w3.a(arra5);
                k1.a[] arra6 = new k1.a[]{j.c};
                w3.a(arra6);
                k1.a[] arra7 = new k1.a[]{k.c};
                w3.a(arra7);
                k1.a[] arra8 = new k1.a[]{l.c};
                w3.a(arra8);
                k1.a[] arra9 = new k1.a[]{new q(context3)};
                w3.a(arra9);
                k1.a[] arra10 = new k1.a[]{new q(context3, 10, 11)};
                w3.a(arra10);
                k1.a[] arra11 = new k1.a[]{d.c};
                w3.a(arra11);
                k1.a[] arra12 = new k1.a[]{e.c};
                w3.a(arra12);
                k1.a[] arra13 = new k1.a[]{f.c};
                w3.a(arra13);
                w3.l = false;
                w3.m = true;
                Executor executor = w3.g;
                if (executor == null && w3.h == null) {
                    k.a a3 = k.b.t;
                    w3.h = a3;
                    w3.g = a3;
                } else if (executor != null && w3.h == null) {
                    w3.h = executor;
                } else if (executor == null) {
                    w3.g = w3.h;
                }
                HashSet hashSet = w3.q;
                LinkedHashSet linkedHashSet = w3.p;
                if (hashSet != null) {
                    Iterator iterator = hashSet.iterator();
                    while (iterator.hasNext()) {
                        int n8 = ((Number)iterator.next()).intValue();
                        if (true ^ linkedHashSet.contains((Object)n8)) continue;
                        throw new IllegalArgumentException(xe1.f((String)"Inconsistency detected. A Migration was supplied to addMigration(Migration... migrations) that has a start or end version equal to a start version supplied to fallbackToDestructiveMigrationFrom(int... startVersions). Start version: ", (int)n8).toString());
                    }
                }
                if ((e5 = w3.i) == null) {
                    e5 = new bm();
                }
                n1.e e6 = e5;
                if (w3.n > 0L) {
                    if (w3.c != null) {
                        throw new IllegalArgumentException("Required value was null.".toString());
                    }
                    throw new IllegalArgumentException("Cannot create auto-closing database for an in-memory database.".toString());
                }
                String string2 = w3.c;
                a2.g g4 = w3.o;
                boolean bl5 = w3.j;
                int n9 = w3.k;
                if (n9 == 0) {
                    throw null;
                }
                Context context4 = w3.a;
                s7.j.i((Object)context4, "context");
                if (n9 != 1) {
                    n6 = n9;
                } else {
                    Object object2 = context4.getSystemService("activity");
                    s7.j.g(object2, "null cannot be cast to non-null type android.app.ActivityManager");
                    int n10 = !((ActivityManager)object2).isLowRamDevice() ? 3 : 2;
                    n6 = n10;
                }
                Executor executor2 = w3.g;
                if (executor2 == null) {
                    throw new IllegalArgumentException("Required value was null.".toString());
                }
                Executor executor3 = w3.h;
                if (executor3 == null) {
                    throw new IllegalArgumentException("Required value was null.".toString());
                }
                e4 = new j1.e(context4, string2, e6, g4, arrayList, bl5, n6, executor2, executor3, w3.l, w3.m, linkedHashSet, w3.e, w3.f);
                Class class_ = w3.b;
                s7.j.i((Object)class_, "klass");
                Package package_ = class_.getPackage();
                s7.j.f((Object)package_);
                String string3 = package_.getName();
                String string4 = class_.getCanonicalName();
                s7.j.f(string4);
                s7.j.h(string3, "fullPackage");
                boolean bl6 = string3.length() == 0;
                if (!bl6) {
                    string4 = string4.substring(1 + string3.length());
                    s7.j.h(string4, "this as java.lang.String).substring(startIndex)");
                }
                String string5 = string4.replace('.', '_');
                s7.j.h(string5, "this as java.lang.String\u2026replace(oldChar, newChar)");
                String string6 = string5.concat("_Impl");
                try {
                    bl = string3.length() == 0;
                }
                catch (InstantiationException instantiationException) {
                    StringBuilder stringBuilder = new StringBuilder("Failed to create an instance of ");
                    stringBuilder.append((Object)class_);
                    stringBuilder.append(".canonicalName");
                    throw new RuntimeException(stringBuilder.toString());
                }
                catch (IllegalAccessException illegalAccessException) {
                    StringBuilder stringBuilder = new StringBuilder("Cannot access the constructor ");
                    stringBuilder.append((Object)class_);
                    stringBuilder.append(".canonicalName");
                    throw new RuntimeException(stringBuilder.toString());
                }
                catch (ClassNotFoundException classNotFoundException) {
                    StringBuilder stringBuilder = new StringBuilder("Cannot find implementation for ");
                    stringBuilder.append(class_.getCanonicalName());
                    stringBuilder.append(". ");
                    stringBuilder.append(string6);
                    stringBuilder.append(" does not exist");
                    throw new RuntimeException(stringBuilder.toString());
                }
                if (bl) {
                    string = string6;
                } else {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(string3);
                    stringBuilder.append('.');
                    stringBuilder.append(string6);
                    string = stringBuilder.toString();
                }
                Class class_2 = Class.forName((String)string, (boolean)true, (ClassLoader)class_.getClassLoader());
                s7.j.g((Object)class_2, "null cannot be cast to non-null type java.lang.Class<T of androidx.room.Room.getGeneratedImplementation>");
                Object object3 = class_2.newInstance();
                y4 = (y)object3;
                y4.getClass();
                y4.c = y4.e(e4);
                Set set = y4.i();
                BitSet bitSet = new BitSet();
                Iterator iterator = set.iterator();
                do {
                    boolean bl7;
                    Class class_3;
                    List list2;
                    block62 : {
                        int n11;
                        block63 : {
                            block61 : {
                                boolean bl8 = iterator.hasNext();
                                linkedHashMap = y4.g;
                                list2 = e4.o;
                                n2 = -1;
                                if (!bl8) break block61;
                                class_3 = (Class)iterator.next();
                                n11 = n2 + list2.size();
                                if (n11 < 0) break block62;
                                break block63;
                            }
                            n5 = n2 + list2.size();
                            if (n5 >= 0) {
                                break;
                            }
                            break block58;
                        }
                        do {
                            int n12 = n11 - 1;
                            if (class_3.isAssignableFrom(list2.get(n11).getClass())) {
                                bitSet.set(n11);
                                n2 = n11;
                                break;
                            }
                            if (n12 < 0) break;
                            n11 = n12;
                        } while (true);
                    }
                    if (!(bl7 = n2 >= 0)) {
                        StringBuilder stringBuilder = new StringBuilder("A required auto migration spec (");
                        stringBuilder.append(class_3.getCanonicalName());
                        stringBuilder.append(") is missing in the database configuration.");
                        throw new IllegalArgumentException(stringBuilder.toString().toString());
                    }
                    linkedHashMap.put((Object)class_3, list2.get(n2));
                } while (true);
                do {
                    int n13 = n5 - 1;
                    if (!bitSet.get(n5)) {
                        throw new IllegalArgumentException("Unexpected auto migration specs found. Annotate AutoMigrationSpec implementation with @ProvidedAutoMigrationSpec annotation or remove this spec from the builder.".toString());
                    }
                    if (n13 < 0) break;
                    n5 = n13;
                } while (true);
            }
            for (k1.a a4 : y4.g(linkedHashMap)) {
                boolean bl;
                int n14 = a4.a;
                a2.g g5 = e4.d;
                HashMap hashMap = g5.a;
                if (hashMap.containsKey((Object)n14)) {
                    Map map = (Map)hashMap.get((Object)n14);
                    if (map == null) {
                        map = k9.k.q;
                    }
                    bl = map.containsKey((Object)a4.b);
                } else {
                    bl = false;
                }
                if (bl) continue;
                g5.a(a4);
            }
            c0 c02 = (c0)y.q(c0.class, y4.h());
            if (c02 != null) {
                c02.getClass();
            }
            j1.d d4 = (j1.d)y.q(j1.d.class, y4.h());
            j1.m m4 = y4.d;
            if (d4 != null) {
                m4.getClass();
                s7.j.i(null, "autoCloser");
                throw null;
            }
            boolean bl = e4.g == 3;
            y4.h().setWriteAheadLoggingEnabled(bl);
            y4.f = e4.e;
            y4.b = e4.h;
            s7.j.i((Object)e4.i, "executor");
            new ArrayDeque();
            y4.e = e4.f;
            Intent intent = e4.j;
            if (intent != null) {
                String string = e4.b;
                if (string == null) {
                    throw new IllegalArgumentException("Required value was null.".toString());
                }
                m4.getClass();
                Context context5 = e4.a;
                s7.j.i((Object)context5, "context");
                Executor executor = m4.a.b;
                if (executor == null) {
                    s7.j.I("internalQueryExecutor");
                    throw null;
                }
                new j1.r(context5, string, intent, m4, executor);
            }
            Map map = y4.j();
            BitSet bitSet = new BitSet();
            Iterator iterator = map.entrySet().iterator();
            block13 : do {
                boolean bl9 = iterator.hasNext();
                list = e4.n;
                if (!bl9) {
                    n3 = n2 + list.size();
                    if (n3 >= 0) {
                        break;
                    }
                    break block59;
                }
                Map.Entry entry = (Map.Entry)iterator.next();
                Class class_ = (Class)entry.getKey();
                Iterator iterator2 = ((List)entry.getValue()).iterator();
                do {
                    Class class_4;
                    int n15;
                    block60 : {
                        if (!iterator2.hasNext()) continue block13;
                        class_4 = (Class)iterator2.next();
                        n15 = n2 + list.size();
                        if (n15 >= 0) {
                            do {
                                int n16 = n15 - 1;
                                if (class_4.isAssignableFrom(list.get(n15).getClass())) {
                                    bitSet.set(n15);
                                    break block60;
                                }
                                if (n16 < 0) break;
                                n15 = n16;
                            } while (true);
                        }
                        n15 = n2;
                    }
                    boolean bl10 = n15 >= 0;
                    if (!bl10) {
                        StringBuilder stringBuilder = new StringBuilder("A required type converter (");
                        stringBuilder.append((Object)class_4);
                        stringBuilder.append(") for ");
                        stringBuilder.append(class_.getCanonicalName());
                        stringBuilder.append(" is missing in the database configuration.");
                        throw new IllegalArgumentException(stringBuilder.toString().toString());
                    }
                    y4.j.put((Object)class_4, list.get(n15));
                } while (true);
                break;
            } while (true);
            do {
                int n17 = n3 - 1;
                if (!bitSet.get(n3)) {
                    Object object4 = list.get(n3);
                    StringBuilder stringBuilder = new StringBuilder("Unexpected type converter ");
                    stringBuilder.append(object4);
                    stringBuilder.append(". Annotate TypeConverter class with @ProvidedTypeConverter annotation or remove this converter from the builder.");
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                if (n17 < 0) break;
                n3 = n17;
            } while (true);
        }
        WorkDatabase workDatabase = (WorkDatabase)y4;
        Context context6 = context.getApplicationContext();
        a2.r r4 = new a2.r(b4.f);
        Object object5 = object = a2.r.b;
        synchronized (object5) {
            a2.r.c = r4;
        }
        this.z = o5 = new o(context6, w2);
        Object[] arrobject = new r[2];
        e2.b b6 = new e2.b(context6, this);
        k2.l.a(context6, SystemJobService.class, true);
        a2.r.d().a(s.a, "Created SystemJobScheduler and enabled SystemJobService");
        arrobject[0] = b6;
        arrobject[1] = new c2.b(context6, b4, o5, this);
        List list = Arrays.asList((Object[])arrobject);
        p p2 = new p(context, b4, w2, workDatabase, list);
        this.q = context2 = context.getApplicationContext();
        this.r = b4;
        this.t = w2;
        this.s = workDatabase;
        this.u = list;
        this.v = p2;
        this.w = new u7.e(11, (Object)workDatabase);
        this.x = false;
        if (Build.VERSION.SDK_INT >= 24 && z.a(context2)) {
            throw new IllegalStateException("Cannot initialize WorkManager in direct boot mode");
        }
        m2.a a6 = this.t;
        k2.f f4 = new k2.f(context2, this);
        ((w)a6).l((Runnable)f4);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static a0 X() {
        Object object;
        Object object2 = object = C;
        synchronized (object2) {
            a0 a02 = A;
            if (a02 == null) return B;
            return a02;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static a0 Y(Context context) {
        Object object;
        Object object2 = object = C;
        synchronized (object2) {
            a0 a02 = a0.X();
            if (a02 != null) {
                return a02;
            }
            context.getApplicationContext();
            throw new IllegalStateException("WorkManager is not initialized properly.  You have explicitly disabled WorkManagerInitializer in your manifest, have not manually called WorkManager#initialize at this point, and your Application does not implement Configuration.Provider.");
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void Z(Context context, a2.b b4) {
        Object object;
        Object object2 = object = C;
        synchronized (object2) {
            a0 a02 = A;
            if (a02 != null && B != null) {
                throw new IllegalStateException("WorkManager is already initialized.  Did you try to initialize it manually without disabling WorkManagerInitializer? See WorkManager#initialize(Context, Configuration) or the class level Javadoc for more information.");
            }
            if (a02 == null) {
                Context context2 = context.getApplicationContext();
                if (B == null) {
                    B = new a0(context2, b4, new w(b4.b));
                }
                A = B;
            }
            return;
        }
    }

    public final m U(String string) {
        c c4 = new c(this, string, true);
        ((w)this.t).l((Runnable)c4);
        return c4.q;
    }

    public final a2.y V(List list) {
        if (!list.isEmpty()) {
            u u3 = new u(this, null, 2, list, 0);
            return u3.K();
        }
        throw new IllegalArgumentException("enqueue needs at least one WorkRequest.");
    }

    public final a2.y W(String string, a2.a0 a02) {
        s7.j.i(string, "name");
        s7.j.i(a02, "workRequest");
        m m4 = new m();
        d0 d02 = new d0((a2.d0)a02, this, string, m4);
        n n2 = (n)((w)this.t).r;
        b0 b02 = new b0(this, string, m4, d02, a02);
        n2.execute(b02);
        return m4;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void a0() {
        Object object;
        Object object2 = object = C;
        synchronized (object2) {
            this.x = true;
            BroadcastReceiver.PendingResult pendingResult = this.y;
            if (pendingResult != null) {
                pendingResult.finish();
                this.y = null;
            }
            return;
        }
    }

    public final void b0() {
        ArrayList arrayList;
        Context context = this.q;
        JobScheduler jobScheduler = (JobScheduler)context.getSystemService("jobscheduler");
        if (jobScheduler != null && (arrayList = e2.b.d(context, jobScheduler)) != null && !arrayList.isEmpty()) {
            Iterator iterator = arrayList.iterator();
            while (iterator.hasNext()) {
                e2.b.b(jobScheduler, ((JobInfo)iterator.next()).getId());
            }
        }
        j2.u u3 = this.s.w();
        Object object = u3.b;
        y y4 = (y)object;
        y4.b();
        j.d d4 = (j.d)u3.m;
        n1.i i3 = d4.c();
        y4.c();
        try {
            i3.j();
            ((y)object).p();
            s.a(this.r, this.s, this.u);
            return;
        }
        finally {
            y4.l();
            d4.j(i3);
        }
    }

    public final void c0(t t2, w w2) {
        m2.a a3 = this.t;
        k0.a a4 = new k0.a(this, t2, (Object)w2, 6, 0);
        ((w)a3).l((Runnable)a4);
    }

    public final void d0(t t2) {
        m2.a a3 = this.t;
        k2.o o5 = new k2.o(this, t2, false);
        ((w)a3).l((Runnable)o5);
    }
}

