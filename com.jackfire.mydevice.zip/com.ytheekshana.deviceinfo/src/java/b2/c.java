/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j2.j
 *  java.lang.Object
 */
package b2;

import j2.j;

public interface c {
    public void c(j var1, boolean var2);
}

