/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  com.google.android.gms.internal.measurement.o3
 *  j2.w
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.UUID
 */
package b2;

import a2.d0;
import a2.r;
import a2.y;
import android.text.TextUtils;
import b2.a0;
import b2.m;
import com.google.android.gms.internal.measurement.o3;
import j2.w;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import k2.e;
import m2.a;
import s7.j;

public final class u
extends o3 {
    public static final String L = r.f("WorkContinuationImpl");
    public final a0 D;
    public final String E;
    public final int F;
    public final List G;
    public final ArrayList H;
    public final ArrayList I;
    public boolean J;
    public m K;

    public u(a0 a02, String string, int n2, List list) {
        this(a02, string, n2, list, 0);
    }

    public u(a0 a02, String string, int n2, List list, int n3) {
        super(0);
        this.D = a02;
        this.E = string;
        this.F = n2;
        this.G = list;
        this.H = new ArrayList(list.size());
        this.I = new ArrayList();
        for (int i3 = 0; i3 < list.size(); ++i3) {
            String string2 = ((d0)list.get((int)i3)).a.toString();
            j.h(string2, "id.toString()");
            this.H.add((Object)string2);
            this.I.add((Object)string2);
        }
    }

    public static boolean L(u u3, HashSet hashSet) {
        hashSet.addAll((Collection)u3.H);
        HashSet hashSet2 = u.M(u3);
        Iterator iterator = hashSet.iterator();
        while (iterator.hasNext()) {
            if (!hashSet2.contains((Object)((String)iterator.next()))) continue;
            return true;
        }
        hashSet.removeAll((Collection)u3.H);
        return false;
    }

    public static HashSet M(u u3) {
        HashSet hashSet = new HashSet();
        u3.getClass();
        return hashSet;
    }

    public final y K() {
        if (!this.J) {
            m m4 = new m();
            e e4 = new e(this, m4);
            ((w)this.D.t).l((Runnable)e4);
            this.K = m4;
        } else {
            r r4 = r.d();
            StringBuilder stringBuilder = new StringBuilder("Already enqueued work ids (");
            stringBuilder.append(TextUtils.join((CharSequence)", ", (Iterable)this.H));
            stringBuilder.append(")");
            String string = stringBuilder.toString();
            r4.g(L, string);
        }
        return this.K;
    }
}

