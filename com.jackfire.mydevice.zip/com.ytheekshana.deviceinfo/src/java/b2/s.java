/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  androidx.work.impl.WorkDatabase
 *  j2.s
 *  j2.u
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.List
 */
package b2;

import a2.b;
import android.os.Build;
import androidx.work.impl.WorkDatabase;
import b2.r;
import j2.u;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public abstract class s {
    public static final String a = a2.r.f("Schedulers");

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(b b2, WorkDatabase workDatabase, List list) {
        ArrayList arrayList;
        ArrayList arrayList2;
        if (list == null) {
            return;
        }
        if (list.size() == 0) {
            return;
        }
        u u2 = workDatabase.w();
        workDatabase.c();
        try {
            int n2 = Build.VERSION.SDK_INT;
            int n3 = b2.h;
            if (n2 == 23) {
                n3 /= 2;
            }
            arrayList = u2.c(n3);
            arrayList2 = u2.b();
            if (arrayList.size() > 0) {
                long l2 = System.currentTimeMillis();
                Iterator iterator = arrayList.iterator();
                while (iterator.hasNext()) {
                    u2.n(((j2.s)iterator.next()).a, l2);
                }
            }
            workDatabase.p();
        }
        catch (Throwable throwable) {}
        workDatabase.l();
        if (arrayList.size() > 0) {
            j2.s[] arrs = (j2.s[])arrayList.toArray((Object[])new j2.s[arrayList.size()]);
            for (r r2 : list) {
                if (!r2.f()) continue;
                r2.e(arrs);
            }
        }
        if (arrayList2.size() > 0) {
            j2.s[] arrs = (j2.s[])arrayList2.toArray((Object[])new j2.s[arrayList2.size()]);
            for (r r3 : list) {
                if (r3.f()) continue;
                r3.e(arrs);
            }
        }
        return;
        workDatabase.l();
        throw throwable;
    }
}

