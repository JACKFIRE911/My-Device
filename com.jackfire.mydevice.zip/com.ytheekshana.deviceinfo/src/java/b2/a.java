/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 *  s7.j
 */
package b2;

import android.content.Context;
import java.io.File;
import s7.j;

public final class a {
    public static final a a = new a();

    public final File a(Context context) {
        j.i((Object)context, (String)"context");
        File file = context.getNoBackupFilesDir();
        j.h((Object)file, (String)"context.noBackupFilesDir");
        return file;
    }
}

