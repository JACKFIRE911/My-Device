/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.appcompat.widget.i0
 *  java.lang.Object
 */
package b2;

import android.content.Context;
import androidx.appcompat.widget.i0;

public abstract class z {
    public static boolean a(Context context) {
        return i0.z((Context)context);
    }
}

