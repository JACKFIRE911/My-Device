/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  o1.c
 */
package b2;

import k1.a;
import o1.c;

public final class h
extends a {
    public static final h c = new h();

    public h() {
        super(3, 4);
    }

    @Override
    public final void a(c c4) {
        c4.h("\n    UPDATE workspec SET schedule_requested_at = 0\n    WHERE state NOT IN (2, 3, 5)\n        AND schedule_requested_at = -1\n        AND interval_duration <> 0\n    ");
    }
}

