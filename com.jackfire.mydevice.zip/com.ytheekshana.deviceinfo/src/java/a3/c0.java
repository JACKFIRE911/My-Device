/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a3;

import a3.b0;
import a3.g0;

public interface c0 {
    public b0 i(g0 var1);
}

