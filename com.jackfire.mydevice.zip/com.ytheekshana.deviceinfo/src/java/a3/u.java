/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.Map
 */
package a3;

import a3.v;
import android.text.TextUtils;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public final class u {
    public static final Map b;
    public final Map a = b;

    public static {
        String string = System.getProperty((String)"http.agent");
        if (!TextUtils.isEmpty((CharSequence)string)) {
            int n2 = string.length();
            StringBuilder stringBuilder = new StringBuilder(string.length());
            for (int i2 = 0; i2 < n2; ++i2) {
                char c2 = string.charAt(i2);
                if ((c2 > '\u001f' || c2 == '\t') && c2 < '') {
                    stringBuilder.append(c2);
                    continue;
                }
                stringBuilder.append('?');
            }
            string = stringBuilder.toString();
        }
        HashMap hashMap = new HashMap(2);
        if (!TextUtils.isEmpty((CharSequence)string)) {
            hashMap.put((Object)"User-Agent", (Object)Collections.singletonList((Object)new v(string)));
        }
        b = Collections.unmodifiableMap((Map)hashMap);
    }
}

