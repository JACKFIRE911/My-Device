/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 */
package a3;

import a3.c0;

public final class f0 {
    public final Class a;
    public final Class b;
    public final c0 c;

    public f0(Class class_, Class class_2, c0 c02) {
        this.a = class_;
        this.b = class_2;
        this.c = c02;
    }
}

