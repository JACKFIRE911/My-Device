/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.bumptech.glide.i
 *  com.bumptech.glide.load.data.d
 *  com.bumptech.glide.load.data.e
 *  java.io.File
 *  java.io.IOException
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 */
package a3;

import android.util.Log;
import com.bumptech.glide.i;
import com.bumptech.glide.load.data.d;
import com.bumptech.glide.load.data.e;
import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import m3.b;
import u2.a;

public final class h
implements e {
    public final /* synthetic */ int q;
    public final Object r;

    public /* synthetic */ h(int n2, Object object) {
        this.q = n2;
        this.r = object;
    }

    public final Class a() {
        switch (this.q) {
            default: {
                break;
            }
            case 0: {
                return ByteBuffer.class;
            }
        }
        return this.r.getClass();
    }

    public final void b() {
    }

    public final void cancel() {
    }

    public final a d() {
        return a.q;
    }

    public final void f(i i3, d d4) {
        int n2 = this.q;
        Object object = this.r;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                try {
                    d4.e((Object)b.a((File)object));
                    return;
                }
                catch (IOException iOException) {
                    if (Log.isLoggable((String)"ByteBufferFileLoader", (int)3)) {
                        Log.d((String)"ByteBufferFileLoader", (String)"Failed to obtain ByteBuffer for file", (Throwable)iOException);
                    }
                    d4.c((Exception)iOException);
                    return;
                }
            }
        }
        d4.e(object);
    }
}

