/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.graphics.drawable.Drawable
 *  com.bumptech.glide.i
 *  com.bumptech.glide.load.data.d
 *  com.bumptech.glide.load.data.e
 *  java.lang.Class
 *  java.lang.Object
 */
package a3;

import a3.e;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import com.bumptech.glide.i;
import com.bumptech.glide.load.data.d;
import s7.j;
import u2.a;

public final class f
implements com.bumptech.glide.load.data.e {
    public final /* synthetic */ int q;
    public final Object r;
    public final Object s;

    public f(Context context, ApplicationInfo applicationInfo) {
        this.q = 1;
        j.i((Object)context, "context");
        j.i((Object)applicationInfo, "model");
        this.r = context;
        this.s = applicationInfo;
    }

    public f(byte[] arrby, e e4) {
        this.q = 0;
        this.r = arrby;
        this.s = e4;
    }

    public final Class a() {
        switch (this.q) {
            default: {
                return Drawable.class;
            }
            case 0: 
        }
        return ((e)this.s).a();
    }

    public final void b() {
    }

    public final void cancel() {
    }

    public final a d() {
        return a.q;
    }

    public final void f(i i3, d d4) {
        int n2 = this.q;
        Object object = this.r;
        Object object2 = this.s;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                d4.e(((e)object2).l((byte[])object));
                return;
            }
        }
        j.i((Object)i3, "priority");
        j.i((Object)d4, "callback");
        Drawable drawable = ((Context)object).getPackageManager().getApplicationIcon((ApplicationInfo)object2);
        j.h((Object)drawable, "context.packageManager.getApplicationIcon(model)");
        d4.e((Object)drawable);
    }
}

