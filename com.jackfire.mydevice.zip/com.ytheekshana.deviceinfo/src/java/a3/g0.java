/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a3.i
 *  a3.l
 *  a3.o
 *  android.content.pm.ApplicationInfo
 *  android.graphics.drawable.Drawable
 *  com.bumptech.glide.k
 *  g2.d
 *  j2.w
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  m0.c
 */
package a3;

import a3.b0;
import a3.c0;
import a3.f0;
import a3.i;
import a3.l;
import a3.o;
import a8.b1;
import android.content.pm.ApplicationInfo;
import android.graphics.drawable.Drawable;
import com.bumptech.glide.k;
import g2.d;
import j2.w;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import m0.c;

public final class g0 {
    public static final d e = new d(10);
    public static final i f = new i(1);
    public final ArrayList a;
    public final d b;
    public final HashSet c;
    public final c d;

    public g0(w w2) {
        d d2 = e;
        this.a = new ArrayList();
        this.c = new HashSet();
        this.d = w2;
        this.b = d2;
    }

    public final void a(Class class_, Class class_2, c0 c02) {
        g0 g02 = this;
        synchronized (g02) {
            f0 f02 = new f0(class_, class_2, c02);
            ArrayList arrayList = this.a;
            arrayList.add(arrayList.size(), (Object)f02);
            return;
        }
    }

    public final b0 b(f0 f02) {
        b0 b02 = f02.c.i(this);
        b1.i(b02);
        return b02;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final b0 c(Class class_, Class class_2) {
        g0 g02 = this;
        synchronized (g02) {
            try {
                ArrayList arrayList = new ArrayList();
                Iterator iterator = this.a.iterator();
                int n2 = 0;
                do {
                    f0 f02;
                    int n3;
                    block10 : {
                        block9 : {
                            block8 : {
                                boolean bl = iterator.hasNext();
                                n3 = 1;
                                if (!bl) break block8;
                                f02 = (f0)iterator.next();
                                if (this.c.contains((Object)f02)) {
                                    n2 = n3;
                                    continue;
                                }
                                if (!f02.a.isAssignableFrom(class_) || !f02.b.isAssignableFrom(class_2)) break block9;
                                break block10;
                            }
                            if (arrayList.size() > n3) {
                                d d2 = this.b;
                                c c2 = this.d;
                                d2.getClass();
                                return new o(arrayList, c2);
                            }
                            if (arrayList.size() == n3) {
                                return (b0)arrayList.get(0);
                            }
                            if (n2 == 0) throw new k(class_, class_2);
                            return f;
                        }
                        n3 = 0;
                    }
                    if (n3 == 0) continue;
                    this.c.add((Object)f02);
                    arrayList.add((Object)this.b(f02));
                    this.c.remove((Object)f02);
                } while (true);
            }
            catch (Throwable throwable) {}
            this.c.clear();
            throw throwable;
        }
    }

    public final ArrayList d(Class class_) {
        g0 g02 = this;
        synchronized (g02) {
            Throwable throwable2;
            block6 : {
                ArrayList arrayList;
                try {
                    arrayList = new ArrayList();
                    for (f0 f02 : this.a) {
                        if (this.c.contains((Object)f02) || !f02.a.isAssignableFrom(class_)) continue;
                        this.c.add((Object)f02);
                        b0 b02 = f02.c.i(this);
                        b1.i(b02);
                        arrayList.add((Object)b02);
                        this.c.remove((Object)f02);
                    }
                }
                catch (Throwable throwable2) {
                    break block6;
                }
                return arrayList;
            }
            this.c.clear();
            throw throwable2;
        }
    }

    public final ArrayList e(Class class_) {
        g0 g02 = this;
        synchronized (g02) {
            ArrayList arrayList = new ArrayList();
            for (f0 f02 : this.a) {
                if (arrayList.contains((Object)f02.b) || !f02.a.isAssignableFrom(class_)) continue;
                arrayList.add((Object)f02.b);
            }
            return arrayList;
        }
    }

    public final void f(l l2) {
        g0 g02 = this;
        synchronized (g02) {
            f0 f02 = new f0(ApplicationInfo.class, Drawable.class, (c0)l2);
            this.a.add(0, (Object)f02);
            return;
        }
    }
}

