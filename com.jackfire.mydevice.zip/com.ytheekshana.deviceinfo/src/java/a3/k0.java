/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  java.lang.Object
 */
package a3;

import a3.b0;
import a3.c0;
import a3.g0;
import a3.l0;
import a3.m0;
import android.content.ContentResolver;

public final class k0
implements c0,
l0 {
    public final /* synthetic */ int q;
    public final ContentResolver r;

    public /* synthetic */ k0(ContentResolver contentResolver, int n2) {
        this.q = n2;
        this.r = contentResolver;
    }

    @Override
    public final b0 i(g0 g02) {
        switch (this.q) {
            default: {
                break;
            }
            case 1: {
                return new m0(this);
            }
            case 0: {
                return new m0(this);
            }
        }
        return new m0(this);
    }
}

