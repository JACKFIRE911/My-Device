/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a3;

import a2.s;

public final class v {
    public final String a;

    public v(String string) {
        this.a = string;
    }

    public final boolean equals(Object object) {
        if (object instanceof v) {
            v v2 = (v)object;
            return this.a.equals((Object)v2.a);
        }
        return false;
    }

    public final int hashCode() {
        return this.a.hashCode();
    }

    public final String toString() {
        return s.v(new StringBuilder("StringHeaderFactory{value='"), this.a, "'}");
    }
}

