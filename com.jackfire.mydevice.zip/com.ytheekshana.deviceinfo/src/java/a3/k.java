/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  u7.e
 */
package a3;

import a3.b0;
import a3.c0;
import a3.g;
import a3.g0;
import c.a;
import e0.s;
import u7.e;

public final class k
implements c0 {
    public final /* synthetic */ int q;
    public final s r;

    public k(int n2) {
        this.q = n2;
        if (n2 != 1) {
            this.r = new a(19, this);
            return;
        }
        super();
        this.r = new e(null);
    }

    @Override
    public final b0 i(g0 g02) {
        int n2 = this.q;
        s s3 = this.r;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                return new g(1, (a)s3);
            }
        }
        return new b3.a((e)s3);
    }
}

