/*
 * Decompiled with CFR 0.0.
 */
package a3;

import a3.p;
import a3.r;
import g2.d;

public final class q
extends p {
    public q(int n3) {
        if (n3 != 1) {
            super(new d(9));
            return;
        }
        super(new j2.q(9));
    }
}

