/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a3.w
 *  java.lang.Object
 *  java.util.Map
 */
package a3;

import a3.u;
import a3.w;
import java.util.Map;

public interface t {
    public static final w a = new w(new u().a);

    public Map a();
}

