/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.text.TextUtils
 *  java.io.File
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.net.URL
 *  u2.k
 */
package a3;

import a3.a0;
import a3.b0;
import a3.s;
import android.net.Uri;
import android.text.TextUtils;
import java.io.File;
import java.net.URL;
import u2.k;

public final class i0
implements b0 {
    public final /* synthetic */ int a;
    public final b0 b;

    public /* synthetic */ i0(b0 b02, int n2) {
        this.a = n2;
        this.b = b02;
    }

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        int n5 = this.a;
        b0 b02 = this.b;
        switch (n5) {
            default: {
                break;
            }
            case 0: {
                Uri uri;
                String string = (String)object;
                Uri uri2 = TextUtils.isEmpty((CharSequence)string) ? null : (string.charAt(0) == '/' ? Uri.fromFile((File)new File(string)) : ((uri = Uri.parse((String)string)).getScheme() == null ? Uri.fromFile((File)new File(string)) : uri));
                a0 a02 = null;
                if (uri2 != null) {
                    if (!b02.b((Object)uri2)) {
                        return null;
                    }
                    a02 = b02.a((Object)uri2, n2, n3, k3);
                }
                return a02;
            }
        }
        return b02.a(new s((URL)object), n2, n3, k3);
    }
}

