/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 *  u2.k
 */
package a3;

import a3.a0;
import a3.b0;
import a3.s;
import android.net.Uri;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import u2.k;

public final class n0
implements b0 {
    public static final Set b = Collections.unmodifiableSet((Set)new HashSet((Collection)Arrays.asList((Object[])new String[]{"http", "https"})));
    public final b0 a;

    public n0(b0 b02) {
        this.a = b02;
    }

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        s s3 = new s(((Uri)object).toString());
        return this.a.a(s3, n2, n3, k3);
    }

    @Override
    public final boolean b(Object object) {
        Uri uri = (Uri)object;
        return b.contains((Object)uri.getScheme());
    }
}

