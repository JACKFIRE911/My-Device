/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.bumptech.glide.load.data.e
 *  java.io.File
 *  java.lang.Object
 *  l3.b
 *  u2.k
 */
package a3;

import a3.a0;
import a3.b0;
import a3.h;
import com.bumptech.glide.load.data.e;
import java.io.File;
import l3.b;
import u2.k;

public final class i
implements b0 {
    public final /* synthetic */ int a;

    public /* synthetic */ i(int n2) {
        this.a = n2;
    }

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        switch (this.a) {
            default: {
                return null;
            }
            case 0: 
        }
        File file = (File)object;
        return new a0((u2.h)new b((Object)file), new h(0, (Object)file));
    }

    @Override
    public final boolean b(Object object) {
        switch (this.a) {
            default: {
                return false;
            }
            case 0: 
        }
        (File)object;
        return true;
    }
}

