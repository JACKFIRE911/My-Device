/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.bumptech.glide.load.data.e
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 *  l3.b
 *  u2.k
 */
package a3;

import a3.a0;
import a3.b0;
import a3.e;
import a3.f;
import a3.j;
import a3.r;
import c.a;
import java.io.File;
import l3.b;
import u2.h;
import u2.k;

public final class g
implements b0 {
    public final /* synthetic */ int a;
    public final Object b;

    public /* synthetic */ g(int n2, Object object) {
        this.a = n2;
        this.b = object;
    }

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        int n5 = this.a;
        Object object2 = this.b;
        switch (n5) {
            default: {
                break;
            }
            case 1: {
                return new a0((h)new b(object), new j(object.toString(), 0, (a)object2));
            }
            case 0: {
                byte[] arrby = (byte[])object;
                return new a0((h)new b((Object)arrby), new f(arrby, (e)object2));
            }
        }
        File file = (File)object;
        return new a0((h)new b((Object)file), new j((Object)file, 1, (r)object2));
    }

    @Override
    public final boolean b(Object object) {
        switch (this.a) {
            default: {
                break;
            }
            case 1: {
                return object.toString().startsWith("data:image");
            }
            case 0: {
                (byte[])object;
                return true;
            }
        }
        (File)object;
        return true;
    }
}

