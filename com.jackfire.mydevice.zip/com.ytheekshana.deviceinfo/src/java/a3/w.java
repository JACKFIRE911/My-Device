/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collections
 *  java.util.HashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package a3;

import a3.t;
import a3.v;
import android.text.TextUtils;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class w
implements t {
    public final Map b;
    public volatile Map c;

    public w(Map map) {
        this.b = Collections.unmodifiableMap((Map)map);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Map a() {
        if (this.c != null) return this.c;
        w w2 = this;
        synchronized (w2) {
            if (this.c != null) return this.c;
            this.c = Collections.unmodifiableMap((Map)this.b());
            return this.c;
        }
    }

    public final HashMap b() {
        HashMap hashMap = new HashMap();
        for (Map.Entry entry : this.b.entrySet()) {
            List list = (List)entry.getValue();
            StringBuilder stringBuilder = new StringBuilder();
            int n2 = list.size();
            for (int i3 = 0; i3 < n2; ++i3) {
                String string = ((v)list.get((int)i3)).a;
                if (TextUtils.isEmpty((CharSequence)string)) continue;
                stringBuilder.append(string);
                if (i3 == -1 + list.size()) continue;
                stringBuilder.append(',');
            }
            String string = stringBuilder.toString();
            if (TextUtils.isEmpty((CharSequence)string)) continue;
            hashMap.put(entry.getKey(), (Object)string);
        }
        return hashMap;
    }

    public final boolean equals(Object object) {
        if (object instanceof w) {
            w w2 = (w)object;
            return this.b.equals((Object)w2.b);
        }
        return false;
    }

    public final int hashCode() {
        return this.b.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("LazyHeaders{headers=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

