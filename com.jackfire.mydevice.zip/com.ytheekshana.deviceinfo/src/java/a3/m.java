/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetFileDescriptor
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.Drawable
 *  com.bumptech.glide.i
 *  com.bumptech.glide.load.data.d
 *  com.bumptech.glide.load.data.e
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 */
package a3;

import a3.l;
import a3.n;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import com.bumptech.glide.i;
import com.bumptech.glide.load.data.d;
import com.bumptech.glide.load.data.e;
import java.io.InputStream;
import u2.a;
import y7.f;

public final class m
implements e {
    public final Resources.Theme q;
    public final Resources r;
    public final n s;
    public final int t;
    public Object u;

    public m(Resources.Theme theme, Resources resources, n n2, int n3) {
        this.q = theme;
        this.r = resources;
        this.s = n2;
        this.t = n3;
    }

    public final Class a() {
        switch (((l)this.s).q) {
            default: {
                return InputStream.class;
            }
            case 1: {
                return Drawable.class;
            }
            case 0: 
        }
        return AssetFileDescriptor.class;
    }

    /*
     * Exception decompiling
     */
    public final void b() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public final void cancel() {
    }

    public final a d() {
        return a.q;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void f(i var1_1, d var2_2) {
        try {
            var4_3 = this.s;
            var5_4 = this.q;
            var6_5 = this.r;
            var7_6 = this.t;
            var8_7 = (l)var4_3;
            switch (var8_7.q) {
                case 1: {
                    var10_8 = var8_7.r;
                    var9_9 = f.l(var10_8, var10_8, var7_6, var5_4);
                    ** break;
                }
                case 0: {
                    var9_9 = var6_5.openRawResourceFd(var7_6);
                    ** break;
                }
            }
            var9_9 = var6_5.openRawResource(var7_6);
lbl16: // 3 sources:
            this.u = var9_9;
            var2_2.e((Object)var9_9);
            return;
        }
        catch (Resources.NotFoundException var3_10) {
            var2_2.c((Exception)var3_10);
            return;
        }
    }
}

