/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.bumptech.glide.load.data.e
 *  java.lang.Object
 *  java.util.Collections
 *  java.util.List
 *  u2.h
 */
package a3;

import a8.b1;
import com.bumptech.glide.load.data.e;
import java.util.Collections;
import java.util.List;
import u2.h;

public final class a0 {
    public final h a;
    public final List b;
    public final e c;

    public a0(h h2, e e2) {
        List list = Collections.emptyList();
        b1.i((Object)h2);
        this.a = h2;
        b1.i((Object)list);
        this.b = list;
        this.c = e2;
    }
}

