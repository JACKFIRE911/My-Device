/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.net.Uri
 *  com.bumptech.glide.load.data.e
 *  java.lang.Long
 *  java.lang.Object
 *  java.util.List
 *  l3.b
 *  u2.k
 *  v2.a
 *  v2.b
 *  v2.c
 */
package a3;

import a3.a0;
import a3.b0;
import a3.f;
import a3.x;
import a8.b1;
import android.content.ContentResolver;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import com.bumptech.glide.load.data.e;
import d3.f0;
import java.util.List;
import l3.b;
import s7.j;
import u2.h;
import u2.k;
import v2.a;
import v2.c;
import v2.d;

public final class y
implements b0 {
    public final /* synthetic */ int a;
    public final Context b;

    public y(Context context, int n2) {
        this.a = n2;
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    this.b = context;
                    return;
                }
                j.i((Object)context, "context");
                super();
                this.b = context;
                return;
            }
            super();
            this.b = context.getApplicationContext();
            return;
        }
        super();
        this.b = context.getApplicationContext();
    }

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        switch (this.a) {
            default: {
                break;
            }
            case 2: {
                return this.c((Uri)object, n2, n3, k3);
            }
            case 1: {
                return this.c((Uri)object, n2, n3, k3);
            }
            case 0: {
                return this.c((Uri)object, n2, n3, k3);
            }
        }
        ApplicationInfo applicationInfo = (ApplicationInfo)object;
        j.i((Object)applicationInfo, "model");
        j.i((Object)k3, "options");
        return new a0((h)new b((Object)applicationInfo), new f(this.b, applicationInfo));
    }

    @Override
    public final boolean b(Object object) {
        switch (this.a) {
            default: {
                break;
            }
            case 2: {
                return this.d((Uri)object);
            }
            case 1: {
                return this.d((Uri)object);
            }
            case 0: {
                return this.d((Uri)object);
            }
        }
        j.i((Object)((ApplicationInfo)object), "model");
        return true;
    }

    public final a0 c(Uri uri, int n2, int n3, k k3) {
        boolean bl = true;
        int n5 = this.a;
        Context context = this.b;
        switch (n5) {
            default: {
                break;
            }
            case 1: {
                if (n2 == Integer.MIN_VALUE || n3 == Integer.MIN_VALUE || n2 > 512 || n3 > 384) {
                    bl = false;
                }
                a0 a02 = null;
                if (bl) {
                    a02 = new a0((h)new b((Object)uri), (e)c.c((Context)context, (Uri)uri, (d)new a(context.getContentResolver())));
                }
                return a02;
            }
            case 0: {
                return new a0((h)new b((Object)uri), new x(context, uri));
            }
        }
        boolean bl2 = n2 != Integer.MIN_VALUE && n3 != Integer.MIN_VALUE && n2 <= 512 && n3 <= 384 ? bl : false;
        a0 a03 = null;
        if (bl2) {
            Long l3 = (Long)k3.c(f0.d);
            if (l3 == null || l3 != -1L) {
                bl = false;
            }
            a03 = null;
            if (bl) {
                a03 = new a0((h)new b((Object)uri), (e)c.c((Context)context, (Uri)uri, (d)new v2.b(context.getContentResolver())));
            }
        }
        return a03;
    }

    public final boolean d(Uri uri) {
        switch (this.a) {
            default: {
                break;
            }
            case 1: {
                return b1.v(uri) && !uri.getPathSegments().contains((Object)"video");
            }
            case 0: {
                return b1.v(uri);
            }
        }
        return b1.v(uri) && uri.getPathSegments().contains((Object)"video");
    }
}

