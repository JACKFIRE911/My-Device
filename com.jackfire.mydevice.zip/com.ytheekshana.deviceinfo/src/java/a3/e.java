/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 */
package a3;

public interface e {
    public Class a();

    public Object l(byte[] var1);
}

