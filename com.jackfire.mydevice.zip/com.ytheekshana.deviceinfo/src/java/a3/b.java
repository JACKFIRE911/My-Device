/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetManager
 *  java.lang.Object
 */
package a3;

import a3.a;
import a3.b0;
import a3.c;
import a3.c0;
import a3.g0;
import android.content.res.AssetManager;

public final class b
implements c0,
a {
    public final /* synthetic */ int q;
    public final AssetManager r;

    public /* synthetic */ b(AssetManager assetManager, int n2) {
        this.q = n2;
        this.r = assetManager;
    }

    @Override
    public final b0 i(g0 g02) {
        int n2 = this.q;
        AssetManager assetManager = this.r;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                return new c(assetManager, this);
            }
        }
        return new c(assetManager, this);
    }
}

