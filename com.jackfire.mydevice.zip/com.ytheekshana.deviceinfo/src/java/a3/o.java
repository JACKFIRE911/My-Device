/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.content.res.Resources$Theme
 *  android.net.Uri
 *  android.util.Log
 *  com.bumptech.glide.load.data.e
 *  java.lang.Integer
 *  java.lang.NumberFormatException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Iterator
 *  java.util.List
 *  l3.b
 *  u2.k
 */
package a3;

import a3.a0;
import a3.b0;
import a3.e0;
import a3.m;
import a3.n;
import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import android.util.Log;
import com.bumptech.glide.load.data.e;
import e3.d;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import l3.b;
import m0.c;
import u2.h;
import u2.j;
import u2.k;

public final class o
implements b0 {
    public final /* synthetic */ int a;
    public final Object b;
    public final Object c;

    public o(Context context, b0 b02) {
        this.a = 3;
        this.b = context.getApplicationContext();
        this.c = b02;
    }

    public o(Context context, n n2) {
        this.a = 0;
        this.b = context.getApplicationContext();
        this.c = n2;
    }

    public o(Resources resources, b0 b02) {
        this.a = 2;
        this.c = resources;
        this.b = b02;
    }

    public o(ArrayList arrayList, c c4) {
        this.a = 1;
        this.b = arrayList;
        this.c = c4;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        int n5 = this.a;
        Object object2 = this.c;
        Object object3 = this.b;
        switch (n5) {
            default: {
                break;
            }
            case 2: {
                return this.c((Integer)object, n2, n3, k3);
            }
            case 1: {
                List list = (List)object3;
                int n6 = list.size();
                ArrayList arrayList = new ArrayList(n6);
                h h3 = null;
                for (int i3 = 0; i3 < n6; ++i3) {
                    a0 a02;
                    b0 b02 = (b0)list.get(i3);
                    if (!b02.b(object) || (a02 = b02.a(object, n2, n3, k3)) == null) continue;
                    arrayList.add((Object)a02.c);
                    h3 = a02.a;
                }
                boolean bl = arrayList.isEmpty();
                a0 a03 = null;
                if (bl) return a03;
                a03 = null;
                if (h3 == null) return a03;
                return new a0(h3, new e0(arrayList, (c)object2));
            }
            case 0: {
                return this.c((Integer)object, n2, n3, k3);
            }
        }
        Uri uri = (Uri)object;
        List list = uri.getPathSegments();
        if (list.size() == 1) {
            int n7;
            block12 : {
                try {
                    n7 = Integer.parseInt((String)((String)uri.getPathSegments().get(0)));
                    if (n7 != 0) break block12;
                }
                catch (NumberFormatException numberFormatException) {
                    if (!Log.isLoggable((String)"ResourceUriLoader", (int)5)) return null;
                    StringBuilder stringBuilder = new StringBuilder("Failed to parse resource id from: ");
                    stringBuilder.append((Object)uri);
                    Log.w((String)"ResourceUriLoader", (String)stringBuilder.toString(), (Throwable)numberFormatException);
                    return null;
                }
                if (!Log.isLoggable((String)"ResourceUriLoader", (int)5)) return null;
                StringBuilder stringBuilder = new StringBuilder("Failed to parse a valid non-0 resource id from: ");
                stringBuilder.append((Object)uri);
                Log.w((String)"ResourceUriLoader", (String)stringBuilder.toString());
                return null;
            }
            return ((b0)object2).a(n7, n2, n3, k3);
        }
        if (list.size() == 2) {
            List list2 = uri.getPathSegments();
            String string = (String)list2.get(0);
            String string2 = (String)list2.get(1);
            Context context = (Context)object3;
            int n8 = context.getResources().getIdentifier(string2, string, context.getPackageName());
            if (n8 != 0) return ((b0)object2).a(n8, n2, n3, k3);
            if (!Log.isLoggable((String)"ResourceUriLoader", (int)5)) return null;
            StringBuilder stringBuilder = new StringBuilder("Failed to find resource id for: ");
            stringBuilder.append((Object)uri);
            Log.w((String)"ResourceUriLoader", (String)stringBuilder.toString());
            return null;
        }
        if (!Log.isLoggable((String)"ResourceUriLoader", (int)5)) return null;
        StringBuilder stringBuilder = new StringBuilder("Failed to parse resource uri: ");
        stringBuilder.append((Object)uri);
        Log.w((String)"ResourceUriLoader", (String)stringBuilder.toString());
        return null;
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public final boolean b(Object object) {
        int n2 = this.a;
        Object object2 = this.b;
        switch (n2) {
            default: {
                break;
            }
            case 2: {
                (Integer)object;
                return true;
            }
            case 1: {
                Iterator iterator = ((List)object2).iterator();
                do {
                    boolean bl = iterator.hasNext();
                    boolean bl2 = false;
                    if (!bl) return bl2;
                } while (!((b0)iterator.next()).b(object));
                return true;
            }
            case 0: {
                (Integer)object;
                return true;
            }
        }
        Uri uri = (Uri)object;
        boolean bl = "android.resource".equals((Object)uri.getScheme());
        boolean bl3 = false;
        if (!bl) return bl3;
        boolean bl4 = ((Context)object2).getPackageName().equals((Object)uri.getAuthority());
        bl3 = false;
        if (!bl4) return bl3;
        return true;
    }

    public final a0 c(Integer n2, int n3, int n5, k k3) {
        Uri uri;
        int n6 = this.a;
        Object object = this.c;
        Object object2 = this.b;
        switch (n6) {
            default: {
                break;
            }
            case 0: {
                Resources.Theme theme = (Resources.Theme)k3.c(d.b);
                Resources resources = theme != null ? theme.getResources() : ((Context)object2).getResources();
                return new a0((h)new b((Object)n2), new m(theme, resources, (n)object, n2));
            }
        }
        try {
            StringBuilder stringBuilder = new StringBuilder("android.resource://");
            stringBuilder.append(((Resources)object).getResourcePackageName(n2.intValue()));
            stringBuilder.append('/');
            stringBuilder.append(((Resources)object).getResourceTypeName(n2.intValue()));
            stringBuilder.append('/');
            stringBuilder.append(((Resources)object).getResourceEntryName(n2.intValue()));
            uri = Uri.parse((String)stringBuilder.toString());
        }
        catch (Resources.NotFoundException notFoundException) {
            if (Log.isLoggable((String)"ResourceLoader", (int)5)) {
                StringBuilder stringBuilder = new StringBuilder("Received invalid resource id: ");
                stringBuilder.append((Object)n2);
                Log.w((String)"ResourceLoader", (String)stringBuilder.toString(), (Throwable)notFoundException);
            }
            uri = null;
        }
        if (uri == null) {
            return null;
        }
        return ((b0)object2).a((Object)uri, n3, n5, k3);
    }

    public final String toString() {
        switch (this.a) {
            default: {
                return super.toString();
            }
            case 1: 
        }
        StringBuilder stringBuilder = new StringBuilder("MultiModelLoader{modelLoaders=");
        stringBuilder.append(Arrays.toString((Object[])((List)this.b).toArray()));
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

