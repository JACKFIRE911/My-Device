/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.net.Uri
 *  com.bumptech.glide.load.data.a
 *  com.bumptech.glide.load.data.e
 *  com.bumptech.glide.load.data.o
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Set
 *  l3.b
 *  u2.k
 */
package a3;

import a3.a0;
import a3.b0;
import a3.k0;
import a3.l0;
import android.content.ContentResolver;
import android.net.Uri;
import com.bumptech.glide.load.data.a;
import com.bumptech.glide.load.data.e;
import com.bumptech.glide.load.data.o;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import l3.b;
import u2.h;
import u2.k;

public final class m0
implements b0 {
    public static final Set b = Collections.unmodifiableSet((Set)new HashSet((Collection)Arrays.asList((Object[])new String[]{"file", "content", "android.resource"})));
    public final l0 a;

    public m0(l0 l02) {
        this.a = l02;
    }

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        o o5;
        b b4;
        block4 : {
            Uri uri = (Uri)object;
            b4 = new b((Object)uri);
            k0 k02 = (k0)this.a;
            int n5 = k02.q;
            ContentResolver contentResolver = k02.r;
            switch (n5) {
                default: {
                    break;
                }
                case 1: {
                    o5 = new a(contentResolver, uri, 1);
                    break block4;
                }
                case 0: {
                    o5 = new a(contentResolver, uri, 0);
                    break block4;
                }
            }
            o5 = new o(contentResolver, uri);
        }
        return new a0((h)b4, (e)o5);
    }

    @Override
    public final boolean b(Object object) {
        Uri uri = (Uri)object;
        return b.contains((Object)uri.getScheme());
    }
}

