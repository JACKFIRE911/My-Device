/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.bumptech.glide.i
 *  com.bumptech.glide.load.data.d
 *  com.bumptech.glide.load.data.e
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.List
 */
package a3;

import a8.b1;
import com.bumptech.glide.i;
import com.bumptech.glide.load.data.d;
import com.bumptech.glide.load.data.e;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import m0.c;
import u2.a;
import w2.a0;

public final class e0
implements e,
d {
    public final List q;
    public final c r;
    public int s;
    public i t;
    public d u;
    public List v;
    public boolean w;

    public e0(ArrayList arrayList, c c3) {
        this.r = c3;
        if (!arrayList.isEmpty()) {
            this.q = arrayList;
            this.s = 0;
            return;
        }
        throw new IllegalArgumentException("Must not be empty.");
    }

    public final Class a() {
        return ((e)this.q.get(0)).a();
    }

    public final void b() {
        List list = this.v;
        if (list != null) {
            this.r.b((Object)list);
        }
        this.v = null;
        Iterator iterator = this.q.iterator();
        while (iterator.hasNext()) {
            ((e)iterator.next()).b();
        }
    }

    public final void c(Exception exception) {
        List list = this.v;
        b1.i((Object)list);
        list.add((Object)exception);
        this.g();
    }

    public final void cancel() {
        this.w = true;
        Iterator iterator = this.q.iterator();
        while (iterator.hasNext()) {
            ((e)iterator.next()).cancel();
        }
    }

    public final a d() {
        return ((e)this.q.get(0)).d();
    }

    public final void e(Object object) {
        if (object != null) {
            this.u.e(object);
            return;
        }
        this.g();
    }

    public final void f(i i3, d d4) {
        this.t = i3;
        this.u = d4;
        this.v = (List)this.r.g();
        ((e)this.q.get(this.s)).f(i3, (d)this);
        if (this.w) {
            this.cancel();
        }
    }

    public final void g() {
        if (this.w) {
            return;
        }
        if (this.s < -1 + this.q.size()) {
            this.s = 1 + this.s;
            this.f(this.t, this.u);
            return;
        }
        b1.i((Object)this.v);
        this.u.c((Exception)new a0("Fetch failed", (List)new ArrayList((Collection)this.v)));
    }
}

