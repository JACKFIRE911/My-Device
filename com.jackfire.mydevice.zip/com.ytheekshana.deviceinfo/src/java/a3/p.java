/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a3;

import a3.b0;
import a3.c0;
import a3.g;
import a3.g0;
import a3.r;

public abstract class p
implements c0 {
    public final r q;

    public p(r r4) {
        this.q = r4;
    }

    @Override
    public final b0 i(g0 g02) {
        return new g(2, this.q);
    }
}

