/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  com.bumptech.glide.i
 *  com.bumptech.glide.load.data.d
 *  com.bumptech.glide.load.data.e
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package a3;

import a3.r;
import android.util.Log;
import c.a;
import com.bumptech.glide.i;
import com.bumptech.glide.load.data.d;
import com.bumptech.glide.load.data.e;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStream;

public final class j
implements e {
    public final /* synthetic */ int q;
    public Object r;
    public final Object s;
    public final Object t;

    public /* synthetic */ j(Object object, int n2, Object object2) {
        this.q = n2;
        this.s = object;
        this.t = object2;
    }

    public final Class a() {
        int n2 = this.q;
        Object object = this.t;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                ((a)object).getClass();
                return InputStream.class;
            }
        }
        return ((r)object).a();
    }

    /*
     * Exception decompiling
     */
    public final void b() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public final void cancel() {
    }

    public final u2.a d() {
        return u2.a.q;
    }

    public final void f(i i3, d d4) {
        int n2 = this.q;
        Object object = this.s;
        Object object2 = this.t;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                try {
                    a a3 = (a)object2;
                    String string = (String)object;
                    a3.getClass();
                    ByteArrayInputStream byteArrayInputStream = a.u(string);
                    this.r = byteArrayInputStream;
                    d4.e((Object)byteArrayInputStream);
                    return;
                }
                catch (IllegalArgumentException illegalArgumentException) {
                    d4.c((Exception)illegalArgumentException);
                    return;
                }
            }
        }
        try {
            Object object3;
            this.r = object3 = ((r)object2).l((File)object);
            d4.e(object3);
            return;
        }
        catch (FileNotFoundException fileNotFoundException) {
            if (Log.isLoggable((String)"FileLoader", (int)3)) {
                Log.d((String)"FileLoader", (String)"Failed to open file", (Throwable)fileNotFoundException);
            }
            d4.c((Exception)fileNotFoundException);
            return;
        }
    }
}

