/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.File
 *  java.lang.Class
 *  java.lang.Object
 */
package a3;

import java.io.File;

public interface r {
    public Class a();

    public Object l(File var1);

    public void o(Object var1);
}

