/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.database.Cursor
 *  android.net.Uri
 *  android.text.TextUtils
 *  com.bumptech.glide.i
 *  com.bumptech.glide.load.data.d
 *  com.bumptech.glide.load.data.e
 *  java.io.File
 *  java.io.FileNotFoundException
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a3;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.text.TextUtils;
import com.bumptech.glide.i;
import com.bumptech.glide.load.data.d;
import com.bumptech.glide.load.data.e;
import java.io.File;
import java.io.FileNotFoundException;
import u2.a;

public final class x
implements e {
    public static final String[] s = new String[]{"_data"};
    public final Context q;
    public final Uri r;

    public x(Context context, Uri uri) {
        this.q = context;
        this.r = uri;
    }

    public final Class a() {
        return File.class;
    }

    public final void b() {
    }

    public final void cancel() {
    }

    public final a d() {
        return a.q;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void f(i i3, d d4) {
        String string;
        Cursor cursor = this.q.getContentResolver().query(this.r, s, null, null, null);
        string = null;
        if (cursor != null) {
            try {
                boolean bl = cursor.moveToFirst();
                string = null;
                if (bl) {
                    string = cursor.getString(cursor.getColumnIndexOrThrow("_data"));
                }
            }
            finally {
                cursor.close();
            }
        }
        if (TextUtils.isEmpty(string)) {
            StringBuilder stringBuilder = new StringBuilder("Failed to find file path for: ");
            stringBuilder.append((Object)this.r);
            d4.c((Exception)new FileNotFoundException(stringBuilder.toString()));
            return;
        }
        d4.e((Object)new File(string));
    }
}

