/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.List
 */
package a3;

import java.util.List;

public final class d0 {
    public final List a;

    public d0(List list) {
        this.a = list;
    }
}

