/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetFileDescriptor
 *  android.net.Uri
 *  android.os.ParcelFileDescriptor
 *  androidx.fragment.app.w0
 *  androidx.lifecycle.v0
 *  androidx.lifecycle.x0
 *  com.google.android.gms.internal.ads.a01
 *  com.google.android.gms.internal.ads.c31
 *  com.google.android.gms.internal.ads.h41
 *  com.google.android.gms.internal.ads.h91
 *  com.google.android.gms.internal.ads.j31
 *  com.google.android.gms.internal.ads.pv0
 *  com.google.android.gms.internal.ads.q21
 *  com.google.android.gms.internal.ads.rv0
 *  com.google.android.gms.internal.ads.ya1
 *  java.io.InputStream
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.nio.ByteBuffer
 *  java.security.GeneralSecurityException
 *  java.security.InvalidAlgorithmParameterException
 *  java.security.KeyFactory
 *  java.security.KeyPairGenerator
 *  java.security.MessageDigest
 *  java.security.Provider
 *  java.security.Signature
 *  javax.crypto.Cipher
 *  javax.crypto.KeyAgreement
 *  javax.crypto.Mac
 *  t8.c
 *  u7.e
 */
package a3;

import a3.b0;
import a3.c0;
import a3.g;
import a3.g0;
import a3.i;
import a3.i0;
import a3.n0;
import a3.s;
import android.content.res.AssetFileDescriptor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import androidx.fragment.app.w0;
import androidx.lifecycle.v0;
import androidx.lifecycle.x0;
import com.google.android.gms.internal.ads.a01;
import com.google.android.gms.internal.ads.c31;
import com.google.android.gms.internal.ads.h41;
import com.google.android.gms.internal.ads.h91;
import com.google.android.gms.internal.ads.j31;
import com.google.android.gms.internal.ads.pv0;
import com.google.android.gms.internal.ads.q21;
import com.google.android.gms.internal.ads.rv0;
import com.google.android.gms.internal.ads.ya1;
import d1.e;
import e1.a;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.security.GeneralSecurityException;
import java.security.InvalidAlgorithmParameterException;
import java.security.KeyFactory;
import java.security.KeyPairGenerator;
import java.security.MessageDigest;
import java.security.Provider;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.KeyAgreement;
import javax.crypto.Mac;
import t8.c;

public final class d
implements c0,
x0,
a01,
ya1,
rv0,
c31,
h91 {
    public final int q;

    public /* synthetic */ d() {
        this.q = 13;
    }

    public /* synthetic */ d(int n2) {
        this.q = n2;
    }

    public /* synthetic */ d(int n2, int n3) {
        this.q = n2;
    }

    public void A(Throwable throwable) {
        x4.b0.a("Notification of cache hit failed.");
    }

    public v0 a(Class class_) {
        switch (this.q) {
            default: {
                break;
            }
            case 0: {
                return new w0(true);
            }
        }
        return new a();
    }

    public int b() {
        return 32;
    }

    public byte[] c() {
        return j31.k;
    }

    public /* synthetic */ void d(Object object) {
        (Void)object;
        x4.b0.a("Notification of cache hit successful.");
    }

    public byte[] e(byte[] arrby, byte[] arrby2, byte[] arrby3, byte[] arrby4) {
        if (arrby.length == 32) {
            q21 q212 = new q21(0, arrby);
            int n2 = arrby3.length;
            if (n2 <= 2147483631) {
                ByteBuffer byteBuffer = ByteBuffer.allocate((int)(n2 + 16));
                q212.k(byteBuffer, arrby2, arrby3, arrby4);
                return byteBuffer.array();
            }
            throw new GeneralSecurityException("plaintext too long");
        }
        throw new InvalidAlgorithmParameterException("Unexpected key length: 32");
    }

    public /* synthetic */ pv0 f(h41 h412, CharSequence charSequence) {
        return new pv0((rv0)this, h412, charSequence, 1);
    }

    @Override
    public b0 i(g0 g02) {
        switch (this.q) {
            default: {
                break;
            }
            case 6: {
                return new n0(g02.c(s.class, InputStream.class));
            }
            case 5: {
                return new i0(g02.c(Uri.class, InputStream.class), 0);
            }
            case 4: {
                return new i0(g02.c(Uri.class, ParcelFileDescriptor.class), 0);
            }
            case 3: {
                return new i0(g02.c(Uri.class, AssetFileDescriptor.class), 0);
            }
            case 2: {
                return new i(0);
            }
            case 1: {
                return new g(0, (Object)new c(20, (Object)this));
            }
            case 0: {
                return new g(0, (Object)new u7.e(15, (Object)this));
            }
        }
        return new i0(g02.c(s.class, InputStream.class), 1);
    }

    public v0 j(Class class_, e e4) {
        switch (this.q) {
            default: {
                break;
            }
            case 0: {
                return this.a(class_);
            }
        }
        return this.a(class_);
    }
}

