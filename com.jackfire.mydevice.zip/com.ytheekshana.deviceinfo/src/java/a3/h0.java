/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetFileDescriptor
 *  android.content.res.Resources
 *  android.net.Uri
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Object
 */
package a3;

import a3.b0;
import a3.c0;
import a3.g0;
import a3.j0;
import a3.o;
import android.content.res.AssetFileDescriptor;
import android.content.res.Resources;
import android.net.Uri;
import java.io.InputStream;

public final class h0
implements c0 {
    public final /* synthetic */ int q;
    public final Resources r;

    public /* synthetic */ h0(Resources resources, int n2) {
        this.q = n2;
        this.r = resources;
    }

    @Override
    public final b0 i(g0 g02) {
        int n2 = this.q;
        Resources resources = this.r;
        switch (n2) {
            default: {
                break;
            }
            case 1: {
                return new o(resources, g02.c(Uri.class, InputStream.class));
            }
            case 0: {
                return new o(resources, g02.c(Uri.class, AssetFileDescriptor.class));
            }
        }
        return new o(resources, (b0)j0.a);
    }
}

