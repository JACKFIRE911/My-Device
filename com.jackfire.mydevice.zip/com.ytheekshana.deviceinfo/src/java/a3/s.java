/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  android.text.TextUtils
 *  java.lang.CharSequence
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.net.URL
 *  java.nio.charset.Charset
 *  java.security.MessageDigest
 */
package a3;

import a3.t;
import a3.w;
import a8.b1;
import android.net.Uri;
import android.text.TextUtils;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import u2.h;

public final class s
implements h {
    public final t b;
    public final URL c;
    public final String d;
    public String e;
    public URL f;
    public volatile byte[] g;
    public int h;

    public s(String string) {
        w w2 = t.a;
        this.c = null;
        if (!TextUtils.isEmpty((CharSequence)string)) {
            this.d = string;
            b1.i(w2);
            this.b = w2;
            return;
        }
        throw new IllegalArgumentException("Must not be null or empty");
    }

    public s(URL uRL) {
        w w2 = t.a;
        b1.i((Object)uRL);
        this.c = uRL;
        this.d = null;
        b1.i(w2);
        this.b = w2;
    }

    @Override
    public final void a(MessageDigest messageDigest) {
        if (this.g == null) {
            this.g = this.c().getBytes(h.a);
        }
        messageDigest.update(this.g);
    }

    public final String c() {
        String string = this.d;
        if (string != null) {
            return string;
        }
        URL uRL = this.c;
        b1.i((Object)uRL);
        return uRL.toString();
    }

    public final URL d() {
        if (this.f == null) {
            if (TextUtils.isEmpty((CharSequence)this.e)) {
                String string = this.d;
                if (TextUtils.isEmpty((CharSequence)string)) {
                    URL uRL = this.c;
                    b1.i((Object)uRL);
                    string = uRL.toString();
                }
                this.e = Uri.encode((String)string, (String)"@#&=*+-_.,:!?()/~'%;$");
            }
            this.f = new URL(this.e);
        }
        return this.f;
    }

    @Override
    public final boolean equals(Object object) {
        boolean bl = object instanceof s;
        boolean bl2 = false;
        if (bl) {
            s s3 = (s)object;
            boolean bl3 = this.c().equals((Object)s3.c());
            bl2 = false;
            if (bl3) {
                boolean bl4 = this.b.equals((Object)s3.b);
                bl2 = false;
                if (bl4) {
                    bl2 = true;
                }
            }
        }
        return bl2;
    }

    @Override
    public final int hashCode() {
        if (this.h == 0) {
            int n2;
            this.h = n2 = this.c().hashCode();
            this.h = n2 * 31 + this.b.hashCode();
        }
        return this.h;
    }

    public final String toString() {
        return this.c();
    }
}

