/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetManager
 *  android.net.Uri
 *  com.bumptech.glide.load.data.e
 *  com.bumptech.glide.load.data.k
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 *  l3.b
 *  u2.k
 */
package a3;

import a3.a;
import a3.a0;
import a3.b;
import a3.b0;
import android.content.res.AssetManager;
import android.net.Uri;
import com.bumptech.glide.load.data.e;
import com.bumptech.glide.load.data.k;
import java.util.List;
import u2.h;

public final class c
implements b0 {
    public final AssetManager a;
    public final a b;

    public c(AssetManager assetManager, a a3) {
        this.a = assetManager;
        this.b = a3;
    }

    @Override
    public final a0 a(Object object, int n2, int n3, u2.k k3) {
        k k4;
        l3.b b4;
        block3 : {
            Uri uri = (Uri)object;
            String string = uri.toString().substring(22);
            b4 = new l3.b((Object)uri);
            int n5 = ((b)this.b).q;
            AssetManager assetManager = this.a;
            switch (n5) {
                default: {
                    break;
                }
                case 0: {
                    k4 = new k(assetManager, string, 0);
                    break block3;
                }
            }
            k4 = new k(assetManager, string, 1);
        }
        return new a0((h)b4, (e)k4);
    }

    @Override
    public final boolean b(Object object) {
        Uri uri = (Uri)object;
        boolean bl = "file".equals((Object)uri.getScheme());
        boolean bl2 = false;
        if (bl) {
            boolean bl3 = uri.getPathSegments().isEmpty();
            bl2 = false;
            if (!bl3) {
                boolean bl4 = "android_asset".equals(uri.getPathSegments().get(0));
                bl2 = false;
                if (bl4) {
                    bl2 = true;
                }
            }
        }
        return bl2;
    }
}

