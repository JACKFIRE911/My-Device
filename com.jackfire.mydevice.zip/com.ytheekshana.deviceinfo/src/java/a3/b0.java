/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  u2.k
 */
package a3;

import a3.a0;
import u2.k;

public interface b0 {
    public a0 a(Object var1, int var2, int var3, k var4);

    public boolean b(Object var1);
}

