/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.bumptech.glide.load.data.e
 *  java.lang.Object
 *  l3.b
 *  u2.k
 */
package a3;

import a3.a0;
import a3.b0;
import a3.h;
import com.bumptech.glide.load.data.e;
import l3.b;
import u2.k;

public final class j0
implements b0 {
    public static final j0 a = new j0();

    @Override
    public final a0 a(Object object, int n2, int n3, k k3) {
        return new a0((u2.h)new b(object), new h(1, object));
    }

    @Override
    public final boolean b(Object object) {
        return true;
    }
}

