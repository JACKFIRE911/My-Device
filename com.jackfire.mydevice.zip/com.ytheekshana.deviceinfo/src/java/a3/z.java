/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.ArrayDeque
 */
package a3;

import java.util.ArrayDeque;

public final class z {
    public static final ArrayDeque d = new ArrayDeque(0);
    public int a;
    public int b;
    public Object c;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static z a(Object object) {
        ArrayDeque arrayDeque;
        ArrayDeque arrayDeque2 = arrayDeque = d;
        // MONITORENTER : arrayDeque2
        z z2 = (z)arrayDeque.poll();
        // MONITOREXIT : arrayDeque2
        if (z2 == null) {
            z2 = new z();
        }
        z2.c = object;
        z2.b = 0;
        z2.a = 0;
        return z2;
    }

    public final boolean equals(Object object) {
        boolean bl = object instanceof z;
        boolean bl2 = false;
        if (bl) {
            z z2 = (z)object;
            int n2 = this.b;
            int n3 = z2.b;
            bl2 = false;
            if (n2 == n3) {
                int n5 = this.a;
                int n6 = z2.a;
                bl2 = false;
                if (n5 == n6) {
                    boolean bl3 = this.c.equals(z2.c);
                    bl2 = false;
                    if (bl3) {
                        bl2 = true;
                    }
                }
            }
        }
        return bl2;
    }

    public final int hashCode() {
        return 31 * (31 * this.a + this.b) + this.c.hashCode();
    }
}

