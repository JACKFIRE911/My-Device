/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetFileDescriptor
 *  java.io.InputStream
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 */
package a3;

import a3.b0;
import a3.c0;
import a3.g0;
import a3.n;
import a3.o;
import a3.y;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import java.io.InputStream;
import s7.j;

public final class l
implements c0,
n {
    public final /* synthetic */ int q;
    public final Context r;

    public l(Context context) {
        this.q = 8;
        this.r = context;
    }

    public /* synthetic */ l(Context context, int n2) {
        this.q = n2;
        this.r = context;
    }

    @Override
    public final b0 i(g0 g02) {
        int n2 = this.q;
        Context context = this.r;
        switch (n2) {
            default: {
                break;
            }
            case 7: {
                return new y(context, 2);
            }
            case 6: {
                return new y(context, 1);
            }
            case 5: {
                return new o(context, g02.c(Integer.class, InputStream.class));
            }
            case 4: {
                return new o(context, g02.c(Integer.class, AssetFileDescriptor.class));
            }
            case 3: {
                return new y(context, 0);
            }
            case 2: {
                return new o(context, this);
            }
            case 1: {
                return new o(context, this);
            }
            case 0: {
                return new o(context, this);
            }
        }
        j.i(g02, "multiFactory");
        return new y(context, 3);
    }
}

