/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Thread
 *  java.util.concurrent.locks.LockSupport
 */
package ba;

import ba.a;
import ba.l0;
import java.util.concurrent.locks.LockSupport;
import m9.h;
import s7.j;

public final class c
extends a {
    public final Thread t;
    public final l0 u;

    public c(h h2, Thread thread, l0 l02) {
        super(h2, true);
        this.t = thread;
        this.u = l02;
    }

    @Override
    public final void g(Object object) {
        Thread thread;
        Thread thread2 = Thread.currentThread();
        if (!j.b((Object)thread2, (Object)(thread = this.t))) {
            LockSupport.unpark((Thread)thread);
        }
    }
}

