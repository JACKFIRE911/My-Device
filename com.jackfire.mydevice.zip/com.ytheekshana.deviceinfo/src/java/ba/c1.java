/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.x
 *  ba.c
 *  ba.o
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collections
 *  java.util.IdentityHashMap
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 *  java.util.concurrent.CancellationException
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 */
package ba;

import ba.a1;
import ba.b1;
import ba.c;
import ba.e;
import ba.f0;
import ba.f1;
import ba.g0;
import ba.g1;
import ba.h;
import ba.i1;
import ba.k;
import ba.l;
import ba.m;
import ba.o;
import ba.o0;
import ba.p0;
import ba.q;
import ba.q0;
import ba.r0;
import ba.s0;
import ba.t0;
import ba.u0;
import ba.v0;
import ba.x;
import ba.x0;
import ba.y0;
import ba.z0;
import da.i;
import java.util.ArrayList;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import m9.d;
import m9.f;
import n7.b;
import n9.a;
import s5.g;
import s7.j;
import t9.p;

public class c1
implements t0,
m,
i1 {
    public static final AtomicReferenceFieldUpdater q = AtomicReferenceFieldUpdater.newUpdater(c1.class, Object.class, (String)"_state");
    public static final AtomicReferenceFieldUpdater r = AtomicReferenceFieldUpdater.newUpdater(c1.class, Object.class, (String)"_parentHandle");
    private volatile Object _parentHandle;
    private volatile Object _state;

    public c1(boolean bl) {
        g0 g02 = bl ? g.i : g.h;
        this._state = g02;
    }

    public static l H(i i4) {
        while (i4.n()) {
            i4 = i4.m();
        }
        do {
            if ((i4 = i4.l()).n()) {
                continue;
            }
            if (i4 instanceof l) {
                return (l)i4;
            }
            if (i4 instanceof f1) break;
        } while (true);
        return null;
    }

    public static String N(Object object) {
        block9 : {
            block10 : {
                block8 : {
                    block7 : {
                        if (!(object instanceof a1)) break block7;
                        a1 a12 = (a1)object;
                        if (a12.d()) {
                            return "Cancelling";
                        }
                        if (a12.e()) {
                            return "Completing";
                        }
                        break block8;
                    }
                    if (!(object instanceof p0)) break block9;
                    if (!((p0)object).a()) break block10;
                }
                return "Active";
            }
            return "New";
        }
        if (object instanceof q) {
            return "Cancelled";
        }
        return "Completed";
    }

    public final void A(t0 t02) {
        int n3;
        g1 g12 = g1.q;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = r;
        if (t02 == null) {
            atomicReferenceFieldUpdater.set((Object)this, (Object)g12);
            return;
        }
        c1 c12 = (c1)t02;
        while ((n3 = c12.M(c12.x())) != 0 && n3 != 1) {
        }
        k k4 = (k)x.k(c12, true, new l(this), 2);
        atomicReferenceFieldUpdater.set((Object)this, (Object)k4);
        if (true ^ this.x() instanceof p0) {
            k4.c();
            atomicReferenceFieldUpdater.set((Object)this, (Object)g12);
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final f0 B(boolean bl, boolean bl2, t9.l l2) {
        if (bl) {
            void var4_6;
            if (l2 instanceof v0) {
                v0 v02 = (v0)l2;
            } else {
                Object var4_5 = null;
            }
            if (var4_6 == null) {
                r0 r02 = new r0(l2);
            }
        } else {
            void var4_10;
            if (l2 instanceof x0) {
                x0 x02 = (x0)l2;
            } else {
                Object var4_9 = null;
            }
            if (var4_10 == null) {
                s0 s02 = new s0(0, l2);
            }
        }
        var4_12.t = this;
        do {
            void var16_21;
            g0 g02;
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
            block28 : {
                boolean bl3;
                void var4_12;
                block25 : {
                    Object object;
                    block27 : {
                        block26 : {
                            if (!((object = this.x()) instanceof g0)) break block26;
                            g02 = (g0)object;
                            if (g02.q) break block27;
                            f1 f12 = new f1();
                            if (!g02.q) {
                                o0 o02 = new o0(f12);
                            }
                            break block28;
                        }
                        if (object instanceof p0) {
                            Throwable throwable;
                            f1 f13 = ((p0)object).h();
                            if (f13 == null) {
                                j.g(object, "null cannot be cast to non-null type kotlinx.coroutines.JobNode");
                                this.L((x0)object);
                                continue;
                            }
                            g1 g12 = g1.q;
                            if (bl && object instanceof a1) {
                                Object object2 = object;
                                synchronized (object2) {
                                    throwable = ((a1)object).c();
                                    if (throwable == null || l2 instanceof l && !((a1)object).e()) {
                                        boolean bl4 = this.f(object, f13, (x0)var4_12);
                                        if (!bl4) {
                                            continue;
                                        }
                                        if (throwable == null) {
                                            return var4_12;
                                        }
                                        void var10_17 = var4_12;
                                    }
                                }
                            } else {
                                throwable = null;
                            }
                            if (throwable != null) {
                                void var10_15;
                                if (bl2) {
                                    l2.g((Object)throwable);
                                }
                                return var10_15;
                            }
                            if (!this.f(object, f13, (x0)var4_12)) continue;
                            return var4_12;
                        }
                        if (bl2) {
                            q q3 = object instanceof q ? (q)object : null;
                            Throwable throwable = null;
                            if (q3 != null) {
                                throwable = q3.a;
                            }
                            l2.g((Object)throwable);
                        }
                        return g1.q;
                    }
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = q;
                    do {
                        if (!atomicReferenceFieldUpdater2.compareAndSet((Object)this, object, (Object)var4_12)) continue;
                        bl3 = true;
                        break block25;
                    } while (atomicReferenceFieldUpdater2.get((Object)this) == object);
                    bl3 = false;
                }
                if (!bl3) continue;
                return var4_12;
            }
            while (!(atomicReferenceFieldUpdater = q).compareAndSet((Object)this, (Object)g02, (Object)var16_21) && atomicReferenceFieldUpdater.get((Object)this) == g02) {
            }
        } while (true);
    }

    @Override
    public final f C(m9.g g2) {
        return b.g(this, g2);
    }

    public boolean D() {
        return this instanceof c;
    }

    public final Object E(d d3) {
        boolean bl;
        block4 : {
            Object object;
            do {
                if ((object = this.x()) instanceof p0) continue;
                bl = false;
                break block4;
            } while (this.M(object) < 0);
            bl = true;
        }
        j9.g g2 = j9.g.a;
        if (!bl) {
            y6.e.C(d3.getContext());
            return g2;
        }
        h h4 = new h(j.y(d3));
        h4.p();
        h4.r(new e(1, this.B(false, true, new s0(2, h4))));
        Object object = h4.o();
        a a4 = a.q;
        if (object != a4) {
            object = g2;
        }
        if (object == a4) {
            return object;
        }
        return g2;
    }

    public final Object F(Object object) {
        Object object2;
        do {
            if ((object2 = this.O(this.x(), object)) != g.c) continue;
            StringBuilder stringBuilder = new StringBuilder("Job ");
            stringBuilder.append((Object)this);
            stringBuilder.append(" is already complete or completing, but is being completed with ");
            stringBuilder.append(object);
            String string = stringBuilder.toString();
            q q3 = object instanceof q ? (q)object : null;
            Throwable throwable = null;
            if (q3 != null) {
                throwable = q3.a;
            }
            throw new IllegalStateException(string, throwable);
        } while (object2 == g.e);
        return object2;
    }

    public String G() {
        return this.getClass().getSimpleName();
    }

    public final void I(f1 f12, Throwable throwable) {
        Object object = f12.k();
        j.g(object, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
        i i4 = (i)object;
        androidx.fragment.app.x x2 = null;
        while (!j.b(i4, f12)) {
            if (i4 instanceof v0) {
                x0 x02 = (x0)i4;
                try {
                    x02.p(throwable);
                }
                catch (Throwable throwable2) {
                    if (x2 != null) {
                        j.a(x2, throwable2);
                    }
                    StringBuilder stringBuilder = new StringBuilder("Exception in completion handler ");
                    stringBuilder.append((Object)x02);
                    stringBuilder.append(" for ");
                    stringBuilder.append((Object)this);
                    x2 = new androidx.fragment.app.x(stringBuilder.toString(), throwable2);
                }
            }
            i4 = i4.l();
        }
        if (x2 != null) {
            this.z(x2);
        }
        this.k(throwable);
    }

    public void J(Object object) {
    }

    public void K() {
    }

    public final void L(x0 x02) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        f1 f12 = new f1();
        x02.getClass();
        i.r.lazySet((Object)f12, (Object)x02);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = i.q;
        atomicReferenceFieldUpdater2.lazySet((Object)f12, (Object)x02);
        while (x02.k() == x02) {
            boolean bl;
            block3 : {
                do {
                    if (!atomicReferenceFieldUpdater2.compareAndSet((Object)x02, (Object)x02, (Object)f12)) continue;
                    bl = true;
                    break block3;
                } while (atomicReferenceFieldUpdater2.get((Object)x02) == x02);
                bl = false;
            }
            if (!bl) continue;
            f12.j(x02);
            break;
        }
        i i4 = x02.l();
        do {
            if (!(atomicReferenceFieldUpdater = q).compareAndSet((Object)this, (Object)x02, (Object)i4)) continue;
            return;
        } while (atomicReferenceFieldUpdater.get((Object)this) == x02);
    }

    public final int M(Object object) {
        boolean bl = object instanceof g0;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = q;
        if (bl) {
            Object object2;
            boolean bl2;
            if (((g0)object).q) {
                return 0;
            }
            g0 g02 = g.i;
            do {
                if (atomicReferenceFieldUpdater.compareAndSet((Object)this, object, (Object)g02)) {
                    bl2 = true;
                    break;
                }
                object2 = atomicReferenceFieldUpdater.get((Object)this);
                bl2 = false;
            } while (object2 == object);
            if (!bl2) {
                return -1;
            }
            this.K();
            return 1;
        }
        if (object instanceof o0) {
            Object object3;
            boolean bl3;
            f1 f12 = ((o0)object).q;
            do {
                if (atomicReferenceFieldUpdater.compareAndSet((Object)this, object, (Object)f12)) {
                    bl3 = true;
                    break;
                }
                object3 = atomicReferenceFieldUpdater.get((Object)this);
                bl3 = false;
            } while (object3 == object);
            if (!bl3) {
                return -1;
            }
            this.K();
            return 1;
        }
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object O(Object object, Object object2) {
        p0 p02;
        l l2;
        f1 f12;
        l l5;
        int n3;
        a1 a12;
        block23 : {
            int n5;
            Object object3;
            block24 : {
                p0 p03;
                int n6;
                block20 : {
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
                    Object object4;
                    block22 : {
                        block21 : {
                            if (!(object instanceof p0)) {
                                return g.c;
                            }
                            boolean bl = object instanceof g0;
                            n3 = 1;
                            if (!bl && !(object instanceof x0) || object instanceof l || object2 instanceof q) break block21;
                            p03 = (p0)object;
                            object4 = object2 instanceof p0 ? new q0((p0)object2) : object2;
                            break block22;
                        }
                        p02 = (p0)object;
                        f12 = this.w(p02);
                        if (f12 == null) {
                            return g.e;
                        }
                        a12 = p02 instanceof a1 ? (a1)p02 : null;
                        if (a12 == null) {
                            a12 = new a1(f12, null);
                        }
                        a1 a13 = a12;
                        // MONITORENTER : a13
                        if (a12.e()) {
                            o2.p p5 = g.c;
                            // MONITOREXIT : a13
                            return p5;
                        }
                        a1.r.set((Object)a12, n3);
                        if (a12 == p02) break block23;
                        break block24;
                    }
                    do {
                        if (!(atomicReferenceFieldUpdater = q).compareAndSet((Object)this, (Object)p03, object4)) continue;
                        n6 = n3;
                        break block20;
                    } while (atomicReferenceFieldUpdater.get((Object)this) == p03);
                    n6 = 0;
                }
                if (n6 == 0) {
                    n3 = 0;
                } else {
                    this.J(object2);
                    this.o(p03, object2);
                }
                if (n3 == 0) return g.e;
                return object2;
            }
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = q;
            do {
                if (atomicReferenceFieldUpdater.compareAndSet((Object)this, (Object)p02, (Object)a12)) {
                    n5 = n3;
                    break;
                }
                object3 = atomicReferenceFieldUpdater.get((Object)this);
                n5 = 0;
            } while (object3 == p02);
            if (n5 == 0) {
                o2.p p6 = g.e;
                // MONITOREXIT : a13
                return p6;
            }
        }
        int n7 = a12.d();
        q q3 = object2 instanceof q ? (q)object2 : null;
        if (q3 != null) {
            a12.b(q3.a);
        }
        Throwable throwable = a12.c();
        boolean bl = (boolean)(n3 ^ n7);
        if (!bl) {
            throwable = null;
        }
        // MONITOREXIT : a13
        if (throwable != null) {
            this.I(f12, throwable);
        }
        if ((l5 = p02 instanceof l ? (l)p02 : null) == null) {
            f1 f13 = p02.h();
            l2 = null;
            if (f13 != null) {
                l2 = c1.H(f13);
            }
        } else {
            l2 = l5;
        }
        if (l2 == null) return this.q(a12, object2);
        if (!this.P(a12, l2, object2)) return this.q(a12, object2);
        return g.d;
    }

    public final boolean P(a1 a12, l l2, Object object) {
        do {
            z0 z02;
            if (x.k(l2.u, false, z02 = new z0(this, a12, l2, object), 1) == g1.q) continue;
            return true;
        } while ((l2 = c1.H(l2)) != null);
        return false;
    }

    @Override
    public boolean a() {
        Object object = this.x();
        return object instanceof p0 && ((p0)object).a();
    }

    @Override
    public final m9.h b(m9.g g2) {
        return b.k(this, g2);
    }

    public final boolean f(Object object, f1 f12, x0 x02) {
        boolean bl;
        block4 : {
            b1 b12 = new b1(x02, this, object);
            do {
                boolean bl2;
                i i4;
                block3 : {
                    i4 = f12.m();
                    i.r.lazySet((Object)x02, (Object)i4);
                    AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = i.q;
                    atomicReferenceFieldUpdater.lazySet((Object)x02, (Object)f12);
                    b12.c = f12;
                    do {
                        if (!atomicReferenceFieldUpdater.compareAndSet((Object)i4, (Object)f12, (Object)b12)) continue;
                        bl2 = true;
                        break block3;
                    } while (atomicReferenceFieldUpdater.get((Object)i4) == f12);
                    bl2 = false;
                }
                int n3 = !bl2 ? 0 : (b12.a(i4) == null ? 1 : 2);
                if (n3 == true) break;
                bl = false;
                if (n3 != 2) {
                    continue;
                }
                break block4;
                break;
            } while (true);
            bl = true;
        }
        return bl;
    }

    public void g(Object object) {
    }

    @Override
    public final m9.g getKey() {
        return b7.e.t;
    }

    public void h(Object object) {
        this.g(object);
    }

    public final Object i(d d3) {
        Object object;
        do {
            if ((object = this.x()) instanceof p0) continue;
            if (!(object instanceof q)) {
                return g.l(object);
            }
            throw ((q)object).a;
        } while (this.M(object) < 0);
        y0 y02 = new y0(j.y(d3), this);
        y02.p();
        y02.r(new e(1, this.B(false, true, new s0(1, y02))));
        return y02.o();
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final boolean j(Object var1_1) {
        block24 : {
            block23 : {
                var2_2 = g.c;
                if (this.u()) {
                    block22 : {
                        while (!(!((var22_3 = this.x()) instanceof p0) || var22_3 instanceof a1 && ((a1)var22_3).e())) {
                            var2_2 = this.O(var22_3, new q(this.p(var1_1), false));
                            if (var2_2 == g.e) continue;
                            break block22;
                        }
                        var2_2 = g.c;
                    }
                    if (var2_2 == g.d) {
                        return true;
                    }
                }
                if (var2_2 != g.c) break block24;
                var3_4 = null;
                do lbl-1000: // 3 sources:
                {
                    block30 : {
                        block28 : {
                            block25 : {
                                block29 : {
                                    block26 : {
                                        block27 : {
                                            if ((var4_5 = this.x()) instanceof a1) {
                                                var23_13 = var4_5;
                                                // MONITORENTER : var23_13
                                                var16_14 = (a1)var4_5;
                                                var17_15 = a1.t.get((Object)var16_14) == g.g;
                                                if (var17_15) {
                                                    var5_16 = g.f;
                                                    // MONITOREXIT : var23_13
                                                } else {
                                                    var18_17 = ((a1)var4_5).d();
                                                    if (var3_4 == null) {
                                                        var3_4 = this.p(var1_1);
                                                    }
                                                    ((a1)var4_5).b(var3_4);
                                                    var19_18 = ((a1)var4_5).c();
                                                    var20_19 = var18_17 ^ true;
                                                    var21_20 = null;
                                                    if (var20_19) {
                                                        var21_20 = var19_18;
                                                    }
                                                    // MONITOREXIT : var23_13
                                                    if (var21_20 != null) {
                                                        this.I(((a1)var4_5).q, var21_20);
                                                    }
                                                    var5_16 = g.c;
                                                }
                                                break block23;
                                            }
                                            if (!(var4_5 instanceof p0)) break block26;
                                            if (var3_4 == null) {
                                                var3_4 = this.p(var1_1);
                                            }
                                            if (!(var6_6 = (p0)var4_5).a()) break block27;
                                            var10_8 = this.w(var6_6);
                                            if (var10_8 == null) break block28;
                                            break block29;
                                        }
                                        var7_7 = this.O(var4_5, new q(var3_4, false));
                                        if (var7_7 == g.c) {
                                            var8_21 = new StringBuilder("Cannot happen in ");
                                            var8_21.append(var4_5);
                                            throw new IllegalStateException(var8_21.toString().toString());
                                        }
                                        if (var7_7 == g.e) ** GOTO lbl-1000
                                        var2_2 = var7_7;
                                        break block24;
                                    }
                                    var5_16 = g.f;
                                    break block23;
                                }
                                var11_9 = new a1(var10_8, var3_4);
                                do {
                                    if (!(var12_10 = c1.q).compareAndSet((Object)this, (Object)var6_6, (Object)var11_9)) continue;
                                    var13_11 = true;
                                    break block25;
                                } while (var12_10.get((Object)this) == var6_6);
                                var13_11 = false;
                            }
                            if (var13_11) break block30;
                        }
                        var14_12 = false;
                        continue;
                    }
                    this.I(var10_8, var3_4);
                    var14_12 = true;
                } while (!var14_12);
                var5_16 = g.c;
            }
            var2_2 = var5_16;
        }
        if (var2_2 == g.c) {
            return true;
        }
        if (var2_2 == g.d) {
            return true;
        }
        if (var2_2 == g.f) {
            return false;
        }
        this.g(var2_2);
        return true;
    }

    public final boolean k(Throwable throwable) {
        boolean bl = this.D();
        boolean bl2 = true;
        if (bl) {
            return bl2;
        }
        boolean bl3 = throwable instanceof CancellationException;
        k k4 = (k)r.get((Object)this);
        if (k4 != null) {
            if (k4 == g1.q) {
                return bl3;
            }
            if (!k4.e(throwable)) {
                if (bl3) {
                    return bl2;
                }
                bl2 = false;
            }
            return bl2;
        }
        return bl3;
    }

    public String l() {
        return "Job was cancelled";
    }

    @Override
    public final m9.h m(m9.h h4) {
        j.i(h4, "context");
        return y6.e.r0(this, h4);
    }

    public boolean n(Throwable throwable) {
        if (throwable instanceof CancellationException) {
            return true;
        }
        return this.j((Object)throwable) && this.t();
    }

    public final void o(p0 p02, Object object) {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = r;
        k k4 = (k)atomicReferenceFieldUpdater.get((Object)this);
        if (k4 != null) {
            k4.c();
            atomicReferenceFieldUpdater.set((Object)this, (Object)g1.q);
        }
        boolean bl = object instanceof q;
        androidx.fragment.app.x x2 = null;
        q q3 = bl ? (q)object : null;
        Throwable throwable = q3 != null ? q3.a : null;
        if (p02 instanceof x0) {
            try {
                ((x0)p02).p(throwable);
                return;
            }
            catch (Throwable throwable2) {
                StringBuilder stringBuilder = new StringBuilder("Exception in completion handler ");
                stringBuilder.append((Object)p02);
                stringBuilder.append(" for ");
                stringBuilder.append((Object)this);
                this.z(new androidx.fragment.app.x(stringBuilder.toString(), throwable2));
                return;
            }
        }
        f1 f12 = p02.h();
        if (f12 != null) {
            Object object2 = f12.k();
            j.g(object2, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
            i i4 = (i)object2;
            while (!j.b(i4, f12)) {
                if (i4 instanceof x0) {
                    x0 x02 = (x0)i4;
                    try {
                        x02.p(throwable);
                    }
                    catch (Throwable throwable3) {
                        if (x2 != null) {
                            j.a(x2, throwable3);
                        }
                        StringBuilder stringBuilder = new StringBuilder("Exception in completion handler ");
                        stringBuilder.append((Object)x02);
                        stringBuilder.append(" for ");
                        stringBuilder.append((Object)this);
                        x2 = new androidx.fragment.app.x(stringBuilder.toString(), throwable3);
                    }
                }
                i4 = i4.l();
            }
            if (x2 != null) {
                this.z(x2);
            }
        }
    }

    public final Throwable p(Object object) {
        Object object2;
        block9 : {
            c1 c12;
            Throwable throwable;
            block7 : {
                block8 : {
                    block6 : {
                        if (object instanceof Throwable) {
                            return (Throwable)object;
                        }
                        c12 = (c1)((i1)object);
                        object2 = c12.x();
                        if (!(object2 instanceof a1)) break block6;
                        throwable = ((a1)object2).c();
                        break block7;
                    }
                    if (!(object2 instanceof q)) break block8;
                    throwable = ((q)object2).a;
                    break block7;
                }
                if (object2 instanceof p0) break block9;
                throwable = null;
            }
            boolean bl = throwable instanceof CancellationException;
            CancellationException cancellationException = null;
            if (bl) {
                cancellationException = (CancellationException)throwable;
            }
            if (cancellationException == null) {
                cancellationException = new u0("Parent job is ".concat(c1.N(object2)), throwable, c12);
            }
            return cancellationException;
        }
        StringBuilder stringBuilder = new StringBuilder("Cannot be cancelling child in this state: ");
        stringBuilder.append(object2);
        throw new IllegalStateException(stringBuilder.toString().toString());
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final Object q(a1 a12, Object object) {
        Object object2;
        q q3 = object instanceof q ? (q)object : null;
        Throwable throwable = q3 != null ? q3.a : null;
        a1 a13 = a12;
        // MONITORENTER : a13
        a12.d();
        ArrayList arrayList = a12.f(throwable);
        if (arrayList.isEmpty()) {
            boolean bl = a12.d();
            object2 = null;
            if (bl) {
                object2 = new u0(this.l(), null, this);
            }
        } else {
            Object object3;
            block14 : {
                Object object4;
                Iterator iterator = arrayList.iterator();
                do {
                    boolean bl = iterator.hasNext();
                    object3 = null;
                    if (!bl) break block14;
                } while (!(true ^ (Throwable)(object4 = iterator.next()) instanceof CancellationException));
                object3 = object4;
            }
            if ((object2 = (Throwable)object3) == null) {
                object2 = (Throwable)arrayList.get(0);
            }
        }
        if (object2 != null && arrayList.size() > 1) {
            Set set = Collections.newSetFromMap((Map)new IdentityHashMap(arrayList.size()));
            for (Throwable throwable2 : arrayList) {
                if (throwable2 == object2 || throwable2 == object2 || throwable2 instanceof CancellationException || !set.add((Object)throwable2)) continue;
                j.a(object2, throwable2);
            }
        }
        // MONITOREXIT : a13
        if (object2 != null && object2 != throwable) {
            object = new q((Throwable)object2, false);
        }
        if (object2 != null) {
            boolean bl = this.k((Throwable)object2) || this.y((Throwable)object2);
            if (bl) {
                j.g(object, "null cannot be cast to non-null type kotlinx.coroutines.CompletedExceptionally");
                q q4 = (q)object;
                q.b.compareAndSet((Object)q4, 0, 1);
            }
        }
        this.J(object);
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = q;
        Object object5 = object instanceof p0 ? new q0((p0)object) : object;
        while (!atomicReferenceFieldUpdater.compareAndSet((Object)this, (Object)a12, object5) && atomicReferenceFieldUpdater.get((Object)this) == a12) {
        }
        this.o(a12, object);
        return object;
    }

    public final CancellationException r() {
        block13 : {
            u0 u02;
            block12 : {
                Object object;
                block10 : {
                    block11 : {
                        object = this.x();
                        if (!(object instanceof a1)) break block10;
                        Throwable throwable = ((a1)object).c();
                        if (throwable == null) break block11;
                        String string = this.getClass().getSimpleName().concat(" is cancelling");
                        boolean bl = throwable instanceof CancellationException;
                        u02 = null;
                        if (bl) {
                            u02 = (CancellationException)throwable;
                        }
                        if (u02 == null) {
                            if (string == null) {
                                string = this.l();
                            }
                            return new u0(string, throwable, this);
                        }
                        break block12;
                    }
                    StringBuilder stringBuilder = new StringBuilder("Job is still new or active: ");
                    stringBuilder.append((Object)this);
                    throw new IllegalStateException(stringBuilder.toString().toString());
                }
                if (object instanceof p0) break block13;
                if (object instanceof q) {
                    Throwable throwable = ((q)object).a;
                    boolean bl = throwable instanceof CancellationException;
                    u02 = null;
                    if (bl) {
                        u02 = (CancellationException)throwable;
                    }
                    if (u02 == null) {
                        return new u0(this.l(), throwable, this);
                    }
                } else {
                    u02 = new u0(this.getClass().getSimpleName().concat(" has completed normally"), null, this);
                }
            }
            return u02;
        }
        StringBuilder stringBuilder = new StringBuilder("Job is still new or active: ");
        stringBuilder.append((Object)this);
        throw new IllegalStateException(stringBuilder.toString().toString());
    }

    public boolean t() {
        return true;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(this.G());
        stringBuilder2.append('{');
        stringBuilder2.append(c1.N(this.x()));
        stringBuilder2.append('}');
        stringBuilder.append(stringBuilder2.toString());
        stringBuilder.append('@');
        stringBuilder.append(x.i(this));
        return stringBuilder.toString();
    }

    public boolean u() {
        return this instanceof o;
    }

    @Override
    public final Object v(Object object, p p5) {
        return p5.f(object, this);
    }

    public final f1 w(p0 p02) {
        f1 f12 = p02.h();
        if (f12 == null) {
            if (p02 instanceof g0) {
                return new f1();
            }
            if (p02 instanceof x0) {
                this.L((x0)p02);
                return null;
            }
            StringBuilder stringBuilder = new StringBuilder("State should have list: ");
            stringBuilder.append((Object)p02);
            throw new IllegalStateException(stringBuilder.toString().toString());
        }
        return f12;
    }

    public final Object x() {
        Object object;
        while ((object = q.get((Object)this)) instanceof da.o) {
            ((da.o)object).a(this);
        }
        return object;
    }

    public boolean y(Throwable throwable) {
        return false;
    }

    public void z(androidx.fragment.app.x x2) {
        throw x2;
    }
}

