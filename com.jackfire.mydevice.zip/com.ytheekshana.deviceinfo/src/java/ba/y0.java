/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.CancellationException
 */
package ba;

import ba.a1;
import ba.c1;
import ba.h;
import ba.q;
import java.util.concurrent.CancellationException;
import m9.d;

public final class y0
extends h {
    public final c1 y;

    public y0(d d3, c1 c12) {
        super(d3);
        this.y = c12;
    }

    @Override
    public final Throwable n(c1 c12) {
        Throwable throwable;
        Object object = this.y.x();
        if (object instanceof a1 && (throwable = ((a1)object).c()) != null) {
            return throwable;
        }
        if (object instanceof q) {
            return ((q)object).a;
        }
        return c12.r();
    }

    @Override
    public final String u() {
        return "AwaitContinuation";
    }
}

