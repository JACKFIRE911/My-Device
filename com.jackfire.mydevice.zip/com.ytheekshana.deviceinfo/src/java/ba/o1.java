/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.ThreadLocal
 */
package ba;

import ba.p1;
import ba.u;
import da.r;
import j9.c;
import m9.d;
import m9.f;
import m9.g;
import m9.h;
import n7.b;
import o2.p;
import s7.j;
import y6.e;

public final class o1
extends r {
    private volatile boolean threadLocalIsSet;
    public final ThreadLocal u;

    public o1(d d2, h h2) {
        p1 p12 = p1.q;
        h h3 = h2.C(p12) == null ? h2.m(p12) : h2;
        super(d2, h3);
        this.u = new ThreadLocal();
        if (!(d2.getContext().C(b7.e.H) instanceof u)) {
            Object object = j.J(h2, null);
            j.C(h2, object);
            this.S(h2, object);
        }
    }

    public final boolean R() {
        boolean bl = this.threadLocalIsSet && this.u.get() == null;
        this.u.remove();
        return bl ^ true;
    }

    public final void S(h h2, Object object) {
        this.threadLocalIsSet = true;
        this.u.set((Object)new c(h2, object));
    }

    @Override
    public final void h(Object object) {
        if (this.threadLocalIsSet) {
            c c2 = (c)this.u.get();
            if (c2 != null) {
                j.C((h)c2.q, c2.r);
            }
            this.u.remove();
        }
        Object object2 = e.y0(object);
        d d2 = this.t;
        h h2 = d2.getContext();
        Object object3 = j.J(h2, null);
        p p2 = j.d;
        o1 o12 = null;
        if (object3 != p2) {
            o12 = b.t(d2, h2, object3);
        }
        try {
            this.t.e(object2);
            return;
        }
        finally {
            if (o12 == null || o12.R()) {
                j.C(h2, object3);
            }
        }
    }
}

