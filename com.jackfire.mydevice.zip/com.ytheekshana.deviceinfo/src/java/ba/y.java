/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.ThreadLocal
 *  java.lang.Throwable
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 *  java.util.concurrent.locks.LockSupport
 */
package ba;

import ba.i0;
import ba.k0;
import ba.m1;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;

public final class y
extends k0
implements Runnable {
    public static final long A;
    private static volatile Thread _thread;
    private static volatile int debugStatus;
    public static final y z;

    /*
     * Exception decompiling
     */
    public static {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl20 : ALOAD_1 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final Thread I() {
        Thread thread = _thread;
        if (thread != null) {
            return thread;
        }
        y y2 = this;
        synchronized (y2) {
            Thread thread2 = _thread;
            if (thread2 == null) {
                _thread = thread2 = new Thread((Runnable)this, "kotlinx.coroutines.DefaultExecutor");
                thread2.setDaemon(true);
                thread2.start();
            }
            return thread2;
        }
    }

    @Override
    public final void N(long l3, i0 i02) {
        throw new RejectedExecutionException("DefaultExecutor was shut down. This error indicates that Dispatchers.shutdown() was invoked prior to completion of exiting coroutines, leaving coroutines in incomplete state. Please refer to Dispatchers.shutdown documentation for more details");
    }

    @Override
    public final void P(Runnable runnable) {
        boolean bl = debugStatus == 4;
        if (!bl) {
            super.P(runnable);
            return;
        }
        throw new RejectedExecutionException("DefaultExecutor was shut down. This error indicates that Dispatchers.shutdown() was invoked prior to completion of exiting coroutines, leaving coroutines in incomplete state. Please refer to Dispatchers.shutdown documentation for more details");
    }

    public final void T() {
        y y2 = this;
        synchronized (y2) {
            block4 : {
                int n2 = debugStatus;
                boolean bl = n2 == 2 || n2 == 3;
                if (bl) break block4;
                return;
            }
            debugStatus = 3;
            k0.w.set((Object)this, null);
            k0.x.set((Object)this, null);
            this.notifyAll();
            return;
        }
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final void run() {
        long l3;
        Throwable throwable2;
        long l5;
        long l6;
        boolean bl;
        block13 : {
            block12 : {
                m1.a.set((Object)this);
                try {
                    y y2 = this;
                    // MONITORENTER : y2
                    int n2 = debugStatus;
                    boolean bl2 = n2 == 2 || n2 == 3;
                    if (!bl2) break block12;
                    // MONITOREXIT : y2
                    bl = false;
                    break block13;
                }
                catch (Throwable throwable2) {}
            }
            debugStatus = 1;
            this.notifyAll();
            // MONITOREXIT : y2
            bl = true;
        }
        if (!bl) {
            _thread = null;
            this.T();
            if (this.R()) return;
            this.I();
            return;
        }
        long l7 = Long.MAX_VALUE;
        do {
            Thread.interrupted();
            l3 = this.L();
            if (l3 != Long.MAX_VALUE) break block14;
            l5 = System.nanoTime();
            if (l7 != Long.MAX_VALUE) break block15;
            l6 = A;
            break;
        } while (true);
        {
            block16 : {
                block17 : {
                    block14 : {
                        long l8;
                        block15 : {
                            l7 = l6 + l5;
                        }
                        if ((l8 = l7 - l5) <= 0L) {
                            _thread = null;
                            this.T();
                            if (this.R()) return;
                            this.I();
                            return;
                        }
                        if (l3 > l8) {
                            l3 = l8;
                        }
                        break block17;
                    }
                    l7 = Long.MAX_VALUE;
                }
                if (l3 <= 0L) continue;
                int n4 = debugStatus;
                boolean bl3 = n4 == 2 || n4 == 3;
                if (!bl3) break block16;
                _thread = null;
                this.T();
                if (this.R()) return;
                this.I();
                return;
            }
            LockSupport.parkNanos((Object)this, (long)l3);
            continue;
        }
        _thread = null;
        this.T();
        if (this.R()) throw throwable2;
        this.I();
        throw throwable2;
    }

    @Override
    public final void shutdown() {
        debugStatus = 4;
        super.shutdown();
    }
}

