/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 */
package ba;

import ba.v0;
import j9.g;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import t9.l;

public final class r0
extends v0 {
    public static final AtomicIntegerFieldUpdater v = AtomicIntegerFieldUpdater.newUpdater(r0.class, (String)"_invoked");
    private volatile int _invoked;
    public final l u;

    public r0(l l2) {
        this.u = l2;
    }

    @Override
    public final void p(Throwable throwable) {
        if (v.compareAndSet((Object)this, 0, 1)) {
            this.u.g((Object)throwable);
        }
    }
}

