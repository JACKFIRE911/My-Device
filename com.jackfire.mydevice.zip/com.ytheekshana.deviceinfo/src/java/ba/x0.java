/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 */
package ba;

import ba.c1;
import ba.f0;
import ba.f1;
import ba.g0;
import ba.p0;
import ba.x;
import da.i;
import da.p;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import s5.g;
import s7.j;
import t9.l;

public abstract class x0
extends i
implements f0,
p0,
l {
    public c1 t;

    @Override
    public final boolean a() {
        return true;
    }

    @Override
    public final void c() {
        Object object;
        c1 c12 = this.o();
        while ((object = c12.x()) instanceof x0) {
            boolean bl;
            Object object2;
            if (object != this) {
                return;
            }
            g0 g02 = g.i;
            do {
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
                if ((atomicReferenceFieldUpdater = c1.q).compareAndSet((Object)c12, object, (Object)g02)) {
                    bl = true;
                    break;
                }
                object2 = atomicReferenceFieldUpdater.get((Object)c12);
                bl = false;
            } while (object2 == object);
            if (!bl) continue;
            return;
        }
        if (object instanceof p0 && ((p0)object).h() != null) {
            i i4;
            boolean bl;
            block2 : do {
                Object object3;
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
                if ((object3 = this.k()) instanceof p) {
                    return;
                }
                if (object3 == this) {
                    (i)object3;
                    return;
                }
                j.g(object3, "null cannot be cast to non-null type kotlinx.coroutines.internal.LockFreeLinkedListNode{ kotlinx.coroutines.internal.LockFreeLinkedListKt.Node }");
                i4 = (i)object3;
                AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2 = i.s;
                p p5 = (p)atomicReferenceFieldUpdater2.get((Object)i4);
                if (p5 == null) {
                    p5 = new p(i4);
                    atomicReferenceFieldUpdater2.lazySet((Object)i4, (Object)p5);
                }
                do {
                    if (!(atomicReferenceFieldUpdater = i.q).compareAndSet((Object)this, object3, (Object)p5)) continue;
                    bl = true;
                    continue block2;
                } while (atomicReferenceFieldUpdater.get((Object)this) == object3);
                bl = false;
            } while (!bl);
            i4.i();
        }
    }

    @Override
    public final f1 h() {
        return null;
    }

    public final c1 o() {
        c1 c12 = this.t;
        if (c12 != null) {
            return c12;
        }
        j.I("job");
        throw null;
    }

    public abstract void p(Throwable var1);

    @Override
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getClass().getSimpleName());
        stringBuilder.append('@');
        stringBuilder.append(x.i(this));
        stringBuilder.append("[job@");
        stringBuilder.append(x.i(this.o()));
        stringBuilder.append(']');
        return stringBuilder.toString();
    }
}

