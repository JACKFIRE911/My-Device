/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.CancellationException
 *  s7.j
 *  t9.l
 */
package ba;

import ba.f;
import java.util.concurrent.CancellationException;
import s7.j;
import t9.l;

public final class p {
    public final Object a;
    public final f b;
    public final l c;
    public final Object d;
    public final Throwable e;

    public p(Object object, f f2, l l2, Object object2, Throwable throwable) {
        this.a = object;
        this.b = f2;
        this.c = l2;
        this.d = object2;
        this.e = throwable;
    }

    public /* synthetic */ p(Object object, f f2, l l2, CancellationException cancellationException, int n2) {
        f f4 = (n2 & 2) != 0 ? null : f2;
        l l3 = (n2 & 4) != 0 ? null : l2;
        CancellationException cancellationException2 = (n2 & 16) != 0 ? null : cancellationException;
        this(object, f4, l3, null, (Throwable)cancellationException2);
    }

    public static p a(p p2, f f2, CancellationException cancellationException, int n2) {
        Object object = (n2 & 1) != 0 ? p2.a : null;
        if ((n2 & 2) != 0) {
            f2 = p2.b;
        }
        f f4 = f2;
        l l2 = (n2 & 4) != 0 ? p2.c : null;
        int n5 = n2 & 8;
        Object object2 = null;
        if (n5 != 0) {
            object2 = p2.d;
        }
        Object object3 = object2;
        if ((n2 & 16) != 0) {
            cancellationException = p2.e;
        }
        CancellationException cancellationException2 = cancellationException;
        p2.getClass();
        p p3 = new p(object, f4, l2, object3, (Throwable)cancellationException2);
        return p3;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof p)) {
            return false;
        }
        p p2 = (p)object;
        Object object2 = p2.a;
        if (!j.b((Object)this.a, (Object)object2)) {
            return false;
        }
        if (!j.b((Object)this.b, (Object)p2.b)) {
            return false;
        }
        if (!j.b((Object)this.c, (Object)p2.c)) {
            return false;
        }
        if (!j.b((Object)this.d, (Object)p2.d)) {
            return false;
        }
        return j.b((Object)this.e, (Object)p2.e);
    }

    public final int hashCode() {
        Object object = this.a;
        int n2 = object == null ? 0 : object.hashCode();
        int n5 = n2 * 31;
        f f2 = this.b;
        int n6 = f2 == null ? 0 : f2.hashCode();
        int n7 = 31 * (n5 + n6);
        l l2 = this.c;
        int n8 = l2 == null ? 0 : l2.hashCode();
        int n9 = 31 * (n7 + n8);
        Object object2 = this.d;
        int n10 = object2 == null ? 0 : object2.hashCode();
        int n11 = 31 * (n9 + n10);
        Throwable throwable = this.e;
        int n12 = throwable == null ? 0 : throwable.hashCode();
        return n11 + n12;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CompletedContinuation(result=");
        stringBuilder.append(this.a);
        stringBuilder.append(", cancelHandler=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(", onCancellation=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append(", idempotentResume=");
        stringBuilder.append(this.d);
        stringBuilder.append(", cancelCause=");
        stringBuilder.append((Object)this.e);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

