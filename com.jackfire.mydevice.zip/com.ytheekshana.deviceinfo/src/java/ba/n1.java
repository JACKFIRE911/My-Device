/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 */
package ba;

import ba.q1;
import ba.u;
import m8.d;
import m9.f;
import m9.g;
import m9.h;

public final class n1
extends u {
    public static final /* synthetic */ int s;

    public static {
        new n1();
    }

    @Override
    public final void D(h h4, Runnable runnable) {
        q1 q12 = (q1)h4.C(q1.s);
        if (q12 != null) {
            q12.r = true;
            return;
        }
        throw new UnsupportedOperationException("Dispatchers.Unconfined.dispatch function can only be used by the yield function. If you wrap Unconfined dispatcher in your code, make sure you properly delegate isDispatchNeeded and dispatch calls.");
    }

    @Override
    public final String toString() {
        return "Dispatchers.Unconfined";
    }
}

