/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Throwable
 */
package ba;

import ba.a;
import m9.h;
import s7.j;

public class j1
extends a {
    public j1(h h2, boolean bl) {
        super(h2, bl);
    }

    @Override
    public final boolean y(Throwable throwable) {
        j.t(this.s, throwable);
        return true;
    }
}

