/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ba;

import m9.f;

public interface t0
extends f {
    public static final /* synthetic */ int a;

    public boolean a();
}

