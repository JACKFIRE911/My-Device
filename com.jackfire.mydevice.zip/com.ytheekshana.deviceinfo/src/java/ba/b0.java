/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.h
 *  java.lang.Object
 */
package ba;

import ba.h;

public interface b0 {
    public void e(long var1, h var3);
}

