/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 */
package ba;

import ba.c1;
import ba.k;
import ba.m;
import ba.v0;
import j9.g;

public final class l
extends v0
implements k {
    public final m u;

    public l(c1 c12) {
        this.u = c12;
    }

    @Override
    public final boolean e(Throwable throwable) {
        return this.o().n(throwable);
    }

    @Override
    public final void p(Throwable throwable) {
        c1 c12 = this.o();
        ((c1)this.u).j(c12);
    }
}

