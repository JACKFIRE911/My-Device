/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package ba;

import ba.p0;
import da.i;

public final class f1
extends i
implements p0 {
    @Override
    public final boolean a() {
        return true;
    }

    @Override
    public final f1 h() {
        return this;
    }

    @Override
    public final String toString() {
        return super.toString();
    }
}

