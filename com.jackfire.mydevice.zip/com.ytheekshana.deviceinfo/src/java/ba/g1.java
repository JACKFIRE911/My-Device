/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package ba;

import ba.f0;
import ba.k;

public final class g1
implements f0,
k {
    public static final g1 q = new g1();

    @Override
    public final void c() {
    }

    @Override
    public final boolean e(Throwable throwable) {
        return false;
    }

    public final String toString() {
        return "NonDisposableHandle";
    }
}

