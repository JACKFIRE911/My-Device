/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ba;

import ba.t0;

public interface m
extends t0 {
}

