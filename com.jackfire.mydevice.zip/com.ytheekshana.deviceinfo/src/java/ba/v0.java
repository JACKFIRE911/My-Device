/*
 * Decompiled with CFR 0.0.
 */
package ba;

import ba.x0;

public abstract class v0
extends x0 {
}

