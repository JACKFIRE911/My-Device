/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 */
package ba;

import ba.c1;
import ba.h;
import ba.q;
import ba.x;
import ba.x0;
import j9.g;
import m9.d;
import t9.l;

public final class s0
extends x0 {
    public final /* synthetic */ int u;
    public final Object v;

    public /* synthetic */ s0(int n3, Object object) {
        this.u = n3;
        this.v = object;
    }

    @Override
    public final void p(Throwable throwable) {
        int n3 = this.u;
        Object object = this.v;
        switch (n3) {
            default: {
                break;
            }
            case 1: {
                Object object2 = this.o().x();
                if (object2 instanceof q) {
                    ((h)object).e(x.e(((q)object2).a));
                    return;
                }
                ((h)object).e(s5.g.l(object2));
                return;
            }
            case 0: {
                ((l)object).g((Object)throwable);
                return;
            }
        }
        ((d)object).e(g.a);
    }
}

