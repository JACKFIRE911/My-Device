/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.reflect.Method
 *  java.util.concurrent.CancellationException
 *  java.util.concurrent.Executor
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.RejectedExecutionException
 *  java.util.concurrent.ScheduledExecutorService
 *  java.util.concurrent.ScheduledFuture
 *  java.util.concurrent.ScheduledThreadPoolExecutor
 *  java.util.concurrent.TimeUnit
 */
package ba;

import ba.b0;
import ba.e;
import ba.e0;
import ba.h;
import ba.m0;
import ba.y;
import da.b;
import ea.c;
import java.lang.reflect.Method;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import t9.l;

public final class n0
extends m0
implements b0 {
    public final Executor s;

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    public n0(Executor executor) {
        Method method;
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
        block3 : {
            this.s = executor;
            try {
                if (!(executor instanceof ScheduledThreadPoolExecutor)) return;
                scheduledThreadPoolExecutor = (ScheduledThreadPoolExecutor)executor;
                if (scheduledThreadPoolExecutor == null) return;
                method = b.a;
                if (method != null) break block3;
                return;
            }
            catch (Throwable throwable) {}
        }
        Object[] arrobject = new Object[]{Boolean.TRUE};
        method.invoke((Object)scheduledThreadPoolExecutor, arrobject);
        return;
    }

    @Override
    public final void D(m9.h h2, Runnable runnable) {
        try {
            this.s.execute(runnable);
            return;
        }
        catch (RejectedExecutionException rejectedExecutionException) {
            CancellationException cancellationException = new CancellationException("The task was rejected");
            cancellationException.initCause((Throwable)rejectedExecutionException);
            y6.e.j(h2, cancellationException);
            e0.b.D(h2, runnable);
            return;
        }
    }

    public final void close() {
        Executor executor = this.s;
        ExecutorService executorService = executor instanceof ExecutorService ? (ExecutorService)executor : null;
        if (executorService != null) {
            executorService.shutdown();
        }
    }

    @Override
    public final void e(long l3, h h2) {
        Executor executor = this.s;
        ScheduledExecutorService scheduledExecutorService = executor instanceof ScheduledExecutorService ? (ScheduledExecutorService)executor : null;
        ScheduledFuture scheduledFuture = null;
        if (scheduledExecutorService != null) {
            u5.e e2 = new u5.e((Object)this, 20, h2);
            try {
                scheduledFuture = scheduledExecutorService.schedule((Runnable)e2, l3, TimeUnit.MILLISECONDS);
            }
            catch (RejectedExecutionException rejectedExecutionException) {
                CancellationException cancellationException = new CancellationException("The task was rejected");
                cancellationException.initCause((Throwable)rejectedExecutionException);
                y6.e.j(h2.u, cancellationException);
            }
        }
        if (scheduledFuture != null) {
            h2.r(new e(0, (Object)scheduledFuture));
            return;
        }
        y.z.e(l3, h2);
    }

    public final boolean equals(Object object) {
        return object instanceof n0 && ((n0)object).s == this.s;
    }

    public final int hashCode() {
        return System.identityHashCode((Object)this.s);
    }

    @Override
    public final String toString() {
        return this.s.toString();
    }
}

