/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.d
 *  ba.l0
 *  java.lang.Object
 *  java.lang.Thread
 *  java.lang.ThreadLocal
 */
package ba;

import ba.d;
import ba.l0;

public abstract class m1 {
    public static final ThreadLocal a = new ThreadLocal();

    public static l0 a() {
        ThreadLocal threadLocal = a;
        l0 l02 = (l0)threadLocal.get();
        if (l02 == null) {
            l02 = new d(Thread.currentThread());
            threadLocal.set((Object)l02);
        }
        return l02;
    }
}

