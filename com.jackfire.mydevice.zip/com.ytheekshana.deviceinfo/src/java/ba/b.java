/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package ba;

import ba.h1;

public final class b
implements h1 {
    public static final b q = new b();

    public final String toString() {
        return "Active";
    }
}

