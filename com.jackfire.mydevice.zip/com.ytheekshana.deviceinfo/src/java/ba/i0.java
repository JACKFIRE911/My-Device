/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.k0
 *  java.lang.Comparable
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package ba;

import ba.f0;
import ba.j0;
import ba.k0;
import da.t;
import o2.p;
import r.a;

public abstract class i0
implements Runnable,
Comparable,
f0 {
    private volatile Object _heap;
    public long q;
    public int r;

    public i0(long l3) {
        this.q = l3;
        this.r = -1;
    }

    public final t a() {
        Object object = this._heap;
        if (object instanceof t) {
            return (t)object;
        }
        return null;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public final int b(long var1_1, j0 var3_2, k0 var4_3) {
        block15 : {
            block14 : {
                var18_4 = this;
                // MONITORENTER : var18_4
                var6_5 = this._heap;
                var7_6 = a.a;
                if (var6_5 == var7_6) {
                    // MONITOREXIT : var18_4
                    return 2;
                }
                var19_7 = var3_2;
                // MONITORENTER : var19_7
                var9_8 = var3_2.a;
                var10_9 = var9_8 != null ? var9_8[0] : null;
                var11_10 = k0.O((k0)var4_3);
                if (!var11_10) break block14;
                // MONITOREXIT : var18_4
                return 1;
            }
            if (var10_9 != null) break block15;
            var3_2.c = var1_1;
            ** GOTO lbl32
        }
        var12_11 = var10_9.q;
        if (var12_11 - var1_1 < 0L) {
            var1_1 = var12_11;
        }
        if (var1_1 - var3_2.c > 0L) {
            var3_2.c = var1_1;
        }
lbl32: // 4 sources:
        var14_12 = this.q;
        var16_13 = var3_2.c;
        if (var14_12 - var16_13 >= 0L) ** GOTO lbl37
        this.q = var16_13;
lbl37: // 2 sources:
        var3_2.a(this);
        // MONITOREXIT : var19_7
        // MONITOREXIT : var18_4
        return 0;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void c() {
        i0 i02 = this;
        synchronized (i02) {
            Object object = this._heap;
            p p2 = a.a;
            if (object == p2) {
                return;
            }
            j0 j02 = object instanceof j0 ? (j0)object : null;
            if (j02 != null) {
                j02.d(this);
            }
            this._heap = p2;
            return;
        }
    }

    public final int compareTo(Object object) {
        i0 i02 = (i0)object;
        long l3 = this.q - i02.q LCMP 0L;
        if (l3 > 0) {
            return 1;
        }
        if (l3 < 0) {
            return -1;
        }
        return 0;
    }

    public final void d(j0 j02) {
        boolean bl = this._heap != a.a;
        if (bl) {
            this._heap = j02;
            return;
        }
        throw new IllegalArgumentException("Failed requirement.".toString());
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder("Delayed[nanos=");
        stringBuilder.append(this.q);
        stringBuilder.append(']');
        return stringBuilder.toString();
    }
}

