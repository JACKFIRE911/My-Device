/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Closeable
 */
package ba;

import ba.t;
import ba.u;
import java.io.Closeable;
import s7.j;

public abstract class m0
extends u
implements Closeable {
    static {
        j.i(u.r, "baseKey");
    }
}

