/*
 * Decompiled with CFR 0.0.
 */
package ba;

import m8.d;
import m9.a;
import m9.g;

public final class q1
extends a {
    public static final d s = new d();
    public boolean r;

    public q1() {
        super(s);
    }
}

