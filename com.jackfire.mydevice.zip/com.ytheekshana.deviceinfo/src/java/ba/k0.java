/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.System
 *  java.lang.Thread
 *  java.lang.ThreadLocal
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 *  java.util.concurrent.atomic.AtomicLongFieldUpdater
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 *  java.util.concurrent.locks.LockSupport
 */
package ba;

import ba.b0;
import ba.e;
import ba.h;
import ba.h0;
import ba.i0;
import ba.j0;
import ba.l0;
import ba.m1;
import ba.y;
import da.t;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicLongFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import k9.d;
import o2.p;
import r.a;
import s7.j;
import t9.l;

public abstract class k0
extends l0
implements b0 {
    public static final AtomicReferenceFieldUpdater w = AtomicReferenceFieldUpdater.newUpdater(k0.class, Object.class, (String)"_queue");
    public static final AtomicReferenceFieldUpdater x = AtomicReferenceFieldUpdater.newUpdater(k0.class, Object.class, (String)"_delayed");
    public static final AtomicIntegerFieldUpdater y = AtomicIntegerFieldUpdater.newUpdater(k0.class, (String)"_isCompleted");
    private volatile Object _delayed;
    private volatile int _isCompleted = 0;
    private volatile Object _queue;

    public static final boolean O(k0 k02) {
        k02.getClass();
        return y.get((Object)k02) != 0;
    }

    @Override
    public final void D(m9.h h2, Runnable runnable) {
        this.P(runnable);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public final long L() {
        block20 : {
            var1_1 = this.M();
            var2_2 = 0L;
            if (var1_1) {
                return var2_2;
            }
            var4_3 = (j0)k0.x.get((Object)this);
            var5_4 = true;
            if (var4_3 != null && !(var24_5 = var4_3.b() == 0 ? var5_4 : false)) {
                var25_6 = System.nanoTime();
                do {
                    var33_8 = var4_3;
                    // MONITORENTER : var33_8
                    var28_9 = var4_3.a;
                    var29_10 = var28_9 != null ? var28_9[0] : null;
                    if (var29_10 == null) {
                        // MONITOREXIT : var33_8
                        var32_7 = null;
                        continue;
                    }
                    var30_11 = var25_6 - var29_10.q >= var2_2 ? var5_4 : false;
                    var31_12 = var30_11 != false ? this.Q(var29_10) : false;
                    var32_7 = var31_12 != false ? var4_3.e(0) : null;
                    // MONITOREXIT : var33_8
                } while (var32_7 != null);
            }
            do {
                block21 : {
                    block24 : {
                        block23 : {
                            block22 : {
                                if ((var7_14 = (var6_13 = k0.w).get((Object)this)) == null) {
                                    var8_19 = null;
                                    break block20;
                                }
                                if (!(var7_14 instanceof da.l)) break block22;
                                var21_16 = (da.l)var7_14;
                                var22_17 = var21_16.d();
                                if (var22_17 != da.l.g) {
                                    var8_19 = (Runnable)var22_17;
                                    break block20;
                                }
                                var23_18 = var21_16.c();
                                break block23;
                            }
                            if (var7_14 == a.b) {
                                var8_19 = null;
                                break block20;
                            }
                            break block24;
                        }
                        while (!var6_13.compareAndSet((Object)this, var7_14, (Object)var23_18) && var6_13.get((Object)this) == var7_14) {
                        }
                        continue;
                    }
                    do {
                        if (!var6_13.compareAndSet((Object)this, var7_14, null)) continue;
                        var20_15 = var5_4;
                        break block21;
                    } while (var6_13.get((Object)this) == var7_14);
                    var20_15 = false;
                }
                if (var20_15) break;
            } while (true);
            var8_19 = (Runnable)var7_14;
        }
        if (var8_19 != null) {
            var8_19.run();
            return var2_2;
        }
        var9_20 = this.u;
        var10_21 = var9_20 == null || var9_20.isEmpty() != false ? Long.MAX_VALUE : var2_2;
        if (var10_21 == var2_2) {
            return var2_2;
        }
        var12_22 = k0.w.get((Object)this);
        if (var12_22 != null) {
            if (var12_22 instanceof da.l) {
                var17_23 = (da.l)var12_22;
                var18_24 = da.l.f.get((Object)var17_23);
                if ((int)((0x3FFFFFFFL & var18_24) >> 0) != (int)((var18_24 & 1152921503533105152L) >> 30)) {
                    var5_4 = false;
                }
                if (!var5_4) {
                    return var2_2;
                } else {
                    ** GOTO lbl-1000
                }
            }
        } else lbl-1000: // 3 sources:
        {
            if ((var13_25 = (j0)k0.x.get((Object)this)) == null) return Long.MAX_VALUE;
            var14_26 = var13_25.c();
            if (var14_26 == null) return Long.MAX_VALUE;
            var15_27 = var14_26.q - System.nanoTime();
            if (var15_27 >= var2_2) return var15_27;
            return var2_2;
        }
        if (var12_22 != a.b) return var2_2;
        return Long.MAX_VALUE;
    }

    public void P(Runnable runnable) {
        if (this.Q(runnable)) {
            Thread thread = this.I();
            if (Thread.currentThread() != thread) {
                LockSupport.unpark((Thread)thread);
                return;
            }
        } else {
            y.z.P(runnable);
        }
    }

    public final boolean Q(Runnable runnable) {
        do {
            Object object;
            boolean bl;
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = w;
            Object object2 = atomicReferenceFieldUpdater.get((Object)this);
            boolean bl2 = y.get((Object)this) != 0;
            if (bl2) {
                return false;
            }
            if (object2 == null) {
                boolean bl3;
                Object object3;
                do {
                    if (atomicReferenceFieldUpdater.compareAndSet((Object)this, null, (Object)runnable)) {
                        bl3 = true;
                        break;
                    }
                    object3 = atomicReferenceFieldUpdater.get((Object)this);
                    bl3 = false;
                } while (object3 == null);
                if (!bl3) continue;
                return true;
            }
            if (object2 instanceof da.l) {
                da.l l3 = (da.l)object2;
                int n2 = l3.a((Object)runnable);
                if (n2 != 0) {
                    if (n2 != 1) {
                        if (n2 != 2) continue;
                        return false;
                    }
                    da.l l5 = l3.c();
                    while (!atomicReferenceFieldUpdater.compareAndSet((Object)this, object2, (Object)l5) && atomicReferenceFieldUpdater.get((Object)this) == object2) {
                    }
                    continue;
                }
                return true;
            }
            if (object2 == a.b) {
                return false;
            }
            da.l l6 = new da.l(8, true);
            l6.a((Object)((Runnable)object2));
            l6.a((Object)runnable);
            do {
                if (atomicReferenceFieldUpdater.compareAndSet((Object)this, object2, (Object)l6)) {
                    bl = true;
                    break;
                }
                object = atomicReferenceFieldUpdater.get((Object)this);
                bl = false;
            } while (object == object2);
            if (bl) break;
        } while (true);
        return true;
    }

    public final boolean R() {
        da.l l3;
        long l5;
        boolean bl;
        d d2 = this.u;
        boolean bl2 = d2 != null ? d2.isEmpty() : true;
        if (!bl2) {
            return false;
        }
        j0 j02 = (j0)x.get((Object)this);
        if (j02 != null && !(bl = j02.b() == 0)) {
            return false;
        }
        Object object = w.get((Object)this);
        if (object == null) {
            return true;
        }
        return object instanceof da.l ? (int)((0x3FFFFFFFL & (l5 = da.l.f.get((Object)(l3 = (da.l)object)))) >> 0) == (int)((l5 & 1152921503533105152L) >> 30) : object == a.b;
    }

    public final void S(long l3, i0 i02) {
        int n2;
        int n3 = y.get((Object)this);
        int n4 = 1;
        int n5 = n3 != 0 ? n4 : 0;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = x;
        if (n5 != 0) {
            n2 = n4;
        } else {
            j0 j02 = (j0)atomicReferenceFieldUpdater.get((Object)this);
            if (j02 == null) {
                j0 j03 = new j0(l3);
                while (!atomicReferenceFieldUpdater.compareAndSet((Object)this, null, (Object)j03) && atomicReferenceFieldUpdater.get((Object)this) == null) {
                }
                Object object = atomicReferenceFieldUpdater.get((Object)this);
                j.f(object);
                j02 = (j0)object;
            }
            n2 = i02.b(l3, j02, this);
        }
        if (n2 != 0) {
            if (n2 != n4) {
                if (n2 == 2) {
                    return;
                }
                throw new IllegalStateException("unexpected result".toString());
            }
            this.N(l3, i02);
            return;
        }
        j0 j04 = (j0)atomicReferenceFieldUpdater.get((Object)this);
        i0 i03 = null;
        if (j04 != null) {
            i03 = j04.c();
        }
        if (i03 != i02) {
            n4 = 0;
        }
        if (n4 != 0) {
            Thread thread = this.I();
            if (Thread.currentThread() != thread) {
                LockSupport.unpark((Thread)thread);
            }
        }
    }

    @Override
    public final void e(long l3, h h2) {
        long l5 = 0L;
        if (l3 > l5) {
            l5 = l3 >= 9223372036854L ? Long.MAX_VALUE : 1000000L * l3;
        }
        if (l5 < 0x3FFFFFFFFFFFFFFFL) {
            long l6 = System.nanoTime();
            h0 h02 = new h0(this, l5 + l6, h2);
            this.S(l6, h02);
            h2.r(new e(1, h02));
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    @Override
    public void shutdown() {
        m1.a.set(null);
        k0.y.set((Object)this, 1);
        block2 : do lbl-1000: // 3 sources:
        {
            block11 : {
                block9 : {
                    block10 : {
                        var2_1 = k0.w;
                        var3_2 = var2_1.get((Object)this);
                        var4_3 = a.b;
                        if (var3_2 == null) break block10;
                        if (var3_2 instanceof da.l) {
                            ((da.l)var3_2).b();
                            break;
                        }
                        if (var3_2 == var4_3) break;
                        break block11;
                    }
                    do {
                        if (!var2_1.compareAndSet((Object)this, null, (Object)var4_3)) continue;
                        var14_6 = true;
                        break block9;
                    } while (var2_1.get((Object)this) == null);
                    var14_6 = false;
                }
                if (!var14_6) ** GOTO lbl-1000
                break;
            }
            var5_4 = new da.l(8, true);
            var5_4.a((Object)((Runnable)var3_2));
            do {
                if (!var2_1.compareAndSet((Object)this, var3_2, (Object)var5_4)) continue;
                var7_5 = true;
                continue block2;
            } while (var2_1.get((Object)this) == var3_2);
            var7_5 = false;
        } while (!var7_5);
        while (this.L() <= 0L) {
        }
        var8_7 = System.nanoTime();
        while ((var10_8 = (j0)k0.x.get((Object)this)) != null) {
            var15_10 = var10_8;
            // MONITORENTER : var15_10
            var12_9 = var10_8.b() > 0 ? var10_8.e(0) : null;
            // MONITOREXIT : var15_10
            if (var12_9 == null) {
                return;
            }
            this.N(var8_7, var12_9);
        }
    }
}

