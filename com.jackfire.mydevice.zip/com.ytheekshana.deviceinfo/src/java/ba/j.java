/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 */
package ba;

import ba.c1;
import ba.h;
import ba.v0;
import da.f;
import j9.g;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import m9.d;
import o2.p;
import r.a;

public final class j
extends v0 {
    public final h u;

    public j(h h4) {
        this.u = h4;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void p(Throwable var1_1) {
        block6 : {
            block5 : {
                var2_2 = this.o();
                var3_3 = this.u;
                var4_4 = var3_3.n(var2_2);
                if (var3_3.s()) break block5;
                var5_5 = false;
                break block6;
            }
            var6_6 = var3_3.t;
            s7.j.g(var6_6, "null cannot be cast to non-null type kotlinx.coroutines.internal.DispatchedContinuation<*>");
            var7_7 = (f)var6_6;
            do lbl-1000: // 3 sources:
            {
                block8 : {
                    block9 : {
                        block4 : {
                            block7 : {
                                var8_8 = f.x;
                                var9_9 = var8_8.get((Object)var7_7);
                                var10_10 = a.i;
                                var11_11 = s7.j.b(var9_9, var10_10);
                                var12_12 = true;
                                if (var11_11) break block7;
                                if (!(var9_9 instanceof Throwable)) break block8;
                                break block9;
                            }
                            do {
                                if (!var8_8.compareAndSet((Object)var7_7, (Object)var10_10, (Object)var4_4)) continue;
                                var13_13 = var12_12;
                                break block4;
                            } while (var8_8.get((Object)var7_7) == var10_10);
                            var13_13 = false;
                        }
                        if (!var13_13) ** GOTO lbl-1000
                    }
                    var5_5 = var12_12;
                    break;
                }
                while (!var8_8.compareAndSet((Object)var7_7, var9_9, null)) {
                    if (var8_8.get((Object)var7_7) == var9_9) continue;
                    var12_12 = false;
                    break;
                }
                var5_5 = false;
            } while (!var12_12);
        }
        if (var5_5) {
            return;
        }
        var3_3.k(var4_4);
        if (var3_3.s() != false) return;
        var3_3.l();
    }
}

