/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.w
 *  androidx.fragment.app.x
 *  com.google.android.gms.internal.ads.jv0
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 */
package ba;

import ba.c1;
import ba.q;
import ba.t0;
import ba.w;
import ba.x;
import com.google.android.gms.internal.ads.jv0;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import m9.d;
import m9.f;
import m9.h;
import s5.g;
import s7.j;
import t9.p;
import y6.e;

public abstract class a
extends c1
implements d,
w {
    public final h s;

    public a(h h2, boolean bl) {
        super(bl);
        this.A((t0)h2.C(b7.e.t));
        this.s = h2.m(this);
    }

    @Override
    public final String G() {
        return super.G();
    }

    @Override
    public final void J(Object object) {
        if (object instanceof q) {
            q q2 = (q)object;
            q2.getClass();
            q.b.get((Object)q2);
        }
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void Q(int n2, a a2, p p2) {
        if (n2 == 0) throw null;
        int n3 = n2 - 1;
        j9.g g2 = j9.g.a;
        if (n3 != 0) {
            Throwable throwable2222;
            if (n3 == 1) return;
            if (n3 == 2) {
                j.i(p2, "<this>");
                j.y(j.l(a2, this, p2)).e(g2);
                return;
            }
            if (n3 != 3) throw new androidx.fragment.app.x(null);
            h h2 = this.s;
            Object object = j.J(h2, null);
            {
                catch (Throwable throwable2222) {}
            }
            e.f(p2);
            Object object2 = p2.f(a2, this);
            j.C(h2, object);
            if (object2 == n9.a.q) return;
            this.e(object2);
            return;
            catch (Throwable throwable3) {
                j.C(h2, object);
                throw throwable3;
            }
            this.e(x.e(throwable2222));
            return;
        }
        try {
            r.a.v(j.y(j.l(a2, this, p2)), g2, null);
            return;
        }
        catch (Throwable throwable) {
            this.e(x.e(throwable));
            throw throwable;
        }
    }

    @Override
    public final boolean a() {
        return super.a();
    }

    @Override
    public final h d() {
        return this.s;
    }

    @Override
    public final void e(Object object) {
        Throwable throwable = jv0.a((Object)object);
        if (throwable != null) {
            object = new q(throwable, false);
        }
        Object object2 = this.F(object);
        if (object2 == g.d) {
            return;
        }
        this.h(object2);
    }

    @Override
    public final h getContext() {
        return this.s;
    }

    @Override
    public final String l() {
        return this.getClass().getSimpleName().concat(" was cancelled");
    }

    @Override
    public final void z(androidx.fragment.app.x x2) {
        j.t(this.s, (Throwable)x2);
    }
}

