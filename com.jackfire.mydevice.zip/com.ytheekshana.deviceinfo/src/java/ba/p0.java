/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.f1
 *  java.lang.Object
 */
package ba;

import ba.f1;

public interface p0 {
    public boolean a();

    public f1 h();
}

