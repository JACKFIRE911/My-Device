/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 */
package ba;

import ba.j1;
import ba.x;
import j9.g;
import m9.d;
import m9.h;
import r.a;
import s7.j;
import t9.p;

public final class d1
extends j1 {
    public final d t;

    public d1(h h2, p p2) {
        super(h2, false);
        this.t = j.l(this, this, p2);
    }

    @Override
    public final void K() {
        d d2 = this.t;
        try {
            a.v(j.y(d2), g.a, null);
            return;
        }
        catch (Throwable throwable) {
            this.e(x.e(throwable));
            throw throwable;
        }
    }
}

