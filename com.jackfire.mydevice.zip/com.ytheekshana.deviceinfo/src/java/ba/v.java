/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 */
package ba;

import m9.f;
import m9.h;

public interface v
extends f {
    public void s(h var1, Throwable var2);
}

