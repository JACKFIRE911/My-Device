/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 */
package ba;

import da.r;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import m9.d;
import m9.h;
import r.a;
import s7.j;
import y6.e;

public final class c0
extends r {
    public static final AtomicIntegerFieldUpdater u = AtomicIntegerFieldUpdater.newUpdater(c0.class, (String)"_decision");
    private volatile int _decision;

    public c0(d d2, h h2) {
        super(d2, h2);
    }

    @Override
    public final void g(Object object) {
        this.h(object);
    }

    @Override
    public final void h(Object object) {
        boolean bl;
        block3 : {
            AtomicIntegerFieldUpdater atomicIntegerFieldUpdater;
            do {
                int n2;
                if ((n2 = (atomicIntegerFieldUpdater = u).get((Object)this)) == 0) continue;
                if (n2 == 1) {
                    bl = false;
                    break block3;
                }
                throw new IllegalStateException("Already resumed".toString());
            } while (!atomicIntegerFieldUpdater.compareAndSet((Object)this, 0, 2));
            bl = true;
        }
        if (bl) {
            return;
        }
        a.v(j.y(this.t), e.y0(object), null);
    }
}

