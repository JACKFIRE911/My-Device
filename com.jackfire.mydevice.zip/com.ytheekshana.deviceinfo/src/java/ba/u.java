/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package ba;

import b7.e;
import ba.n1;
import ba.t;
import ba.x;
import m9.a;
import m9.b;
import m9.f;
import m9.g;
import m9.h;
import m9.i;
import s7.j;
import t9.l;

public abstract class u
extends a
implements m9.e {
    public static final t r = new t(0);

    public u() {
        super(e.H);
    }

    @Override
    public final f C(g g2) {
        j.i(g2, "key");
        if (g2 instanceof b) {
            f f4;
            b b3 = (b)g2;
            g g4 = this.q;
            j.i(g4, "key");
            boolean bl = g4 == b3 || b3.r == g4;
            if (bl && (f4 = (f)b3.q.g(this)) instanceof f) {
                return f4;
            }
        } else if (e.H == g2) {
            return this;
        }
        return null;
    }

    public abstract void D(h var1, Runnable var2);

    public void E(h h4, Runnable runnable) {
        this.D(h4, runnable);
    }

    public boolean F() {
        return true ^ this instanceof n1;
    }

    @Override
    public final h b(g g2) {
        j.i(g2, "key");
        boolean bl = g2 instanceof b;
        i i4 = i.q;
        if (bl) {
            b b3 = (b)g2;
            g g4 = this.q;
            j.i(g4, "key");
            boolean bl2 = g4 == b3 || b3.r == g4;
            if (bl2 && (f)b3.q.g(this) != null) {
                return i4;
            }
        } else if (e.H == g2) {
            return i4;
        }
        return this;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.getClass().getSimpleName());
        stringBuilder.append('@');
        stringBuilder.append(x.i(this));
        return stringBuilder.toString();
    }
}

