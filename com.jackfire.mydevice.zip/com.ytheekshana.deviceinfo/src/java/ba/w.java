/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  m9.h
 */
package ba;

import m9.h;

public interface w {
    public h d();
}

