/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 */
package ba;

import ba.f1;
import ba.p0;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import o2.p;
import s5.g;
import s7.j;

public final class a1
implements p0 {
    public static final AtomicIntegerFieldUpdater r = AtomicIntegerFieldUpdater.newUpdater(a1.class, (String)"_isCompleting");
    public static final AtomicReferenceFieldUpdater s = AtomicReferenceFieldUpdater.newUpdater(a1.class, Object.class, (String)"_rootCause");
    public static final AtomicReferenceFieldUpdater t = AtomicReferenceFieldUpdater.newUpdater(a1.class, Object.class, (String)"_exceptionsHolder");
    private volatile Object _exceptionsHolder;
    private volatile int _isCompleting;
    private volatile Object _rootCause;
    public final f1 q;

    public a1(f1 f12, Throwable throwable) {
        this.q = f12;
        this._isCompleting = 0;
        this._rootCause = throwable;
    }

    @Override
    public final boolean a() {
        return this.c() == null;
    }

    public final void b(Throwable throwable) {
        Throwable throwable2 = this.c();
        if (throwable2 == null) {
            s.set((Object)this, (Object)throwable);
            return;
        }
        if (throwable == throwable2) {
            return;
        }
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = t;
        Object object = atomicReferenceFieldUpdater.get((Object)this);
        if (object == null) {
            atomicReferenceFieldUpdater.set((Object)this, (Object)throwable);
            return;
        }
        if (object instanceof Throwable) {
            if (throwable == object) {
                return;
            }
            ArrayList arrayList = new ArrayList(4);
            arrayList.add(object);
            arrayList.add((Object)throwable);
            atomicReferenceFieldUpdater.set((Object)this, (Object)arrayList);
            return;
        }
        if (object instanceof ArrayList) {
            ((ArrayList)object).add((Object)throwable);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder("State is ");
        stringBuilder.append(object);
        throw new IllegalStateException(stringBuilder.toString().toString());
    }

    public final Throwable c() {
        return (Throwable)s.get((Object)this);
    }

    public final boolean d() {
        return this.c() != null;
    }

    public final boolean e() {
        return r.get((Object)this) != 0;
    }

    public final ArrayList f(Throwable throwable) {
        Object object;
        block8 : {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
            ArrayList arrayList;
            block6 : {
                block7 : {
                    block5 : {
                        atomicReferenceFieldUpdater = t;
                        object = atomicReferenceFieldUpdater.get((Object)this);
                        if (object != null) break block5;
                        arrayList = new ArrayList(4);
                        break block6;
                    }
                    if (!(object instanceof Throwable)) break block7;
                    ArrayList arrayList2 = new ArrayList(4);
                    arrayList2.add(object);
                    arrayList = arrayList2;
                    break block6;
                }
                if (!(object instanceof ArrayList)) break block8;
                arrayList = (ArrayList)object;
            }
            Throwable throwable2 = this.c();
            if (throwable2 != null) {
                arrayList.add(0, (Object)throwable2);
            }
            if (throwable != null && !j.b((Object)throwable, (Object)throwable2)) {
                arrayList.add((Object)throwable);
            }
            atomicReferenceFieldUpdater.set((Object)this, (Object)g.g);
            return arrayList;
        }
        StringBuilder stringBuilder = new StringBuilder("State is ");
        stringBuilder.append(object);
        throw new IllegalStateException(stringBuilder.toString().toString());
    }

    @Override
    public final f1 h() {
        return this.q;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Finishing[cancelling=");
        stringBuilder.append(this.d());
        stringBuilder.append(", completing=");
        stringBuilder.append(this.e());
        stringBuilder.append(", rootCause=");
        stringBuilder.append((Object)this.c());
        stringBuilder.append(", exceptions=");
        stringBuilder.append(t.get((Object)this));
        stringBuilder.append(", list=");
        stringBuilder.append((Object)this.q);
        stringBuilder.append(']');
        return stringBuilder.toString();
    }
}

