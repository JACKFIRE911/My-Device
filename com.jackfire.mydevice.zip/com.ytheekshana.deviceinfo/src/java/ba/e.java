/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.Future
 */
package ba;

import ba.f;
import ba.f0;
import ba.x;
import j9.g;
import java.util.concurrent.Future;
import t9.l;

public final class e
extends f {
    public final /* synthetic */ int q;
    public final Object r;

    public /* synthetic */ e(int n3, Object object) {
        this.q = n3;
        this.r = object;
    }

    @Override
    public final void a(Throwable throwable) {
        int n3 = this.q;
        Object object = this.r;
        switch (n3) {
            default: {
                break;
            }
            case 1: {
                ((f0)object).c();
                return;
            }
            case 0: {
                if (throwable != null) {
                    ((Future)object).cancel(false);
                }
                return;
            }
        }
        ((l)object).g((Object)throwable);
    }

    public final String toString() {
        int n3 = this.q;
        Object object = this.r;
        switch (n3) {
            default: {
                break;
            }
            case 1: {
                StringBuilder stringBuilder = new StringBuilder("DisposeOnCancel[");
                stringBuilder.append((Object)((f0)object));
                stringBuilder.append(']');
                return stringBuilder.toString();
            }
            case 0: {
                StringBuilder stringBuilder = new StringBuilder("CancelFutureOnCancel[");
                stringBuilder.append((Object)((Future)object));
                stringBuilder.append(']');
                return stringBuilder.toString();
            }
        }
        StringBuilder stringBuilder = new StringBuilder("InvokeOnCancel[");
        stringBuilder.append(((l)object).getClass().getSimpleName());
        stringBuilder.append('@');
        stringBuilder.append(x.i(this));
        stringBuilder.append(']');
        return stringBuilder.toString();
    }
}

