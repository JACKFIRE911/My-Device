/*
 * Decompiled with CFR 0.0.
 */
package ba;

import ba.u;

public abstract class e1
extends u {
}

