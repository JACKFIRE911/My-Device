/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.c1
 *  ba.o1
 *  ba.t0
 *  com.google.android.gms.internal.ads.jv0
 *  com.google.android.gms.internal.ads.uz0
 *  da.f
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.CancellationException
 *  m9.f
 */
package ba;

import a3.d;
import b7.e;
import ba.c1;
import ba.o1;
import ba.q;
import ba.t0;
import ba.x;
import com.google.android.gms.internal.ads.jv0;
import com.google.android.gms.internal.ads.uz0;
import ea.h;
import j9.g;
import java.util.concurrent.CancellationException;
import m9.f;
import n7.b;
import o2.p;
import s7.j;

public abstract class d0
extends h {
    public int s;

    public d0(int n2) {
        super(0L, ea.j.g);
        this.s = n2;
    }

    public abstract void a(Object var1, CancellationException var2);

    public abstract m9.d b();

    public Throwable d(Object object) {
        q q4 = object instanceof q ? (q)object : null;
        Throwable throwable = null;
        if (q4 != null) {
            throwable = q4.a;
        }
        return throwable;
    }

    public Object f(Object object) {
        return object;
    }

    public final void g(Throwable throwable, Throwable throwable2) {
        if (throwable == null && throwable2 == null) {
            return;
        }
        if (throwable != null && throwable2 != null) {
            j.a(throwable, throwable2);
        }
        if (throwable == null) {
            throwable = throwable2;
        }
        StringBuilder stringBuilder = new StringBuilder("Fatal exception in coroutines machinery for ");
        stringBuilder.append((Object)this);
        stringBuilder.append(". Please read KDoc to 'handleFatalException' method and report this incident to maintainers");
        String string = stringBuilder.toString();
        j.f((Object)throwable);
        uz0 uz02 = new uz0(string, throwable);
        j.t(this.b().getContext(), (Throwable)uz02);
    }

    public abstract Object h();

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public final void run() {
        block17 : {
            var1_1 = g.a;
            var2_2 = this.r;
            try {
                var6_3 = this.b();
                j.g(var6_3, "null cannot be cast to non-null type kotlinx.coroutines.internal.DispatchedContinuation<T of kotlinx.coroutines.DispatchedTask>");
                var7_4 = (da.f)var6_3;
                var8_5 = var7_4.u;
                var9_6 = var7_4.w;
                var10_7 = var8_5.getContext();
                var11_8 = j.J(var10_7, var9_6);
                var12_9 = var11_8 != j.d ? b.t(var8_5, var10_7, var11_8) : null;
            }
            catch (Throwable var3_19) {
                try {
                    var2_2.getClass();
                }
                catch (Throwable var4_20) {
                    var1_1 = x.e(var4_20);
                }
                this.g(var3_19, jv0.a((Object)var1_1));
                return;
            }
            var14_10 = var8_5.getContext();
            var15_11 = this.h();
            var16_12 = this.d(var15_11);
            if (var16_12 != null) ** GOTO lbl-1000
            var17_13 = this.s;
            var18_14 = 1;
            if (var17_13 != var18_14 && var17_13 != 2) {
                var18_14 = 0;
            }
            if (var18_14 != 0) {
                var19_15 = (t0)var14_10.C(e.t);
            } else lbl-1000: // 2 sources:
            {
                var19_15 = null;
            }
            if (var19_15 != null && !var19_15.a()) {
                var22_16 = ((c1)var19_15).r();
                this.a(var15_11, var22_16);
                var8_5.e(x.e((Throwable)var22_16));
            } else if (var16_12 != null) {
                var8_5.e(x.e(var16_12));
            } else {
                var8_5.e(this.f(var15_11));
            }
            if (var12_9 == null) ** GOTO lbl45
            if (!var12_9.R()) break block17;
lbl45: // 2 sources:
            j.C(var10_7, var11_8);
        }
        try {
            var2_2.getClass();
        }
        catch (Throwable var20_17) {
            var1_1 = x.e(var20_17);
        }
        this.g(null, jv0.a((Object)var1_1));
        return;
        catch (Throwable var13_18) {}
        if (var12_9 == null) ** GOTO lbl58
        if (var12_9.R() == false) throw var13_18;
lbl58: // 2 sources:
        j.C(var10_7, var11_8);
        throw var13_18;
    }
}

