/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Throwable
 */
package ba;

import ba.h1;
import t9.l;

public abstract class f
implements h1,
l {
    public abstract void a(Throwable var1);
}

