/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a3.d
 *  android.animation.Animator
 *  android.animation.ObjectAnimator
 *  android.animation.StateListAnimator
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.content.res.Resources
 *  android.graphics.Color
 *  android.graphics.ColorFilter
 *  android.graphics.PorterDuff
 *  android.graphics.PorterDuff$Mode
 *  android.graphics.PorterDuffColorFilter
 *  android.graphics.drawable.Drawable
 *  android.graphics.drawable.GradientDrawable
 *  android.graphics.drawable.LayerDrawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.os.StrictMode
 *  android.os.StrictMode$ThreadPolicy
 *  android.os.StrictMode$ThreadPolicy$Builder
 *  android.text.TextUtils
 *  android.util.DisplayMetrics
 *  android.util.JsonReader
 *  android.util.JsonToken
 *  android.util.JsonWriter
 *  android.util.Log
 *  android.util.LongSparseArray
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.View$OnHoverListener
 *  android.view.View$OnLongClickListener
 *  android.widget.ImageView
 *  androidx.appcompat.widget.m4
 *  androidx.appcompat.widget.o4
 *  androidx.fragment.app.d0
 *  b7.e
 *  ba.c1
 *  ba.d0
 *  ba.h
 *  ba.l0
 *  ba.q1
 *  ba.t0
 *  ba.u
 *  ba.w0
 *  ba.x0
 *  com.google.android.gms.internal.ads.b1
 *  com.google.android.gms.internal.ads.b2
 *  com.google.android.gms.internal.ads.c31
 *  com.google.android.gms.internal.ads.cq
 *  com.google.android.gms.internal.ads.cq0
 *  com.google.android.gms.internal.ads.d
 *  com.google.android.gms.internal.ads.du0
 *  com.google.android.gms.internal.ads.dx0
 *  com.google.android.gms.internal.ads.f
 *  com.google.android.gms.internal.ads.f1
 *  com.google.android.gms.internal.ads.f31
 *  com.google.android.gms.internal.ads.fk0
 *  com.google.android.gms.internal.ads.jv0
 *  com.google.android.gms.internal.ads.kl0
 *  com.google.android.gms.internal.ads.kn
 *  com.google.android.gms.internal.ads.ko
 *  com.google.android.gms.internal.ads.l4
 *  com.google.android.gms.internal.ads.lv0
 *  com.google.android.gms.internal.ads.m91
 *  com.google.android.gms.internal.ads.ng0
 *  com.google.android.gms.internal.ads.ro0
 *  com.google.android.gms.internal.ads.s90
 *  com.google.android.gms.internal.ads.uo1
 *  com.google.android.gms.internal.ads.vx0
 *  com.google.android.gms.internal.ads.w71
 *  com.google.android.gms.internal.ads.y0
 *  com.google.android.gms.internal.ads.zo1
 *  da.f
 *  j2.p
 *  j2.q
 *  j7.b
 *  j9.d
 *  j9.g
 *  java.io.IOException
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalAccessException
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Math
 *  java.lang.NoSuchFieldException
 *  java.lang.NullPointerException
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.lang.Void
 *  java.lang.reflect.Field
 *  java.security.InvalidKeyException
 *  java.security.MessageDigest
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 *  java.util.Collections
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.concurrent.Callable
 *  k9.d
 *  m1.f
 *  m9.d
 *  m9.f
 *  m9.g
 *  m9.h
 *  n9.a
 *  o9.c
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 *  p2.a
 *  s5.m
 *  s7.a
 *  s7.c
 *  s7.f
 *  s7.j
 *  s7.m
 *  s7.v
 *  t8.a
 *  t8.d
 *  t9.l
 *  u7.c
 *  u9.b
 *  x4.b0
 *  y6.e
 *  y9.b
 *  z8.l
 */
package ba;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.os.StrictMode;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.JsonReader;
import android.util.JsonToken;
import android.util.JsonWriter;
import android.util.Log;
import android.util.LongSparseArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import androidx.appcompat.widget.m4;
import androidx.appcompat.widget.o4;
import ba.b0;
import ba.c1;
import ba.d0;
import ba.f0;
import ba.h;
import ba.l0;
import ba.m1;
import ba.q1;
import ba.t0;
import ba.u;
import ba.u0;
import ba.w0;
import ba.x0;
import ba.z;
import com.google.android.gms.internal.ads.b1;
import com.google.android.gms.internal.ads.b2;
import com.google.android.gms.internal.ads.c31;
import com.google.android.gms.internal.ads.cq;
import com.google.android.gms.internal.ads.cq0;
import com.google.android.gms.internal.ads.du0;
import com.google.android.gms.internal.ads.dx0;
import com.google.android.gms.internal.ads.f1;
import com.google.android.gms.internal.ads.f31;
import com.google.android.gms.internal.ads.fk0;
import com.google.android.gms.internal.ads.jv0;
import com.google.android.gms.internal.ads.kl0;
import com.google.android.gms.internal.ads.kn;
import com.google.android.gms.internal.ads.ko;
import com.google.android.gms.internal.ads.l4;
import com.google.android.gms.internal.ads.lv0;
import com.google.android.gms.internal.ads.m91;
import com.google.android.gms.internal.ads.ng0;
import com.google.android.gms.internal.ads.ro0;
import com.google.android.gms.internal.ads.s90;
import com.google.android.gms.internal.ads.uo1;
import com.google.android.gms.internal.ads.vx0;
import com.google.android.gms.internal.ads.w71;
import com.google.android.gms.internal.ads.y0;
import com.google.android.gms.internal.ads.zo1;
import d0.i;
import e.v0;
import j2.p;
import j2.q;
import j9.d;
import j9.g;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import s7.a;
import s7.c;
import s7.f;
import s7.j;
import s7.m;
import s7.v;
import t9.l;
import u9.b;
import y6.e;

public abstract class x {
    public static Field a;
    public static boolean b;
    public static Class c;
    public static boolean d;
    public static Field e;
    public static boolean f;
    public static Field g;
    public static boolean h;
    public static final String[] i;
    public static final cq0 j;
    public static final cq0 k;
    public static final s90 l;
    public static final s90 m;
    public static final int[] n;
    public static final int[] o;
    public static final int[] p;
    public static final int[] q;
    public static final int[] r;
    public static final int[] s;
    public static final int[] t;
    public static final q u;
    public static final String[] v;

    static /* synthetic */ {
        i = new String[]{"Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall", "Goa", "Drum & Bass", "Club-House", "Hardcore", "Terror", "Indie", "BritPop", "Afro-Punk", "Polsk Punk", "Beat", "Christian Gangsta Rap", "Heavy Metal", "Black Metal", "Crossover", "Contemporary Christian", "Christian Rock", "Merengue", "Salsa", "Thrash Metal", "Anime", "Jpop", "Synthpop", "Abstract", "Art Rock", "Baroque", "Bhangra", "Big beat", "Breakbeat", "Chillout", "Downtempo", "Dub", "EBM", "Eclectic", "Electro", "Electroclash", "Emo", "Experimental", "Garage", "Global", "IDM", "Illbient", "Industro-Goth", "Jam Band", "Krautrock", "Leftfield", "Lounge", "Math Rock", "New Romantic", "Nu-Breakz", "Post-Punk", "Post-Rock", "Psytrance", "Shoegaze", "Space Rock", "Trop Rock", "World Music", "Neoclassical", "Audiobook", "Audio theatre", "Neue Deutsche Welle", "Podcast", "Indie-Rock", "G-Funk", "Dubstep", "Garage Rock", "Psybient"};
        j = new cq0(5);
        k = new cq0(20);
        l = new s90(4);
        m = new s90(20);
        n = new int[]{1, 2, 3, 6};
        o = new int[]{48000, 44100, 32000};
        p = new int[]{24000, 22050, 16000};
        q = new int[]{2, 1, 2, 3, 3, 4, 4, 5};
        r = new int[]{32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 448, 512, 576, 640};
        s = new int[]{69, 87, 104, 121, 139, 174, 208, 243, 278, 348, 417, 487, 557, 696, 835, 975, 1114, 1253, 1393};
        t = new int[]{16843848};
        u = new q(21);
        v = new String[]{"standard", "accelerate", "decelerate", "linear"};
    }

    public static c31 A(w71 w712) {
        if (w712.z() == 3) {
            return new s5.m(16);
        }
        if (w712.z() == 4) {
            return new s5.m(32);
        }
        if (w712.z() == 5) {
            return new a3.d(14);
        }
        throw new IllegalArgumentException("Unrecognized HPKE AEAD identifier");
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static Object B(Context context, Callable callable) {
        StrictMode.ThreadPolicy threadPolicy;
        try {
            threadPolicy = StrictMode.getThreadPolicy();
        }
        catch (Throwable throwable) {
            x4.b0.h((String)"Unexpected exception.", (Throwable)throwable);
            kn.a((Context)context).j("StrictModeUtil.runWithLaxStrictMode", throwable);
            return null;
        }
        StrictMode.setThreadPolicy((StrictMode.ThreadPolicy)new StrictMode.ThreadPolicy.Builder(threadPolicy).permitDiskReads().permitDiskWrites().build());
        Object object = callable.call();
        {
            catch (Throwable throwable) {
                StrictMode.setThreadPolicy((StrictMode.ThreadPolicy)threadPolicy);
                throw throwable;
            }
        }
        StrictMode.setThreadPolicy((StrictMode.ThreadPolicy)threadPolicy);
        return object;
    }

    public static void C(String string, int n2) {
        if (n2 >= 0) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(" cannot be negative but was: ");
        stringBuilder.append(n2);
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    public static byte[] D(byte[] arrby, byte[] arrby2) {
        if (arrby.length == 32) {
            long[] arrl = new long[11];
            byte[] arrby3 = Arrays.copyOf((byte[])arrby, (int)32);
            int n2 = 0;
            arrby3[0] = (byte)(248 & arrby3[0]);
            int n5 = 127 & arrby3[31];
            arrby3[31] = (byte)n5;
            arrby3[31] = (byte)(n5 | 64);
            if (arrby2.length == 32) {
                int n6;
                byte[] arrby4 = Arrays.copyOf((byte[])arrby2, (int)32);
                arrby4[31] = (byte)(127 & arrby4[31]);
                for (int i2 = 0; i2 < 7; ++i2) {
                    byte[][] arrby5 = j7.b.i;
                    if (!MessageDigest.isEqual((byte[])arrby5[i2], (byte[])arrby4)) {
                        continue;
                    }
                    throw new InvalidKeyException("Banned public key: ".concat(a8.b1.P(arrby5[i2])));
                }
                int n7 = 10;
                long[] arrl2 = new long[n7];
                for (int i3 = 0; i3 < n7; ++i3) {
                    int n8 = p2.a.g[i3];
                    int n9 = 255 & arrby4[n8];
                    int n10 = 255 & arrby4[n8 + 1];
                    int n11 = 255 & arrby4[n8 + 2];
                    int n12 = 255 & arrby4[n8 + 3];
                    int n13 = p2.a.h[i3];
                    long l2 = n10;
                    long l3 = n9;
                    byte[] arrby6 = arrby4;
                    long l5 = n11;
                    long l6 = l3 | l2 << 8;
                    long l7 = n12;
                    long l8 = (l6 | l5 << 16 | l7 << 24) >> n13;
                    int n14 = i3 & 1;
                    arrl2[i3] = l8 & (long)p2.a.i[n14];
                    arrby4 = arrby6;
                    n7 = 10;
                }
                long[] arrl3 = new long[19];
                long[] arrl4 = new long[19];
                arrl4[0] = 1L;
                long[] arrl5 = new long[19];
                arrl5[0] = 1L;
                long[] arrl6 = new long[19];
                long[] arrl7 = new long[19];
                long[] arrl8 = new long[19];
                arrl8[0] = 1L;
                long[] arrl9 = new long[19];
                long[] arrl10 = new long[19];
                arrl10[0] = 1L;
                System.arraycopy((Object)arrl2, (int)0, (Object)arrl3, (int)0, (int)10);
                for (int i4 = 0; i4 < 32; ++i4) {
                    int n15 = 255 & arrby3[-1 + (32 - i4)];
                    int n16 = 8;
                    while (n2 < n16) {
                        int n17 = 1 & n15 >> 7 - n2;
                        j7.b.t((long[])arrl5, (long[])arrl3, (int)n17);
                        j7.b.t((long[])arrl6, (long[])arrl4, (int)n17);
                        byte[] arrby7 = arrby3;
                        long[] arrl11 = Arrays.copyOf((long[])arrl5, (int)10);
                        int n18 = n15;
                        long[] arrl12 = new long[19];
                        long[] arrl13 = arrl;
                        long[] arrl14 = new long[19];
                        int n19 = i4;
                        long[] arrl15 = new long[19];
                        int n20 = n2;
                        long[] arrl16 = new long[19];
                        long[] arrl17 = new long[19];
                        long[] arrl18 = arrl10;
                        long[] arrl19 = new long[19];
                        long[] arrl20 = new long[19];
                        p2.a.m((long[])arrl5, (long[])arrl5, (long[])arrl6);
                        p2.a.l((long[])arrl6, (long[])arrl11, (long[])arrl6);
                        int n21 = 10;
                        long[] arrl21 = Arrays.copyOf((long[])arrl3, (int)n21);
                        p2.a.m((long[])arrl3, (long[])arrl3, (long[])arrl4);
                        p2.a.l((long[])arrl4, (long[])arrl21, (long[])arrl4);
                        p2.a.h((long[])arrl16, (long[])arrl3, (long[])arrl6);
                        p2.a.h((long[])arrl17, (long[])arrl5, (long[])arrl4);
                        p2.a.j((long[])arrl16);
                        p2.a.i((long[])arrl16);
                        p2.a.j((long[])arrl17);
                        p2.a.i((long[])arrl17);
                        long[] arrl22 = arrl3;
                        System.arraycopy((Object)arrl16, (int)0, (Object)arrl21, (int)0, (int)n21);
                        p2.a.m((long[])arrl16, (long[])arrl16, (long[])arrl17);
                        p2.a.l((long[])arrl17, (long[])arrl21, (long[])arrl17);
                        p2.a.k((long[])arrl20, (long[])arrl16);
                        p2.a.k((long[])arrl19, (long[])arrl17);
                        p2.a.h((long[])arrl17, (long[])arrl19, (long[])arrl2);
                        p2.a.j((long[])arrl17);
                        p2.a.i((long[])arrl17);
                        System.arraycopy((Object)arrl20, (int)0, (Object)arrl7, (int)0, (int)n21);
                        System.arraycopy((Object)arrl17, (int)0, (Object)arrl8, (int)0, (int)n21);
                        p2.a.k((long[])arrl14, (long[])arrl5);
                        p2.a.k((long[])arrl15, (long[])arrl6);
                        p2.a.h((long[])arrl9, (long[])arrl14, (long[])arrl15);
                        p2.a.j((long[])arrl9);
                        p2.a.i((long[])arrl9);
                        p2.a.l((long[])arrl15, (long[])arrl14, (long[])arrl15);
                        Arrays.fill((long[])arrl12, (int)n21, (int)18, (long)0L);
                        for (int i6 = 0; i6 < n21; ++i6) {
                            arrl12[i6] = 121665L * arrl15[i6];
                            n21 = 10;
                        }
                        p2.a.i((long[])arrl12);
                        p2.a.m((long[])arrl12, (long[])arrl12, (long[])arrl14);
                        p2.a.h((long[])arrl18, (long[])arrl15, (long[])arrl12);
                        p2.a.j((long[])arrl18);
                        p2.a.i((long[])arrl18);
                        j7.b.t((long[])arrl9, (long[])arrl7, (int)n17);
                        j7.b.t((long[])arrl18, (long[])arrl8, (int)n17);
                        n2 = n20 + 1;
                        arrl3 = arrl7;
                        n15 = n18;
                        arrby3 = arrby7;
                        arrl = arrl13;
                        i4 = n19;
                        arrl7 = arrl22;
                        n16 = 8;
                        long[] arrl23 = arrl8;
                        arrl8 = arrl4;
                        arrl4 = arrl23;
                        long[] arrl24 = arrl9;
                        arrl9 = arrl5;
                        arrl5 = arrl24;
                        arrl10 = arrl6;
                        arrl6 = arrl18;
                    }
                    n2 = 0;
                }
                long[] arrl25 = arrl;
                long[] arrl26 = new long[10];
                long[] arrl27 = new long[10];
                long[] arrl28 = new long[10];
                long[] arrl29 = new long[10];
                long[] arrl30 = new long[10];
                long[] arrl31 = new long[10];
                long[] arrl32 = new long[10];
                long[] arrl33 = new long[10];
                long[] arrl34 = new long[10];
                long[] arrl35 = new long[10];
                long[] arrl36 = arrl3;
                long[] arrl37 = new long[10];
                p2.a.k((long[])arrl27, (long[])arrl6);
                p2.a.k((long[])arrl37, (long[])arrl27);
                p2.a.k((long[])arrl35, (long[])arrl37);
                p2.a.f((long[])arrl28, (long[])arrl35, (long[])arrl6);
                p2.a.f((long[])arrl29, (long[])arrl28, (long[])arrl27);
                p2.a.k((long[])arrl35, (long[])arrl29);
                p2.a.f((long[])arrl30, (long[])arrl35, (long[])arrl28);
                p2.a.k((long[])arrl35, (long[])arrl30);
                p2.a.k((long[])arrl37, (long[])arrl35);
                p2.a.k((long[])arrl35, (long[])arrl37);
                p2.a.k((long[])arrl37, (long[])arrl35);
                p2.a.k((long[])arrl35, (long[])arrl37);
                p2.a.f((long[])arrl31, (long[])arrl35, (long[])arrl30);
                p2.a.k((long[])arrl35, (long[])arrl31);
                p2.a.k((long[])arrl37, (long[])arrl35);
                for (int i7 = n6 = 2; i7 < 10; i7 += 2) {
                    p2.a.k((long[])arrl35, (long[])arrl37);
                    p2.a.k((long[])arrl37, (long[])arrl35);
                }
                p2.a.f((long[])arrl32, (long[])arrl37, (long[])arrl31);
                p2.a.k((long[])arrl35, (long[])arrl32);
                p2.a.k((long[])arrl37, (long[])arrl35);
                for (int i8 = n6; i8 < 20; i8 += 2) {
                    p2.a.k((long[])arrl35, (long[])arrl37);
                    p2.a.k((long[])arrl37, (long[])arrl35);
                }
                p2.a.f((long[])arrl35, (long[])arrl37, (long[])arrl32);
                p2.a.k((long[])arrl37, (long[])arrl35);
                p2.a.k((long[])arrl35, (long[])arrl37);
                for (int i9 = n6; i9 < 10; i9 += 2) {
                    p2.a.k((long[])arrl37, (long[])arrl35);
                    p2.a.k((long[])arrl35, (long[])arrl37);
                }
                p2.a.f((long[])arrl33, (long[])arrl35, (long[])arrl31);
                p2.a.k((long[])arrl35, (long[])arrl33);
                p2.a.k((long[])arrl37, (long[])arrl35);
                for (int i10 = n6; i10 < 50; i10 += 2) {
                    p2.a.k((long[])arrl35, (long[])arrl37);
                    p2.a.k((long[])arrl37, (long[])arrl35);
                }
                p2.a.f((long[])arrl34, (long[])arrl37, (long[])arrl33);
                p2.a.k((long[])arrl37, (long[])arrl34);
                p2.a.k((long[])arrl35, (long[])arrl37);
                for (int i11 = n6; i11 < 100; i11 += 2) {
                    p2.a.k((long[])arrl37, (long[])arrl35);
                    p2.a.k((long[])arrl35, (long[])arrl37);
                }
                p2.a.f((long[])arrl37, (long[])arrl35, (long[])arrl34);
                p2.a.k((long[])arrl35, (long[])arrl37);
                p2.a.k((long[])arrl37, (long[])arrl35);
                while (n6 < 50) {
                    p2.a.k((long[])arrl35, (long[])arrl37);
                    p2.a.k((long[])arrl37, (long[])arrl35);
                    n6 += 2;
                }
                p2.a.f((long[])arrl35, (long[])arrl37, (long[])arrl33);
                p2.a.k((long[])arrl37, (long[])arrl35);
                p2.a.k((long[])arrl35, (long[])arrl37);
                p2.a.k((long[])arrl37, (long[])arrl35);
                p2.a.k((long[])arrl35, (long[])arrl37);
                p2.a.k((long[])arrl37, (long[])arrl35);
                p2.a.f((long[])arrl26, (long[])arrl37, (long[])arrl29);
                p2.a.f((long[])arrl25, (long[])arrl5, (long[])arrl26);
                long[] arrl38 = new long[10];
                long[] arrl39 = new long[10];
                long[] arrl40 = new long[11];
                long[] arrl41 = new long[11];
                long[] arrl42 = new long[11];
                p2.a.f((long[])arrl38, (long[])arrl2, (long[])arrl25);
                p2.a.m((long[])arrl39, (long[])arrl2, (long[])arrl25);
                long[] arrl43 = new long[10];
                arrl43[0] = 486662L;
                p2.a.m((long[])arrl41, (long[])arrl39, (long[])arrl43);
                p2.a.f((long[])arrl41, (long[])arrl41, (long[])arrl4);
                p2.a.m((long[])arrl41, (long[])arrl41, (long[])arrl36);
                p2.a.f((long[])arrl41, (long[])arrl41, (long[])arrl38);
                p2.a.f((long[])arrl41, (long[])arrl41, (long[])arrl36);
                for (int i12 = 0; i12 < 10; ++i12) {
                    arrl40[i12] = 4L * arrl41[i12];
                }
                p2.a.i((long[])arrl40);
                p2.a.f((long[])arrl41, (long[])arrl38, (long[])arrl4);
                p2.a.l((long[])arrl41, (long[])arrl41, (long[])arrl4);
                p2.a.f((long[])arrl42, (long[])arrl39, (long[])arrl36);
                p2.a.m((long[])arrl41, (long[])arrl41, (long[])arrl42);
                p2.a.k((long[])arrl41, (long[])arrl41);
                if (MessageDigest.isEqual((byte[])p2.a.n((long[])arrl40), (byte[])p2.a.n((long[])arrl41))) {
                    return p2.a.n((long[])arrl25);
                }
                throw new IllegalStateException("Arithmetic error in curve multiplication with the public key: ".concat(a8.b1.P(arrby2)));
            }
            throw new InvalidKeyException("Public key length is not 32-byte");
        }
        throw new InvalidKeyException("Private key must have 32 bytes.");
    }

    public static int E(fk0 fk02) {
        fk02.f(4);
        if (fk02.h() == 1684108385) {
            fk02.f(8);
            return fk02.m();
        }
        ng0.d((String)"MetadataUtil", (String)"Failed to parse uint8 attribute value");
        return -1;
    }

    public static f31 F(w71 w712) {
        if (w712.B() == 3) {
            return new du0(2, (Object)new cq("HmacSha256"));
        }
        if (w712.B() == 4) {
            return kl0.s((int)1);
        }
        if (w712.B() == 5) {
            return kl0.s((int)2);
        }
        if (w712.B() == 6) {
            return kl0.s((int)3);
        }
        throw new IllegalArgumentException("Unrecognized HPKE KEM identifier");
    }

    public static void G(List list, lv0 lv02, int n2, int n5) {
        int n6 = list.size();
        while (--n6 > n5) {
            if (!lv02.g(list.get(n6))) continue;
            list.remove(n6);
        }
        while (--n5 >= n2) {
            list.remove(n5);
        }
    }

    public static byte[] H() {
        byte[] arrby = m91.a((int)32);
        arrby[0] = (byte)(7 | arrby[0]);
        int n2 = 63 & arrby[31];
        arrby[31] = (byte)n2;
        arrby[31] = (byte)(n2 | 128);
        return arrby;
    }

    public static b1 I(int n2, String string, fk0 fk02, boolean bl, boolean bl2) {
        int n5 = x.E(fk02);
        if (bl2) {
            n5 = Math.min((int)1, (int)n5);
        }
        if (n5 >= 0) {
            if (bl) {
                return new f1(string, null, dx0.r((Object)Integer.toString((int)n5)));
            }
            return new y0("und", string, Integer.toString((int)n5));
        }
        ng0.d((String)"MetadataUtil", (String)"Failed to parse uint8 attribute: ".concat(b2.b((int)n2)));
        return null;
    }

    public static cq J(w71 w712) {
        if (w712.A() == 3) {
            return new cq("HmacSha256");
        }
        if (w712.A() == 4) {
            return new cq("HmacSha384");
        }
        if (w712.A() == 5) {
            return new cq("HmacSha512");
        }
        throw new IllegalArgumentException("Unrecognized HPKE KDF identifier");
    }

    public static List K(JSONArray jSONArray, ArrayList arrayList) {
        if (arrayList == null) {
            arrayList = new ArrayList();
        }
        if (jSONArray != null) {
            for (int i2 = 0; i2 < jSONArray.length(); ++i2) {
                arrayList.add((Object)jSONArray.getString(i2));
            }
        }
        return arrayList;
    }

    /*
     * Exception decompiling
     */
    public static boolean L(fk0 var0, com.google.android.gms.internal.ads.f var1, int var2, com.google.android.gms.internal.ads.d var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl107 : ILOAD : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public static boolean M(zo1 zo12) {
        fk0 fk02 = new fk0(8);
        int n2 = l4.a((zo1)zo12, (fk0)fk02).a;
        if (n2 != 1380533830 && n2 != 1380333108) {
            return false;
        }
        byte[] arrby = fk02.a;
        ((uo1)zo12).q(arrby, 0, 4, false);
        fk02.e(0);
        int n5 = fk02.h();
        if (n5 != 1463899717) {
            StringBuilder stringBuilder = new StringBuilder("Unsupported form type: ");
            stringBuilder.append(n5);
            ng0.a((String)"WavHeaderReader", (String)stringBuilder.toString());
            return false;
        }
        return true;
    }

    public static byte[] N(byte[] arrby) {
        if (arrby.length == 32) {
            byte[] arrby2 = new byte[32];
            arrby2[0] = 9;
            return x.D(arrby, arrby2);
        }
        throw new InvalidKeyException("Private key must have 32 bytes.");
    }

    public static f1 O(int n2, String string, fk0 fk02) {
        int n5 = fk02.h();
        if (fk02.h() == 1684108385 && n5 >= 22) {
            fk02.f(10);
            int n6 = fk02.p();
            if (n6 > 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(n6);
                String string2 = stringBuilder.toString();
                int n7 = fk02.p();
                if (n7 > 0) {
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append(string2);
                    stringBuilder2.append("/");
                    stringBuilder2.append(n7);
                    string2 = stringBuilder2.toString();
                }
                return new f1(string, null, dx0.r((Object)string2));
            }
        }
        ng0.d((String)"MetadataUtil", (String)"Failed to parse index/count attribute: ".concat(b2.b((int)n2)));
        return null;
    }

    public static l4 P(int n2, zo1 zo12, fk0 fk02) {
        int n5;
        l4 l42 = l4.a((zo1)zo12, (fk0)fk02);
        while ((n5 = l42.a) != n2) {
            u7.c.e((String)"Ignoring unknown WAV chunk: ", (int)n5, (String)"WavHeaderReader");
            long l2 = 8L + l42.b;
            if (l2 <= Integer.MAX_VALUE) {
                int n6 = (int)l2;
                ((uo1)zo12).h(n6);
                l42 = l4.a((zo1)zo12, (fk0)fk02);
                continue;
            }
            StringBuilder stringBuilder = new StringBuilder("Chunk is too large (~2GB+) to skip; id: ");
            stringBuilder.append(l42.a);
            throw ko.b((String)stringBuilder.toString());
        }
        return l42;
    }

    public static ArrayList Q(JsonReader jsonReader) {
        ArrayList arrayList = new ArrayList();
        jsonReader.beginArray();
        while (jsonReader.hasNext()) {
            arrayList.add((Object)jsonReader.nextString());
        }
        jsonReader.endArray();
        return arrayList;
    }

    public static f1 R(int n2, String string, fk0 fk02) {
        int n5 = fk02.h();
        if (fk02.h() == 1684108385) {
            fk02.f(8);
            return new f1(string, null, dx0.r((Object)fk02.x(n5 - 16)));
        }
        ng0.d((String)"MetadataUtil", (String)"Failed to parse text attribute: ".concat(b2.b((int)n2)));
        return null;
    }

    public static JSONArray S(JsonReader jsonReader) {
        JSONArray jSONArray = new JSONArray();
        jsonReader.beginArray();
        while (jsonReader.hasNext()) {
            JsonToken jsonToken = jsonReader.peek();
            if (JsonToken.BEGIN_ARRAY.equals((Object)jsonToken)) {
                jSONArray.put((Object)x.S(jsonReader));
                continue;
            }
            if (JsonToken.BEGIN_OBJECT.equals((Object)jsonToken)) {
                jSONArray.put((Object)x.V(jsonReader));
                continue;
            }
            if (JsonToken.BOOLEAN.equals((Object)jsonToken)) {
                jSONArray.put(jsonReader.nextBoolean());
                continue;
            }
            if (JsonToken.NUMBER.equals((Object)jsonToken)) {
                jSONArray.put(jsonReader.nextDouble());
                continue;
            }
            if (JsonToken.STRING.equals((Object)jsonToken)) {
                jSONArray.put((Object)jsonReader.nextString());
                continue;
            }
            throw new IllegalStateException("unexpected json token: ".concat(String.valueOf((Object)jsonToken)));
        }
        jsonReader.endArray();
        return jSONArray;
    }

    public static int T(int n2, int n5) {
        int n6;
        if (n2 >= 0 && n2 < 3 && n5 >= 0 && (n6 = n5 >> 1) < 19) {
            int n7 = o[n2];
            if (n7 == 44100) {
                int n8 = s[n6] + (n5 & 1);
                return n8 + n8;
            }
            int n9 = r[n6];
            if (n7 == 32000) {
                return n9 * 6;
            }
            return n9 * 4;
        }
        return -1;
    }

    public static JSONObject U(String string, JSONObject jSONObject) {
        try {
            JSONObject jSONObject2 = jSONObject.getJSONObject(string);
            return jSONObject2;
        }
        catch (JSONException jSONException) {
            JSONObject jSONObject3 = new JSONObject();
            jSONObject.put(string, (Object)jSONObject3);
            return jSONObject3;
        }
    }

    public static JSONObject V(JsonReader jsonReader) {
        JSONObject jSONObject = new JSONObject();
        jsonReader.beginObject();
        while (jsonReader.hasNext()) {
            String string = jsonReader.nextName();
            JsonToken jsonToken = jsonReader.peek();
            if (JsonToken.BEGIN_ARRAY.equals((Object)jsonToken)) {
                jSONObject.put(string, (Object)x.S(jsonReader));
                continue;
            }
            if (JsonToken.BEGIN_OBJECT.equals((Object)jsonToken)) {
                jSONObject.put(string, (Object)x.V(jsonReader));
                continue;
            }
            if (JsonToken.BOOLEAN.equals((Object)jsonToken)) {
                jSONObject.put(string, jsonReader.nextBoolean());
                continue;
            }
            if (JsonToken.NUMBER.equals((Object)jsonToken)) {
                jSONObject.put(string, jsonReader.nextDouble());
                continue;
            }
            if (JsonToken.STRING.equals((Object)jsonToken)) {
                jSONObject.put(string, (Object)jsonReader.nextString());
                continue;
            }
            throw new IllegalStateException("unexpected json token: ".concat(String.valueOf((Object)jsonToken)));
        }
        jsonReader.endObject();
        return jSONObject;
    }

    public static void W(JsonWriter jsonWriter, JSONArray jSONArray) {
        jsonWriter.beginArray();
        int n2 = 0;
        do {
            block10 : {
                try {
                    if (n2 < jSONArray.length()) {
                        Object object = jSONArray.get(n2);
                        if (object instanceof String) {
                            jsonWriter.value((String)object);
                            break block10;
                        }
                        if (object instanceof Number) {
                            jsonWriter.value((Number)object);
                            break block10;
                        }
                        if (object instanceof Boolean) {
                            jsonWriter.value(((Boolean)object).booleanValue());
                            break block10;
                        }
                        if (object instanceof JSONObject) {
                            x.X(jsonWriter, (JSONObject)object);
                            break block10;
                        }
                        if (object instanceof JSONArray) {
                            x.W(jsonWriter, (JSONArray)object);
                            break block10;
                        }
                        String string = String.valueOf((Object)object);
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("unable to write field: ");
                        stringBuilder.append(string);
                        throw new JSONException(stringBuilder.toString());
                    }
                    jsonWriter.endArray();
                    return;
                }
                catch (JSONException jSONException) {
                    throw new IOException((Throwable)jSONException);
                }
            }
            ++n2;
        } while (true);
    }

    public static void X(JsonWriter jsonWriter, JSONObject jSONObject) {
        try {
            jsonWriter.beginObject();
            Iterator iterator = jSONObject.keys();
            while (iterator.hasNext()) {
                String string = (String)iterator.next();
                Object object = jSONObject.get(string);
                if (object instanceof String) {
                    jsonWriter.name(string).value((String)object);
                    continue;
                }
                if (object instanceof Number) {
                    jsonWriter.name(string).value((Number)object);
                    continue;
                }
                if (object instanceof Boolean) {
                    jsonWriter.name(string).value(((Boolean)object).booleanValue());
                    continue;
                }
                if (object instanceof JSONObject) {
                    x.X(jsonWriter.name(string), (JSONObject)object);
                    continue;
                }
                if (object instanceof JSONArray) {
                    x.W(jsonWriter.name(string), (JSONArray)object);
                    continue;
                }
                String string2 = String.valueOf((Object)object);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("unable to write field: ");
                stringBuilder.append(string2);
                throw new JSONException(stringBuilder.toString());
            }
            jsonWriter.endObject();
            return;
        }
        catch (JSONException jSONException) {
            throw new IOException((Throwable)jSONException);
        }
    }

    public static /* varargs */ boolean Y(JSONObject jSONObject, String ... arrstring) {
        JSONObject jSONObject2 = x.a0(jSONObject, arrstring);
        if (jSONObject2 == null) {
            return false;
        }
        return jSONObject2.optBoolean(arrstring[-1 + arrstring.length], false);
    }

    public static String Z(ro0 ro02) {
        if (ro02 == null) {
            return null;
        }
        StringWriter stringWriter = new StringWriter();
        try {
            JsonWriter jsonWriter = new JsonWriter((Writer)stringWriter);
            x.b0(jsonWriter, (Object)ro02);
            jsonWriter.close();
        }
        catch (IOException iOException) {
            x4.b0.h((String)"Error when writing JSON.", (Throwable)iOException);
            return null;
        }
        return stringWriter.toString();
    }

    public static void a(w0 w02) {
        w02.getClass();
        w02.j((Object)new u0(w02.l(), null, (t0)w02));
    }

    public static JSONObject a0(JSONObject jSONObject, String[] arrstring) {
        for (int i2 = 0; i2 < -1 + arrstring.length; ++i2) {
            if (jSONObject == null) {
                return null;
            }
            jSONObject = jSONObject.optJSONObject(arrstring[i2]);
        }
        return jSONObject;
    }

    public static int b(int n2, int n5, int n6) {
        if (n2 < n5) {
            return n5;
        }
        if (n2 > n6) {
            return n6;
        }
        return n2;
    }

    public static void b0(JsonWriter jsonWriter, Object object) {
        if (object == null) {
            jsonWriter.nullValue();
            return;
        }
        if (object instanceof Number) {
            jsonWriter.value((Number)object);
            return;
        }
        if (object instanceof Boolean) {
            jsonWriter.value(((Boolean)object).booleanValue());
            return;
        }
        if (object instanceof String) {
            jsonWriter.value((String)object);
            return;
        }
        if (object instanceof ro0) {
            x.X(jsonWriter, ((ro0)object).d);
            return;
        }
        if (object instanceof Map) {
            jsonWriter.beginObject();
            for (Map.Entry entry : ((Map)object).entrySet()) {
                Object object2 = entry.getKey();
                if (!(object2 instanceof String)) continue;
                Object object3 = entry.getValue();
                x.b0(jsonWriter.name((String)object2), object3);
            }
            jsonWriter.endObject();
            return;
        }
        if (object instanceof List) {
            jsonWriter.beginArray();
            Iterator iterator = ((List)object).iterator();
            while (iterator.hasNext()) {
                x.b0(jsonWriter, iterator.next());
            }
            jsonWriter.endArray();
            return;
        }
        jsonWriter.nullValue();
    }

    public static c c(String string, String string2) {
        t8.a a2 = new t8.a(string, string2);
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        HashSet hashSet3 = new HashSet();
        hashSet.add((Object)v.a(t8.a.class));
        a a3 = new a(0, (Object)a2);
        c c2 = new c(null, (Set)new HashSet((Collection)hashSet), (Set)new HashSet((Collection)hashSet2), 0, 1, (f)a3, (Set)hashSet3);
        return c2;
    }

    public static ColorFilter d(int n2) {
        e0.b b4 = e0.b.q;
        if (Build.VERSION.SDK_INT >= 29) {
            Object object = e0.d.a(b4);
            ColorFilter colorFilter = null;
            if (object != null) {
                colorFilter = e0.a.a(n2, object);
            }
            return colorFilter;
        }
        PorterDuff.Mode mode = PorterDuff.Mode.SRC_ATOP;
        PorterDuffColorFilter porterDuffColorFilter = null;
        if (mode != null) {
            porterDuffColorFilter = new PorterDuffColorFilter(n2, mode);
        }
        return porterDuffColorFilter;
    }

    public static final d e(Throwable throwable) {
        j.i((Object)throwable, (String)"exception");
        return new d(throwable);
    }

    public static final Object f(long l2, m9.d d2) {
        Object object;
        long l3 = l2 LCMP 0L;
        g g2 = g.a;
        if (l3 <= 0) {
            return g2;
        }
        h h2 = new h(j.y((m9.d)d2));
        h2.p();
        if (l2 < Long.MAX_VALUE) {
            b7.e e2 = b7.e.H;
            m9.f f2 = h2.u.C((m9.g)e2);
            b0 b02 = f2 instanceof b0 ? (b0)f2 : null;
            if (b02 == null) {
                b02 = z.a;
            }
            b02.e(l2, h2);
        }
        if ((object = h2.o()) == n9.a.q) {
            return object;
        }
        return g2;
    }

    public static void g(Object object) {
        LongSparseArray longSparseArray;
        Class class_;
        Field field;
        if (!d) {
            try {
                c = Class.forName((String)"android.content.res.ThemedResourceCache");
            }
            catch (ClassNotFoundException classNotFoundException) {
                Log.e((String)"ResourcesFlusher", (String)"Could not find ThemedResourceCache class", (Throwable)classNotFoundException);
            }
            d = true;
        }
        if ((class_ = c) == null) {
            return;
        }
        if (!f) {
            try {
                Field field2;
                e = field2 = class_.getDeclaredField("mUnthemedEntries");
                field2.setAccessible(true);
            }
            catch (NoSuchFieldException noSuchFieldException) {
                Log.e((String)"ResourcesFlusher", (String)"Could not retrieve ThemedResourceCache#mUnthemedEntries field", (Throwable)noSuchFieldException);
            }
            f = true;
        }
        if ((field = e) == null) {
            return;
        }
        try {
            longSparseArray = (LongSparseArray)field.get(object);
        }
        catch (IllegalAccessException illegalAccessException) {
            Log.e((String)"ResourcesFlusher", (String)"Could not retrieve value from ThemedResourceCache#mUnthemedEntries", (Throwable)illegalAccessException);
            longSparseArray = null;
        }
        if (longSparseArray != null) {
            v0.a(longSparseArray);
        }
    }

    public static c h(String string, p p2) {
        Class[] arrclass = new Class[]{};
        HashSet hashSet = new HashSet();
        HashSet hashSet2 = new HashSet();
        HashSet hashSet3 = new HashSet();
        hashSet.add((Object)v.a(t8.a.class));
        for (Class class_ : arrclass) {
            if (class_ != null) {
                hashSet.add((Object)v.a((Class)class_));
                continue;
            }
            throw new NullPointerException("Null interface");
        }
        m m2 = m.a(Context.class);
        if (true ^ hashSet.contains((Object)m2.a)) {
            hashSet2.add((Object)m2);
            t8.d d2 = new t8.d(0, (Object)p2, string);
            c c2 = new c(null, (Set)new HashSet((Collection)hashSet), (Set)new HashSet((Collection)hashSet2), 0, 1, (f)d2, (Set)hashSet3);
            return c2;
        }
        throw new IllegalArgumentException("Components are not allowed to depend on interfaces they themselves provide.");
    }

    public static final String i(Object object) {
        return Integer.toHexString((int)System.identityHashCode((Object)object));
    }

    public static final Class j(y9.b b4) {
        j.i((Object)b4, (String)"<this>");
        Class class_ = ((b)b4).a();
        if (!class_.isPrimitive()) {
            return class_;
        }
        String string = class_.getName();
        switch (string.hashCode()) {
            default: {
                return class_;
            }
            case 109413500: {
                if (!string.equals((Object)"short")) {
                    return class_;
                }
                return Short.class;
            }
            case 97526364: {
                if (!string.equals((Object)"float")) {
                    return class_;
                }
                return Float.class;
            }
            case 64711720: {
                if (!string.equals((Object)"boolean")) {
                    return class_;
                }
                return Boolean.class;
            }
            case 3625364: {
                if (!string.equals((Object)"void")) {
                    return class_;
                }
                return Void.class;
            }
            case 3327612: {
                if (!string.equals((Object)"long")) {
                    return class_;
                }
                return Long.class;
            }
            case 3052374: {
                if (!string.equals((Object)"char")) {
                    return class_;
                }
                return Character.class;
            }
            case 3039496: {
                if (!string.equals((Object)"byte")) {
                    return class_;
                }
                return Byte.class;
            }
            case 104431: {
                if (!string.equals((Object)"int")) {
                    return class_;
                }
                return Integer.class;
            }
            case -1325958191: 
        }
        if (!string.equals((Object)"double")) {
            return class_;
        }
        return Double.class;
    }

    public static /* synthetic */ f0 k(t0 t02, boolean bl, x0 x02, int n2) {
        if ((n2 & 1) != 0) {
            bl = false;
        }
        int n5 = n2 & 2;
        boolean bl2 = false;
        if (n5 != 0) {
            bl2 = true;
        }
        return ((c1)t02).B(bl, bl2, (l)x02);
    }

    public static boolean l(int n2, Context context, String string) {
        if (string == null) {
            return false;
        }
        String[] arrstring = context.getResources().getStringArray(n2);
        int n5 = arrstring.length;
        for (int i2 = 0; i2 < n5; ++i2) {
            if (!string.equals((Object)arrstring[i2])) continue;
            return true;
        }
        return false;
    }

    public static boolean m(int n2, Context context, String string) {
        if (string == null) {
            return false;
        }
        String[] arrstring = context.getResources().getStringArray(n2);
        int n5 = arrstring.length;
        for (int i2 = 0; i2 < n5; ++i2) {
            if (!string.startsWith(arrstring[i2])) continue;
            return true;
        }
        return false;
    }

    public static boolean n(int n2, Context context, String string) {
        if (string == null) {
            return false;
        }
        String[] arrstring = context.getResources().getStringArray(n2);
        int n5 = arrstring.length;
        for (int i2 = 0; i2 < n5; ++i2) {
            if (!string.equalsIgnoreCase(arrstring[i2])) continue;
            return true;
        }
        return false;
    }

    public static final int o(int n2) {
        if (n2 < 0) {
            return n2;
        }
        if (n2 < 3) {
            return n2 + 1;
        }
        if (n2 < 1073741824) {
            return (int)(1.0f + (float)n2 / 0.75f);
        }
        return Integer.MAX_VALUE;
    }

    public static androidx.fragment.app.d0 p(Context context) {
        if (context instanceof androidx.fragment.app.d0) {
            return (androidx.fragment.app.d0)context;
        }
        if (context instanceof ContextWrapper) {
            return x.p(((ContextWrapper)context).getBaseContext());
        }
        return null;
    }

    public static final void q(View view, m1.f f2) {
        j.i((Object)view, (String)"<this>");
        view.setTag(2131362892, (Object)f2);
    }

    public static void r(ImageView imageView, int n2, boolean bl) {
        GradientDrawable gradientDrawable;
        Resources resources = imageView.getContext().getResources();
        Drawable drawable = imageView.getDrawable();
        if (drawable instanceof GradientDrawable) {
            gradientDrawable = (GradientDrawable)drawable;
        } else {
            gradientDrawable = new GradientDrawable();
            gradientDrawable.setShape(1);
        }
        int n5 = Color.rgb((int)(192 * Color.red((int)n2) / 256), (int)(192 * Color.green((int)n2) / 256), (int)(192 * Color.blue((int)n2) / 256));
        gradientDrawable.setColor(n2);
        gradientDrawable.setStroke((int)TypedValue.applyDimension((int)1, (float)2.0f, (DisplayMetrics)resources.getDisplayMetrics()), n5);
        if (bl) {
            gradientDrawable = new LayerDrawable(new Drawable[]{gradientDrawable, i.a(resources, 2131230987, null)});
        }
        imageView.setImageDrawable((Drawable)gradientDrawable);
    }

    public static void s(View view, float f2) {
        int n2 = view.getResources().getInteger(2131427330);
        StateListAnimator stateListAnimator = new StateListAnimator();
        int[] arrn = new int[]{16842910, 2130969691, -2130969692};
        ObjectAnimator objectAnimator = ObjectAnimator.ofFloat((Object)view, (String)"elevation", (float[])new float[]{0.0f});
        long l2 = n2;
        stateListAnimator.addState(arrn, (Animator)objectAnimator.setDuration(l2));
        stateListAnimator.addState(new int[]{16842910}, (Animator)ObjectAnimator.ofFloat((Object)view, (String)"elevation", (float[])new float[]{f2}).setDuration(l2));
        stateListAnimator.addState(new int[0], (Animator)ObjectAnimator.ofFloat((Object)view, (String)"elevation", (float[])new float[]{0.0f}).setDuration(0L));
        view.setStateListAnimator(stateListAnimator);
    }

    public static void t(View view, CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 26) {
            m4.a((View)view, (CharSequence)charSequence);
            return;
        }
        o4 o42 = o4.A;
        if (o42 != null && o42.q == view) {
            o4.b(null);
        }
        if (TextUtils.isEmpty((CharSequence)charSequence)) {
            o4 o43 = o4.B;
            if (o43 != null && o43.q == view) {
                o43.a();
            }
            view.setOnLongClickListener(null);
            view.setLongClickable(false);
            view.setOnHoverListener(null);
            return;
        }
        new o4(view, charSequence);
    }

    public static final void u(Object object) {
        if (!(object instanceof d)) {
            return;
        }
        throw ((d)object).q;
    }

    public static final String v(m9.d d2) {
        Object object;
        if (d2 instanceof da.f) {
            return d2.toString();
        }
        try {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append((Object)d2);
            stringBuilder.append('@');
            stringBuilder.append(x.i((Object)d2));
            object = stringBuilder.toString();
        }
        catch (Throwable throwable) {
            object = x.e(throwable);
        }
        if (jv0.a((Object)object) != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(d2.getClass().getName());
            stringBuilder.append('@');
            stringBuilder.append(x.i((Object)d2));
            object = stringBuilder.toString();
        }
        return (String)object;
    }

    public static final Map w(LinkedHashMap linkedHashMap) {
        Map.Entry entry = (Map.Entry)linkedHashMap.entrySet().iterator().next();
        Map map = Collections.singletonMap((Object)entry.getKey(), (Object)entry.getValue());
        j.h((Object)map, (String)"with(entries.iterator().\u2026ingletonMap(key, value) }");
        return map;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static final Object x(z8.l var0) {
        block7 : {
            block6 : {
                block9 : {
                    block8 : {
                        var1_1 = var0.r;
                        j.f((Object)var1_1);
                        e.C((m9.h)var1_1);
                        var2_2 = j.y((m9.d)var0);
                        var3_3 = var2_2 instanceof da.f != false ? (da.f)var2_2 : null;
                        var4_4 = n9.a.q;
                        var5_5 = g.a;
                        if (var3_3 == null) ** GOTO lbl45
                        var6_6 = var3_3.t;
                        var7_7 = var6_6.F();
                        var8_8 = true;
                        if (!var7_7) break block8;
                        var3_3.v = var5_5;
                        var3_3.s = var8_8;
                        var6_6.E(var1_1, (Runnable)var3_3);
                        break block6;
                    }
                    var9_9 = new q1();
                    var10_10 = var1_1.m((m9.h)var9_9);
                    var3_3.v = var5_5;
                    var3_3.s = var8_8;
                    var6_6.E(var10_10, (Runnable)var3_3);
                    if (!var9_9.r) break block6;
                    var12_11 = m1.a();
                    var13_12 = var12_11.u;
                    var14_13 = var13_12 != null ? (boolean)(var13_12.isEmpty() ? 1 : 0) : var8_8;
                    if (var14_13) ** GOTO lbl43
                    if (!var12_11.K()) break block9;
                    var3_3.v = var5_5;
                    var3_3.s = var8_8;
                    var12_11.H((d0)var3_3);
                    ** GOTO lbl44
                }
                var12_11.J(var8_8);
                try {
                    var3_3.run();
                    while (var17_14 = var12_11.M()) {
                    }
                }
                catch (Throwable var15_15) {
                    var3_3.g(var15_15, null);
lbl43: // 3 sources:
                    var8_8 = false;
lbl44: // 2 sources:
                    if (var8_8) break block6;
lbl45: // 2 sources:
                    var11_16 = var5_5;
                    break block7;
                    finally {
                        var12_11.G(var8_8);
                    }
                }
            }
            var11_16 = var4_4;
        }
        if (var11_16 != var4_4) return var5_5;
        return var11_16;
    }

    public static int y(int n2, fk0 fk02) {
        switch (n2) {
            default: {
                return -1;
            }
            case 8: 
            case 9: 
            case 10: 
            case 11: 
            case 12: 
            case 13: 
            case 14: 
            case 15: {
                return 256 << n2 - 8;
            }
            case 7: {
                return 1 + fk02.p();
            }
            case 6: {
                return 1 + fk02.m();
            }
            case 2: 
            case 3: 
            case 4: 
            case 5: {
                return 576 << n2 - 2;
            }
            case 1: 
        }
        return 192;
    }

    public static Bundle z(JSONObject jSONObject) {
        if (jSONObject == null) {
            return null;
        }
        Iterator iterator = jSONObject.keys();
        Bundle bundle = new Bundle();
        while (iterator.hasNext()) {
            String string = (String)iterator.next();
            Object object = jSONObject.opt(string);
            if (object == null) continue;
            if (object instanceof Boolean) {
                bundle.putBoolean(string, ((Boolean)object).booleanValue());
                continue;
            }
            if (object instanceof Double) {
                bundle.putDouble(string, ((Double)object).doubleValue());
                continue;
            }
            if (object instanceof Integer) {
                bundle.putInt(string, ((Integer)object).intValue());
                continue;
            }
            if (object instanceof Long) {
                bundle.putLong(string, ((Long)object).longValue());
                continue;
            }
            if (object instanceof String) {
                bundle.putString(string, (String)object);
                continue;
            }
            if (object instanceof JSONArray) {
                JSONArray jSONArray = (JSONArray)object;
                if (jSONArray.length() == 0) continue;
                int n2 = jSONArray.length();
                int n5 = 0;
                Object object2 = null;
                for (int i2 = 0; object2 == null && i2 < n2; ++i2) {
                    object2 = !jSONArray.isNull(i2) ? jSONArray.opt(i2) : null;
                }
                if (object2 == null) {
                    x4.b0.j((String)"Expected JSONArray with at least 1 non-null element for key:".concat(String.valueOf((Object)string)));
                    continue;
                }
                if (object2 instanceof JSONObject) {
                    Bundle[] arrbundle = new Bundle[n2];
                    while (n5 < n2) {
                        Bundle bundle2 = !jSONArray.isNull(n5) ? x.z(jSONArray.optJSONObject(n5)) : null;
                        arrbundle[n5] = bundle2;
                        ++n5;
                    }
                    bundle.putParcelableArray(string, (Parcelable[])arrbundle);
                    continue;
                }
                if (object2 instanceof Number) {
                    double[] arrd = new double[jSONArray.length()];
                    while (n5 < n2) {
                        arrd[n5] = jSONArray.optDouble(n5);
                        ++n5;
                    }
                    bundle.putDoubleArray(string, arrd);
                    continue;
                }
                if (object2 instanceof CharSequence) {
                    String[] arrstring = new String[n2];
                    while (n5 < n2) {
                        String string2 = !jSONArray.isNull(n5) ? jSONArray.optString(n5) : null;
                        arrstring[n5] = string2;
                        ++n5;
                    }
                    bundle.putStringArray(string, arrstring);
                    continue;
                }
                if (object2 instanceof Boolean) {
                    boolean[] arrbl = new boolean[n2];
                    while (n5 < n2) {
                        arrbl[n5] = jSONArray.optBoolean(n5);
                        ++n5;
                    }
                    bundle.putBooleanArray(string, arrbl);
                    continue;
                }
                Class class_ = object2.getClass();
                Object[] arrobject = new Object[]{class_.getCanonicalName(), string};
                x4.b0.j((String)String.format((String)"JSONArray with unsupported type %s for key:%s", (Object[])arrobject));
                continue;
            }
            if (object instanceof JSONObject) {
                bundle.putBundle(string, x.z((JSONObject)object));
                continue;
            }
            x4.b0.j((String)"Unsupported type for key:".concat(String.valueOf((Object)string)));
        }
        return bundle;
    }
}

