/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ba;

import m9.f;
import m9.g;
import m9.h;
import n7.b;
import s7.j;
import t9.p;
import y6.e;

public final class p1
implements f,
g {
    public static final p1 q = new p1();

    @Override
    public final f C(g g2) {
        return b.g(this, g2);
    }

    @Override
    public final h b(g g2) {
        return b.k(this, g2);
    }

    @Override
    public final g getKey() {
        return this;
    }

    @Override
    public final h m(h h4) {
        j.i(h4, "context");
        return e.r0(this, h4);
    }

    @Override
    public final Object v(Object object, p p5) {
        return p5.f(object, this);
    }
}

