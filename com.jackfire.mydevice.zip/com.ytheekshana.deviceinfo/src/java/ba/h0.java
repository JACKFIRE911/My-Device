/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.k0
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package ba;

import ba.g;
import ba.h;
import ba.i0;
import ba.k0;
import ba.u;

public final class h0
extends i0 {
    public final g s;
    public final /* synthetic */ k0 t;

    public h0(k0 k02, long l2, h h4) {
        this.t = k02;
        super(l2);
        this.s = h4;
    }

    public final void run() {
        ((h)this.s).x((u)this.t);
    }

    @Override
    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        stringBuilder.append((Object)this.s);
        return stringBuilder.toString();
    }
}

