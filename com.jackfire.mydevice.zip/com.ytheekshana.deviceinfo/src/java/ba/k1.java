/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Throwable
 */
package ba;

import ba.t0;
import ba.w0;

public final class k1
extends w0 {
    public k1(t0 t02) {
        super(t02);
    }

    @Override
    public final boolean n(Throwable throwable) {
        return false;
    }
}

