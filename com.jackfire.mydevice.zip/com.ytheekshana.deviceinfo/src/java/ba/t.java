/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.o0
 */
package ba;

import androidx.lifecycle.o0;
import b7.e;
import ba.u;
import m9.b;
import m9.g;

public final class t
extends b {
    public t(int n3) {
        if (n3 != 1) {
            super(e.H, o0.v);
            return;
        }
        super(u.r, o0.w);
    }
}

