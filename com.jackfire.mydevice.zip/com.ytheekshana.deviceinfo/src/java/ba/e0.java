/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ea.c
 *  ea.d
 *  java.lang.Object
 */
package ba;

import ea.c;
import ea.d;

public abstract class e0 {
    public static final d a = d.t;
    public static final c b = c.s;

    public static final d a() {
        return a;
    }
}

