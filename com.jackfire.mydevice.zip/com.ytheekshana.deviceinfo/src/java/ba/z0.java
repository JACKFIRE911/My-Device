/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.Throwable
 */
package ba;

import ba.a1;
import ba.c1;
import ba.l;
import ba.x0;
import j9.g;

public final class z0
extends x0 {
    public final c1 u;
    public final a1 v;
    public final l w;
    public final Object x;

    public z0(c1 c12, a1 a12, l l2, Object object) {
        this.u = c12;
        this.v = a12;
        this.w = l2;
        this.x = object;
    }

    @Override
    public final void p(Throwable throwable) {
        c1 c12 = this.u;
        c12.getClass();
        l l2 = c1.H(this.w);
        a1 a12 = this.v;
        Object object = this.x;
        if (l2 != null && c12.P(a12, l2, object)) {
            return;
        }
        c12.g(c12.q(a12, object));
    }
}

