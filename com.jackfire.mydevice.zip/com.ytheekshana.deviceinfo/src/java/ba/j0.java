/*
 * Decompiled with CFR 0.0.
 */
package ba;

import da.t;

public final class j0
extends t {
    public long c;

    public j0(long l3) {
        this.c = l3;
    }
}

