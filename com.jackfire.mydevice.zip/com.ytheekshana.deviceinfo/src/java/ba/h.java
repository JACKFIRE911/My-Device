/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.x
 *  com.google.android.gms.internal.ads.jv0
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.CancellationException
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 */
package ba;

import a2.s;
import ba.b;
import ba.c1;
import ba.d0;
import ba.e;
import ba.f;
import ba.f0;
import ba.g;
import ba.g1;
import ba.h1;
import ba.i;
import ba.j;
import ba.l0;
import ba.m1;
import ba.p;
import ba.q;
import ba.t0;
import ba.u;
import ba.x;
import com.google.android.gms.internal.ads.jv0;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import o9.d;
import r.a;
import t9.l;

public class h
extends d0
implements g,
d {
    public static final AtomicIntegerFieldUpdater v = AtomicIntegerFieldUpdater.newUpdater(h.class, (String)"_decisionAndIndex");
    public static final AtomicReferenceFieldUpdater w = AtomicReferenceFieldUpdater.newUpdater(h.class, Object.class, (String)"_state");
    public static final AtomicReferenceFieldUpdater x = AtomicReferenceFieldUpdater.newUpdater(h.class, Object.class, (String)"_parentHandle");
    private volatile int _decisionAndIndex;
    private volatile Object _parentHandle;
    private volatile Object _state;
    public final m9.d t;
    public final m9.h u;

    public h(m9.d d3) {
        super(1);
        this.t = d3;
        this.u = d3.getContext();
        this._decisionAndIndex = 536870911;
        this._state = b.q;
    }

    public static void t(f f4, Object object) {
        StringBuilder stringBuilder = new StringBuilder("It's prohibited to register multiple handlers, tried to register ");
        stringBuilder.append((Object)f4);
        stringBuilder.append(", already has ");
        stringBuilder.append(object);
        throw new IllegalStateException(stringBuilder.toString().toString());
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static void w(h var0, Object var1_1, int var2_2) {
        var0.getClass();
        block0 : do {
            block8 : {
                block7 : {
                    var4_4 = h.w;
                    var5_5 = var4_4.get((Object)var0);
                    var6_6 = var5_5 instanceof h1;
                    var7_7 = 1;
                    if (!var6_6) break block7;
                    var12_8 = (h1)var5_5;
                    if (var1_1 instanceof q) ** GOTO lbl-1000
                    var13_9 = var2_2 != var7_7 && var2_2 != 2 ? 0 : var7_7;
                    if (var13_9 == 0 || !(var12_8 instanceof f)) lbl-1000: // 2 sources:
                    {
                        var16_3 = var1_1;
                    } else {
                        var14_10 = var12_8 instanceof f != false ? (f)var12_8 : null;
                        var15_11 = var14_10;
                        var16_3 = new p(var1_1, var15_11, null, null, 16);
                    }
                    break block8;
                }
                if (var5_5 instanceof i) {
                    var10_12 = (i)var5_5;
                    var10_12.getClass();
                    if (i.c.compareAndSet((Object)var10_12, 0, var7_7)) {
                        return;
                    }
                }
                var8_13 = new StringBuilder("Already resumed, but proposed with update ");
                var8_13.append(var1_1);
                throw new IllegalStateException(var8_13.toString().toString());
            }
            while (!var4_4.compareAndSet((Object)var0, var5_5, var16_3)) {
                if (var4_4.get((Object)var0) == var5_5) continue;
                var7_7 = 0;
                continue block0;
            }
        } while (var7_7 == 0);
        if (!var0.s()) {
            var0.l();
        }
        var0.m(var2_2);
    }

    @Override
    public final void a(Object object, CancellationException cancellationException) {
        Object object2;
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        while (!((object2 = (atomicReferenceFieldUpdater = w).get((Object)this)) instanceof h1)) {
            if (object2 instanceof q) {
                return;
            }
            boolean bl = object2 instanceof p;
            boolean bl2 = true;
            if (bl) {
                p p5 = (p)object2;
                boolean bl3 = p5.e != null ? bl2 : false;
                if (bl3 ^ bl2) {
                    l l2;
                    p p6 = p.a(p5, null, cancellationException, 15);
                    while (!atomicReferenceFieldUpdater.compareAndSet((Object)this, object2, (Object)p6)) {
                        if (atomicReferenceFieldUpdater.get((Object)this) == object2) continue;
                        bl2 = false;
                        break;
                    }
                    if (!bl2) continue;
                    f f4 = p5.b;
                    if (f4 != null) {
                        this.i(f4, (Throwable)cancellationException);
                    }
                    if ((l2 = p5.c) != null) {
                        this.j(l2, (Throwable)cancellationException);
                    }
                    return;
                }
                throw new IllegalStateException("Must be called at most once".toString());
            }
            p p7 = new p(object2, null, null, cancellationException, 14);
            while (!atomicReferenceFieldUpdater.compareAndSet((Object)this, object2, (Object)p7)) {
                if (atomicReferenceFieldUpdater.get((Object)this) == object2) continue;
                bl2 = false;
                break;
            }
            if (!bl2) continue;
            return;
        }
        throw new IllegalStateException("Not completed".toString());
    }

    @Override
    public final m9.d b() {
        return this.t;
    }

    @Override
    public final d c() {
        m9.d d3 = this.t;
        if (d3 instanceof d) {
            return (d)((Object)d3);
        }
        return null;
    }

    @Override
    public final Throwable d(Object object) {
        Throwable throwable = super.d(object);
        if (throwable != null) {
            return throwable;
        }
        return null;
    }

    @Override
    public final void e(Object object) {
        Throwable throwable = jv0.a((Object)object);
        if (throwable != null) {
            object = new q(throwable, false);
        }
        h.w(this, object, this.s);
    }

    @Override
    public final Object f(Object object) {
        if (object instanceof p) {
            object = ((p)object).a;
        }
        return object;
    }

    @Override
    public final m9.h getContext() {
        return this.u;
    }

    @Override
    public final Object h() {
        return w.get((Object)this);
    }

    public final void i(f f4, Throwable throwable) {
        try {
            f4.a(throwable);
            return;
        }
        catch (Throwable throwable2) {
            StringBuilder stringBuilder = new StringBuilder("Exception in invokeOnCancellation handler for ");
            stringBuilder.append((Object)this);
            androidx.fragment.app.x x2 = new androidx.fragment.app.x(stringBuilder.toString(), throwable2);
            s7.j.t(this.u, (Throwable)x2);
            return;
        }
    }

    public final void j(l l2, Throwable throwable) {
        try {
            l2.g((Object)throwable);
            return;
        }
        catch (Throwable throwable2) {
            StringBuilder stringBuilder = new StringBuilder("Exception in resume onCancellation handler for ");
            stringBuilder.append((Object)this);
            androidx.fragment.app.x x2 = new androidx.fragment.app.x(stringBuilder.toString(), throwable2);
            s7.j.t(this.u, (Throwable)x2);
            return;
        }
    }

    public final void k(Throwable throwable) {
        boolean bl;
        Object object;
        block0 : do {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
            if (!((object = (atomicReferenceFieldUpdater = w).get((Object)this)) instanceof h1)) {
                return;
            }
            i i4 = new i(this, throwable, object instanceof f);
            do {
                if (!atomicReferenceFieldUpdater.compareAndSet((Object)this, object, (Object)i4)) continue;
                bl = true;
                continue block0;
            } while (atomicReferenceFieldUpdater.get((Object)this) == object);
            bl = false;
        } while (!bl);
        if ((h1)object instanceof f) {
            this.i((f)object, throwable);
        }
        if (!this.s()) {
            this.l();
        }
        this.m(this.s);
    }

    public final void l() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = x;
        f0 f02 = (f0)atomicReferenceFieldUpdater.get((Object)this);
        if (f02 == null) {
            return;
        }
        f02.c();
        atomicReferenceFieldUpdater.set((Object)this, (Object)g1.q);
    }

    public final void m(int n3) {
        m9.d d3;
        boolean bl;
        block17 : {
            boolean bl2;
            boolean bl3;
            block19 : {
                block18 : {
                    boolean bl4;
                    block16 : {
                        int n5;
                        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater;
                        do {
                            int n6;
                            if ((n6 = (n5 = (atomicIntegerFieldUpdater = v).get((Object)this)) >> 29) == 0) continue;
                            if (n6 == 1) {
                                bl4 = false;
                                break block16;
                            }
                            throw new IllegalStateException("Already resumed".toString());
                        } while (!atomicIntegerFieldUpdater.compareAndSet((Object)this, n5, 1073741824 + (536870911 & n5)));
                        bl4 = true;
                    }
                    if (bl4) {
                        return;
                    }
                    bl = n3 == 4;
                    d3 = this.t;
                    if (bl || !(d3 instanceof da.f)) break block17;
                    bl3 = n3 == 1 || n3 == 2;
                    int n7 = this.s;
                    if (n7 == 1) break block18;
                    bl2 = false;
                    if (n7 != 2) break block19;
                }
                bl2 = true;
            }
            if (bl3 == bl2) {
                u u2 = ((da.f)d3).t;
                m9.h h4 = d3.getContext();
                if (u2.F()) {
                    u2.D(h4, this);
                    return;
                }
                l0 l02 = m1.a();
                if (l02.K()) {
                    l02.H(this);
                    return;
                }
                l02.J(true);
                try {
                    boolean bl5;
                    y6.e.C0(this, d3, true);
                    while (bl5 = l02.M()) {
                    }
                }
                catch (Throwable throwable) {
                    this.g(throwable, null);
                }
                return;
                {
                    finally {
                        l02.G(true);
                    }
                }
            }
        }
        y6.e.C0(this, d3, bl);
    }

    public Throwable n(c1 c12) {
        return c12.r();
    }

    public final Object o() {
        Object object;
        block12 : {
            t0 t02;
            boolean bl;
            b7.e e3;
            block14 : {
                block13 : {
                    boolean bl2;
                    boolean bl3;
                    block11 : {
                        AtomicIntegerFieldUpdater atomicIntegerFieldUpdater;
                        int n3;
                        bl3 = this.s();
                        do {
                            int n5;
                            if ((n5 = (n3 = (atomicIntegerFieldUpdater = v).get((Object)this)) >> 29) == 0) continue;
                            if (n5 == 2) {
                                bl2 = false;
                                break block11;
                            }
                            throw new IllegalStateException("Already suspended".toString());
                        } while (!atomicIntegerFieldUpdater.compareAndSet((Object)this, n3, 536870912 + (536870911 & n3)));
                        bl2 = true;
                    }
                    if (bl2) {
                        if ((f0)x.get((Object)this) == null) {
                            this.q();
                        }
                        if (bl3) {
                            this.v();
                        }
                        return n9.a.q;
                    }
                    if (bl3) {
                        this.v();
                    }
                    if ((object = w.get((Object)this)) instanceof q) break block12;
                    int n6 = this.s;
                    if (n6 == 1) break block13;
                    bl = false;
                    if (n6 != 2) break block14;
                }
                bl = true;
            }
            if (bl && (t02 = (t0)this.u.C(e3 = b7.e.t)) != null && !t02.a()) {
                CancellationException cancellationException = ((c1)t02).r();
                this.a(object, cancellationException);
                throw cancellationException;
            }
            return this.f(object);
        }
        throw ((q)object).a;
    }

    public final void p() {
        f0 f02 = this.q();
        if (f02 == null) {
            return;
        }
        if (true ^ w.get((Object)this) instanceof h1) {
            f02.c();
            g1 g12 = g1.q;
            x.set((Object)this, (Object)g12);
        }
    }

    public final f0 q() {
        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
        b7.e e3 = b7.e.t;
        t0 t02 = (t0)this.u.C(e3);
        if (t02 == null) {
            return null;
        }
        f0 f02 = x.k(t02, true, new j(this), 2);
        do {
            if (!(atomicReferenceFieldUpdater = x).compareAndSet((Object)this, null, (Object)f02)) continue;
            return f02;
        } while (atomicReferenceFieldUpdater.get((Object)this) == null);
        return f02;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void r(l var1_1) {
        var2_2 = var1_1 instanceof f != false ? (f)var1_1 : new e(2, var1_1);
        block0 : do lbl-1000: // 4 sources:
        {
            block14 : {
                block13 : {
                    block11 : {
                        block12 : {
                            var3_3 = h.w;
                            var4_4 = var3_3.get((Object)this);
                            var5_5 = var4_4 instanceof b;
                            var6_6 = 1;
                            if (var5_5) break block11;
                            if (var4_4 instanceof f) {
                                h.t(var2_2, var4_4);
                                throw null;
                            }
                            var7_7 = var4_4 instanceof q;
                            if (var7_7) {
                                var13_13 = (q)var4_4;
                                var13_13.getClass();
                                if (!q.b.compareAndSet((Object)var13_13, 0, var6_6)) {
                                    h.t(var2_2, var4_4);
                                    throw null;
                                }
                                if (var4_4 instanceof i == false) return;
                                if (!var7_7) {
                                    var13_13 = null;
                                }
                                var15_14 = var13_13 != null ? var13_13.a : null;
                                if (var2_2 instanceof f) {
                                    this.i(var2_2, var15_14);
                                    return;
                                }
                                s7.j.g(var2_2, "null cannot be cast to non-null type kotlinx.coroutines.internal.Segment<*>");
                                s.x(var2_2);
                                throw null;
                            }
                            if (!(var4_4 instanceof p)) break block12;
                            var9_9 = (p)var4_4;
                            if (var9_9.b != null) {
                                h.t(var2_2, var4_4);
                                throw null;
                            }
                            s7.j.g(var2_2, "null cannot be cast to non-null type kotlinx.coroutines.CancelHandler");
                            var10_10 = var9_9.e;
                            var11_11 = var10_10 != null ? var6_6 : 0;
                            if (var11_11 != 0) {
                                this.i(var2_2, var10_10);
                                return;
                            }
                            var12_12 = p.a(var9_9, var2_2, null, 29);
                            break block13;
                        }
                        s7.j.g(var2_2, "null cannot be cast to non-null type kotlinx.coroutines.CancelHandler");
                        var8_8 = new p(var4_4, var2_2, null, null, 28);
                        break block14;
                    }
                    while (!var3_3.compareAndSet((Object)this, var4_4, (Object)var2_2)) {
                        if (var3_3.get((Object)this) == var4_4) continue;
                        var6_6 = 0;
                        break;
                    }
                    if (var6_6 == 0) ** GOTO lbl-1000
                    return;
                }
                while (!var3_3.compareAndSet((Object)this, var4_4, (Object)var12_12)) {
                    if (var3_3.get((Object)this) == var4_4) continue;
                    var6_6 = 0;
                    break;
                }
                if (var6_6 == 0) ** GOTO lbl-1000
                return;
            }
            while (!var3_3.compareAndSet((Object)this, var4_4, (Object)var8_8)) {
                if (var3_3.get((Object)this) == var4_4) continue;
                var6_6 = 0;
                continue block0;
            }
        } while (var6_6 == 0);
    }

    public final boolean s() {
        boolean bl = this.s == 2;
        if (bl) {
            m9.d d3 = this.t;
            s7.j.g(d3, "null cannot be cast to non-null type kotlinx.coroutines.internal.DispatchedContinuation<*>");
            da.f f4 = (da.f)d3;
            boolean bl2 = da.f.x.get((Object)f4) != null;
            if (bl2) {
                return true;
            }
        }
        return false;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.u());
        stringBuilder.append('(');
        stringBuilder.append(x.v(this.t));
        stringBuilder.append("){");
        Object object = w.get((Object)this);
        String string = object instanceof h1 ? "Active" : (object instanceof i ? "Cancelled" : "Completed");
        stringBuilder.append(string);
        stringBuilder.append("}@");
        stringBuilder.append(x.i(this));
        return stringBuilder.toString();
    }

    public String u() {
        return "CancellableContinuation";
    }

    public final void v() {
        block10 : {
            Object object;
            block11 : {
                block12 : {
                    Throwable throwable;
                    block9 : {
                        Object object2;
                        o2.p p5;
                        boolean bl;
                        AtomicReferenceFieldUpdater atomicReferenceFieldUpdater;
                        m9.d d3 = this.t;
                        da.f f4 = d3 instanceof da.f ? (da.f)d3 : null;
                        if (f4 == null) break block10;
                        while ((object = (atomicReferenceFieldUpdater = da.f.x).get((Object)f4)) == (p5 = a.i)) {
                            Object object3;
                            boolean bl2;
                            do {
                                if (atomicReferenceFieldUpdater.compareAndSet((Object)f4, (Object)p5, (Object)this)) {
                                    bl2 = true;
                                    break;
                                }
                                object3 = atomicReferenceFieldUpdater.get((Object)f4);
                                bl2 = false;
                            } while (object3 == p5);
                            if (!bl2) continue;
                            throwable = null;
                            break block9;
                        }
                        if (!(object instanceof Throwable)) break block11;
                        do {
                            if (atomicReferenceFieldUpdater.compareAndSet((Object)f4, object, null)) {
                                bl = true;
                                break;
                            }
                            object2 = atomicReferenceFieldUpdater.get((Object)f4);
                            bl = false;
                        } while (object2 == object);
                        if (!bl) break block12;
                        throwable = (Throwable)object;
                    }
                    if (throwable == null) {
                        return;
                    }
                    this.l();
                    this.k(throwable);
                    return;
                }
                throw new IllegalArgumentException("Failed requirement.".toString());
            }
            StringBuilder stringBuilder = new StringBuilder("Inconsistent state ");
            stringBuilder.append(object);
            throw new IllegalStateException(stringBuilder.toString().toString());
        }
    }

    public final void x(u u2) {
        j9.g g2 = j9.g.a;
        m9.d d3 = this.t;
        da.f f4 = d3 instanceof da.f ? (da.f)d3 : null;
        u u4 = null;
        if (f4 != null) {
            u4 = f4.t;
        }
        int n3 = u4 == u2 ? 4 : this.s;
        h.w(this, g2, n3);
    }
}

