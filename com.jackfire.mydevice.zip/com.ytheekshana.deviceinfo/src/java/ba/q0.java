/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ba;

import ba.p0;

public final class q0 {
    public final p0 a;

    public q0(p0 p02) {
        this.a = p02;
    }
}

