/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.CancellationException
 *  java.util.concurrent.atomic.AtomicIntegerFieldUpdater
 */
package ba;

import ba.q;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicIntegerFieldUpdater;
import m9.d;

public final class i
extends q {
    public static final AtomicIntegerFieldUpdater c = AtomicIntegerFieldUpdater.newUpdater(i.class, (String)"_resumed");
    private volatile int _resumed;

    public i(d d4, Throwable throwable, boolean bl) {
        if (throwable == null) {
            StringBuilder stringBuilder = new StringBuilder("Continuation ");
            stringBuilder.append((Object)d4);
            stringBuilder.append(" was cancelled normally");
            throwable = new CancellationException(stringBuilder.toString());
        }
        super(throwable, bl);
        this._resumed = 0;
    }
}

