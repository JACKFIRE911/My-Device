/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Thread
 */
package ba;

import ba.k0;

public final class d
extends k0 {
    public final Thread z;

    public d(Thread thread) {
        this.z = thread;
    }

    @Override
    public final Thread I() {
        return this.z;
    }
}

