/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package ba;

import ba.f1;
import ba.p0;

public final class o0
implements p0 {
    public final f1 q;

    public o0(f1 f12) {
        this.q = f12;
    }

    @Override
    public final boolean a() {
        return false;
    }

    @Override
    public final f1 h() {
        return this.q;
    }

    public final String toString() {
        return super.toString();
    }
}

