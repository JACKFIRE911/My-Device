/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.y
 *  java.lang.Object
 *  java.lang.Thread
 */
package ba;

import ba.d0;
import ba.i0;
import ba.u;
import ba.y;
import k9.d;

public abstract class l0
extends u {
    public static final /* synthetic */ int v;
    public long s;
    public boolean t;
    public d u;

    public final void G(boolean bl) {
        long l2;
        long l5 = this.s;
        long l6 = bl ? 0x100000000L : 1L;
        this.s = l2 = l5 - l6;
        if (l2 > 0L) {
            return;
        }
        if (this.t) {
            this.shutdown();
        }
    }

    public final void H(d0 d02) {
        d d3 = this.u;
        if (d3 == null) {
            this.u = d3 = new d();
        }
        d3.h(d02);
    }

    public abstract Thread I();

    public final void J(boolean bl) {
        long l2 = this.s;
        long l5 = bl ? 0x100000000L : 1L;
        this.s = l5 + l2;
        if (!bl) {
            this.t = true;
        }
    }

    public final boolean K() {
        return this.s >= 0x100000000L;
    }

    public abstract long L();

    public final boolean M() {
        d d3 = this.u;
        if (d3 == null) {
            return false;
        }
        Object object = d3.isEmpty() ? null : d3.m();
        d0 d02 = (d0)object;
        if (d02 == null) {
            return false;
        }
        d02.run();
        return true;
    }

    public void N(long l2, i0 i02) {
        y.z.S(l2, i02);
    }

    public abstract void shutdown();
}

