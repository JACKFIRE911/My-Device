/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 */
package ba;

import ba.c1;
import ba.k;
import ba.l;
import ba.t0;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;

public class w0
extends c1 {
    public final boolean s;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public w0(t0 var1_1) {
        var2_2 = true;
        super(var2_2);
        this.A(var1_1);
        var3_3 = c1.r;
        var4_4 = (k)var3_3.get((Object)this);
        var5_5 = var4_4 instanceof l != false ? (l)var4_4 : null;
        if (var5_5 == null) ** GOTO lbl15
        var6_6 = var5_5.o();
        while (!var6_6.t()) {
            var7_7 = (k)var3_3.get((Object)var6_6);
            var8_8 = var7_7 instanceof l != false ? (l)var7_7 : null;
            if (var8_8 != null) {
                var6_6 = var8_8.o();
                continue;
            }
lbl15: // 3 sources:
            var2_2 = false;
            break;
        }
        this.s = var2_2;
    }

    @Override
    public final boolean t() {
        return this.s;
    }

    @Override
    public final boolean u() {
        return true;
    }
}

