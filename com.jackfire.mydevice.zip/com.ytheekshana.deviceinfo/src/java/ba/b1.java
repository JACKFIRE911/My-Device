/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.concurrent.atomic.AtomicReferenceFieldUpdater
 */
package ba;

import ba.c1;
import da.a;
import da.i;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import o2.p;
import s5.g;
import s7.j;

public final class b1
extends a {
    public final i b;
    public i c;
    public final /* synthetic */ c1 d;
    public final /* synthetic */ Object e;

    public b1(i i4, c1 c12, Object object) {
        this.d = c12;
        this.e = object;
        this.b = i4;
    }

    @Override
    public final void b(Object object, Object object2) {
        i i4 = (i)object;
        boolean bl = true;
        boolean bl2 = object2 == null ? bl : false;
        i i5 = this.b;
        i i6 = bl2 ? i5 : this.c;
        if (i6 != null) {
            AtomicReferenceFieldUpdater atomicReferenceFieldUpdater = i.q;
            while (!atomicReferenceFieldUpdater.compareAndSet((Object)i4, (Object)this, (Object)i6)) {
                if (atomicReferenceFieldUpdater.get((Object)i4) == this) continue;
                bl = false;
                break;
            }
            if (bl && bl2) {
                i i7 = this.c;
                j.f(i7);
                i5.j(i7);
            }
        }
    }

    @Override
    public final p c(Object object) {
        (i)object;
        boolean bl = this.d.x() == this.e;
        if (bl) {
            return null;
        }
        return g.n;
    }
}

