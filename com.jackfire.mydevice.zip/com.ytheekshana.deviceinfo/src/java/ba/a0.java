/*
 * Decompiled with CFR 0.0.
 */
package ba;

import ba.a;
import m9.h;

public class a0
extends a {
    public a0(h h2, boolean bl) {
        super(h2, bl);
    }
}

