/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package ba;

import ba.f1;
import ba.p0;

public final class g0
implements p0 {
    public final boolean q;

    public g0(boolean bl) {
        this.q = bl;
    }

    @Override
    public final boolean a() {
        return this.q;
    }

    @Override
    public final f1 h() {
        return null;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Empty{");
        String string = this.q ? "Active" : "New";
        stringBuilder.append(string);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

