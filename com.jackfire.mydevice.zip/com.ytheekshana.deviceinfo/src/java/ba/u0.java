/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.t0
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.concurrent.CancellationException
 *  s7.j
 */
package ba;

import ba.t0;
import java.util.concurrent.CancellationException;
import s7.j;

public final class u0
extends CancellationException {
    public final transient t0 q;

    public u0(String string, Throwable throwable, t0 t02) {
        super(string);
        this.q = t02;
        if (throwable != null) {
            this.initCause(throwable);
        }
    }

    public final boolean equals(Object object) {
        u0 u02;
        return object == this || object instanceof u0 && j.b((Object)(u02 = (u0)((Object)object)).getMessage(), (Object)this.getMessage()) && j.b((Object)u02.q, (Object)this.q) && j.b((Object)u02.getCause(), (Object)this.getCause());
        {
        }
    }

    public final Throwable fillInStackTrace() {
        this.setStackTrace(new StackTraceElement[0]);
        return this;
    }

    public final int hashCode() {
        String string = this.getMessage();
        j.f((Object)string);
        int n2 = 31 * (31 * string.hashCode() + this.q.hashCode());
        Throwable throwable = this.getCause();
        int n5 = throwable != null ? throwable.hashCode() : 0;
        return n2 + n5;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(super.toString());
        stringBuilder.append("; job=");
        stringBuilder.append((Object)this.q);
        return stringBuilder.toString();
    }
}

