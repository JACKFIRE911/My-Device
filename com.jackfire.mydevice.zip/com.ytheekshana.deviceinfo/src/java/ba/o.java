/*
 * Decompiled with CFR 0.0.
 */
package ba;

import ba.c1;
import ba.n;
import ba.t0;

public final class o
extends c1
implements n {
    public o(t0 t02) {
        super(true);
        this.A(t02);
    }
}

