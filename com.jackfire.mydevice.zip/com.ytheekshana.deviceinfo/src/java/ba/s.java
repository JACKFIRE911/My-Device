/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package ba;

import m9.f;
import m9.h;
import t9.p;
import u9.k;

public final class s
extends u9.f
implements p {
    public s(k k4, boolean bl) {
        super(2);
    }

    @Override
    public final Object f(Object object, Object object2) {
        return ((h)object).m((f)object2);
    }
}

