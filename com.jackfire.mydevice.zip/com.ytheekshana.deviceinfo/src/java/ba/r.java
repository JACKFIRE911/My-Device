/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  s7.j
 *  t9.l
 */
package ba;

import s7.j;
import t9.l;

public final class r {
    public final Object a;
    public final l b;

    public r(Object object, l l2) {
        this.a = object;
        this.b = l2;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (!(object instanceof r)) {
            return false;
        }
        r r2 = (r)object;
        Object object2 = r2.a;
        if (!j.b((Object)this.a, (Object)object2)) {
            return false;
        }
        return j.b((Object)this.b, (Object)r2.b);
    }

    public final int hashCode() {
        Object object = this.a;
        int n2 = object == null ? 0 : object.hashCode();
        return n2 * 31 + this.b.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("CompletedWithCancellation(result=");
        stringBuilder.append(this.a);
        stringBuilder.append(", onCancellation=");
        stringBuilder.append((Object)this.b);
        stringBuilder.append(')');
        return stringBuilder.toString();
    }
}

