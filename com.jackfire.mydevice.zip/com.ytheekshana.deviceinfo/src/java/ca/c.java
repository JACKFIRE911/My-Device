/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.util.concurrent.CancellationException
 */
package ca;

import android.os.Handler;
import android.os.Looper;
import ba.b0;
import ba.e0;
import ba.e1;
import ba.h;
import j1.b;
import java.util.concurrent.CancellationException;
import s7.j;
import t9.l;
import u5.e;

public final class c
extends e1
implements b0 {
    private volatile c _immediate;
    public final Handler s;
    public final String t;
    public final boolean u;
    public final c v;

    public c(Handler handler) {
        this(handler, null, false);
    }

    public c(Handler handler, String string, boolean bl) {
        this.s = handler;
        this.t = string;
        this.u = bl;
        c c2 = bl ? this : null;
        c c3 = this._immediate = c2;
        if (c3 == null) {
            this._immediate = c3 = new c(handler, string, true);
        }
        this.v = c3;
    }

    @Override
    public final void D(m9.h h2, Runnable runnable) {
        if (!this.s.post(runnable)) {
            this.G(h2, runnable);
        }
    }

    @Override
    public final boolean F() {
        return !this.u || !j.b((Object)Looper.myLooper(), (Object)this.s.getLooper());
        {
        }
    }

    public final void G(m9.h h2, Runnable runnable) {
        StringBuilder stringBuilder = new StringBuilder("The task was rejected, the handler underlying the dispatcher '");
        stringBuilder.append((Object)this);
        stringBuilder.append("' was closed");
        y6.e.j(h2, new CancellationException(stringBuilder.toString()));
        e0.b.D(h2, runnable);
    }

    @Override
    public final void e(long l3, h h2) {
        e e2 = new e((Object)h2, 21, this);
        if (l3 > 0x3FFFFFFFFFFFFFFFL) {
            l3 = 0x3FFFFFFFFFFFFFFFL;
        }
        if (this.s.postDelayed((Runnable)e2, l3)) {
            h2.r(new b(this, 2, e2));
            return;
        }
        this.G(h2.u, e2);
    }

    public final boolean equals(Object object) {
        return object instanceof c && ((c)object).s == this.s;
    }

    public final int hashCode() {
        return System.identityHashCode((Object)this.s);
    }

    /*
     * Exception decompiling
     */
    @Override
    public final String toString() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl18 : ALOAD_0 : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }
}

