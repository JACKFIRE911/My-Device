/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  ba.e1
 *  ca.c
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.List
 */
package ca;

import android.os.Handler;
import android.os.Looper;
import ba.e1;
import ca.c;
import ca.d;
import da.m;
import java.util.List;

public final class a
implements m {
    @Override
    public String a() {
        return "For tests Dispatchers.setMain from kotlinx-coroutines-test module can be used";
    }

    @Override
    public e1 b(List list) {
        Looper looper = Looper.getMainLooper();
        if (looper != null) {
            return new c(d.a(looper));
        }
        throw new IllegalStateException("The main looper is not available");
    }

    @Override
    public int c() {
        return 1073741823;
    }
}

