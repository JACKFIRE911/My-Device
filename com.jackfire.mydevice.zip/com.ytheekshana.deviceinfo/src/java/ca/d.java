/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.os.Handler$Callback
 *  android.os.Looper
 *  android.view.Choreographer
 *  ca.c
 *  j9.d
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.NoSuchMethodException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 *  java.lang.reflect.Method
 *  s7.j
 */
package ca;

import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Choreographer;
import ba.x;
import ca.c;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import s7.j;

public abstract class d {
    private static volatile Choreographer choreographer;

    public static {
        j9.d d2;
        try {
            d2 = new c(d.a(Looper.getMainLooper()));
        }
        catch (Throwable throwable) {
            d2 = x.e(throwable);
        }
        if (d2 instanceof j9.d) {
            d2 = null;
        }
        (c)d2;
    }

    public static final Handler a(Looper looper) {
        Constructor constructor;
        if (Build.VERSION.SDK_INT >= 28) {
            Object object = Handler.class.getDeclaredMethod("createAsync", new Class[]{Looper.class}).invoke(null, new Object[]{looper});
            j.g((Object)object, (String)"null cannot be cast to non-null type android.os.Handler");
            return (Handler)object;
        }
        try {
            Class[] arrclass = new Class[]{Looper.class, Handler.Callback.class, Boolean.TYPE};
            constructor = Handler.class.getDeclaredConstructor(arrclass);
        }
        catch (NoSuchMethodException noSuchMethodException) {
            return new Handler(looper);
        }
        Object[] arrobject = new Object[]{looper, null, Boolean.TRUE};
        return (Handler)constructor.newInstance(arrobject);
    }
}

