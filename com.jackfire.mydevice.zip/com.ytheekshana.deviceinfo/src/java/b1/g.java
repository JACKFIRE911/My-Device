/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.a0
 *  java.lang.Object
 *  java.lang.String
 */
package b1;

import androidx.fragment.app.a0;
import b1.h;
import s7.j;

public abstract class g
extends h {
    public g(a0 a02, String string) {
        j.i((Object)a02, "fragment");
        super(a02, string);
    }
}

