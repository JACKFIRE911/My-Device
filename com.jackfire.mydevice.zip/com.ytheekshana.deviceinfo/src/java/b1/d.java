/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.ViewGroup
 *  androidx.fragment.app.a0
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b1;

import android.view.ViewGroup;
import androidx.fragment.app.a0;
import b1.h;
import s7.j;

public final class d
extends h {
    public final ViewGroup r;

    public d(a0 a02, ViewGroup viewGroup, int n2) {
        if (n2 != 1) {
            StringBuilder stringBuilder = new StringBuilder("Attempting to use <fragment> tag to add fragment ");
            stringBuilder.append((Object)a02);
            stringBuilder.append(" to container ");
            stringBuilder.append((Object)viewGroup);
            super(a02, stringBuilder.toString());
            this.r = viewGroup;
            return;
        }
        j.i((Object)viewGroup, "container");
        StringBuilder stringBuilder = new StringBuilder("Attempting to add fragment ");
        stringBuilder.append((Object)a02);
        stringBuilder.append(" to container ");
        stringBuilder.append((Object)viewGroup);
        stringBuilder.append(" which is not a FragmentContainerView");
        super(a02, stringBuilder.toString());
        this.r = viewGroup;
    }

    public d(a0 a02, String string) {
        j.i((Object)a02, "fragment");
        j.i(string, "previousFragmentId");
        StringBuilder stringBuilder = new StringBuilder("Attempting to reuse fragment ");
        stringBuilder.append((Object)a02);
        stringBuilder.append(" with previous ID ");
        stringBuilder.append(string);
        super(a02, stringBuilder.toString());
    }
}

