/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.a0
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b1;

import androidx.fragment.app.a0;
import b1.g;
import s7.j;

public final class e
extends g {
    public e(a0 a02) {
        j.i((Object)a02, "fragment");
        StringBuilder stringBuilder = new StringBuilder("Attempting to get target fragment from fragment ");
        stringBuilder.append((Object)a02);
        super(a02, stringBuilder.toString());
    }
}

