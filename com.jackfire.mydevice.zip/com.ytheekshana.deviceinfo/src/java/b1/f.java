/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.a0
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b1;

import androidx.fragment.app.a0;
import b1.g;
import s7.j;

public final class f
extends g {
    public f(a0 a02, a0 a03) {
        j.i((Object)a02, "fragment");
        j.i((Object)a03, "targetFragment");
        StringBuilder stringBuilder = new StringBuilder("Attempting to set target fragment ");
        stringBuilder.append((Object)a03);
        stringBuilder.append(" with request code 0 for fragment ");
        stringBuilder.append((Object)a02);
        super(a02, stringBuilder.toString());
    }
}

