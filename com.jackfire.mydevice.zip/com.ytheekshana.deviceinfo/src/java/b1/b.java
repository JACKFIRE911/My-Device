/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.LinkedHashMap
 *  java.util.Set
 *  k9.l
 */
package b1;

import java.util.LinkedHashMap;
import java.util.Set;
import k9.l;

public final class b {
    public static final b c = new b();
    public final Set a;
    public final LinkedHashMap b;

    public b() {
        l l2 = l.q;
        this.a = l2;
        this.b = new LinkedHashMap();
    }
}

