/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.fragment.app.a0
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  s7.j
 */
package b1;

import androidx.fragment.app.a0;
import s7.j;

public abstract class h
extends RuntimeException {
    public final a0 q;

    public h(a0 a02, String string) {
        j.i((Object)a02, (String)"fragment");
        super(string);
        this.q = a02;
    }
}

