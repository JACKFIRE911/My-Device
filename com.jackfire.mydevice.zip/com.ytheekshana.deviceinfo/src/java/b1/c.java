/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Handler
 *  android.os.Looper
 *  android.util.Log
 *  androidx.fragment.app.a0
 *  androidx.fragment.app.c0
 *  androidx.fragment.app.u0
 *  b1.d
 *  java.lang.ArithmeticException
 *  java.lang.Class
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.Collection
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  java.util.List
 *  java.util.Set
 *  s7.j
 */
package b1;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.fragment.app.a0;
import androidx.fragment.app.c0;
import androidx.fragment.app.u0;
import b1.a;
import b1.b;
import b1.d;
import b1.h;
import e.s0;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Set;
import s7.j;

public abstract class c {
    public static final b a = b.c;

    public static b a(a0 a02) {
        while (a02 != null) {
            if (a02.w()) {
                a02.p();
            }
            a02 = a02.K;
        }
        return a;
    }

    public static void b(b b2, h h2) {
        a0 a02 = h2.q;
        String string = a02.getClass().getName();
        Set set = b2.a;
        a a2 = a.q;
        if (set.contains((Object)a2)) {
            Log.d((String)"FragmentStrictMode", (String)"Policy violation in ".concat(string), (Throwable)h2);
        }
        if (set.contains((Object)a.r)) {
            s0 s02 = new s0(string, 4, (Object)h2);
            if (a02.w()) {
                Handler handler = a02.p().t.F;
                j.h((Object)handler, (String)"fragment.parentFragmentManager.host.handler");
                if (j.b((Object)handler.getLooper(), (Object)Looper.myLooper())) {
                    s02.run();
                    return;
                }
                handler.post((Runnable)s02);
                return;
            }
            s02.run();
        }
    }

    public static void c(h h2) {
        if (u0.K((int)3)) {
            Log.d((String)"FragmentManager", (String)"StrictMode violation in ".concat(h2.q.getClass().getName()), (Throwable)h2);
        }
    }

    public static final void d(a0 a02, String string) {
        j.i((Object)a02, (String)"fragment");
        j.i((Object)string, (String)"previousFragmentId");
        d d2 = new d(a02, string);
        c.c((h)d2);
        b b2 = c.a(a02);
        if (b2.a.contains((Object)a.s) && c.e(b2, a02.getClass(), d.class)) {
            c.b(b2, (h)d2);
        }
    }

    public static boolean e(b b2, Class class_, Class class_2) {
        String string = class_.getName();
        Set set = (Set)b2.b.get((Object)string);
        if (set == null) {
            return true;
        }
        if (!j.b((Object)class_2.getSuperclass(), h.class)) {
            boolean bl;
            Iterable iterable = (Iterable)set;
            Class class_3 = class_2.getSuperclass();
            if (iterable instanceof Collection) {
                bl = ((Collection)iterable).contains((Object)class_3);
            } else {
                int n2;
                block10 : {
                    if (iterable instanceof List) {
                        n2 = ((List)iterable).indexOf((Object)class_3);
                    } else {
                        Iterator iterator = iterable.iterator();
                        int n3 = 0;
                        while (iterator.hasNext()) {
                            Object object = iterator.next();
                            if (n3 >= 0) {
                                if (j.b((Object)class_3, (Object)object)) {
                                    n2 = n3;
                                    break block10;
                                }
                                ++n3;
                                continue;
                            }
                            throw new ArithmeticException("Index overflow has happened.");
                        }
                        n2 = -1;
                    }
                }
                bl = n2 >= 0;
            }
            if (bl) {
                return false;
            }
        }
        return true ^ set.contains((Object)class_2);
    }
}

