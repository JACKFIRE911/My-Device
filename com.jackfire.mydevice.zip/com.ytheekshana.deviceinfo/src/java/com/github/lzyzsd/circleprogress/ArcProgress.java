/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.graphics.Canvas
 *  android.graphics.Color
 *  android.graphics.Paint
 *  android.graphics.Paint$Cap
 *  android.graphics.Paint$Style
 *  android.graphics.RectF
 *  android.os.Bundle
 *  android.os.Parcelable
 *  android.text.TextPaint
 *  android.text.TextUtils
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  java.lang.CharSequence
 *  java.lang.Math
 *  java.lang.String
 *  o3.a
 */
package com.github.lzyzsd.circleprogress;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextPaint;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View;
import o3.a;

public class ArcProgress
extends View {
    public int A;
    public int B;
    public int C;
    public float D;
    public String E;
    public float F;
    public float G;
    public final int H;
    public final int I;
    public Paint q;
    public TextPaint r;
    public final RectF s = new RectF();
    public float t;
    public float u;
    public float v;
    public String w;
    public float x;
    public int y;
    public int z = 0;

    public ArcProgress(Context context, AttributeSet attributeSet) {
        int n2;
        String string;
        super(context, attributeSet, 0);
        this.E = string = "%";
        this.H = n2 = Color.rgb((int)72, (int)106, (int)176);
        int n5 = Color.rgb((int)66, (int)145, (int)241);
        this.I = (int)(0.5f + 100.0f * this.getResources().getDisplayMetrics().density);
        float f2 = 40.0f * this.getResources().getDisplayMetrics().scaledDensity;
        float f4 = 15.0f * this.getResources().getDisplayMetrics().scaledDensity;
        float f5 = 0.5f + 4.0f * this.getResources().getDisplayMetrics().density;
        float f6 = 10.0f * this.getResources().getDisplayMetrics().scaledDensity;
        float f7 = 0.5f + 4.0f * this.getResources().getDisplayMetrics().density;
        TypedArray typedArray = context.getTheme().obtainStyledAttributes(attributeSet, a.a, 0, 0);
        this.B = typedArray.getColor(3, -1);
        this.C = typedArray.getColor(12, n2);
        this.y = typedArray.getColor(10, n5);
        this.x = typedArray.getDimension(11, f2);
        this.D = typedArray.getFloat(0, 288.0f);
        this.setMax(typedArray.getInt(4, 100));
        this.setProgress(typedArray.getInt(5, 0));
        this.t = typedArray.getDimension(6, f7);
        this.u = typedArray.getDimension(9, f4);
        if (!TextUtils.isEmpty((CharSequence)typedArray.getString(7))) {
            string = typedArray.getString(7);
        }
        this.E = string;
        this.F = typedArray.getDimension(8, f5);
        this.v = typedArray.getDimension(2, f6);
        this.w = typedArray.getString(1);
        typedArray.recycle();
        this.a();
    }

    public final void a() {
        TextPaint textPaint;
        Paint paint;
        this.r = textPaint = new TextPaint();
        textPaint.setColor(this.y);
        this.r.setTextSize(this.x);
        this.r.setAntiAlias(true);
        this.q = paint = new Paint();
        paint.setColor(this.H);
        this.q.setAntiAlias(true);
        this.q.setStrokeWidth(this.t);
        this.q.setStyle(Paint.Style.STROKE);
        this.q.setStrokeCap(Paint.Cap.ROUND);
    }

    public float getArcAngle() {
        return this.D;
    }

    public String getBottomText() {
        return this.w;
    }

    public float getBottomTextSize() {
        return this.v;
    }

    public int getFinishedStrokeColor() {
        return this.B;
    }

    public int getMax() {
        return this.A;
    }

    public int getProgress() {
        return this.z;
    }

    public float getStrokeWidth() {
        return this.t;
    }

    public String getSuffixText() {
        return this.E;
    }

    public float getSuffixTextPadding() {
        return this.F;
    }

    public float getSuffixTextSize() {
        return this.u;
    }

    public int getSuggestedMinimumHeight() {
        return this.I;
    }

    public int getSuggestedMinimumWidth() {
        return this.I;
    }

    public int getTextColor() {
        return this.y;
    }

    public float getTextSize() {
        return this.x;
    }

    public int getUnfinishedStrokeColor() {
        return this.C;
    }

    public final void invalidate() {
        this.a();
        super.invalidate();
    }

    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float f2 = 270.0f - this.D / 2.0f;
        float f4 = (float)this.z / (float)this.getMax() * this.D;
        float f5 = this.z == 0 ? 0.01f : f2;
        this.q.setColor(this.C);
        RectF rectF = this.s;
        canvas.drawArc(rectF, f2, this.D, false, this.q);
        this.q.setColor(this.B);
        Paint paint = this.q;
        canvas.drawArc(rectF, f5, f4, false, paint);
        String string = String.valueOf((int)this.getProgress());
        if (!TextUtils.isEmpty((CharSequence)string)) {
            this.r.setColor(this.y);
            this.r.setTextSize(this.x);
            float f6 = this.r.descent() + this.r.ascent();
            float f7 = ((float)this.getHeight() - f6) / 2.0f;
            canvas.drawText(string, ((float)this.getWidth() - this.r.measureText(string)) / 2.0f, f7, (Paint)this.r);
            this.r.setTextSize(this.u);
            float f8 = this.r.descent() + this.r.ascent();
            canvas.drawText(this.E, (float)this.getWidth() / 2.0f + this.r.measureText(string) + this.F, f7 + f6 - f8, (Paint)this.r);
        }
        if (this.G == 0.0f) {
            this.G = (float)this.getWidth() / 2.0f * (float)(1.0 - Math.cos((double)(3.141592653589793 * (double)((360.0f - this.D) / 2.0f / 180.0f))));
        }
        if (!TextUtils.isEmpty((CharSequence)this.getBottomText())) {
            this.r.setTextSize(this.v);
            float f10 = (float)this.getHeight() - this.G - (this.r.descent() + this.r.ascent()) / 2.0f;
            canvas.drawText(this.getBottomText(), ((float)this.getWidth() - this.r.measureText(this.getBottomText())) / 2.0f, f10, (Paint)this.r);
        }
    }

    public final void onMeasure(int n2, int n5) {
        this.setMeasuredDimension(n2, n5);
        int n6 = View.MeasureSpec.getSize((int)n2);
        RectF rectF = this.s;
        float f2 = this.t;
        float f4 = f2 / 2.0f;
        float f5 = f2 / 2.0f;
        float f6 = n6;
        rectF.set(f4, f5, f6 - f2 / 2.0f, (float)View.MeasureSpec.getSize((int)n5) - this.t / 2.0f);
        this.G = f6 / 2.0f * (float)(1.0 - Math.cos((double)(3.141592653589793 * (double)((360.0f - this.D) / 2.0f / 180.0f))));
    }

    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof Bundle) {
            Bundle bundle = (Bundle)parcelable;
            this.t = bundle.getFloat("stroke_width");
            this.u = bundle.getFloat("suffix_text_size");
            this.F = bundle.getFloat("suffix_text_padding");
            this.v = bundle.getFloat("bottom_text_size");
            this.w = bundle.getString("bottom_text");
            this.x = bundle.getFloat("text_size");
            this.y = bundle.getInt("text_color");
            this.setMax(bundle.getInt("max"));
            this.setProgress(bundle.getInt("progress"));
            this.B = bundle.getInt("finished_stroke_color");
            this.C = bundle.getInt("unfinished_stroke_color");
            this.E = bundle.getString("suffix");
            this.a();
            super.onRestoreInstanceState(bundle.getParcelable("saved_instance"));
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    public final Parcelable onSaveInstanceState() {
        Bundle bundle = new Bundle();
        bundle.putParcelable("saved_instance", super.onSaveInstanceState());
        bundle.putFloat("stroke_width", this.getStrokeWidth());
        bundle.putFloat("suffix_text_size", this.getSuffixTextSize());
        bundle.putFloat("suffix_text_padding", this.getSuffixTextPadding());
        bundle.putFloat("bottom_text_size", this.getBottomTextSize());
        bundle.putString("bottom_text", this.getBottomText());
        bundle.putFloat("text_size", this.getTextSize());
        bundle.putInt("text_color", this.getTextColor());
        bundle.putInt("progress", this.getProgress());
        bundle.putInt("max", this.getMax());
        bundle.putInt("finished_stroke_color", this.getFinishedStrokeColor());
        bundle.putInt("unfinished_stroke_color", this.getUnfinishedStrokeColor());
        bundle.putFloat("arc_angle", this.getArcAngle());
        bundle.putString("suffix", this.getSuffixText());
        return bundle;
    }

    public void setArcAngle(float f2) {
        this.D = f2;
        this.invalidate();
    }

    public void setBottomText(String string) {
        this.w = string;
        this.invalidate();
    }

    public void setBottomTextSize(float f2) {
        this.v = f2;
        this.invalidate();
    }

    public void setFinishedStrokeColor(int n2) {
        this.B = n2;
        this.invalidate();
    }

    public void setMax(int n2) {
        if (n2 > 0) {
            this.A = n2;
            this.invalidate();
        }
    }

    public void setProgress(int n2) {
        this.z = n2;
        if (n2 > this.getMax()) {
            this.z %= this.getMax();
        }
        this.invalidate();
    }

    public void setStrokeWidth(float f2) {
        this.t = f2;
        this.invalidate();
    }

    public void setSuffixText(String string) {
        this.E = string;
        this.invalidate();
    }

    public void setSuffixTextPadding(float f2) {
        this.F = f2;
        this.invalidate();
    }

    public void setSuffixTextSize(float f2) {
        this.u = f2;
        this.invalidate();
    }

    public void setTextColor(int n2) {
        this.y = n2;
        this.invalidate();
    }

    public void setTextSize(float f2) {
        this.x = f2;
        this.invalidate();
    }

    public void setUnfinishedStrokeColor(int n2) {
        this.C = n2;
        this.invalidate();
    }
}

