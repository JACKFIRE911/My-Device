/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.util.AttributeSet
 *  java.lang.Object
 *  java.lang.ref.WeakReference
 */
package com.github.mikephil.charting.charts;

import a4.i;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.AttributeSet;
import java.lang.ref.WeakReference;
import q3.a;
import s3.c;
import s3.f;
import z3.b;
import z3.e;

public class LineChart
extends a
implements v3.c {
    public LineChart(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    @Override
    public final void e() {
        super.e();
        this.F = new e(this, this.I, this.H);
    }

    @Override
    public f getLineData() {
        return (f)this.r;
    }

    @Override
    public final void onDetachedFromWindow() {
        b b3 = this.F;
        if (b3 != null && b3 instanceof e) {
            WeakReference weakReference;
            e e3 = (e)b3;
            Canvas canvas = e3.A;
            if (canvas != null) {
                canvas.setBitmap(null);
                e3.A = null;
            }
            if ((weakReference = e3.z) != null) {
                Bitmap bitmap = (Bitmap)weakReference.get();
                if (bitmap != null) {
                    bitmap.recycle();
                }
                e3.z.clear();
                e3.z = null;
            }
        }
        q3.c.super.onDetachedFromWindow();
    }
}

