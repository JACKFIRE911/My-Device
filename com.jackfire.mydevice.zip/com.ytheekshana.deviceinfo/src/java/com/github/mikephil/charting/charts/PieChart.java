/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.RectF
 *  android.graphics.Typeface
 *  android.text.TextPaint
 *  android.util.AttributeSet
 *  android.util.Log
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 */
package com.github.mikephil.charting.charts;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import j2.l;
import java.lang.ref.WeakReference;
import p3.a;
import q3.d;
import r3.e;
import s.h;
import s3.c;
import s3.i;
import s3.j;
import u3.b;
import z3.g;

public class PieChart
extends d {
    public final RectF W = new RectF();
    public boolean a0 = true;
    public float[] b0 = new float[1];
    public float[] c0 = new float[1];
    public boolean d0 = true;
    public boolean e0 = false;
    public boolean f0 = false;
    public boolean g0 = false;
    public CharSequence h0 = "";
    public final a4.d i0 = a4.d.b(0.0f, 0.0f);
    public float j0 = 50.0f;
    public float k0 = 55.0f;
    public boolean l0 = true;
    public float m0 = 100.0f;
    public float n0 = 360.0f;
    public float o0 = 0.0f;

    public PieChart(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void a() {
        block21 : {
            block10 : {
                block17 : {
                    block20 : {
                        block18 : {
                            block19 : {
                                block12 : {
                                    block11 : {
                                        block15 : {
                                            block13 : {
                                                block16 : {
                                                    block14 : {
                                                        var1_1 = this.B;
                                                        var2_2 = this.H;
                                                        var3_3 = 0.0f;
                                                        if (var1_1 == null || !var1_1.a || var1_1.j) break block10;
                                                        var31_4 = Math.min((float)var1_1.s, (float)(var2_2.c * var1_1.r));
                                                        var32_5 = h.c(this.B.i);
                                                        if (var32_5 == 0) break block11;
                                                        if (var32_5 != 1) break block12;
                                                        var42_6 = this.B;
                                                        var43_7 = var42_6.g;
                                                        if (var43_7 != 1 && var43_7 != 3) {
                                                            var44_8 = 0.0f;
                                                        } else if (var42_6.h == 2) {
                                                            var44_8 = var31_4 + a4.h.c(13.0f);
                                                        } else {
                                                            var44_8 = var31_4 + a4.h.c(8.0f);
                                                            var45_9 = this.B;
                                                            var46_10 = var45_9.t + var45_9.u;
                                                            var47_11 = this.getCenter();
                                                            var48_12 = this.B.g == 3 ? 15.0f + ((float)this.getWidth() - var44_8) : var44_8 - 15.0f;
                                                            var49_13 = var46_10 + 15.0f;
                                                            var50_14 = this.h(var48_12, var49_13);
                                                            var51_15 = this.getRadius();
                                                            var52_16 = this.i(var48_12, var49_13);
                                                            var53_17 = a4.d.b(0.0f, 0.0f);
                                                            var54_18 = var47_11.r;
                                                            var56_19 = var51_15;
                                                            var58_20 = var52_16;
                                                            var53_17.r = (float)(var54_18 + var56_19 * Math.cos((double)Math.toRadians((double)var58_20)));
                                                            var53_17.s = var60_21 = (float)((double)var47_11.s + var56_19 * Math.sin((double)Math.toRadians((double)var58_20)));
                                                            var61_22 = this.h(var53_17.r, var60_21);
                                                            var62_23 = a4.h.c(5.0f);
                                                            if (!(var49_13 >= var47_11.s) || !((float)this.getHeight() - var44_8 > (float)this.getWidth())) {
                                                                var44_8 = var50_14 < var61_22 ? var62_23 + (var61_22 - var50_14) : 0.0f;
                                                            }
                                                            a4.d.c(var47_11);
                                                            a4.d.c(var53_17);
                                                        }
                                                        var63_24 = h.c(this.B.g);
                                                        if (var63_24 == 0) break block13;
                                                        if (var63_24 == 1) break block14;
                                                        if (var63_24 != 2) ** GOTO lbl-1000
                                                        var39_25 = var44_8;
                                                        var64_26 = 0.0f;
                                                        var3_3 = 0.0f;
                                                        var65_27 = 0.0f;
                                                        break block15;
                                                    }
                                                    var67_28 = h.c(this.B.h);
                                                    if (var67_28 != 0) {
                                                        ** if (var67_28 == 2) goto lbl-1000
                                                    }
                                                    break block16;
lbl-1000: // 2 sources:
                                                    {
                                                        var64_26 = 0.0f;
                                                        ** GOTO lbl56
                                                    }
lbl-1000: // 1 sources:
                                                    {
                                                        var69_29 = this.B;
                                                        var64_26 = Math.min((float)var69_29.t, (float)(var2_2.d * var69_29.r));
                                                    }
lbl56: // 2 sources:
                                                    var3_3 = 0.0f;
                                                    var65_27 = 0.0f;
                                                    var39_25 = 0.0f;
                                                    break block15;
                                                }
                                                var68_30 = this.B;
                                                var65_27 = Math.min((float)var68_30.t, (float)(var2_2.d * var68_30.r));
                                                var64_26 = 0.0f;
                                                var3_3 = 0.0f;
                                                var39_25 = 0.0f;
                                                break block15;
                                            }
                                            var64_26 = 0.0f;
                                            var39_25 = 0.0f;
                                            var3_3 = var44_8;
                                            var65_27 = 0.0f;
                                        }
                                        var66_31 = var65_27;
                                        var38_32 = var64_26;
                                        var36_33 = var66_31;
                                        break block17;
                                    }
                                    var33_34 = this.B.h;
                                    if (var33_34 != 1 && var33_34 != 3) break block12;
                                    var34_35 = this.getRequiredLegendOffset();
                                    var35_36 = this.B;
                                    var36_33 = Math.min((float)(var34_35 + var35_36.t), (float)(var2_2.d * var35_36.r));
                                    var37_37 = h.c(this.B.h);
                                    if (var37_37 == 0) break block18;
                                    if (var37_37 == 2) break block19;
                                }
                                var38_32 = 0.0f;
                                var36_33 = 0.0f;
                                break block20;
                            }
                            var38_32 = var36_33;
                            var36_33 = 0.0f;
                            var3_3 = 0.0f;
                            var39_25 = 0.0f;
                            break block17;
                        }
                        var38_32 = 0.0f;
                    }
                    var39_25 = 0.0f;
                }
                var40_38 = var3_3 + this.getRequiredBaseOffset();
                var6_39 = var39_25 + this.getRequiredBaseOffset();
                var41_40 = var36_33 + this.getRequiredBaseOffset();
                var5_41 = var38_32 + this.getRequiredBaseOffset();
                var3_3 = var41_40;
                var4_42 = var40_38;
                break block21;
            }
            var4_42 = 0.0f;
            var5_41 = 0.0f;
            var6_39 = 0.0f;
        }
        var7_43 = a4.h.c(this.V);
        var8_44 = var3_3 + this.getExtraTopOffset();
        var9_45 = var6_39 + this.getExtraRightOffset();
        var10_46 = var5_41 + this.getExtraBottomOffset();
        var11_47 = Math.max((float)var7_43, (float)(var4_42 + this.getExtraLeftOffset()));
        var12_48 = Math.max((float)var7_43, (float)var8_44);
        var13_49 = Math.max((float)var7_43, (float)var9_45);
        var14_50 = Math.max((float)var7_43, (float)Math.max((float)this.getRequiredBaseOffset(), (float)var10_46));
        var2_2.b.set(var11_47, var12_48, var2_2.c - var13_49, var2_2.d - var14_50);
        if (this.q) {
            var15_51 = new StringBuilder("offsetLeft: ");
            var15_51.append(var11_47);
            var15_51.append(", offsetTop: ");
            var15_51.append(var12_48);
            var15_51.append(", offsetRight: ");
            var15_51.append(var13_49);
            var15_51.append(", offsetBottom: ");
            var15_51.append(var14_50);
            Log.i((String)"MPAndroidChart", (String)var15_51.toString());
        }
        if (this.r == null) {
            return;
        }
        var24_52 = this.getDiameter() / 2.0f;
        var25_53 = this.getCenterOffsets();
        var26_54 = ((i)this.r).k().t;
        var27_55 = this.W;
        var28_56 = var25_53.r;
        var29_57 = var26_54 + (var28_56 - var24_52);
        var30_58 = var25_53.s;
        var27_55.set(var29_57, var26_54 + (var30_58 - var24_52), var28_56 + var24_52 - var26_54, var30_58 + var24_52 - var26_54);
        a4.d.c(var25_53);
    }

    @Override
    public final void e() {
        super.e();
        this.F = new g(this, this.I, this.H);
        this.y = null;
        this.G = new l(this);
    }

    public float[] getAbsoluteAngles() {
        return this.c0;
    }

    public a4.d getCenterCircleBox() {
        RectF rectF = this.W;
        return a4.d.b(rectF.centerX(), rectF.centerY());
    }

    public CharSequence getCenterText() {
        return this.h0;
    }

    public a4.d getCenterTextOffset() {
        a4.d d3 = this.i0;
        return a4.d.b(d3.r, d3.s);
    }

    public float getCenterTextRadiusPercent() {
        return this.m0;
    }

    public RectF getCircleBox() {
        return this.W;
    }

    public float[] getDrawAngles() {
        return this.b0;
    }

    public float getHoleRadius() {
        return this.j0;
    }

    public float getMaxAngle() {
        return this.n0;
    }

    public float getMinAngleForSlices() {
        return this.o0;
    }

    @Override
    public float getRadius() {
        RectF rectF = this.W;
        if (rectF == null) {
            return 0.0f;
        }
        return Math.min((float)(rectF.width() / 2.0f), (float)(rectF.height() / 2.0f));
    }

    @Override
    public float getRequiredBaseOffset() {
        return 0.0f;
    }

    @Override
    public float getRequiredLegendOffset() {
        return 2.0f * this.E.r.getTextSize();
    }

    public float getTransparentCircleRadius() {
        return this.k0;
    }

    @Deprecated
    @Override
    public r3.g getXAxis() {
        throw new RuntimeException("PieChart has no XAxis");
    }

    @Override
    public final void onDetachedFromWindow() {
        z3.b b3 = this.F;
        if (b3 != null && b3 instanceof g) {
            WeakReference weakReference;
            g g2 = (g)b3;
            Canvas canvas = g2.G;
            if (canvas != null) {
                canvas.setBitmap(null);
                g2.G = null;
            }
            if ((weakReference = g2.F) != null) {
                Bitmap bitmap = (Bitmap)weakReference.get();
                if (bitmap != null) {
                    bitmap.recycle();
                }
                g2.F.clear();
                g2.F = null;
            }
        }
        q3.c.super.onDetachedFromWindow();
    }

    @Override
    public final void onDraw(Canvas canvas) {
        q3.c.super.onDraw(canvas);
        if (this.r == null) {
            return;
        }
        this.F.k(canvas);
        b[] arrb = this.O;
        boolean bl = false;
        if (arrb != null) {
            int n3 = arrb.length;
            bl = false;
            if (n3 > 0) {
                bl = arrb[0] != null;
            }
        }
        if (bl) {
            this.F.m(canvas, arrb);
        }
        this.F.l(canvas);
        this.F.n(canvas);
        this.E.m(canvas);
        this.b(canvas);
    }

    public void setCenterText(CharSequence charSequence) {
        if (charSequence == null) {
            this.h0 = "";
            return;
        }
        this.h0 = charSequence;
    }

    public void setCenterTextColor(int n3) {
        ((g)this.F).z.setColor(n3);
    }

    public void setCenterTextRadiusPercent(float f4) {
        this.m0 = f4;
    }

    public void setCenterTextSize(float f4) {
        ((g)this.F).z.setTextSize(a4.h.c(f4));
    }

    public void setCenterTextSizePixels(float f4) {
        ((g)this.F).z.setTextSize(f4);
    }

    public void setCenterTextTypeface(Typeface typeface) {
        ((g)this.F).z.setTypeface(typeface);
    }

    public void setDrawCenterText(boolean bl) {
        this.l0 = bl;
    }

    public void setDrawEntryLabels(boolean bl) {
        this.a0 = bl;
    }

    public void setDrawHoleEnabled(boolean bl) {
        this.d0 = bl;
    }

    public void setDrawRoundedSlices(boolean bl) {
        this.g0 = bl;
    }

    @Deprecated
    public void setDrawSliceText(boolean bl) {
        this.a0 = bl;
    }

    public void setDrawSlicesUnderHole(boolean bl) {
        this.e0 = bl;
    }

    public void setEntryLabelColor(int n3) {
        ((g)this.F).A.setColor(n3);
    }

    public void setEntryLabelTextSize(float f4) {
        ((g)this.F).A.setTextSize(a4.h.c(f4));
    }

    public void setEntryLabelTypeface(Typeface typeface) {
        ((g)this.F).A.setTypeface(typeface);
    }

    public void setHoleColor(int n3) {
        ((g)this.F).w.setColor(n3);
    }

    public void setHoleRadius(float f4) {
        this.j0 = f4;
    }

    public void setMaxAngle(float f4) {
        if (f4 > 360.0f) {
            f4 = 360.0f;
        }
        if (f4 < 90.0f) {
            f4 = 90.0f;
        }
        this.n0 = f4;
    }

    public void setMinAngleForSlices(float f4) {
        float f6 = this.n0;
        if (f4 > f6 / 2.0f) {
            f4 = f6 / 2.0f;
        } else if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        this.o0 = f4;
    }

    public void setTransparentCircleAlpha(int n3) {
        ((g)this.F).x.setAlpha(n3);
    }

    public void setTransparentCircleColor(int n3) {
        Paint paint = ((g)this.F).x;
        int n5 = paint.getAlpha();
        paint.setColor(n3);
        paint.setAlpha(n5);
    }

    public void setTransparentCircleRadius(float f4) {
        this.k0 = f4;
    }

    public void setUsePercentValues(boolean bl) {
        this.f0 = bl;
    }
}

