/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.media.MediaDrm
 *  android.os.Bundle
 *  android.view.View
 *  android.view.animation.Animation
 *  android.view.animation.AnimationUtils
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.LifecycleCoroutineScopeImpl
 *  androidx.lifecycle.u
 *  com.bumptech.glide.d
 *  com.google.android.material.progressindicator.LinearProgressIndicator
 *  java.util.UUID
 */
package com.ytheekshana.deviceinfo;

import android.content.Context;
import android.media.MediaDrm;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.d0;
import androidx.lifecycle.LifecycleCoroutineScopeImpl;
import androidx.lifecycle.u;
import ba.e1;
import ba.w;
import com.bumptech.glide.d;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import e.n;
import java.util.UUID;
import o2.a;
import o2.b;
import s7.j;
import w8.b0;
import w8.f0;
import w8.g0;
import y6.e;

public final class SplashActivity
extends n {
    public static boolean T;
    public final UUID Q = new UUID(-1301668207276963122L, -6645017420763422227L);
    public a R;
    public LinearProgressIndicator S;

    /*
     * Exception decompiling
     */
    public static final MediaDrm s(SplashActivity var0, UUID var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl14.1 : ACONST_NULL : trying to set 0 previously set to 1
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public final void onCreate(Bundle bundle) {
        a a2;
        d0.super.onCreate(bundle);
        this.setContentView(2131558439);
        this.S = (LinearProgressIndicator)this.findViewById(2131362473);
        TextView textView = (TextView)this.findViewById(2131362678);
        ImageView imageView = (ImageView)this.findViewById(2131362245);
        ImageView imageView2 = (ImageView)this.findViewById(2131362246);
        ImageView imageView3 = (ImageView)this.findViewById(2131362247);
        ImageView imageView4 = (ImageView)this.findViewById(2131362248);
        imageView.setAnimation(AnimationUtils.loadAnimation((Context)this, (int)2130772005));
        imageView2.setAnimation(AnimationUtils.loadAnimation((Context)this, (int)2130772002));
        imageView3.setAnimation(AnimationUtils.loadAnimation((Context)this, (int)2130772003));
        imageView4.setAnimation(AnimationUtils.loadAnimation((Context)this, (int)2130772004));
        Animation animation = AnimationUtils.loadAnimation((Context)this, (int)2130771997);
        textView.setAnimation(animation);
        LinearProgressIndicator linearProgressIndicator = this.S;
        if (linearProgressIndicator != null) {
            linearProgressIndicator.setAnimation(animation);
        }
        this.R = a2 = new a((Context)this, new b0());
        a2.d(new f0(this));
        T = true;
        LifecycleCoroutineScopeImpl lifecycleCoroutineScopeImpl = d.k((u)this);
        e.g0((w)lifecycleCoroutineScopeImpl, da.n.a, new g0(this, null), 2);
    }

    @Override
    public final void onDestroy() {
        a a2 = this.R;
        if (a2 != null) {
            a2.a();
            super.onDestroy();
            return;
        }
        j.I("billingClient");
        throw null;
    }
}

