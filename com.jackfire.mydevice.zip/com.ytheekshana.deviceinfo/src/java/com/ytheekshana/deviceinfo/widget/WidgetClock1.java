/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.appwidget.AppWidgetManager
 *  android.appwidget.AppWidgetProvider
 *  android.content.Context
 */
package com.ytheekshana.deviceinfo.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

public final class WidgetClock1
extends AppWidgetProvider {
    public final void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] arrn) {
        super.onUpdate(context, appWidgetManager, arrn);
    }
}

