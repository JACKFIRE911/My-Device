/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.appwidget.AppWidgetManager
 *  android.appwidget.AppWidgetProvider
 *  android.content.Context
 *  android.content.Intent
 *  ba.k1
 *  ba.w0
 *  da.c
 *  ea.c
 *  g9.f
 *  g9.g
 *  g9.h
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  m9.d
 *  m9.h
 *  s7.j
 *  t9.p
 *  w8.d
 *  y6.e
 */
package com.ytheekshana.deviceinfo.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import ba.e0;
import ba.k1;
import ba.w;
import ba.w0;
import ba.x;
import da.c;
import g9.f;
import g9.g;
import g9.h;
import s7.j;
import t9.p;
import w8.d;
import y6.e;

public final class MediumWidget
extends AppWidgetProvider {
    public final k1 a;
    public final c b;

    public MediumWidget() {
        k1 k12;
        this.a = k12 = e.b();
        ea.c c2 = e0.b;
        c2.getClass();
        this.b = e.a((m9.h)e.r0((m9.h)c2, (m9.h)k12).m((m9.h)new d(5)));
    }

    public final void onDeleted(Context context, int[] arrn) {
        f f2 = new f(context, arrn, null);
        e.g0((w)this.b, null, (p)f2, (int)3);
        super.onDeleted(context, arrn);
    }

    public final void onDisabled(Context context) {
        x.a((w0)this.a);
        super.onDisabled(context);
    }

    public final void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String string = intent != null ? intent.getAction() : null;
        if (j.b((Object)"refreshClick", (Object)string)) {
            g g2 = new g(context, null);
            e.g0((w)this.b, null, (p)g2, (int)3);
        }
    }

    public final void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] arrn) {
        h h2 = new h(context, arrn, appWidgetManager, null);
        e.g0((w)this.b, null, (p)h2, (int)3);
    }
}

