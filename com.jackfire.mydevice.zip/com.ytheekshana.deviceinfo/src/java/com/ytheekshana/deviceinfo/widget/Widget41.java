/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.appwidget.AppWidgetManager
 *  android.appwidget.AppWidgetProvider
 *  android.content.Context
 *  android.content.Intent
 *  ba.k1
 *  ba.w0
 *  da.c
 *  ea.c
 *  g9.v
 *  g9.w
 *  g9.x
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  m9.d
 *  m9.h
 *  s7.j
 *  t9.p
 *  w8.d
 *  y6.e
 */
package com.ytheekshana.deviceinfo.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import ba.e0;
import ba.k1;
import ba.w;
import ba.w0;
import ba.x;
import da.c;
import g9.v;
import m9.h;
import s7.j;
import t9.p;
import w8.d;
import y6.e;

public final class Widget41
extends AppWidgetProvider {
    public final k1 a;
    public final c b;

    public Widget41() {
        k1 k12;
        this.a = k12 = e.b();
        ea.c c2 = e0.b;
        c2.getClass();
        this.b = e.a((h)e.r0((h)c2, (h)k12).m((h)new d(8)));
    }

    public final void onDeleted(Context context, int[] arrn) {
        v v2 = new v(context, arrn, null);
        e.g0((w)this.b, null, (p)v2, (int)3);
        super.onDeleted(context, arrn);
    }

    public final void onDisabled(Context context) {
        x.a((w0)this.a);
        super.onDisabled(context);
    }

    public final void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String string = intent != null ? intent.getAction() : null;
        if (j.b((Object)"refreshClick", (Object)string)) {
            g9.w w2 = new g9.w(context, null);
            e.g0((w)this.b, null, (p)w2, (int)3);
        }
    }

    public final void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] arrn) {
        g9.x x2 = new g9.x(context, arrn, appWidgetManager, null);
        e.g0((w)this.b, null, (p)x2, (int)3);
    }
}

