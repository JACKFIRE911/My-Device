/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.work.CoroutineWorker
 *  androidx.work.WorkerParameters
 *  ea.c
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.widget;

import android.content.Context;
import androidx.work.CoroutineWorker;
import androidx.work.WorkerParameters;
import ba.e0;
import ba.x;
import ea.c;
import g9.h0;
import g9.i0;
import m9.d;
import n9.a;
import s7.j;
import y6.e;

public final class WidgetService
extends CoroutineWorker {
    public final Context x;

    public WidgetService(Context context, WorkerParameters workerParameters) {
        j.i((Object)context, "context");
        j.i((Object)workerParameters, "params");
        super(context, workerParameters);
        this.x = context;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final Object a(d var1_1) {
        if (!(var1_1 instanceof h0)) ** GOTO lbl-1000
        var2_2 = (h0)var1_1;
        var8_3 = var2_2.v;
        if ((var8_3 & Integer.MIN_VALUE) != 0) {
            var2_2.v = var8_3 + Integer.MIN_VALUE;
        } else lbl-1000: // 2 sources:
        {
            var2_2 = new h0(this, var1_1);
        }
        var3_4 = var2_2.t;
        var4_5 = a.q;
        var5_6 = var2_2.v;
        if (var5_6 != 0) {
            if (var5_6 != 1) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            x.u(var3_4);
        } else {
            x.u(var3_4);
            var6_7 = e0.b;
            var7_8 = new i0(this, null);
            var2_2.v = 1;
            var3_4 = e.Q0(var6_7, var7_8, var2_2);
            if (var3_4 == var4_5) {
                return var4_5;
            }
        }
        j.h(var3_4, "@RequiresApi(Build.VERSI\u2026failure()\n        }\n    }");
        return var3_4;
    }
}

