/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.u
 *  com.bumptech.glide.d
 *  com.google.android.material.appbar.MaterialToolbar
 *  java.lang.Exception
 */
package com.ytheekshana.deviceinfo.widget;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.d0;
import androidx.lifecycle.u;
import ba.e0;
import ba.w;
import com.bumptech.glide.d;
import com.google.android.material.appbar.MaterialToolbar;
import e.n;
import g9.g0;
import w8.t;
import y6.e;

public final class WidgetActivity
extends n {
    public static final /* synthetic */ int Q;

    public final void onCreate(Bundle bundle) {
        d0.super.onCreate(bundle);
        this.setContentView(2131558454);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        try {
            if (Build.VERSION.SDK_INT < 33) {
                e.k((Context)this, "android.permission.READ_EXTERNAL_STORAGE", new t(this, 8));
            }
            e.g0((w)d.k((u)this), e0.a, new g0(this, null), 2);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }
}

