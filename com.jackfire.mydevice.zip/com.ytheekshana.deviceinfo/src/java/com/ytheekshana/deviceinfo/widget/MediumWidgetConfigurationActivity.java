/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.SeekBar
 *  android.widget.SeekBar$OnSeekBarChangeListener
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  com.google.android.material.chip.ChipGroup
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.Arrays
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.Locale
 */
package com.ytheekshana.deviceinfo.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.fragment.app.d0;
import c0.d;
import c9.f;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import f1.a0;
import g7.b;
import g9.i;
import g9.k;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import m6.h;
import s5.j;
import w8.t;
import y6.e;

public final class MediumWidgetConfigurationActivity
extends n {
    public static final /* synthetic */ int e0;
    public int Q;
    public String R = "";
    public String S = "";
    public String T = "";
    public TextView U;
    public TextView V;
    public TextView W;
    public TextView X;
    public TextView Y;
    public ImageView Z;
    public ImageView a0;
    public ProgressBar b0;
    public ProgressBar c0;
    public int d0;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        SharedPreferences sharedPreferences;
        ChipGroup chipGroup;
        Drawable drawable;
        SeekBar seekBar;
        int n2;
        MaterialButton materialButton;
        TextView textView;
        RelativeLayout relativeLayout;
        ChipGroup chipGroup2;
        ChipGroup chipGroup3;
        MaterialButton materialButton2;
        block24 : {
            ChipGroup chipGroup4;
            block23 : {
                int n5;
                String string;
                int n6;
                String string2 = "item_celsius";
                d0.super.onCreate(bundle);
                this.setContentView(2131558435);
                this.r((MaterialToolbar)this.findViewById(2131362659));
                this.setResult(0);
                try {
                    sharedPreferences = this.getSharedPreferences("widget", 0);
                    SharedPreferences sharedPreferences2 = this.getSharedPreferences(a0.a((Context)this), 0);
                    String string3 = sharedPreferences2.getString("temperature_unit_pref", string2);
                    if (string3 != null) {
                        string2 = string3;
                    }
                    this.T = string2;
                    n2 = Build.VERSION.SDK_INT;
                    int n7 = n2 >= 31 ? (sharedPreferences2.getBoolean("system_color_pref", true) ? d.a((Context)this, 17170494) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"))) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"));
                    this.d0 = n7;
                    Intent intent = this.getIntent();
                    Bundle bundle2 = intent != null ? intent.getExtras() : null;
                    int n8 = bundle2 != null ? bundle2.getInt("appWidgetId", 0) : 0;
                    this.Q = n8;
                    if (n2 < 33) {
                        e.k((Context)this, "android.permission.READ_EXTERNAL_STORAGE", new t(this, 4));
                    }
                    int n9 = this.Q;
                    StringBuilder stringBuilder = new StringBuilder("slot1");
                    stringBuilder.append(n9);
                    this.R = String.valueOf((Object)sharedPreferences.getString(stringBuilder.toString(), "ram"));
                    int n10 = this.Q;
                    StringBuilder stringBuilder2 = new StringBuilder("slot2");
                    stringBuilder2.append(n10);
                    this.S = String.valueOf((Object)sharedPreferences.getString(stringBuilder2.toString(), "storage"));
                    this.W = (TextView)this.findViewById(2131362781);
                    this.X = (TextView)this.findViewById(2131362784);
                    this.U = (TextView)this.findViewById(2131362782);
                    this.V = (TextView)this.findViewById(2131362785);
                    this.Y = (TextView)this.findViewById(2131362761);
                    this.Z = (ImageView)this.findViewById(2131362288);
                    this.a0 = (ImageView)this.findViewById(2131362289);
                    this.b0 = (ProgressBar)this.findViewById(2131362468);
                    this.c0 = (ProgressBar)this.findViewById(2131362469);
                    chipGroup = (ChipGroup)this.findViewById(2131362050);
                    chipGroup3 = (ChipGroup)this.findViewById(2131362053);
                    chipGroup4 = (ChipGroup)this.findViewById(2131362054);
                    materialButton2 = (MaterialButton)this.findViewById(2131361939);
                    relativeLayout = (RelativeLayout)this.findViewById(16908288);
                    relativeLayout.setOnClickListener((View.OnClickListener)new b(10, this));
                    seekBar = (SeekBar)this.findViewById(2131362563);
                    textView = (TextView)this.findViewById(2131362814);
                    int n11 = this.Q;
                    StringBuilder stringBuilder3 = new StringBuilder("alpha");
                    stringBuilder3.append(n11);
                    n6 = sharedPreferences.getInt(stringBuilder3.toString(), 5);
                    seekBar.setProgress(n6);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
                int n12 = n6 * 10;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(n12);
                stringBuilder.append("%");
                textView.setText((CharSequence)stringBuilder.toString());
                relativeLayout.setBackgroundResource(2131231177);
                drawable = relativeLayout.getBackground();
                drawable.setAlpha((int)((double)(10 * (10 - n6)) / 100.0 * (double)255));
                relativeLayout.setBackground(drawable);
                int n13 = this.Q;
                StringBuilder stringBuilder4 = new StringBuilder("interval");
                stringBuilder4.append(n13);
                int n14 = sharedPreferences.getInt(stringBuilder4.toString(), 15);
                if (n14 != 15) {
                    if (n14 != 30) {
                        if (n14 == 60) {
                            chipGroup.a(2131362025);
                        }
                    } else {
                        chipGroup.a(2131362024);
                    }
                } else {
                    chipGroup.a(2131362023);
                }
                String string4 = this.R;
                int n15 = string4.hashCode();
                if (n15 != -1884274053) {
                    if (n15 != 112670) {
                        if (n15 == 321701236 && string4.equals((Object)"temperature")) {
                            chipGroup3.a(2131362081);
                        }
                    } else if (string4.equals((Object)"ram")) {
                        chipGroup3.a(2131362079);
                    }
                } else if (string4.equals((Object)"storage")) {
                    chipGroup3.a(2131362080);
                }
                if ((n5 = (string = this.S).hashCode()) != -1884274053) {
                    if (n5 != 112670) {
                        if (n5 != 321701236 || !string.equals((Object)"temperature")) break block23;
                        chipGroup2 = chipGroup4;
                        chipGroup2.a(2131362084);
                        break block24;
                    }
                    chipGroup2 = chipGroup4;
                    if (string.equals((Object)"ram")) {
                        chipGroup2.a(2131362082);
                    }
                    break block24;
                }
                chipGroup2 = chipGroup4;
                if (string.equals((Object)"storage")) {
                    chipGroup2.a(2131362083);
                }
                break block24;
            }
            chipGroup2 = chipGroup4;
        }
        this.s();
        k k2 = new k(this, textView, drawable, relativeLayout, 0);
        seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener)k2);
        chipGroup3.setOnCheckedStateChangeListener((h)new i(this, 0));
        chipGroup2.setOnCheckedStateChangeListener((h)new i(this, 1));
        if (n2 < 31 || !MainActivity.Z) {
            int n16 = this.d0;
            materialButton = materialButton2;
            materialButton.setBackgroundColor(n16);
        } else {
            materialButton = materialButton2;
        }
        g9.j j2 = new g9.j(this, sharedPreferences, seekBar, chipGroup, chipGroup3, chipGroup2);
        materialButton.setOnClickListener((View.OnClickListener)j2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void s() {
        block46 : {
            block43 : {
                block44 : {
                    block45 : {
                        var1_1 = new f((Context)this);
                        var2_2 = this.R;
                        var3_3 = var2_2.hashCode();
                        var4_4 = "storage";
                        if (var3_3 == -1884274053) break block43;
                        if (var3_3 == 112670) break block44;
                        if (var3_3 == 321701236 && var2_2.equals((Object)"temperature")) break block45;
                        var5_5 = " \u2109";
                        var6_6 = " \u2103";
                        var7_7 = "item_fahrenheit";
                        ** GOTO lbl72
                    }
                    var71_9 = this.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
                    var72_10 = var71_9 != null ? var71_9.getIntExtra("temperature", 0) / 10 : 0;
                    if (s7.j.b(this.T, "item_celsius")) {
                        var73_11 = xe1.e((int)var72_10, (String)" \u2103");
                        var6_6 = " \u2103";
                        var7_7 = "item_fahrenheit";
                    } else if (s7.j.b(this.T, "item_fahrenheit")) {
                        var79_12 = j.C((Context)this);
                        var80_13 = new Object[1];
                        var6_6 = " \u2103";
                        var7_7 = "item_fahrenheit";
                        var80_13[0] = j.i0((double)var72_10);
                        var81_14 = String.format((Locale)var79_12, (String)"%.1f", (Object[])Arrays.copyOf((Object[])var80_13, (int)1));
                        s7.j.h(var81_14, "format(locale, format, *args)");
                        var73_11 = var81_14.concat(" \u2109");
                    } else {
                        var6_6 = " \u2103";
                        var7_7 = "item_fahrenheit";
                        var73_11 = "";
                    }
                    var74_15 = this.W;
                    if (var74_15 != null) {
                        var74_15.setText((CharSequence)var73_11);
                    }
                    var75_16 = this.b0;
                    if (var75_16 != null) {
                        var75_16.setProgress(var72_10);
                    }
                    var76_17 = this.U;
                    if (var76_17 != null) {
                        var76_17.setText((CharSequence)this.getString(2131951662));
                    }
                    var77_18 = this.Z;
                    if (var77_18 == null) ** GOTO lbl-1000
                    var77_18.setImageResource(2131231082);
                    ** GOTO lbl-1000
                }
                var6_6 = " \u2103";
                var7_7 = "item_fahrenheit";
                if (var2_2.equals((Object)"ram")) {
                    var1_1.c();
                    var60_19 = var1_1.e;
                    var62_20 = var1_1.f;
                    var64_21 = Locale.US;
                    var8_8 = "ram";
                    var5_5 = " \u2109";
                    var65_22 = new Object[]{var60_19 / 1024.0};
                    var66_23 = xe1.i((String)xe1.k((Object[])var65_22, (int)1, (Locale)var64_21, (String)"%.2f", (String)"format(locale, format, *args)"), (String)"GB ", (String)this.getString(2131952420));
                    var67_24 = this.W;
                    if (var67_24 != null) {
                        var67_24.setText((CharSequence)var66_23);
                    }
                    var68_25 = this.b0;
                    if (var68_25 != null) {
                        var68_25.setProgress((int)var62_20);
                    }
                    var69_26 = this.U;
                    if (var69_26 != null) {
                        var69_26.setText((CharSequence)this.getString(2131952259));
                    }
                    var70_27 = this.Z;
                    if (var70_27 != null) {
                        var70_27.setImageResource(2131231078);
                    }
                } else lbl-1000: // 3 sources:
                {
                    var5_5 = " \u2109";
lbl72: // 2 sources:
                    var8_8 = "ram";
                }
                break block46;
            }
            var5_5 = " \u2109";
            var6_6 = " \u2103";
            var7_7 = "item_fahrenheit";
            var8_8 = "ram";
            var9_28 = var4_4;
            if (!var2_2.equals((Object)var9_28)) {
                var4_4 = var9_28;
            } else {
                var1_1.b();
                var10_29 = var1_1.p;
                var12_30 = var1_1.q;
                var14_31 = Locale.US;
                var4_4 = var9_28;
                var15_32 = new Object[]{var10_29};
                var16_33 = xe1.i((String)xe1.k((Object[])var15_32, (int)1, (Locale)var14_31, (String)"%.2f", (String)"format(locale, format, *args)"), (String)"GB ", (String)this.getString(2131952420));
                var17_34 = this.W;
                if (var17_34 != null) {
                    var17_34.setText((CharSequence)var16_33);
                }
                var18_35 = this.b0;
                if (var18_35 != null) {
                    var18_35.setProgress((int)var12_30);
                }
                var19_36 = this.U;
                if (var19_36 != null) {
                    var19_36.setText((CharSequence)this.getString(2131952368));
                }
                var20_37 = this.Z;
                if (var20_37 != null) {
                    var20_37.setImageResource(2131231080);
                }
            }
        }
        var21_38 = this.S;
        var22_39 = var21_38.hashCode();
        if (var22_39 != -1884274053) {
            if (var22_39 != 112670) {
                if (var22_39 == 321701236 && var21_38.equals((Object)"temperature")) {
                    var49_40 = this.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
                    var50_41 = var49_40 != null ? var49_40.getIntExtra("temperature", 0) / 10 : 0;
                    if (s7.j.b(this.T, "item_celsius")) {
                        var51_42 = xe1.e((int)var50_41, (String)var6_6);
                    } else if (s7.j.b(this.T, var7_7)) {
                        var57_43 = j.C((Context)this);
                        var58_44 = new Object[]{j.i0((double)var50_41)};
                        var59_45 = String.format((Locale)var57_43, (String)"%.1f", (Object[])Arrays.copyOf((Object[])var58_44, (int)1));
                        s7.j.h(var59_45, "format(locale, format, *args)");
                        var51_42 = var59_45.concat(var5_5);
                    } else {
                        var51_42 = "";
                    }
                    var52_46 = this.X;
                    if (var52_46 != null) {
                        var52_46.setText((CharSequence)var51_42);
                    }
                    var53_47 = this.c0;
                    if (var53_47 != null) {
                        var53_47.setProgress(var50_41);
                    }
                    var54_48 = this.V;
                    if (var54_48 != null) {
                        var54_48.setText((CharSequence)this.getString(2131951662));
                    }
                    var55_49 = this.a0;
                    if (var55_49 != null) {
                        var55_49.setImageResource(2131231082);
                    }
                }
            } else if (var21_38.equals((Object)var8_8)) {
                var1_1.c();
                var38_50 = var1_1.e;
                var40_51 = var1_1.f;
                var42_52 = Locale.US;
                var43_53 = new Object[]{var38_50 / 1024.0};
                var44_54 = xe1.i((String)xe1.k((Object[])var43_53, (int)1, (Locale)var42_52, (String)"%.2f", (String)"format(locale, format, *args)"), (String)"GB ", (String)this.getString(2131952420));
                var45_55 = this.X;
                if (var45_55 != null) {
                    var45_55.setText((CharSequence)var44_54);
                }
                var46_56 = this.c0;
                if (var46_56 != null) {
                    var46_56.setProgress((int)var40_51);
                }
                var47_57 = this.V;
                if (var47_57 != null) {
                    var47_57.setText((CharSequence)this.getString(2131952259));
                }
                var48_58 = this.a0;
                if (var48_58 != null) {
                    var48_58.setImageResource(2131231078);
                }
            }
        } else if (var21_38.equals((Object)var4_4)) {
            var1_1.b();
            var23_59 = var1_1.p;
            var25_60 = var1_1.q;
            var27_61 = Locale.US;
            var28_62 = new Object[]{var23_59};
            var29_63 = xe1.i((String)xe1.k((Object[])var28_62, (int)1, (Locale)var27_61, (String)"%.2f", (String)"format(locale, format, *args)"), (String)"GB ", (String)this.getString(2131952420));
            var30_64 = this.X;
            if (var30_64 != null) {
                var30_64.setText((CharSequence)var29_63);
            }
            var31_65 = this.c0;
            if (var31_65 != null) {
                var31_65.setProgress((int)var25_60);
            }
            var32_66 = this.V;
            if (var32_66 != null) {
                var32_66.setText((CharSequence)this.getString(2131952368));
            }
            var33_67 = this.a0;
            if (var33_67 != null) {
                var33_67.setImageResource(2131231080);
            }
        }
        var35_68 = new SimpleDateFormat("yyyy/MM/dd hh:mm a", j.C((Context)this));
        var36_69 = xe1.i((String)this.getString(2131952060), (String)" ", (String)var35_68.format(Calendar.getInstance().getTime()));
        var37_70 = this.Y;
        if (var37_70 == null) {
            return;
        }
        var37_70.setText((CharSequence)var36_69);
    }
}

