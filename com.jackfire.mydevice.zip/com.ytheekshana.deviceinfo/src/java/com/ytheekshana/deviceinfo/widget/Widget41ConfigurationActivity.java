/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.RelativeLayout
 *  android.widget.SeekBar
 *  android.widget.SeekBar$OnSeekBarChangeListener
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  com.google.android.material.chip.ChipGroup
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Locale
 */
package com.ytheekshana.deviceinfo.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.fragment.app.d0;
import c0.d;
import c9.f;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.i0;
import f1.a0;
import g9.k;
import java.util.Arrays;
import java.util.Locale;
import m6.h;
import q0.b;
import s5.j;
import w8.t;
import y6.e;

public final class Widget41ConfigurationActivity
extends n {
    public static final /* synthetic */ int Y;
    public int Q;
    public String R = "";
    public String S = "";
    public TextView T;
    public TextView U;
    public TextView V;
    public ImageView W;
    public int X;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        SharedPreferences sharedPreferences;
        ChipGroup chipGroup;
        MaterialButton materialButton;
        SeekBar seekBar;
        ChipGroup chipGroup2;
        block20 : {
            MaterialButton materialButton2;
            block19 : {
                ChipGroup chipGroup3;
                RelativeLayout relativeLayout;
                int n2;
                int n5;
                TextView textView;
                String string = "item_celsius";
                d0.super.onCreate(bundle);
                this.setContentView(2131558456);
                this.r((MaterialToolbar)this.findViewById(2131362659));
                this.setResult(0);
                try {
                    sharedPreferences = this.getSharedPreferences("widget", 0);
                    SharedPreferences sharedPreferences2 = this.getSharedPreferences(a0.a((Context)this), 0);
                    String string2 = sharedPreferences2.getString("temperature_unit_pref", string);
                    if (string2 != null) {
                        string = string2;
                    }
                    this.S = string;
                    n2 = Build.VERSION.SDK_INT;
                    int n6 = n2 >= 31 ? (sharedPreferences2.getBoolean("system_color_pref", true) ? d.a((Context)this, 17170494) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"))) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"));
                    this.X = n6;
                    Intent intent = this.getIntent();
                    Bundle bundle2 = intent != null ? intent.getExtras() : null;
                    int n7 = 0;
                    if (bundle2 != null) {
                        n7 = bundle2.getInt("appWidgetId", 0);
                    }
                    this.Q = n7;
                    if (n2 < 33) {
                        e.k((Context)this, "android.permission.READ_EXTERNAL_STORAGE", new t(this, 7));
                    }
                    int n8 = this.Q;
                    StringBuilder stringBuilder = new StringBuilder("slot");
                    stringBuilder.append(n8);
                    this.R = String.valueOf((Object)sharedPreferences.getString(stringBuilder.toString(), "ram"));
                    this.T = (TextView)this.findViewById(2131362747);
                    this.U = (TextView)this.findViewById(2131362805);
                    this.V = (TextView)this.findViewById(2131362822);
                    this.W = (ImageView)this.findViewById(2131362268);
                    chipGroup3 = (ChipGroup)this.findViewById(2131362050);
                    chipGroup2 = (ChipGroup)this.findViewById(2131362052);
                    materialButton2 = (MaterialButton)this.findViewById(2131361939);
                    relativeLayout = (RelativeLayout)this.findViewById(16908288);
                    relativeLayout.setOnClickListener((View.OnClickListener)new g7.b(13, this));
                    seekBar = (SeekBar)this.findViewById(2131362563);
                    textView = (TextView)this.findViewById(2131362814);
                    int n9 = this.Q;
                    StringBuilder stringBuilder2 = new StringBuilder("alpha");
                    stringBuilder2.append(n9);
                    n5 = sharedPreferences.getInt(stringBuilder2.toString(), 5);
                    seekBar.setProgress(n5);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
                int n10 = n5 * 10;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(n10);
                stringBuilder.append("%");
                textView.setText((CharSequence)stringBuilder.toString());
                relativeLayout.setBackgroundResource(2131231177);
                Drawable drawable = relativeLayout.getBackground();
                drawable.setAlpha((int)((double)(10 * (10 - n5)) / 100.0 * (double)255));
                relativeLayout.setBackground(drawable);
                int n11 = this.Q;
                StringBuilder stringBuilder3 = new StringBuilder("interval");
                stringBuilder3.append(n11);
                int n12 = sharedPreferences.getInt(stringBuilder3.toString(), 15);
                if (n12 != 15) {
                    if (n12 != 30) {
                        if (n12 != 60) {
                            chipGroup = chipGroup3;
                        } else {
                            chipGroup = chipGroup3;
                            chipGroup.a(2131362025);
                        }
                    } else {
                        chipGroup = chipGroup3;
                        chipGroup.a(2131362024);
                    }
                } else {
                    chipGroup = chipGroup3;
                    chipGroup.a(2131362023);
                }
                String string3 = this.R;
                int n13 = string3.hashCode();
                if (n13 != -1884274053) {
                    if (n13 != 112670) {
                        if (n13 == 321701236 && string3.equals((Object)"temperature")) {
                            chipGroup2.a(2131362087);
                        }
                    } else if (string3.equals((Object)"ram")) {
                        chipGroup2.a(2131362085);
                    }
                } else if (string3.equals((Object)"storage")) {
                    chipGroup2.a(2131362086);
                }
                this.s();
                k k2 = new k(this, textView, drawable, relativeLayout, 2);
                seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener)k2);
                chipGroup2.setOnCheckedStateChangeListener((h)new b(24, this));
                if (n2 >= 31 && MainActivity.Z) break block19;
                int n14 = this.X;
                materialButton = materialButton2;
                materialButton.setBackgroundColor(n14);
                break block20;
            }
            materialButton = materialButton2;
        }
        i0 i02 = new i0(this, (Object)sharedPreferences, (View)seekBar, (View)chipGroup, (View)chipGroup2, 2);
        materialButton.setOnClickListener((View.OnClickListener)i02);
    }

    public final void s() {
        f f4 = new f((Context)this);
        String string = this.R;
        int n2 = string.hashCode();
        if (n2 != -1884274053) {
            if (n2 != 112670) {
                String string2;
                if (n2 != 321701236) {
                    return;
                }
                if (!string.equals((Object)"temperature")) {
                    return;
                }
                Intent intent = this.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
                int n5 = intent != null ? intent.getIntExtra("temperature", 0) / 10 : 0;
                if (s7.j.b(this.S, "item_celsius")) {
                    string2 = xe1.e((int)n5, (String)" \u2103");
                } else if (s7.j.b(this.S, "item_fahrenheit")) {
                    Locale locale = j.C((Context)this);
                    Object[] arrobject = new Object[]{j.i0((double)n5)};
                    String string3 = String.format((Locale)locale, (String)"%.1f", (Object[])Arrays.copyOf((Object[])arrobject, (int)1));
                    s7.j.h(string3, "format(locale, format, *args)");
                    string2 = string3.concat(" \u2109");
                } else {
                    string2 = "";
                }
                TextView textView = this.U;
                if (textView != null) {
                    textView.setText((CharSequence)this.getString(2131951662));
                }
                TextView textView2 = this.T;
                if (textView2 != null) {
                    textView2.setText((CharSequence)string2);
                }
                TextView textView3 = this.V;
                if (textView3 != null) {
                    textView3.setVisibility(8);
                }
                ImageView imageView = this.W;
                if (imageView != null) {
                    imageView.setImageResource(2131231082);
                    return;
                }
            } else if (string.equals((Object)"ram")) {
                f4.c();
                double d3 = f4.e;
                double d4 = f4.f;
                double d6 = f4.c;
                String string4 = xe1.e((int)((int)d4), (String)"%");
                String string5 = this.getString(2131952420);
                Locale locale = j.C((Context)this);
                Object[] arrobject = new Object[]{d3 / 1024.0};
                String string6 = xe1.k((Object[])arrobject, (int)1, (Locale)locale, (String)"%.2f", (String)"format(locale, format, *args)");
                String string7 = this.getString(2131952392);
                Locale locale2 = j.C((Context)this);
                Object[] arrobject2 = new Object[]{d6 / 1024.0};
                String string8 = xe1.k((Object[])arrobject2, (int)1, (Locale)locale2, (String)"%.2f", (String)"format(locale, format, *args)");
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string5);
                stringBuilder.append(": ");
                stringBuilder.append(string6);
                stringBuilder.append("GB, ");
                stringBuilder.append(string7);
                stringBuilder.append(": ");
                stringBuilder.append(string8);
                stringBuilder.append("GB");
                String string9 = stringBuilder.toString();
                TextView textView = this.U;
                if (textView != null) {
                    textView.setText((CharSequence)this.getString(2131952259));
                }
                TextView textView4 = this.V;
                if (textView4 != null) {
                    textView4.setText((CharSequence)string9);
                }
                TextView textView5 = this.V;
                if (textView5 != null) {
                    textView5.setVisibility(0);
                }
                TextView textView6 = this.T;
                if (textView6 != null) {
                    textView6.setText((CharSequence)string4);
                }
                ImageView imageView = this.W;
                if (imageView != null) {
                    imageView.setImageResource(2131231078);
                    return;
                }
            }
        } else {
            if (!string.equals((Object)"storage")) {
                return;
            }
            f4.b();
            double d7 = f4.p;
            double d8 = f4.q;
            double d9 = f4.n;
            String string10 = xe1.e((int)((int)d8), (String)"%");
            String string11 = this.getString(2131952420);
            Locale locale = j.C((Context)this);
            Object[] arrobject = new Object[]{d7};
            String string12 = xe1.k((Object[])arrobject, (int)1, (Locale)locale, (String)"%.2f", (String)"format(locale, format, *args)");
            String string13 = this.getString(2131952392);
            Locale locale3 = j.C((Context)this);
            Object[] arrobject3 = new Object[]{d9};
            String string14 = xe1.k((Object[])arrobject3, (int)1, (Locale)locale3, (String)"%.2f", (String)"format(locale, format, *args)");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string11);
            stringBuilder.append(": ");
            stringBuilder.append(string12);
            stringBuilder.append("GB, ");
            stringBuilder.append(string13);
            stringBuilder.append(": ");
            stringBuilder.append(string14);
            stringBuilder.append("GB");
            String string15 = stringBuilder.toString();
            TextView textView = this.U;
            if (textView != null) {
                textView.setText((CharSequence)this.getString(2131952368));
            }
            TextView textView7 = this.V;
            if (textView7 != null) {
                textView7.setText((CharSequence)string15);
            }
            TextView textView8 = this.V;
            if (textView8 != null) {
                textView8.setVisibility(0);
            }
            TextView textView9 = this.T;
            if (textView9 != null) {
                textView9.setText((CharSequence)string10);
            }
            ImageView imageView = this.W;
            if (imageView != null) {
                imageView.setImageResource(2131231080);
            }
        }
    }
}

