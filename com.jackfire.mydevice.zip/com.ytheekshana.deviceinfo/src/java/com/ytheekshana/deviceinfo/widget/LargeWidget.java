/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.appwidget.AppWidgetManager
 *  android.appwidget.AppWidgetProvider
 *  android.content.Context
 *  android.content.Intent
 *  ba.k1
 *  ba.w0
 *  da.c
 *  ea.c
 *  g9.a
 *  g9.b
 *  g9.c
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  m9.d
 *  m9.h
 *  s7.j
 *  t9.p
 *  w8.d
 *  y6.e
 */
package com.ytheekshana.deviceinfo.widget;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import ba.e0;
import ba.k1;
import ba.w;
import ba.w0;
import ba.x;
import g9.a;
import g9.b;
import g9.c;
import m9.h;
import s7.j;
import t9.p;
import w8.d;
import y6.e;

public final class LargeWidget
extends AppWidgetProvider {
    public final k1 a;
    public final da.c b;

    public LargeWidget() {
        k1 k12;
        this.a = k12 = e.b();
        ea.c c2 = e0.b;
        c2.getClass();
        this.b = e.a((h)e.r0((h)c2, (h)k12).m((h)new d(4)));
    }

    public final void onDeleted(Context context, int[] arrn) {
        a a2 = new a(context, arrn, null);
        e.g0((w)this.b, null, (p)a2, (int)3);
        super.onDeleted(context, arrn);
    }

    public final void onDisabled(Context context) {
        x.a((w0)this.a);
        super.onDisabled(context);
    }

    public final void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String string = intent != null ? intent.getAction() : null;
        if (j.b((Object)"refreshClick", (Object)string)) {
            b b5 = new b(context, null);
            e.g0((w)this.b, null, (p)b5, (int)3);
        }
    }

    public final void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] arrn) {
        c c2 = new c(context, arrn, appWidgetManager, null);
        e.g0((w)this.b, null, (p)c2, (int)3);
    }
}

