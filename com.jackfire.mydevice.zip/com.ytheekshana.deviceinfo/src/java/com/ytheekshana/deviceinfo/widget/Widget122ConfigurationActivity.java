/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.graphics.Color
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.RelativeLayout
 *  android.widget.SeekBar
 *  android.widget.SeekBar$OnSeekBarChangeListener
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  com.google.android.material.chip.Chip
 *  com.google.android.material.chip.ChipGroup
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.Locale
 */
package com.ytheekshana.deviceinfo.widget;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.fragment.app.d0;
import c0.d;
import c9.f;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import f1.a0;
import f1.f0;
import g7.b;
import java.util.Arrays;
import java.util.Locale;
import m6.h;
import s5.j;
import w8.p;
import w8.t;
import y6.e;

public final class Widget122ConfigurationActivity
extends n {
    public static final /* synthetic */ int h0;
    public int Q;
    public String R = "";
    public String S = "";
    public TextView T;
    public TextView U;
    public TextView V;
    public TextView W;
    public TextView X;
    public TextView Y;
    public TextView Z;
    public TextView a0;
    public boolean b0;
    public boolean c0;
    public boolean d0;
    public boolean e0;
    public float f0 = 16.0f;
    public int g0;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        SharedPreferences sharedPreferences;
        ChipGroup chipGroup;
        MaterialButton materialButton;
        ChipGroup chipGroup2;
        block14 : {
            MaterialButton materialButton2;
            block13 : {
                boolean bl;
                boolean bl2;
                SeekBar seekBar;
                Chip chip;
                ChipGroup chipGroup3;
                Chip chip2;
                int n2;
                ChipGroup chipGroup4;
                boolean bl3;
                Chip chip3;
                boolean bl4;
                int n5;
                Chip chip4;
                String string = "item_celsius";
                d0.super.onCreate(bundle);
                this.setContentView(2131558455);
                this.r((MaterialToolbar)this.findViewById(2131362659));
                this.setResult(0);
                try {
                    boolean bl5;
                    boolean bl6;
                    float f4;
                    sharedPreferences = this.getSharedPreferences("widget", 0);
                    SharedPreferences sharedPreferences2 = this.getSharedPreferences(a0.a((Context)this), 0);
                    String string2 = sharedPreferences2.getString("temperature_unit_pref", string);
                    if (string2 != null) {
                        string = string2;
                    }
                    this.S = string;
                    n2 = Build.VERSION.SDK_INT;
                    int n6 = n2 >= 31 ? (sharedPreferences2.getBoolean("system_color_pref", true) ? d.a((Context)this, 17170494) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"))) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"));
                    this.g0 = n6;
                    Intent intent = this.getIntent();
                    Bundle bundle2 = intent != null ? intent.getExtras() : null;
                    int n7 = bundle2 != null ? bundle2.getInt("appWidgetId", 0) : 0;
                    this.Q = n7;
                    if (n2 < 33) {
                        e.k((Context)this, "android.permission.READ_EXTERNAL_STORAGE", new t(this, 6));
                    }
                    int n8 = this.Q;
                    StringBuilder stringBuilder = new StringBuilder("type");
                    stringBuilder.append(n8);
                    this.R = String.valueOf((Object)sharedPreferences.getString(stringBuilder.toString(), "brief"));
                    this.T = (TextView)this.findViewById(2131362807);
                    this.U = (TextView)this.findViewById(2131362808);
                    this.V = (TextView)this.findViewById(2131362809);
                    this.W = (TextView)this.findViewById(2131362806);
                    this.X = (TextView)this.findViewById(2131362824);
                    this.Y = (TextView)this.findViewById(2131362825);
                    this.Z = (TextView)this.findViewById(2131362826);
                    this.a0 = (TextView)this.findViewById(2131362823);
                    chipGroup3 = (ChipGroup)this.findViewById(2131362056);
                    chip3 = (Chip)this.findViewById(2131362073);
                    chip = (Chip)this.findViewById(2131362088);
                    chip2 = (Chip)this.findViewById(2131362091);
                    chip4 = (Chip)this.findViewById(2131362032);
                    chipGroup = (ChipGroup)this.findViewById(2131362050);
                    chipGroup4 = (ChipGroup)this.findViewById(2131362055);
                    materialButton2 = (MaterialButton)this.findViewById(2131361939);
                    seekBar = (SeekBar)this.findViewById(2131362562);
                    ((RelativeLayout)this.findViewById(16908288)).setOnClickListener((View.OnClickListener)new b(12, this));
                    int n9 = this.Q;
                    StringBuilder stringBuilder2 = new StringBuilder("font");
                    stringBuilder2.append(n9);
                    this.f0 = f4 = sharedPreferences.getFloat(stringBuilder2.toString(), 16.0f);
                    boolean bl7 = f4 == 14.0f;
                    n5 = bl7 ? 0 : (!(bl6 = f4 == 16.0f) && (bl5 = f4 == 18.0f) ? 2 : 1);
                }
                catch (Exception exception) {
                    exception.printStackTrace();
                    return;
                }
                seekBar.setProgress(n5);
                int n10 = this.Q;
                StringBuilder stringBuilder = new StringBuilder("interval");
                stringBuilder.append(n10);
                int n11 = sharedPreferences.getInt(stringBuilder.toString(), 15);
                if (n11 != 15) {
                    if (n11 != 30) {
                        if (n11 == 60) {
                            chipGroup.a(2131362025);
                        }
                    } else {
                        chipGroup.a(2131362024);
                    }
                } else {
                    chipGroup.a(2131362023);
                }
                int n12 = this.Q;
                StringBuilder stringBuilder3 = new StringBuilder("ram");
                stringBuilder3.append(n12);
                this.b0 = bl4 = sharedPreferences.getBoolean(stringBuilder3.toString(), true);
                chip3.setChecked(bl4);
                int n13 = this.Q;
                StringBuilder stringBuilder4 = new StringBuilder("storage");
                stringBuilder4.append(n13);
                this.c0 = bl3 = sharedPreferences.getBoolean(stringBuilder4.toString(), true);
                chip.setChecked(bl3);
                int n14 = this.Q;
                StringBuilder stringBuilder5 = new StringBuilder("temperature");
                stringBuilder5.append(n14);
                this.d0 = bl2 = sharedPreferences.getBoolean(stringBuilder5.toString(), true);
                chip2.setChecked(bl2);
                int n15 = this.Q;
                StringBuilder stringBuilder6 = new StringBuilder("battery");
                stringBuilder6.append(n15);
                this.e0 = bl = sharedPreferences.getBoolean(stringBuilder6.toString(), true);
                chip4.setChecked(bl);
                String string3 = this.R;
                if (s7.j.b(string3, "brief")) {
                    chipGroup2 = chipGroup4;
                    chipGroup2.a(2131362094);
                } else {
                    chipGroup2 = chipGroup4;
                    if (s7.j.b(string3, "detailed")) {
                        chipGroup2.a(2131362095);
                    }
                }
                this.s();
                chipGroup2.setOnCheckedStateChangeListener((h)new g9.t(this, 0));
                chipGroup3.setOnCheckedStateChangeListener((h)new g9.t(this, 1));
                seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener)new f0(1, this));
                if (n2 >= 31 && MainActivity.Z) break block13;
                int n16 = this.g0;
                materialButton = materialButton2;
                materialButton.setBackgroundColor(n16);
                break block14;
            }
            materialButton = materialButton2;
        }
        p p3 = new p(this, (Object)sharedPreferences, (Object)chipGroup, (Object)chipGroup2, 4);
        materialButton.setOnClickListener((View.OnClickListener)p3);
    }

    public final void s() {
        String string;
        String string2;
        f f4 = new f((Context)this);
        f4.c();
        String string3 = xe1.e((int)((int)f4.f), (String)"%");
        TextView textView = this.X;
        if (textView != null) {
            textView.setText((CharSequence)string3);
        }
        f4.b();
        String string4 = xe1.e((int)((int)f4.q), (String)"%");
        TextView textView2 = this.Y;
        if (textView2 != null) {
            textView2.setText((CharSequence)string4);
        }
        Intent intent = this.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        int n2 = intent != null ? intent.getIntExtra("level", -1) : 0;
        int n5 = intent != null ? intent.getIntExtra("status", -1) : 1;
        int n6 = intent != null ? intent.getIntExtra("temperature", 0) / 10 : 0;
        if (s7.j.b(this.S, "item_celsius")) {
            string = xe1.e((int)n6, (String)" \u2103");
            string2 = this.getString(2131951822);
            s7.j.h(string2, "getString(R.string.celsius)");
        } else if (s7.j.b(this.S, "item_fahrenheit")) {
            Locale locale = j.C((Context)this);
            Object[] arrobject = new Object[]{j.i0((double)n6)};
            String string5 = String.format((Locale)locale, (String)"%.1f", (Object[])Arrays.copyOf((Object[])arrobject, (int)1));
            s7.j.h(string5, "format(locale, format, *args)");
            string = string5.concat(" \u2109");
            string2 = this.getString(2131951924);
            s7.j.h(string2, "getString(R.string.fahrenheit)");
        } else {
            string2 = string = "";
        }
        TextView textView3 = this.Z;
        if (textView3 != null) {
            textView3.setText((CharSequence)string);
        }
        String string6 = xe1.e((int)n2, (String)"%");
        TextView textView4 = this.a0;
        if (textView4 != null) {
            textView4.setText((CharSequence)string6);
        }
        String string7 = this.R;
        if (s7.j.b(string7, "brief")) {
            TextView textView5 = this.T;
            if (textView5 != null) {
                textView5.setText((CharSequence)this.getString(2131952259));
            }
            TextView textView6 = this.U;
            if (textView6 != null) {
                textView6.setText((CharSequence)this.getString(2131952368));
            }
            TextView textView7 = this.V;
            if (textView7 != null) {
                textView7.setText((CharSequence)this.getString(2131951662));
            }
            TextView textView8 = this.W;
            if (textView8 != null) {
                textView8.setText((CharSequence)this.getString(2131951726));
            }
        } else if (s7.j.b(string7, "detailed")) {
            double d3 = f4.e;
            double d4 = f4.p;
            String string8 = this.getString(2131952259);
            Locale locale = j.C((Context)this);
            Object[] arrobject = new Object[]{d3 / 1024.0};
            String string9 = xe1.k((Object[])arrobject, (int)1, (Locale)locale, (String)"%.2f", (String)"format(locale, format, *args)");
            String string10 = this.getString(2131952420);
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(string8);
            stringBuilder.append(" - ");
            stringBuilder.append(string9);
            stringBuilder.append("GB ");
            stringBuilder.append(string10);
            String string11 = stringBuilder.toString();
            String string12 = this.getString(2131952368);
            Locale locale2 = j.C((Context)this);
            Object[] arrobject2 = new Object[]{d4};
            String string13 = xe1.k((Object[])arrobject2, (int)1, (Locale)locale2, (String)"%.2f", (String)"format(locale, format, *args)");
            String string14 = this.getString(2131952420);
            StringBuilder stringBuilder2 = new StringBuilder();
            stringBuilder2.append(string12);
            stringBuilder2.append(" - ");
            stringBuilder2.append(string13);
            stringBuilder2.append("GB ");
            stringBuilder2.append(string14);
            String string15 = stringBuilder2.toString();
            String string16 = xe1.i((String)this.getString(2131951662), (String)" - ", (String)string2);
            String string17 = xe1.i((String)this.getString(2131951726), (String)" - ", (String)j.p((Context)this, n5));
            TextView textView9 = this.T;
            if (textView9 != null) {
                textView9.setText((CharSequence)string11);
            }
            TextView textView10 = this.U;
            if (textView10 != null) {
                textView10.setText((CharSequence)string15);
            }
            TextView textView11 = this.V;
            if (textView11 != null) {
                textView11.setText((CharSequence)string16);
            }
            TextView textView12 = this.W;
            if (textView12 != null) {
                textView12.setText((CharSequence)string17);
            }
        }
        RelativeLayout relativeLayout = (RelativeLayout)this.findViewById(2131362503);
        RelativeLayout relativeLayout2 = (RelativeLayout)this.findViewById(2131362505);
        RelativeLayout relativeLayout3 = (RelativeLayout)this.findViewById(2131362507);
        RelativeLayout relativeLayout4 = (RelativeLayout)this.findViewById(2131362501);
        int n7 = this.b0 ? 0 : 8;
        relativeLayout.setVisibility(n7);
        int n8 = this.c0 ? 0 : 8;
        relativeLayout2.setVisibility(n8);
        int n9 = this.d0 ? 0 : 8;
        relativeLayout3.setVisibility(n9);
        int n10 = this.e0 ? 0 : 8;
        relativeLayout4.setVisibility(n10);
        TextView textView13 = this.T;
        if (textView13 != null) {
            textView13.setTextSize(this.f0);
        }
        TextView textView14 = this.U;
        if (textView14 != null) {
            textView14.setTextSize(this.f0);
        }
        TextView textView15 = this.V;
        if (textView15 != null) {
            textView15.setTextSize(this.f0);
        }
        TextView textView16 = this.W;
        if (textView16 != null) {
            textView16.setTextSize(this.f0);
        }
        TextView textView17 = this.X;
        if (textView17 != null) {
            textView17.setTextSize(this.f0);
        }
        TextView textView18 = this.Y;
        if (textView18 != null) {
            textView18.setTextSize(this.f0);
        }
        TextView textView19 = this.Z;
        if (textView19 != null) {
            textView19.setTextSize(this.f0);
        }
        TextView textView20 = this.a0;
        if (textView20 == null) {
            return;
        }
        textView20.setTextSize(this.f0);
    }
}

