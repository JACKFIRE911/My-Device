/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.graphics.Color
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageButton
 *  android.widget.ProgressBar
 *  android.widget.RelativeLayout
 *  android.widget.SeekBar
 *  android.widget.SeekBar$OnSeekBarChangeListener
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  com.google.android.material.chip.ChipGroup
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.text.SimpleDateFormat
 *  java.util.Arrays
 *  java.util.Calendar
 *  java.util.Date
 *  java.util.Iterator
 *  java.util.Locale
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package com.ytheekshana.deviceinfo.widget;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import androidx.fragment.app.d0;
import c0.d;
import c9.f;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.ChipGroup;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import f1.a0;
import g7.b;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import s5.j;
import w8.p;
import w8.t;
import y6.e;

public final class LargeWidgetConfigurationActivity
extends n {
    public static final /* synthetic */ int U;
    public int Q;
    public String R = "0%";
    public String S = "";
    public int T;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        SharedPreferences sharedPreferences;
        SeekBar seekBar;
        RelativeLayout relativeLayout;
        int n2;
        MaterialButton materialButton;
        ChipGroup chipGroup;
        TextView textView;
        int n5;
        RelativeLayout relativeLayout2;
        TextView textView2;
        TextView textView3;
        String string = "item_celsius";
        d0.super.onCreate(bundle);
        this.setContentView(2131558433);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        this.setResult(0);
        try {
            sharedPreferences = this.getSharedPreferences("widget", 0);
            SharedPreferences sharedPreferences2 = this.getSharedPreferences(a0.a((Context)this), 0);
            String string2 = sharedPreferences2.getString("temperature_unit_pref", string);
            if (string2 != null) {
                string = string2;
            }
            this.S = string;
            n2 = Build.VERSION.SDK_INT;
            int n6 = n2 >= 31 ? (sharedPreferences2.getBoolean("system_color_pref", true) ? d.a((Context)this, 17170494) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"))) : sharedPreferences2.getInt("accent_color_dialog", Color.parseColor((String)"#2196f3"));
            this.T = n6;
            Intent intent = this.getIntent();
            Bundle bundle2 = intent != null ? intent.getExtras() : null;
            int n7 = bundle2 != null ? bundle2.getInt("appWidgetId", 0) : 0;
            this.Q = n7;
            if (n2 < 33) {
                e.k((Context)this, "android.permission.READ_EXTERNAL_STORAGE", new t(this, 3));
            }
            ((ImageButton)this.findViewById(2131361935)).setOnClickListener((View.OnClickListener)new b(9, this));
            relativeLayout2 = (RelativeLayout)this.findViewById(2131362499);
            relativeLayout = (RelativeLayout)this.findViewById(16908288);
            seekBar = (SeekBar)this.findViewById(2131362563);
            textView3 = (TextView)this.findViewById(2131362814);
            textView = (TextView)this.findViewById(2131362696);
            textView2 = (TextView)this.findViewById(2131362788);
            chipGroup = (ChipGroup)this.findViewById(2131362050);
            materialButton = (MaterialButton)this.findViewById(2131361939);
            int n8 = this.Q;
            StringBuilder stringBuilder = new StringBuilder("alpha");
            stringBuilder.append(n8);
            n5 = sharedPreferences.getInt(stringBuilder.toString(), 5);
            seekBar.setProgress(n5);
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        int n9 = n5 * 10;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(n9);
        stringBuilder.append("%");
        textView3.setText((CharSequence)stringBuilder.toString());
        relativeLayout2.setBackgroundResource(2131231177);
        relativeLayout.setBackgroundResource(2131231177);
        Drawable drawable = relativeLayout.getBackground();
        Drawable drawable2 = relativeLayout2.getBackground();
        int n10 = (int)((double)(10 * (10 - n5)) / 100.0 * (double)255);
        drawable.setAlpha(n10);
        drawable2.setAlpha(n10);
        relativeLayout.setBackground(drawable);
        relativeLayout2.setBackground(drawable2);
        int n11 = this.Q;
        StringBuilder stringBuilder2 = new StringBuilder("interval");
        stringBuilder2.append(n11);
        int n12 = sharedPreferences.getInt(stringBuilder2.toString(), 15);
        if (n12 != 15) {
            if (n12 != 30) {
                if (n12 == 60) {
                    chipGroup.a(2131362025);
                }
            } else {
                chipGroup.a(2131362024);
            }
        } else {
            chipGroup.a(2131362023);
        }
        SharedPreferences sharedPreferences3 = this.getSharedPreferences("Web", 0);
        String string3 = sharedPreferences3.getString("market_name", null);
        if (string3 != null) {
            textView.setText((CharSequence)string3);
        } else {
            textView.setText((CharSequence)Build.MODEL);
        }
        String string4 = sharedPreferences3.getString("soc", null);
        if (string4 != null) {
            textView2.setText((CharSequence)string4);
        } else {
            textView2.setText((CharSequence)Build.BOARD);
        }
        this.s();
        g9.d d3 = new g9.d(this, textView3, drawable, drawable2, relativeLayout, relativeLayout2);
        seekBar.setOnSeekBarChangeListener((SeekBar.OnSeekBarChangeListener)d3);
        if (n2 < 31 || !MainActivity.Z) {
            materialButton.setBackgroundColor(this.T);
        }
        materialButton.setOnClickListener((View.OnClickListener)new p(this, sharedPreferences, seekBar, chipGroup));
    }

    public final void s() {
        String string;
        int n2;
        f f4 = new f((Context)this);
        f4.c();
        double d3 = f4.e;
        double d4 = f4.f;
        TextView textView = (TextView)this.findViewById(2131362759);
        Locale locale = j.C((Context)this);
        Object[] arrobject = new Object[]{d3 / 1024.0};
        String string2 = xe1.k((Object[])arrobject, (int)1, (Locale)locale, (String)"%.2f", (String)"format(locale, format, *args)");
        String string3 = this.getString(2131952420);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string2);
        stringBuilder.append("GB ");
        stringBuilder.append(string3);
        textView.setText((CharSequence)stringBuilder.toString());
        ((ProgressBar)this.findViewById(2131362467)).setProgress((int)d4);
        f4.b();
        double d6 = f4.p;
        double d7 = f4.q;
        TextView textView2 = (TextView)this.findViewById(2131362791);
        Locale locale2 = j.C((Context)this);
        Object[] arrobject2 = new Object[]{d6};
        String string4 = xe1.k((Object[])arrobject2, (int)1, (Locale)locale2, (String)"%.2f", (String)"format(locale, format, *args)");
        String string5 = this.getString(2131952420);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(string4);
        stringBuilder2.append("GB ");
        stringBuilder2.append(string5);
        textView2.setText((CharSequence)stringBuilder2.toString());
        ((ProgressBar)this.findViewById(2131362470)).setProgress((int)d7);
        TextView textView3 = (TextView)this.findViewById(2131362761);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd hh:mm a", j.C((Context)this));
        String string6 = this.getString(2131952060);
        String string7 = simpleDateFormat.format(Calendar.getInstance().getTime());
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(string6);
        stringBuilder3.append(" ");
        stringBuilder3.append(string7);
        textView3.setText((CharSequence)stringBuilder3.toString());
        TextView textView4 = (TextView)this.findViewById(2131362798);
        ProgressBar progressBar = (ProgressBar)this.findViewById(2131362471);
        Intent intent = this.registerReceiver(null, new IntentFilter("android.intent.action.BATTERY_CHANGED"));
        int n5 = intent != null ? intent.getIntExtra("temperature", 0) / 10 : 0;
        if (s7.j.b(this.S, "item_celsius")) {
            string = xe1.e((int)n5, (String)" \u2103");
        } else if (s7.j.b(this.S, "item_fahrenheit")) {
            Locale locale3 = j.C((Context)this);
            Object[] arrobject3 = new Object[]{j.i0((double)n5)};
            String string8 = String.format((Locale)locale3, (String)"%.1f", (Object[])Arrays.copyOf((Object[])arrobject3, (int)1));
            s7.j.h(string8, "format(locale, format, *args)");
            string = string8.concat(" \u2109");
        } else {
            string = "";
        }
        textView4.setText((CharSequence)string);
        progressBar.setProgress(n5);
        SharedPreferences sharedPreferences = this.getSharedPreferences("tests", 0);
        Map map = sharedPreferences.getAll();
        s7.j.h((Object)map, "map");
        Iterator iterator = map.entrySet().iterator();
        int n6 = 0;
        while (iterator.hasNext()) {
            if (Integer.parseInt((String)String.valueOf((Object)((Map.Entry)iterator.next()).getValue())) != 1) continue;
            ++n6;
        }
        if (sharedPreferences.contains("total_test_count")) {
            n2 = sharedPreferences.getInt("total_test_count", 0);
        } else {
            j.S((Activity)this);
            n2 = sharedPreferences.getInt("total_test_count", 0);
        }
        TextView textView5 = (TextView)this.findViewById(2131362801);
        String string9 = this.getString(2131952228);
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(n6);
        stringBuilder4.append("/");
        stringBuilder4.append(n2);
        stringBuilder4.append(" ");
        stringBuilder4.append(string9);
        textView5.setText((CharSequence)stringBuilder4.toString());
        ProgressBar progressBar2 = (ProgressBar)this.findViewById(2131362472);
        progressBar2.setMax(n2);
        progressBar2.setProgress(n6);
    }
}

