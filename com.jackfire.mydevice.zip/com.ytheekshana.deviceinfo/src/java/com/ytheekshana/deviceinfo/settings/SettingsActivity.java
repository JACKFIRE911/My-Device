/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  androidx.activity.m
 *  androidx.activity.p
 *  androidx.activity.u
 *  androidx.fragment.app.a
 *  androidx.fragment.app.a0
 *  androidx.fragment.app.d0
 *  androidx.fragment.app.m0
 *  androidx.fragment.app.u0
 *  androidx.lifecycle.u
 *  com.google.android.material.appbar.MaterialToolbar
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.settings;

import a9.b;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.activity.m;
import androidx.activity.p;
import androidx.activity.u;
import androidx.fragment.app.a;
import androidx.fragment.app.d0;
import androidx.fragment.app.m0;
import androidx.fragment.app.u0;
import com.google.android.material.appbar.MaterialToolbar;
import com.ytheekshana.deviceinfo.libs.colorpreference.ColorPreferenceCompat;
import d9.c;
import e.n;
import f1.a0;
import java.io.Serializable;
import y6.e;

public final class SettingsActivity
extends n
implements b {
    public static ColorPreferenceCompat Q;

    @Override
    public final void f(int n2) {
        ColorPreferenceCompat colorPreferenceCompat = Q;
        if (colorPreferenceCompat != null) {
            colorPreferenceCompat.a((Serializable)Integer.valueOf((int)n2));
            colorPreferenceCompat.d0 = n2;
            colorPreferenceCompat.x(n2);
            colorPreferenceCompat.j();
        }
        SharedPreferences.Editor editor = this.getSharedPreferences(a0.a((Context)this), 0).edit();
        editor.putInt("accent_color_dialog", n2);
        editor.apply();
    }

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        SharedPreferences sharedPreferences = this.getSharedPreferences(a0.a((Context)this), 0);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        d0.super.onCreate(bundle);
        this.setContentView(2131558437);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        if (!sharedPreferences.contains("temperature_unit_pref")) {
            editor.putString("temperature_unit_pref", "item_celsius");
            editor.apply();
        }
        if (!sharedPreferences.contains("theme_pref")) {
            editor.putString("theme_pref", "theme_system_default");
            editor.apply();
        }
        if (Build.VERSION.SDK_INT >= 31 && !sharedPreferences.contains("system_color_pref")) {
            editor.putBoolean("system_color_pref", true);
            editor.apply();
        }
        if (this.findViewById(2131362570) != null) {
            if (bundle != null) {
                return;
            }
            u0 u02 = this.n();
            u02.getClass();
            a a2 = new a(u02);
            a2.e(2131362570, (androidx.fragment.app.a0)new c(), null, 1);
            a2.d(false);
        }
        m0 m02 = new m0(this);
        ((m)this).x.a((androidx.lifecycle.u)this, (p)m02);
    }
}

