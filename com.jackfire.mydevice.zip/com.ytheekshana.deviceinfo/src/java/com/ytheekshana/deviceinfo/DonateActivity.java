/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.TypedArray
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.text.TextUtils
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  android.view.accessibility.AccessibilityManager
 *  android.widget.Button
 *  android.widget.FrameLayout
 *  android.widget.TextView
 *  android.widget.Toast
 *  androidx.appcompat.widget.j
 *  androidx.coordinatorlayout.widget.CoordinatorLayout
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.u
 *  com.android.billingclient.api.Purchase
 *  com.bumptech.glide.c
 *  com.bumptech.glide.d
 *  com.google.android.gms.internal.ads.cj1
 *  com.google.android.gms.internal.play_billing.p
 *  com.google.android.gms.internal.play_billing.t1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  com.google.android.material.snackbar.SnackbarContentLayout
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.ref.WeakReference
 *  java.util.List
 *  java.util.concurrent.Callable
 *  java.util.concurrent.Future
 *  org.json.JSONObject
 */
package com.ytheekshana.deviceinfo;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.d0;
import androidx.lifecycle.u;
import ba.e0;
import ba.t0;
import ba.w;
import ba.x;
import com.android.billingclient.api.Purchase;
import com.bumptech.glide.c;
import com.google.android.gms.internal.ads.cj1;
import com.google.android.gms.internal.play_billing.p;
import com.google.android.gms.internal.play_billing.t1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.SnackbarContentLayout;
import com.ytheekshana.deviceinfo.MainActivity;
import d7.g;
import d7.i;
import d7.j;
import d7.l;
import d7.m;
import d7.n;
import d7.o;
import ea.d;
import java.lang.ref.WeakReference;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.Future;
import o2.a;
import o2.b;
import o2.h;
import o2.s;
import o2.v;
import org.json.JSONObject;
import y6.e;

public final class DonateActivity
extends e.n
implements o2.n {
    public static final /* synthetic */ int R;
    public a Q;

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public static final Object s(DonateActivity var0, Purchase var1_1, m9.d var2_2) {
        block29 : {
            block33 : {
                block32 : {
                    block31 : {
                        block30 : {
                            var3_3 = var0;
                            var0.getClass();
                            if (!(var2_2 instanceof w8.i)) ** GOTO lbl-1000
                            var5_4 = (w8.i)var2_2;
                            var58_5 = var5_4.w;
                            if ((var58_5 & Integer.MIN_VALUE) != 0) {
                                var5_4.w = var58_5 + Integer.MIN_VALUE;
                            } else lbl-1000: // 2 sources:
                            {
                                var5_4 = new w8.i(var3_3, var2_2);
                            }
                            var6_6 = var5_4.u;
                            var7_7 = n9.a.q;
                            var8_8 = var5_4.w;
                            var9_9 = 1;
                            if (var8_8 == 0) break block30;
                            if (var8_8 != var9_9) throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                            var3_3 = var5_4.t;
                            x.u(var6_6);
                            break block31;
                        }
                        x.u(var6_6);
                        var10_10 = var1_1.c.optInt("purchaseState", var9_9) != 4 ? var9_9 : 2;
                        if (var10_10 != var9_9) return j9.g.a;
                        if (var1_1.c.optBoolean("acknowledged", (boolean)var9_9) != false) return j9.g.a;
                        var11_11 = var1_1.c;
                        var12_12 = var11_11.optString("token", var11_11.optString("purchaseToken"));
                        var13_13 = var3_3.Q;
                        if (var13_13 != null) {
                            if (var12_12 == null) throw new IllegalArgumentException("Purchase token must be set");
                            var48_14 = new d5.e(0);
                            var48_14.a = var12_12;
                            var5_4.t = var3_3;
                            var5_4.w = var9_9;
                            var49_15 = new ba.o(null);
                            var50_16 = new u7.e(12, var49_15);
                            if (!var13_13.b()) {
                                var56_17 = var13_13.f;
                                var57_18 = s.j;
                                var56_17.o(c.n((int)2, (int)3, (h)var57_18));
                                var50_16.q(var57_18);
                            } else if (TextUtils.isEmpty((CharSequence)var48_14.a)) {
                                p.e((String)"BillingClient", (String)"Please provide a valid purchase token.");
                                var54_19 = var13_13.f;
                                var55_20 = s.g;
                                var54_19.o(c.n((int)26, (int)3, (h)var55_20));
                                var50_16.q(var55_20);
                            } else if (!var13_13.l) {
                                var52_21 = var13_13.f;
                                var53_22 = s.b;
                                var52_21.o(c.n((int)27, (int)3, (h)var53_22));
                                var50_16.q(var53_22);
                            } else if (var13_13.i(new v(var13_13, var48_14, var50_16, var9_9), 30000L, (Runnable)new androidx.appcompat.widget.j((Object)var13_13, (Object)var50_16, 13), var13_13.e()) == null) {
                                var51_23 = var13_13.g();
                                var13_13.f.o(c.n((int)25, (int)3, (h)var51_23));
                                var50_16.q(var51_23);
                            }
                            var6_6 = var49_15.i(var5_4);
                            if (var6_6 == var7_7) {
                                return var7_7;
                            } else {
                                ** GOTO lbl62
                            }
                        }
                        break block32;
                    }
                    var14_24 = (h)var6_6;
                    break block33;
                }
                var14_24 = null;
            }
            var15_25 = var14_24 != null ? new Integer(var14_24.a) : null;
            if (var15_25 == null) {
                return j9.g.a;
            }
            if (var15_25 != 0) return j9.g.a;
            var16_26 /* !! */  = var3_3.findViewById(2131362531);
            var17_27 = var3_3.getString(2131952258);
            var19_28 = null;
            do {
                if (var16_26 /* !! */  instanceof CoordinatorLayout) {
                    var20_30 = (ViewGroup)var16_26 /* !! */ ;
                    break block29;
                }
                if (var16_26 /* !! */  instanceof FrameLayout) {
                    if (var16_26 /* !! */ .getId() == 16908290) {
                        var20_30 = (ViewGroup)var16_26 /* !! */ ;
                        break block29;
                    }
                    var19_28 = (ViewGroup)var16_26 /* !! */ ;
                }
                if (var16_26 /* !! */  == null) continue;
                var47_29 = var16_26 /* !! */ .getParent();
                var16_26 /* !! */  = var47_29 instanceof View != false ? (View)var47_29 : null;
            } while (var16_26 /* !! */  != null);
            var20_30 = var19_28;
        }
        if (var20_30 == null) throw new IllegalArgumentException("No suitable parent found from the given view. Please provide a valid view.");
        var21_31 = var20_30.getContext();
        var22_32 = LayoutInflater.from((Context)var21_31);
        var23_33 = var21_31.obtainStyledAttributes(m.C);
        var24_34 = var23_33.getResourceId(0, -1);
        var25_35 = var23_33.getResourceId(var9_9, -1);
        var23_33.recycle();
        var26_36 = var24_34 != -1 && var25_35 != -1 ? var9_9 : 0;
        var27_37 = var26_36 != 0 ? 2131558535 : 2131558482;
        var28_38 = (SnackbarContentLayout)var22_32.inflate(var27_37, var20_30, false);
        var29_39 = new m(var21_31, var20_30, var28_38, var28_38);
        ((SnackbarContentLayout)var29_39.i.getChildAt(0)).getMessageView().setText((CharSequence)var17_27);
        var29_39.k = var30_40 = -2;
        var31_41 = (Button)var29_39.i.findViewById(2131362581);
        var31_41.setTextColor(MainActivity.U);
        var31_41.setBackground(null);
        var32_42 = var3_3.getString(2131952272);
        var33_43 = new g7.b(3, var3_3);
        var34_44 = ((SnackbarContentLayout)var29_39.i.getChildAt(0)).getActionView();
        if (!TextUtils.isEmpty((CharSequence)var32_42)) {
            var29_39.B = var9_9;
            var34_44.setVisibility(0);
            var34_44.setText((CharSequence)var32_42);
            var34_44.setOnClickListener((View.OnClickListener)new l(var29_39, 0, var33_43));
        } else {
            var34_44.setVisibility(8);
            var34_44.setOnClickListener(null);
            var29_39.B = false;
        }
        var35_45 = o.b();
        var36_46 = var29_39.k;
        if (var36_46 != var30_40) {
            var37_47 = Build.VERSION.SDK_INT;
            var38_48 = var29_39.A;
            if (var37_47 >= 29) {
                var46_49 = var29_39.B != false ? 4 : 0;
                var30_40 = cj1.a((AccessibilityManager)var38_48, (int)var36_46, (int)(2 | (var46_49 | var9_9)));
            } else if (!var29_39.B || !var38_48.isTouchExplorationEnabled()) {
                var30_40 = var36_46;
            }
        }
        var39_50 = var29_39.t;
        var59_52 = var40_51 = var35_45.a;
        // MONITORENTER : var59_52
        if (var35_45.c(var39_50)) {
            var45_53 = var35_45.c;
            var45_53.b = var30_40;
            var35_45.b.removeCallbacksAndMessages((Object)var45_53);
            var35_45.f(var35_45.c);
            // MONITOREXIT : var59_52
            return j9.g.a;
        }
        var42_54 = var35_45.d;
        if (var42_54 == null || (var44_55 = var39_50 != null && var42_54.a.get() == var39_50 ? var9_9 : 0) == 0) {
            var9_9 = 0;
        }
        if (var9_9 != 0) {
            var35_45.d.b = var30_40;
        } else {
            var35_45.d = new n(var30_40, var39_50);
        }
        var43_56 = var35_45.c;
        if (var43_56 != null && var35_45.a(var43_56, 4)) {
            // MONITOREXIT : var59_52
            return j9.g.a;
        }
        var35_45.c = null;
        var35_45.g();
        // MONITOREXIT : var59_52
        return j9.g.a;
    }

    @Override
    public final void h(h h2, List list) {
        s7.j.i(h2, "billingResult");
        int n2 = h2.a;
        if (n2 == 0 && list != null) {
            for (Purchase purchase : list) {
                e.g0((w)com.bumptech.glide.d.k((u)this), e0.a, new w8.o(this, purchase, null), 2);
            }
        } else {
            if (n2 == 1) {
                Toast.makeText((Context)this, (CharSequence)this.getString(2131952257), (int)0).show();
                return;
            }
            if (n2 == 7) {
                Toast.makeText((Context)this, (CharSequence)this.getString(2131951709), (int)0).show();
                return;
            }
            Toast.makeText((Context)this, (CharSequence)this.getString(2131952396), (int)0).show();
        }
    }

    public final void onCreate(Bundle bundle) {
        a a2;
        e.m((Context)this);
        int n2 = MainActivity.U;
        d0.super.onCreate(bundle);
        this.setContentView(2131558431);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        View view = this.findViewById(2131362689);
        s7.j.h((Object)view, "findViewById(R.id.txtCoffeePrice)");
        TextView textView = (TextView)view;
        View view2 = this.findViewById(2131362768);
        s7.j.h((Object)view2, "findViewById(R.id.txtSandwichPrice)");
        TextView textView2 = (TextView)view2;
        View view3 = this.findViewById(2131362730);
        s7.j.h((Object)view3, "findViewById(R.id.txtLunchPrice)");
        TextView textView3 = (TextView)view3;
        View view4 = this.findViewById(2131362713);
        s7.j.h((Object)view4, "findViewById(R.id.txtHugePrice)");
        TextView textView4 = (TextView)view4;
        View view5 = this.findViewById(2131361922);
        s7.j.h((Object)view5, "findViewById(R.id.btnCoffee)");
        MaterialButton materialButton = (MaterialButton)view5;
        materialButton.setTextColor(n2);
        View view6 = this.findViewById(2131361938);
        s7.j.h((Object)view6, "findViewById(R.id.btnSandwich)");
        MaterialButton materialButton2 = (MaterialButton)view6;
        materialButton2.setTextColor(n2);
        View view7 = this.findViewById(2131361932);
        s7.j.h((Object)view7, "findViewById(R.id.btnLunch)");
        MaterialButton materialButton3 = (MaterialButton)view7;
        materialButton3.setTextColor(n2);
        View view8 = this.findViewById(2131361930);
        s7.j.h((Object)view8, "findViewById(R.id.btnHuge)");
        MaterialButton materialButton4 = (MaterialButton)view8;
        materialButton4.setTextColor(n2);
        this.Q = a2 = new a((Context)this, this);
        w8.n n4 = new w8.n(this, materialButton, materialButton4, materialButton3, materialButton2, textView, textView3, textView2, textView4);
        a2.d(n4);
    }

    @Override
    public final void onDestroy() {
        a a2 = this.Q;
        if (a2 != null) {
            a2.a();
        }
        this.Q = null;
        super.onDestroy();
    }
}

