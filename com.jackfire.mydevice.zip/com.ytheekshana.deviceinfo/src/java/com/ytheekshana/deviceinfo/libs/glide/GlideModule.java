/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  com.bumptech.glide.b
 *  com.bumptech.glide.h
 *  com.bumptech.glide.l
 *  com.google.android.gms.internal.measurement.n3
 *  com.google.android.gms.internal.measurement.o3
 *  java.lang.Object
 *  java.util.Map
 */
package com.ytheekshana.deviceinfo.libs.glide;

import a3.g0;
import a3.l;
import android.content.Context;
import com.bumptech.glide.b;
import com.bumptech.glide.h;
import com.google.android.gms.internal.measurement.n3;
import com.google.android.gms.internal.measurement.o3;
import java.util.Map;
import s7.j;

public final class GlideModule
extends o3 {
    public final void w(Context context, b b4, com.bumptech.glide.l l3) {
        n3 n32;
        j.i((Object)b4, "glide");
        l l6 = new l(context);
        n3 n33 = n32 = l3.a;
        synchronized (n33) {
            ((g0)n32.r).f(l6);
            ((h)n32.s).a.clear();
            return;
        }
    }
}

