/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a9.c
 *  android.content.Context
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.os.Bundle
 *  android.util.AttributeSet
 *  android.view.View
 *  android.widget.ImageView
 *  androidx.fragment.app.a
 *  androidx.fragment.app.a0
 *  androidx.fragment.app.d0
 *  androidx.fragment.app.u0
 *  androidx.preference.Preference
 *  java.io.Serializable
 *  java.lang.Class
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package com.ytheekshana.deviceinfo.libs.colorpreference;

import a9.b;
import a9.c;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import androidx.fragment.app.a;
import androidx.fragment.app.a0;
import androidx.fragment.app.d0;
import androidx.fragment.app.u0;
import androidx.preference.Preference;
import ba.x;
import java.io.Serializable;
import w8.z;

public class ColorPreferenceCompat
extends Preference
implements b {
    public int d0 = 0;
    public boolean e0 = true;

    public ColorPreferenceCompat(Context context) {
        super(context, null);
        this.D(null, 0);
    }

    public ColorPreferenceCompat(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.D(attributeSet, 0);
    }

    public ColorPreferenceCompat(Context context, AttributeSet attributeSet, int n5) {
        super(context, attributeSet, n5);
        this.D(attributeSet, n5);
    }

    public final void D(AttributeSet attributeSet, int n5) {
        TypedArray typedArray = this.q.getTheme().obtainStyledAttributes(attributeSet, z.a, n5, n5);
        try {
            this.e0 = typedArray.getBoolean(1, true);
            this.V = 2131558476;
            return;
        }
        finally {
            typedArray.recycle();
        }
    }

    @Override
    public final void f(int n5) {
        this.a((Serializable)Integer.valueOf((int)n5));
        this.d0 = n5;
        this.x(n5);
        this.j();
    }

    public final void l() {
        super.l();
        if (this.e0) {
            c c4;
            StringBuilder stringBuilder = new StringBuilder("color_");
            stringBuilder.append(this.B);
            String string = stringBuilder.toString();
            d0 d02 = x.p(this.q);
            if (d02 != null && (c4 = (c)d02.n().E(string)) != null) {
                c4.D0 = this;
                c4.g0();
            }
        }
    }

    public final void n(f1.d0 d02) {
        super.n(d02);
        ImageView imageView = (ImageView)d02.r(2131362111);
        if (imageView != null) {
            x.r(imageView, this.d0, false);
        }
    }

    public final void o() {
        if (this.e0) {
            StringBuilder stringBuilder = new StringBuilder("color_");
            stringBuilder.append(this.B);
            String string = stringBuilder.toString();
            int n5 = this.d0;
            Bundle bundle = new Bundle();
            bundle.putInt("selected_color", n5);
            c c4 = new c();
            c4.X(bundle);
            c4.D0 = this;
            c4.g0();
            d0 d02 = x.p(this.q);
            if (d02 != null) {
                u0 u02 = d02.n();
                u02.getClass();
                a a3 = new a(u02);
                a3.e(0, (a0)c4, string, 1);
                a3.d(false);
            }
        }
    }

    public final Object r(TypedArray typedArray, int n5) {
        return typedArray.getInt(n5, 0);
    }

    public final void v(Object object, boolean bl) {
        int n5 = bl ? this.e(0) : ((Integer)object).intValue();
        this.a((Serializable)Integer.valueOf((int)n5));
        this.d0 = n5;
        this.x(n5);
        this.j();
    }
}

