/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.DialogInterface
 *  android.content.DialogInterface$OnCancelListener
 *  android.content.DialogInterface$OnClickListener
 *  android.content.Intent
 *  android.os.Bundle
 *  android.view.Window
 *  e.k
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  p2.a
 *  p6.b
 *  y6.e
 */
package com.ytheekshana.deviceinfo.libs.permissions;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;
import b9.a;
import b9.b;
import e.f;
import e.j;
import e.k;
import java.io.Serializable;
import java.util.ArrayList;
import y6.e;

public class PermissionsActivity
extends Activity {
    public static p2.a t;
    public ArrayList q;
    public ArrayList r;
    public ArrayList s;

    public final void finish() {
        t = null;
        super.finish();
    }

    public final void onActivityResult(int n2, int n5, Intent intent) {
        if (n2 == 6739 && t != null) {
            ArrayList arrayList = this.q;
            int n6 = arrayList.size();
            String[] arrstring = new String[n6];
            for (int i2 = 0; i2 < n6; ++i2) {
                arrstring[i2] = (String)arrayList.get(i2);
            }
            e.l((Context)this, (String[])arrstring, (p2.a)t);
        }
        super.finish();
    }

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        int n2 = 0;
        this.setFinishOnTouchOutside(false);
        Intent intent = this.getIntent();
        if (intent != null && intent.hasExtra("permissions")) {
            this.getWindow().setStatusBarColor(0);
            this.q = (ArrayList)intent.getSerializableExtra("permissions");
            this.r = new ArrayList();
            this.s = new ArrayList();
            for (String string : this.q) {
                if (this.checkSelfPermission(string) == 0) continue;
                this.r.add((Object)string);
                this.s.add((Object)string);
            }
            if (this.r.isEmpty()) {
                p2.a a2 = t;
                this.finish();
                if (a2 != null) {
                    a2.c();
                }
                return;
            }
            ArrayList arrayList = this.r;
            int n5 = arrayList.size();
            String[] arrstring = new String[n5];
            while (n2 < n5) {
                arrstring[n2] = (String)arrayList.get(n2);
                ++n2;
            }
            this.requestPermissions(arrstring, 6937);
            return;
        }
        this.finish();
    }

    public final void onRequestPermissionsResult(int n2, String[] arrstring, int[] arrn) {
        if (arrn.length == 0) {
            p2.a a2 = t;
            this.finish();
            if (a2 != null) {
                a2.b(this.getApplicationContext());
                return;
            }
        } else {
            this.r.clear();
            for (int i2 = 0; i2 < arrn.length; ++i2) {
                if (arrn[i2] == 0) continue;
                this.r.add((Object)arrstring[i2]);
            }
            if (this.r.size() == 0) {
                p2.a a3 = t;
                this.finish();
                if (a3 != null) {
                    a3.c();
                    return;
                }
            } else {
                ArrayList arrayList = new ArrayList();
                for (String string : this.r) {
                    if (this.s.contains((Object)string)) continue;
                    arrayList.add((Object)string);
                }
                if (arrayList.size() > 0) {
                    p2.a a4 = t;
                    this.finish();
                    if (a4 != null) {
                        a4.b(this.getApplicationContext());
                        return;
                    }
                } else {
                    if (t != null) {
                        p6.b b5 = new p6.b((Context)this);
                        String string = this.getString(2131952238);
                        f f2 = b5.a;
                        f2.d = string;
                        f2.f = this.getString(2131952237);
                        b5.f(this.getString(2131952357), (DialogInterface.OnClickListener)new a(0, (Object)this));
                        a a6 = new a(1, (Object)this);
                        f2.i = f2.a.getText(17039360);
                        f2.j = a6;
                        f2.k = new b(this);
                        b5.a().show();
                        return;
                    }
                    this.finish();
                }
            }
        }
    }
}

