/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageInfo
 *  android.content.pm.PackageManager
 *  android.net.ConnectivityManager
 *  android.net.Network
 *  android.net.NetworkCapabilities
 *  android.net.Uri
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Environment
 *  android.os.ParcelFileDescriptor
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.activity.h
 *  androidx.activity.m
 *  androidx.activity.result.c
 *  androidx.activity.result.e
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.u
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.chip.Chip
 *  com.google.android.material.chip.ChipGroup
 *  com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
 *  com.google.android.material.progressindicator.LinearProgressIndicator
 *  java.io.BufferedWriter
 *  java.io.File
 *  java.io.FileDescriptor
 *  java.io.FileOutputStream
 *  java.io.IOException
 *  java.io.OutputStream
 *  java.io.OutputStreamWriter
 *  java.io.Writer
 *  java.lang.Boolean
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.charset.Charset
 *  java.nio.charset.StandardCharsets
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.concurrent.atomic.AtomicInteger
 */
package com.ytheekshana.deviceinfo;

import aa.a;
import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.view.View;
import androidx.activity.h;
import androidx.activity.m;
import androidx.fragment.app.d0;
import androidx.lifecycle.u;
import c.c;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.concurrent.atomic.AtomicInteger;
import q0.b;
import s5.j;
import w8.p;
import y6.e;

public final class ExportActivity
extends n {
    public static final /* synthetic */ int Z;
    public String Q;
    public String R;
    public String S;
    public String T;
    public String U;
    public HashMap V;
    public LinearProgressIndicator W;
    public boolean X = true;
    public float Y;

    public final void onCreate(Bundle bundle) {
        LinearProgressIndicator linearProgressIndicator;
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558432);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        int n2 = 0;
        SharedPreferences sharedPreferences = this.getSharedPreferences("Web", 0);
        this.Q = String.valueOf((Object)sharedPreferences.getString("market_name", Build.MODEL));
        this.R = String.valueOf((Object)sharedPreferences.getString("soc", Build.BOARD));
        this.S = String.valueOf((Object)sharedPreferences.getString("soc_arch", "no"));
        this.T = String.valueOf((Object)sharedPreferences.getString("soc_process", "no"));
        this.U = String.valueOf((Object)sharedPreferences.getString("memory", "no"));
        this.V = new HashMap();
        this.W = (LinearProgressIndicator)this.findViewById(2131362476);
        int n4 = j.d(MainActivity.U);
        LinearProgressIndicator linearProgressIndicator2 = this.W;
        if (linearProgressIndicator2 != null) {
            int[] arrn = new int[]{MainActivity.U};
            linearProgressIndicator2.setIndicatorColor(arrn);
        }
        if ((linearProgressIndicator = this.W) != null) {
            linearProgressIndicator.setTrackColor(n4);
        }
        ChipGroup chipGroup = (ChipGroup)this.findViewById(2131362048);
        ChipGroup chipGroup2 = (ChipGroup)this.findViewById(2131362051);
        u9.j j2 = new u9.j();
        j2.q = chipGroup.getChildCount();
        chipGroup2.setOnCheckedStateChangeListener((m6.h)new i4.b(this, (Object)j2, (Object)chipGroup, 5));
        int n5 = j2.q;
        while (n2 < n5) {
            View view = chipGroup.getChildAt(n2);
            s7.j.g((Object)view, "null cannot be cast to non-null type com.google.android.material.chip.Chip");
            Chip chip = (Chip)view;
            chip.setChecked(true);
            chip.setSelected(true);
            ++n2;
        }
        c c2 = new c();
        b b3 = new b(14, this);
        StringBuilder stringBuilder = new StringBuilder("activity_rq#");
        stringBuilder.append(((m)this).A.getAndIncrement());
        String string = stringBuilder.toString();
        androidx.activity.result.e e2 = ((m)this).B.c(string, (u)this, (s7.j)c2, (androidx.activity.result.c)b3);
        ExtendedFloatingActionButton extendedFloatingActionButton = (ExtendedFloatingActionButton)this.findViewById(2131362182);
        extendedFloatingActionButton.setBackgroundColor(MainActivity.U);
        p p2 = new p(this, j2, (Object)chipGroup, (Object)e2, 0);
        extendedFloatingActionButton.setOnClickListener((View.OnClickListener)p2);
    }

    public final float s(float f3) {
        float f4;
        this.Y = f4 = f3 + this.Y;
        return f4;
    }

    public final boolean t(ConnectivityManager connectivityManager, int n2) {
        Network network = connectivityManager.getActiveNetwork();
        if (network == null) {
            return false;
        }
        NetworkCapabilities networkCapabilities = connectivityManager.getNetworkCapabilities(network);
        if (networkCapabilities == null) {
            return false;
        }
        return networkCapabilities.hasTransport(n2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void u(Uri uri, String string) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                ParcelFileDescriptor parcelFileDescriptor = uri != null ? this.getContentResolver().openFileDescriptor(uri, "w") : null;
                FileDescriptor fileDescriptor = null;
                if (parcelFileDescriptor != null) {
                    fileDescriptor = parcelFileDescriptor.getFileDescriptor();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(fileDescriptor);
                byte[] arrby = string.getBytes(a.a);
                s7.j.h(arrby, "this as java.lang.String).getBytes(charset)");
                fileOutputStream.write(arrby);
                fileOutputStream.close();
                if (parcelFileDescriptor == null) return;
                {
                    parcelFileDescriptor.close();
                    return;
                }
            }
            File file = new File(Environment.getExternalStoragePublicDirectory((String)Environment.DIRECTORY_DOWNLOADS).getPath());
            if (!file.exists() && !file.mkdirs()) {
                return;
            }
            BufferedWriter bufferedWriter = new BufferedWriter((Writer)new OutputStreamWriter((OutputStream)new FileOutputStream(new File(file, "Device Info Report.txt")), StandardCharsets.UTF_8));
            bufferedWriter.append((CharSequence)string);
            bufferedWriter.flush();
            bufferedWriter.close();
            return;
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    /*
     * Exception decompiling
     */
    public final boolean v(Uri var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.UnsupportedOperationException
        // org.benf.cfr.reader.b.a.a.f.c(Op01WithProcessedDataAndByteJumps.java:77)
        // org.benf.cfr.reader.entities.e.f.a(ExceptionGroup.java:90)
        // org.benf.cfr.reader.entities.e.f.a(ExceptionGroup.java:67)
        // org.benf.cfr.reader.entities.e.b.a(ExceptionAggregator.java:360)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:273)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public final ArrayList w() {
        ArrayList arrayList = new ArrayList();
        try {
            String string = this.getString(2131952428);
            s7.j.h(string, "getString(R.string.version)");
            PackageManager packageManager = this.getPackageManager();
            s7.j.h((Object)packageManager, "packageManager");
            for (PackageInfo packageInfo : s7.j.n(packageManager, 0)) {
                if ((129 & packageInfo.applicationInfo.flags) > 0) continue;
                String string2 = j.z(packageManager, packageInfo);
                String string3 = packageInfo.applicationInfo.packageName;
                s7.j.h(string3, "pack.applicationInfo.packageName");
                String string4 = packageInfo.versionName;
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(string);
                stringBuilder.append(" : ");
                stringBuilder.append(string4);
                arrayList.add((Object)new c9.b(string2, string3, stringBuilder.toString(), null));
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        return arrayList;
    }

    public final boolean x(String string) {
        HashMap hashMap = this.V;
        Boolean bl = hashMap != null ? (Boolean)hashMap.get((Object)string) : null;
        if (bl != null) {
            return bl;
        }
        return false;
    }
}

