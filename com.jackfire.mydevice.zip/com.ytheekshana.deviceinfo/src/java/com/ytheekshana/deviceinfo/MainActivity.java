/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  androidx.activity.m
 *  androidx.activity.p
 *  androidx.activity.u
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.b0
 *  androidx.lifecycle.u
 *  androidx.lifecycle.v0
 *  androidx.lifecycle.z0
 *  androidx.viewpager2.adapter.b
 *  androidx.viewpager2.widget.ViewPager2
 *  com.bumptech.glide.d
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.tabs.TabLayout
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.List
 *  java.util.concurrent.CopyOnWriteArrayList
 */
package com.ytheekshana.deviceinfo;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.activity.m;
import androidx.activity.p;
import androidx.fragment.app.d0;
import androidx.lifecycle.b0;
import androidx.lifecycle.v0;
import androidx.lifecycle.z0;
import androidx.viewpager2.widget.ViewPager2;
import ba.e0;
import c0.d;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.tabs.TabLayout;
import e.n;
import e.t;
import ea.c;
import f1.a0;
import f9.a;
import i1.g1;
import i1.n0;
import i1.o0;
import j2.w;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import q0.b;
import q2.k;
import q2.l;
import s7.j;
import w8.u;
import w8.v;
import w8.x;
import w8.y;
import y6.e;

public final class MainActivity
extends n {
    public static int U;
    public static int V;
    public static int W;
    public static boolean X;
    public static boolean Y;
    public static boolean Z;
    public a Q;
    public ViewPager2 R;
    public SharedPreferences S;
    public l T;

    /*
     * Enabled aggressive block sorting
     */
    public final void onCreate(Bundle bundle) {
        String string;
        String string2;
        n0 n02;
        e.m((Context)this);
        SharedPreferences sharedPreferences = this.getSharedPreferences(a0.a((Context)this), 0);
        j.h((Object)sharedPreferences, "getDefaultSharedPreferences(this)");
        this.S = sharedPreferences;
        String string3 = sharedPreferences.getString("theme_pref", "theme_system_default");
        if (string3 != null) {
            int n2 = string3.hashCode();
            if (n2 != -160705760) {
                if (n2 != 548759596) {
                    if (n2 == 1227218279 && string3.equals((Object)"theme_system_default")) {
                        t.p(-1);
                        int n4 = 48 & this.getApplicationContext().getResources().getConfiguration().uiMode;
                        if (n4 != 16) {
                            if (n4 == 32) {
                                X = true;
                            }
                        } else {
                            X = false;
                        }
                    }
                } else if (string3.equals((Object)"theme_dark")) {
                    t.p(2);
                    X = true;
                }
            } else if (string3.equals((Object)"theme_light")) {
                t.p(1);
                X = false;
            }
        }
        if (Build.VERSION.SDK_INT >= 31) {
            boolean bl;
            SharedPreferences sharedPreferences2 = this.S;
            if (sharedPreferences2 == null) {
                j.I("sharedPrefs");
                throw null;
            }
            Z = bl = sharedPreferences2.getBoolean("system_color_pref", true);
            if (bl) {
                U = d.a((Context)this, 17170494);
                V = d.a((Context)this, 17170495);
            } else {
                int n5;
                SharedPreferences sharedPreferences3 = this.S;
                if (sharedPreferences3 == null) {
                    j.I("sharedPrefs");
                    throw null;
                }
                U = n5 = sharedPreferences3.getInt("accent_color_dialog", -14575885);
                V = e.K((Context)this, n5);
            }
        } else {
            int n6;
            SharedPreferences sharedPreferences4 = this.S;
            if (sharedPreferences4 == null) {
                j.I("sharedPrefs");
                throw null;
            }
            U = n6 = sharedPreferences4.getInt("accent_color_dialog", -14575885);
            V = e.K((Context)this, n6);
        }
        int n7 = X ? 285212671 : 268435456;
        W = n7;
        SharedPreferences sharedPreferences5 = this.S;
        if (sharedPreferences5 == null) {
            j.I("sharedPrefs");
            throw null;
        }
        Y = j.b(sharedPreferences5.getString("temperature_unit_pref", "item_celsius"), "item_celsius");
        d0.super.onCreate(bundle);
        this.setContentView(2131558434);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        View view = this.findViewById(2131362886);
        j.h((Object)view, "findViewById(R.id.viewPager)");
        this.R = (ViewPager2)view;
        u u2 = new u(this);
        ViewPager2 viewPager2 = this.R;
        if (viewPager2 == null) {
            j.I("viewPager");
            throw null;
        }
        viewPager2.setAdapter((n0)((Object)u2));
        ViewPager2 viewPager22 = this.R;
        if (viewPager22 == null) {
            j.I("viewPager");
            throw null;
        }
        viewPager22.setOffscreenPageLimit(2);
        View view2 = this.findViewById(2131362614);
        j.h((Object)view2, "findViewById(R.id.tabs)");
        TabLayout tabLayout = (TabLayout)view2;
        tabLayout.setSelectedTabIndicatorColor(V);
        ViewPager2 viewPager23 = this.R;
        if (viewPager23 == null) {
            j.I("viewPager");
            throw null;
        }
        f7.l l3 = new f7.l(tabLayout, viewPager23, new b(15, this));
        if (l3.e) {
            throw new IllegalStateException("TabLayoutMediator is already attached");
        }
        l3.d = n02 = viewPager23.getAdapter();
        if (n02 == null) {
            throw new IllegalStateException("TabLayoutMediator attached before ViewPager2 has an adapter");
        }
        l3.e = true;
        f7.j j2 = new f7.j(tabLayout);
        ((List)viewPager23.s.b).add((Object)j2);
        f7.k k2 = new f7.k(viewPager23, true);
        ArrayList arrayList = tabLayout.e0;
        if (!arrayList.contains((Object)k2)) {
            arrayList.add((Object)k2);
        }
        g1 g12 = new g1(2, l3);
        l3.d.q.registerObserver((Object)g12);
        l3.a();
        tabLayout.j(viewPager23.getCurrentItem(), 0.0f, true, true, true);
        this.Q = (a)new w((z0)this).m(a.class);
        SharedPreferences sharedPreferences6 = this.getSharedPreferences("Web", 0);
        String string4 = sharedPreferences6.getString("market_name", null);
        String string5 = sharedPreferences6.getString("soc", null);
        String string6 = "no";
        String string7 = sharedPreferences6.getString("soc_arch", string6);
        if (string7 == null) {
            string7 = string6;
        }
        if ((string = sharedPreferences6.getString("soc_process", string6)) == null) {
            string = string6;
        }
        if ((string2 = sharedPreferences6.getString("memory", string6)) != null) {
            string6 = string2;
        }
        if (string4 != null && string5 != null) {
            if (!j.b(string4, Build.MODEL) && !j.b(string5, Build.BOARD)) {
                a a2 = this.Q;
                if (a2 == null) {
                    j.I("mainActivityViewModel");
                    throw null;
                }
                a2.d.f((Object)string4);
                a a3 = this.Q;
                if (a3 == null) {
                    j.I("mainActivityViewModel");
                    throw null;
                }
                a3.e.f((Object)string5);
                a a4 = this.Q;
                if (a4 == null) {
                    j.I("mainActivityViewModel");
                    throw null;
                }
                a4.f.f((Object)string7);
                a a5 = this.Q;
                if (a5 == null) {
                    j.I("mainActivityViewModel");
                    throw null;
                }
                a5.g.f((Object)string);
                a a6 = this.Q;
                if (a6 == null) {
                    j.I("mainActivityViewModel");
                    throw null;
                }
                a6.h.f((Object)string6);
            } else {
                e.g0((ba.w)com.bumptech.glide.d.k((androidx.lifecycle.u)this), e0.b, new v(this, sharedPreferences6, null), 2);
            }
        } else {
            e.g0((ba.w)com.bumptech.glide.d.k((androidx.lifecycle.u)this), e0.b, new v(this, sharedPreferences6, null), 2);
        }
        SharedPreferences sharedPreferences7 = this.S;
        if (sharedPreferences7 == null) {
            j.I("sharedPrefs");
            throw null;
        }
        SharedPreferences.Editor editor = sharedPreferences7.edit();
        j.h((Object)editor, "sharedPrefs.edit()");
        SharedPreferences sharedPreferences8 = this.S;
        if (sharedPreferences8 == null) {
            j.I("sharedPrefs");
            throw null;
        }
        boolean bl = sharedPreferences8.getBoolean("RequestReview", false);
        y y2 = new y(this, bl, editor);
        ViewPager2 viewPager24 = this.R;
        if (viewPager24 != null) {
            w8.w w2 = new w8.w(y2, bl);
            ((List)viewPager24.s.b).add((Object)w2);
            ((m)this).x.a((androidx.lifecycle.u)this, (p)y2);
            x x2 = new x(0, this);
            w w3 = ((m)this).s;
            ((CopyOnWriteArrayList)w3.s).add((Object)x2);
            ((Runnable)w3.r).run();
            return;
        }
        j.I("viewPager");
        throw null;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public final void onDestroy() {
        l l3 = this.T;
        if (l3 != null) {
            HashSet hashSet;
            HashSet hashSet2 = hashSet = l3.b;
            synchronized (hashSet2) {
                for (k k2 : l3.b) {
                    boolean bl = k2.D == "DeviceInfoRequest";
                    if (!bl) continue;
                    k2.b();
                }
            }
        }
        super.onDestroy();
    }
}

