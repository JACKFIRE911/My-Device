/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.os.Bundle
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.xe1
 *  java.lang.CharSequence
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Arrays
 *  java.util.Locale
 */
package com.ytheekshana.deviceinfo;

import a2.s;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import androidx.fragment.app.d0;
import com.github.mikephil.charting.charts.LineChart;
import com.google.android.gms.internal.ads.xe1;
import e.n;
import java.util.Arrays;
import java.util.Locale;
import s3.c;
import s3.d;
import s3.e;
import s3.f;
import s3.g;
import s7.j;
import w3.b;

public final class SensorActivity
extends n
implements SensorEventListener {
    public static final /* synthetic */ int b0;
    public SensorManager Q;
    public Sensor R;
    public Locale S = Locale.US;
    public float T;
    public float U;
    public float V;
    public c5.c W;
    public TextView X;
    public TextView Y;
    public TextView Z;
    public LineChart a0;

    public static g s(String string, int n2) {
        g g2 = new g(string);
        g2.d = 2;
        g2.j(n2);
        g2.J = false;
        g2.C = 3;
        g2.k(1.5f);
        g2.j = false;
        return g2;
    }

    public final void onAccuracyChanged(Sensor sensor, int n2) {
    }

    /*
     * Exception decompiling
     */
    public final void onCreate(Bundle var1_1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // java.lang.IllegalStateException: Inconsistent graph [] lbl65 : y: NOP\u000a does not have a source [2, 3, 5, 6] lbl58 : r: if (var50_25 == null) goto lbl65;

        // org.benf.cfr.reader.b.a.a.b.g$1.a(Cleaner.java:49)
        // org.benf.cfr.reader.b.a.a.b.g$1.a(Cleaner.java:22)
        // org.benf.cfr.reader.util.d.c.d(GraphVisitorDFS.java:68)
        // org.benf.cfr.reader.b.a.a.b.g.a(Cleaner.java:54)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:536)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public final void onPause() {
        d0.super.onPause();
        SensorManager sensorManager = this.Q;
        if (sensorManager != null) {
            sensorManager.unregisterListener((SensorEventListener)this);
        }
    }

    public final void onResume() {
        d0.super.onResume();
        SensorManager sensorManager = this.Q;
        if (sensorManager != null) {
            sensorManager.registerListener((SensorEventListener)this, this.R, 500000);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public final void onSensorChanged(SensorEvent var1_1) {
        block36 : {
            block35 : {
                var2_2 = 1;
                var3_4 = var1_1 != null && (var89_3 = var1_1.values) != null ? var89_3.length : var2_2;
                if (var3_4 < 2) {
                    var87_6 = var1_1 != null && (var88_5 = var1_1.values) != null ? var88_5[0] : 0.0f;
                    this.T = var87_6;
                } else if (var3_4 < 3) {
                    var83_8 = var1_1 != null && (var86_7 = var1_1.values) != null ? var86_7[0] : 0.0f;
                    this.T = var83_8;
                    var84_10 = var1_1 != null && (var85_9 = var1_1.values) != null ? var85_9[var2_2] : 0.0f;
                    this.U = var84_10;
                } else {
                    var4_12 = var1_1 != null && (var82_11 = var1_1.values) != null ? var82_11[0] : 0.0f;
                    this.T = var4_12;
                    var5_14 = var1_1 != null && (var81_13 = var1_1.values) != null ? var81_13[var2_2] : 0.0f;
                    this.U = var5_14;
                    var6_16 = var1_1 != null && (var80_15 = var1_1.values) != null ? var80_15[2] : 0.0f;
                    this.V = var6_16;
                }
                var7_17 = this.a0;
                if (var7_17 == null) return;
                var8_18 = (f)var7_17.getData();
                if (var8_18 == null) return;
                var9_19 = (g)var8_18.e(0);
                if (var9_19 == null) {
                    var9_19 = SensorActivity.s("X", c0.d.a((Context)this, 2131100405));
                    var8_18.a(var9_19);
                }
                if ((var10_20 = (g)var8_18.e(var2_2)) == null) {
                    var10_20 = SensorActivity.s("Y", c0.d.a((Context)this, 2131100406));
                    var8_18.a(var10_20);
                }
                if ((var11_21 = (g)var8_18.e(2)) == null) {
                    var11_21 = SensorActivity.s("Z", c0.d.a((Context)this, 2131100404));
                    var8_18.a(var11_21);
                }
                var8_18.b(new e(var9_19.e(), this.T), 0);
                var8_18.b(new e(var10_20.e(), this.U), var2_2);
                var8_18.b(new e(var11_21.e(), this.V), 2);
                var8_18.c();
                var12_22 = this.a0;
                if (var12_22 != null) {
                    var12_22.f();
                }
                if ((var13_23 = this.a0) != null) {
                    var13_23.setVisibleXRangeMaximum(30.0f);
                }
                if ((var14_24 = this.a0) != null) {
                    var14_24.i(var8_18.f());
                }
                var15_25 = null;
                var16_27 = var1_1 != null && (var76_26 = var1_1.sensor) != null ? Integer.valueOf((int)var76_26.getType()) : null;
                var17_28 = var16_27 != null && var16_27 == var2_2 || var16_27 != null && var16_27 == 35 ? var2_2 : 0;
                var18_29 = var17_28 != 0 || var16_27 != null && var16_27 == 9 ? var2_2 : 0;
                var19_30 = var18_29 != 0 || var16_27 != null && var16_27 == 10 ? var2_2 : 0;
                if (var19_30 == 0) break block35;
                var70_31 = this.S;
                var71_32 = new Object[var2_2];
                var71_32[0] = Float.valueOf((float)this.T);
                var26_33 = s.u("X : ", xe1.k((Object[])var71_32, (int)var2_2, (Locale)var70_31, (String)"%.2f", (String)"format(locale, format, *args)"), " m/s2");
                var72_34 = this.S;
                var73_35 = new Object[var2_2];
                var73_35[0] = Float.valueOf((float)this.U);
                var50_36 = s.u("Y : ", xe1.k((Object[])var73_35, (int)var2_2, (Locale)var72_34, (String)"%.2f", (String)"format(locale, format, *args)"), " m/s2");
                var74_37 = this.S;
                var75_38 = new Object[var2_2];
                var75_38[0] = Float.valueOf((float)this.V);
                var53_39 = s.u("Z : ", xe1.k((Object[])var75_38, (int)var2_2, (Locale)var74_37, (String)"%.2f", (String)"format(locale, format, *args)"), " m/s2");
                ** GOTO lbl116
            }
            var20_42 = var16_27 != null && var16_27 == 4 || var16_27 != null && var16_27 == 16 ? var2_2 : 0;
            var21_43 = var20_42 != 0 || var16_27 != null && var16_27 == 28 ? var2_2 : 0;
            if (var21_43 == 0) break block36;
            var64_44 = this.S;
            var65_45 = new Object[var2_2];
            var65_45[0] = Float.valueOf((float)this.T);
            var26_33 = s.u("X : ", xe1.k((Object[])var65_45, (int)var2_2, (Locale)var64_44, (String)"%.2f", (String)"format(locale, format, *args)"), " rad/s");
            var66_46 = this.S;
            var67_47 = new Object[var2_2];
            var67_47[0] = Float.valueOf((float)this.U);
            var50_36 = s.u("Y : ", xe1.k((Object[])var67_47, (int)var2_2, (Locale)var66_46, (String)"%.2f", (String)"format(locale, format, *args)"), " rad/s");
            var68_48 = this.S;
            var69_49 = new Object[var2_2];
            var69_49[0] = Float.valueOf((float)this.V);
            var53_39 = s.u("Z : ", xe1.k((Object[])var69_49, (int)var2_2, (Locale)var68_48, (String)"%.2f", (String)"format(locale, format, *args)"), " rad/s");
            ** GOTO lbl116
        }
        var22_50 = var16_27 != null && var16_27 == 11 || var16_27 != null && var16_27 == 15 ? var2_2 : 0;
        if (var22_50 != 0) {
            var55_51 = this.S;
            var56_52 = new Object[var2_2];
            var56_52[0] = Float.valueOf((float)this.T);
            var57_53 = String.format((Locale)var55_51, (String)"%.2f", (Object[])Arrays.copyOf((Object[])var56_52, (int)var2_2));
            j.h(var57_53, "format(locale, format, *args)");
            var26_33 = "X : ".concat(var57_53);
            var58_54 = this.S;
            var59_55 = new Object[var2_2];
            var59_55[0] = Float.valueOf((float)this.U);
            var60_56 = String.format((Locale)var58_54, (String)"%.2f", (Object[])Arrays.copyOf((Object[])var59_55, (int)var2_2));
            j.h(var60_56, "format(locale, format, *args)");
            var15_25 = "Y : ".concat(var60_56);
            var61_57 = this.S;
            var62_58 = new Object[var2_2];
            var62_58[0] = Float.valueOf((float)this.V);
            var63_59 = String.format((Locale)var61_57, (String)"%.2f", (Object[])Arrays.copyOf((Object[])var62_58, (int)var2_2));
            j.h(var63_59, "format(locale, format, *args)");
            var27_41 = "Z : ".concat(var63_59);
        } else {
            var23_60 = var16_27 != null && var16_27 == 2 || var16_27 != null && var16_27 == 14 ? var2_2 : 0;
            if (var23_60 != 0) {
                var46_61 = this.S;
                var47_62 = new Object[var2_2];
                var47_62[0] = Float.valueOf((float)this.T);
                var26_33 = s.u("X : ", xe1.k((Object[])var47_62, (int)var2_2, (Locale)var46_61, (String)"%.2f", (String)"format(locale, format, *args)"), " \u00b5T");
                var48_63 = this.S;
                var49_64 = new Object[var2_2];
                var49_64[0] = Float.valueOf((float)this.U);
                var50_36 = s.u("Y : ", xe1.k((Object[])var49_64, (int)var2_2, (Locale)var48_63, (String)"%.2f", (String)"format(locale, format, *args)"), " \u00b5T");
                var51_65 = this.S;
                var52_66 = new Object[var2_2];
                var52_66[0] = Float.valueOf((float)this.V);
                var53_39 = s.u("Z : ", xe1.k((Object[])var52_66, (int)var2_2, (Locale)var51_65, (String)"%.2f", (String)"format(locale, format, *args)"), " \u00b5T");
lbl116: // 3 sources:
                var54_40 = var50_36;
                var27_41 = var53_39;
                var15_25 = var54_40;
            } else {
                if (var16_27 != null && var16_27 == 5) {
                    var43_67 = this.S;
                    var44_68 = new Object[var2_2];
                    var44_68[0] = Float.valueOf((float)this.T);
                    var45_69 = String.format((Locale)var43_67, (String)"%.2f", (Object[])Arrays.copyOf((Object[])var44_68, (int)var2_2));
                    j.h(var45_69, "format(locale, format, *args)");
                    var26_33 = var45_69.concat(" lux");
                } else if (var16_27 != null && var16_27 == 6) {
                    var40_70 = this.S;
                    var41_71 = new Object[var2_2];
                    var41_71[0] = Float.valueOf((float)this.T);
                    var42_72 = String.format((Locale)var40_70, (String)"%.2f", (Object[])Arrays.copyOf((Object[])var41_71, (int)var2_2));
                    j.h(var42_72, "format(locale, format, *args)");
                    var26_33 = var42_72.concat(" hPa");
                } else if (var16_27 != null && var16_27 == 13) {
                    var37_73 = this.S;
                    var38_74 = new Object[var2_2];
                    var38_74[0] = Float.valueOf((float)this.T);
                    var39_75 = String.format((Locale)var37_73, (String)"%.2f", (Object[])Arrays.copyOf((Object[])var38_74, (int)var2_2));
                    j.h(var39_75, "format(locale, format, *args)");
                    var26_33 = var39_75.concat("\u2103");
                } else {
                    var24_76 = this.S;
                    var25_77 = new Object[var2_2];
                    var25_77[0] = Float.valueOf((float)this.T);
                    var26_33 = xe1.k((Object[])var25_77, (int)var2_2, (Locale)var24_76, (String)"%.2f", (String)"format(locale, format, *args)");
                }
                var27_41 = null;
            }
        }
        if (this.T != 0.0f) {
            var2_2 = 0;
        }
        if (var2_2 == 0) {
            var35_78 = this.X;
            if (var35_78 != null) {
                var35_78.setVisibility(0);
            }
            var36_79 = this.X;
            if (var36_79 != null) {
                var36_79.setText((CharSequence)var26_33);
            }
        } else {
            var28_80 = this.X;
            if (var28_80 != null) {
                var28_80.setVisibility(8);
            }
        }
        if (var15_25 != null) {
            var33_81 = this.Y;
            if (var33_81 != null) {
                var33_81.setVisibility(0);
            }
            var34_82 = this.Y;
            if (var34_82 != null) {
                var34_82.setText((CharSequence)var15_25);
            }
        } else {
            var29_83 = this.Y;
            if (var29_83 != null) {
                var29_83.setVisibility(8);
            }
        }
        if (var27_41 != null) {
            var31_84 = this.Z;
            if (var31_84 != null) {
                var31_84.setVisibility(0);
            }
            var32_85 = this.Z;
            if (var32_85 == null) {
                return;
            }
            var32_85.setText((CharSequence)var27_41);
            return;
        }
        var30_86 = this.Z;
        if (var30_86 == null) {
            return;
        }
        var30_86.setVisibility(8);
    }
}

