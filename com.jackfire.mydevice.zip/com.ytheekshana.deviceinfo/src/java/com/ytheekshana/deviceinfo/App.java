/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.app.Application$ActivityLifecycleCallbacks
 *  n6.i
 *  n6.k
 *  o4.a
 */
package com.ytheekshana.deviceinfo;

import android.app.Application;
import n6.i;
import n6.k;
import o4.a;

public final class App
extends Application {
    public final void onCreate() {
        super.onCreate();
        this.registerActivityLifecycleCallbacks((Application.ActivityLifecycleCallbacks)new i(new k(new a(5))));
    }
}

