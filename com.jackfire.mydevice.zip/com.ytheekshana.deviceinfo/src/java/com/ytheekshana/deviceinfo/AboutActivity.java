/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.res.ColorStateList
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.CharSequence
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.d0;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import w8.a;
import y6.e;

public final class AboutActivity
extends n {
    public static final /* synthetic */ int Q;

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        int n2 = MainActivity.U;
        d0.super.onCreate(bundle);
        this.setContentView(2131558428);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        TextView textView = (TextView)this.findViewById(2131362830);
        ((TextView)this.findViewById(2131362746)).setText((CharSequence)this.getApplicationContext().getPackageName());
        textView.setText((CharSequence)"3.3.3.9 (181)");
        ((ImageView)this.findViewById(2131362267)).setImageDrawable(this.getApplicationInfo().loadIcon(this.getPackageManager()));
        MaterialButton materialButton = (MaterialButton)this.findViewById(2131361923);
        materialButton.setTextColor(n2);
        materialButton.setOnClickListener((View.OnClickListener)new a(this, 0));
        MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131361942);
        materialButton2.setTextColor(n2);
        materialButton2.setOnClickListener((View.OnClickListener)new a(this, 1));
        MaterialButton materialButton3 = (MaterialButton)this.findViewById(2131361925);
        materialButton3.setTextColor(n2);
        materialButton3.setIconTint(ColorStateList.valueOf((int)n2));
        materialButton3.setOnClickListener((View.OnClickListener)new a(this, 2));
        ((MaterialButton)this.findViewById(2131361928)).setOnClickListener((View.OnClickListener)new a(this, 3));
        ((MaterialButton)this.findViewById(2131361943)).setOnClickListener((View.OnClickListener)new a(this, 4));
        ((MaterialButton)this.findViewById(2131361931)).setOnClickListener((View.OnClickListener)new a(this, 5));
        ((MaterialButton)this.findViewById(2131361945)).setOnClickListener((View.OnClickListener)new a(this, 6));
        ((MaterialButton)this.findViewById(2131361946)).setOnClickListener((View.OnClickListener)new a(this, 7));
        ((MaterialButton)this.findViewById(2131361940)).setOnClickListener((View.OnClickListener)new a(this, 8));
        MaterialButton materialButton4 = (MaterialButton)this.findViewById(2131361941);
        materialButton4.setTextColor(n2);
        materialButton4.setIconTint(ColorStateList.valueOf((int)n2));
        materialButton4.setOnClickListener((View.OnClickListener)new a(this, 9));
    }
}

