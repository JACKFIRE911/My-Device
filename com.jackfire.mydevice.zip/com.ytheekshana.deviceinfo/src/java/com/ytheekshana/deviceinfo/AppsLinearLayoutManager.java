/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  java.lang.Exception
 */
package com.ytheekshana.deviceinfo;

import android.content.Context;
import androidx.recyclerview.widget.LinearLayoutManager;
import i1.e1;
import i1.k1;

public final class AppsLinearLayoutManager
extends LinearLayoutManager {
    public AppsLinearLayoutManager(Context context) {
        super(1);
    }

    public final void e0(e1 e12, k1 k12) {
        try {
            super.e0(e12, k12);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }
}

