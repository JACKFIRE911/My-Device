/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.KeyEvent
 *  android.view.KeyEvent$Callback
 *  android.view.View
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.LifecycleCoroutineScopeImpl
 *  androidx.lifecycle.u
 *  androidx.recyclerview.widget.LinearLayoutManager
 *  androidx.recyclerview.widget.RecyclerView
 *  com.bumptech.glide.d
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.tabs.TabLayout
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package com.ytheekshana.deviceinfo;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import androidx.fragment.app.d0;
import androidx.lifecycle.LifecycleCoroutineScopeImpl;
import androidx.lifecycle.u;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import ba.e0;
import ba.w;
import com.github.mikephil.charting.charts.PieChart;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.tabs.TabLayout;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import f7.f;
import f7.i;
import i1.n0;
import i1.x0;
import java.util.ArrayList;
import r.a;
import r3.b;
import r3.c;
import w8.d;
import y6.e;

public final class AppAnalyzerActivity
extends n {
    public static final /* synthetic */ int b0;
    public final String Q = "installer";
    public final String R = "target";
    public final String S = "minimum";
    public final String T = "signature";
    public final String U = "platform";
    public final String V = "storage";
    public String W = "installer";
    public ArrayList X = new ArrayList();
    public s3.i Y;
    public x8.f Z;
    public PieChart a0;

    public final void onCreate(Bundle bundle) {
        PieChart pieChart;
        PieChart pieChart2;
        x8.f f3;
        c c2;
        PieChart pieChart3;
        PieChart pieChart4;
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558429);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        RecyclerView recyclerView = (RecyclerView)this.findViewById(2131362489);
        recyclerView.setLayoutManager((x0)new LinearLayoutManager(1));
        this.Z = f3 = new x8.f((Context)this, new ArrayList());
        recyclerView.setAdapter((n0)f3);
        this.a0 = pieChart2 = (PieChart)this.findViewById(2131362020);
        if (pieChart2 != null) {
            pieChart2.setNoDataText("");
        }
        if ((pieChart4 = this.a0) != null) {
            pieChart4.setUsePercentValues(true);
        }
        if ((pieChart3 = this.a0) != null) {
            pieChart3.setHoleColor(0);
        }
        if ((c2 = (pieChart = this.a0) != null ? pieChart.getDescription() : null) != null) {
            c2.a = false;
        }
        PieChart pieChart5 = this.a0;
        if (pieChart5 != null) {
            pieChart5.setHighlightPerTapEnabled(true);
        }
        PieChart pieChart6 = this.a0;
        if (pieChart6 != null) {
            pieChart6.setDrawEntryLabels(false);
        }
        PieChart pieChart7 = this.a0;
        r3.e e2 = null;
        if (pieChart7 != null) {
            e2 = pieChart7.getLegend();
        }
        if (e2 != null) {
            e2.h = 2;
        }
        if (e2 != null) {
            e2.i = 2;
        }
        if (e2 != null) {
            e2.e = a.o((View)recyclerView, 2130968885);
        }
        if (e2 != null) {
            e2.j = false;
        }
        TabLayout tabLayout = (TabLayout)this.findViewById(2131362612);
        tabLayout.setSelectedTabIndicatorColor(MainActivity.V);
        f f4 = tabLayout.g();
        f4.a(2131952046);
        tabLayout.a(f4);
        f f5 = tabLayout.g();
        f5.a(2131952377);
        tabLayout.a(f5);
        if (Build.VERSION.SDK_INT >= 24) {
            f f6 = tabLayout.g();
            f6.a(2131952121);
            tabLayout.a(f6);
        }
        f f7 = tabLayout.g();
        f7.a(2131952361);
        tabLayout.a(f7);
        f f8 = tabLayout.g();
        f8.a(2131952244);
        tabLayout.a(f8);
        f f9 = tabLayout.g();
        f9.a(2131952368);
        tabLayout.a(f9);
        i i2 = new i((KeyEvent.Callback)this);
        ArrayList arrayList = tabLayout.e0;
        if (!arrayList.contains((Object)i2)) {
            arrayList.add((Object)i2);
        }
    }

    public final void onResume() {
        d0.super.onResume();
        this.s();
    }

    public final void s() {
        d d2 = new d(0);
        LifecycleCoroutineScopeImpl lifecycleCoroutineScopeImpl = com.bumptech.glide.d.k((u)this);
        ea.d d3 = e0.a;
        d3.getClass();
        e.g0((w)lifecycleCoroutineScopeImpl, e.r0(d3, d2), new w8.f(this, null), 2);
    }
}

