/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.Canvas
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Point
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.MotionEvent
 *  android.view.View
 *  android.widget.TextView
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  q0.b
 *  s7.j
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.TextView;
import e9.s0;
import java.util.ArrayList;
import q0.b;
import s7.j;

public class MultiTouchCanvas
extends View {
    public s0 q;
    public final Paint r;
    public int s;
    public int t;
    public final ArrayList u;
    public final int[] v;
    public final int[] w;

    public MultiTouchCanvas(Context context, AttributeSet attributeSet) {
        Paint paint;
        super(context, attributeSet);
        this.r = paint = new Paint();
        this.u = new ArrayList();
        this.v = new int[]{-1, -49088, -12517568, -12566273, -48897, -192, -12517377};
        this.w = new int[]{-6250336, -6291456, -16736256, -16777056, -6291296, -6250496, -16736096};
        this.t = (int)(20.0f * this.getResources().getDisplayMetrics().density);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(-1);
        paint.setAntiAlias(true);
        paint.setStrokeWidth(3.0f);
        for (int i2 = 0; i2 < 100; ++i2) {
            Point point = new Point();
            this.u.add((Object)point);
        }
    }

    public final void onDraw(Canvas canvas) {
        int n2;
        super.onDraw(canvas);
        canvas.drawColor(-16777216);
        for (int i2 = 0; i2 < (n2 = this.s); ++i2) {
            Point point = (Point)this.u.get(i2);
            Paint paint = this.r;
            int[] arrn = this.w;
            paint.setColor(arrn[i2 % arrn.length]);
            canvas.drawLine(0.0f, (float)point.y, (float)this.getWidth(), (float)point.y, paint);
            float f2 = point.x;
            canvas.drawLine(f2, 0.0f, f2, (float)this.getHeight(), paint);
            canvas.drawCircle((float)point.x, (float)point.y, 5.0f * (float)this.t / 4.0f, paint);
            int[] arrn2 = this.v;
            paint.setColor(arrn2[i2 % arrn2.length]);
            canvas.drawCircle((float)point.x, (float)point.y, (float)this.t, paint);
        }
        s0 s02 = this.q;
        if (s02 != null) {
            TextView textView = (TextView)((b)s02).r;
            j.i((Object)textView, (String)"$txtInfo");
            StringBuilder stringBuilder = new StringBuilder("Touches Detected : ");
            stringBuilder.append(n2);
            textView.setText((CharSequence)stringBuilder.toString());
        }
    }

    public final boolean onTouchEvent(MotionEvent motionEvent) {
        block8 : {
            int n2;
            block6 : {
                int n5;
                int n6;
                ArrayList arrayList;
                block7 : {
                    n6 = motionEvent.getActionIndex();
                    int n7 = motionEvent.getActionMasked();
                    n2 = motionEvent.getPointerCount();
                    if (n2 > this.s) {
                        this.s = n2;
                    }
                    int n8 = 0;
                    do {
                        arrayList = this.u;
                        if (n8 >= n2) break;
                        ((Point)arrayList.get((int)n8)).x = (int)motionEvent.getX(n8);
                        ((Point)arrayList.get((int)n8)).y = (int)motionEvent.getY(n8);
                        ++n8;
                    } while (true);
                    if (n7 == 0) break block6;
                    if (n7 == 1 || n7 == 3) break block7;
                    if (n7 == 5) break block6;
                    if (n7 != 6) break block8;
                }
                if (n6 < (n5 = n2 - 1)) {
                    Point point = (Point)arrayList.get(n6);
                    ((Point)arrayList.get((int)n5)).x = point.x;
                    ((Point)arrayList.get((int)n5)).y = point.y;
                }
                break block8;
            }
            this.s = n2;
        }
        this.postInvalidate();
        return true;
    }

    public void setStatusListener(s0 s02) {
        this.q = s02;
    }
}

