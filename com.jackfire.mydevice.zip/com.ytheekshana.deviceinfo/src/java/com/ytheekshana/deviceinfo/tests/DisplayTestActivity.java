/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.fragment.app.d0;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.i0;
import e9.j0;
import y6.e;

public final class DisplayTestActivity
extends n {
    public static final /* synthetic */ int Q;

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        int n2 = MainActivity.U;
        d0.super.onCreate(bundle);
        this.setContentView(2131558443);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        TextView textView = (TextView)this.findViewById(2131362697);
        MaterialButton materialButton = (MaterialButton)this.findViewById(2131361933);
        MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131362259);
        MaterialButton materialButton3 = (MaterialButton)this.findViewById(2131362260);
        if (Build.VERSION.SDK_INT < 31 || !MainActivity.Z) {
            materialButton.setBackgroundColor(n2);
            materialButton.setTextColor(-1);
            materialButton2.setBackgroundColor(n2);
            materialButton2.setTextColor(-1);
            materialButton2.setIconTintResource(2131100428);
            materialButton3.setBackgroundColor(n2);
            materialButton3.setTextColor(-1);
            materialButton3.setIconTintResource(2131100428);
        }
        i0 i02 = new i0(this, (Object)materialButton2, (View)materialButton3, (View)materialButton, (View)textView, 0);
        materialButton.setOnClickListener((View.OnClickListener)i02);
        SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
        materialButton2.setOnClickListener((View.OnClickListener)new j0(editor, this, 0));
        materialButton3.setOnClickListener((View.OnClickListener)new j0(editor, this, 1));
    }
}

