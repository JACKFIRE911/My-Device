/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Vibrator
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.fragment.app.d0
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import androidx.fragment.app.d0;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.c0;
import e.n;
import e9.w0;
import s7.j;
import y6.e;

public final class VibrationTestActivity
extends n {
    public static final /* synthetic */ int R;
    public Vibrator Q;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        long[] arrl;
        int n2;
        int n5;
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558451);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        try {
            Vibrator vibrator;
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            MaterialButton materialButton = (MaterialButton)this.findViewById(2131362259);
            MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131362260);
            n5 = Build.VERSION.SDK_INT;
            if (n5 < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(MainActivity.U);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(MainActivity.U);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new w0(editor, this, 0));
            n2 = 1;
            materialButton2.setOnClickListener((View.OnClickListener)new w0(editor, this, n2));
            this.Q = vibrator = j.s((Context)this);
            arrl = new long[3];
            arrl[0] = 0L;
            arrl[n2] = 1000L;
            arrl[2] = 0L;
            if (vibrator == null) return;
            if (vibrator.hasVibrator() != n2) return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        if (n2 == 0) return;
        if (n5 >= 26) {
            Vibrator vibrator = this.Q;
            if (vibrator == null) return;
            c0.y(vibrator, c0.k(arrl));
            return;
        }
        Vibrator vibrator = this.Q;
        if (vibrator == null) return;
        vibrator.vibrate(arrl, 0);
    }

    public final void onPause() {
        Vibrator vibrator = this.Q;
        if (vibrator != null) {
            vibrator.cancel();
        }
        d0.super.onPause();
    }
}

