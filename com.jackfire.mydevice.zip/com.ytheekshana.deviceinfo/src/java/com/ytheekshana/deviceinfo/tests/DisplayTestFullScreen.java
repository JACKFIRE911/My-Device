/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.eh1
 *  java.lang.Object
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.d0;
import com.google.android.gms.internal.ads.eh1;
import e.n;
import g7.b;
import y6.e;

public class DisplayTestFullScreen
extends n {
    public ConstraintLayout Q;
    public int R = 0;

    public final void onCreate(Bundle bundle) {
        ConstraintLayout constraintLayout;
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558430);
        this.getWindow().addFlags(1024);
        if (Build.VERSION.SDK_INT >= 28) {
            eh1.x((WindowManager.LayoutParams)this.getWindow().getAttributes());
        }
        this.getWindow().getDecorView().setSystemUiVisibility(5894);
        this.Q = constraintLayout = (ConstraintLayout)this.findViewById(2131362117);
        constraintLayout.setBackgroundColor(-16777216);
        this.Q.setOnClickListener((View.OnClickListener)new b(8, this));
    }
}

