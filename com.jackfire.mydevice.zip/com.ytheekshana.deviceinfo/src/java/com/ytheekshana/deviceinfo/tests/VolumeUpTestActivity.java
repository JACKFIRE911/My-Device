/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Vibrator
 *  android.view.KeyEvent
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.fragment.app.d0
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.View;
import androidx.fragment.app.d0;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.y0;
import s7.j;
import y6.e;

public final class VolumeUpTestActivity
extends n {
    public static final /* synthetic */ int R;
    public Vibrator Q;

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558453);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        try {
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            View view = this.findViewById(2131362259);
            j.h((Object)view, "findViewById(R.id.imgBtnFailed)");
            MaterialButton materialButton = (MaterialButton)view;
            View view2 = this.findViewById(2131362260);
            j.h((Object)view2, "findViewById(R.id.imgBtnSuccess)");
            MaterialButton materialButton2 = (MaterialButton)view2;
            if (Build.VERSION.SDK_INT < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(MainActivity.U);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(MainActivity.U);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new y0(editor, this, 0));
            materialButton2.setOnClickListener((View.OnClickListener)new y0(editor, this, 1));
            this.Q = j.s((Context)this);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public final boolean onKeyDown(int var1, KeyEvent var2) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    public final boolean onKeyUp(int n2, KeyEvent keyEvent) {
        if (n2 == 24) {
            return true;
        }
        return Activity.super.onKeyUp(n2, keyEvent);
    }
}

