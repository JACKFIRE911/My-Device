/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.media.MediaRecorder
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.Looper
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.ai1
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  com.google.android.material.progressindicator.LinearProgressIndicator
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import androidx.fragment.app.d0;
import com.google.android.gms.internal.ads.ai1;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.r0;
import s5.j;
import w8.t;
import y6.e;

public final class MicrophoneTestActivity
extends n {
    public static final /* synthetic */ int U;
    public LinearProgressIndicator Q;
    public MediaRecorder R;
    public Handler S;
    public boolean T;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558449);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        int n2 = MainActivity.U;
        try {
            MediaRecorder mediaRecorder;
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            MaterialButton materialButton = (MaterialButton)this.findViewById(2131362259);
            MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131362260);
            int n5 = Build.VERSION.SDK_INT;
            if (n5 < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(n2);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(n2);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new r0(editor, this, 0));
            materialButton2.setOnClickListener((View.OnClickListener)new r0(editor, this, 1));
            this.S = new Handler(Looper.getMainLooper());
            View view = this.findViewById(2131362466);
            s7.j.h((Object)view, "findViewById(R.id.progressBarAmplitude)");
            this.Q = (LinearProgressIndicator)view;
            int n6 = j.d(n2);
            LinearProgressIndicator linearProgressIndicator = this.Q;
            if (linearProgressIndicator == null) {
                s7.j.I("progressBarAmplitude");
                throw null;
            }
            linearProgressIndicator.setIndicatorColor(new int[]{n2});
            LinearProgressIndicator linearProgressIndicator2 = this.Q;
            if (linearProgressIndicator2 == null) {
                s7.j.I("progressBarAmplitude");
                throw null;
            }
            linearProgressIndicator2.setTrackColor(n6);
            LinearProgressIndicator linearProgressIndicator3 = this.Q;
            if (linearProgressIndicator3 == null) {
                s7.j.I("progressBarAmplitude");
                throw null;
            }
            linearProgressIndicator3.setMax(48000);
            if (n5 >= 31) {
                xe1.n();
                mediaRecorder = ai1.c((Context)this);
            } else {
                mediaRecorder = new MediaRecorder();
            }
            this.R = mediaRecorder;
            e.k((Context)this, "android.permission.RECORD_AUDIO", new t(this, 2));
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    @Override
    public final void onDestroy() {
        Handler handler = this.S;
        if (handler != null) {
            MediaRecorder mediaRecorder;
            MediaRecorder mediaRecorder2;
            handler.removeCallbacksAndMessages(null);
            if (this.T) {
                MediaRecorder mediaRecorder3 = this.R;
                if (mediaRecorder3 != null) {
                    mediaRecorder3.stop();
                }
                this.T = false;
            }
            if ((mediaRecorder2 = this.R) != null) {
                mediaRecorder2.reset();
            }
            if ((mediaRecorder = this.R) != null) {
                mediaRecorder.release();
            }
            super.onDestroy();
            return;
        }
        s7.j.I("handler");
        throw null;
    }
}

