/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.hardware.Sensor
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Vibrator
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.fragment.app.d0
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import androidx.fragment.app.d0;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.a;
import e9.v0;
import q0.b;
import s7.j;
import y6.e;

public final class AccelerometerTestActivity
extends n {
    public static final /* synthetic */ int S;
    public SensorManager Q;
    public v0 R;

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        try {
            d0.super.onCreate(bundle);
            this.setContentView(2131558440);
            this.r((MaterialToolbar)this.findViewById(2131362659));
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            Vibrator vibrator = j.s((Context)this);
            MaterialButton materialButton = (MaterialButton)this.findViewById(2131362259);
            MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131362260);
            if (Build.VERSION.SDK_INT < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(MainActivity.U);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(MainActivity.U);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new a(editor, this, 0));
            materialButton2.setOnClickListener((View.OnClickListener)new a(editor, this, 1));
            Object object = this.getSystemService("sensor");
            j.g(object, "null cannot be cast to non-null type android.hardware.SensorManager");
            this.Q = (SensorManager)object;
            this.R = new v0(new b(19, (Object)vibrator));
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public final void onPause() {
        v0 v02 = this.R;
        if (v02 != null && v02.t != null) {
            v02.q.a();
            v02.s.unregisterListener((SensorEventListener)v02, v02.t);
            v02.s = null;
            v02.t = null;
        }
        d0.super.onPause();
    }

    public final void onResume() {
        v0 v02 = this.R;
        if (v02 != null) {
            SensorManager sensorManager = this.Q;
            if (v02.t == null) {
                Sensor sensor;
                v02.t = sensor = sensorManager.getDefaultSensor(1);
                if (sensor != null) {
                    v02.s = sensorManager;
                    sensorManager.registerListener((SensorEventListener)v02, sensor, 3);
                }
            }
        }
        d0.super.onResume();
    }
}

