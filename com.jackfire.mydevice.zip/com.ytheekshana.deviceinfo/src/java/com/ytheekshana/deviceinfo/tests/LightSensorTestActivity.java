/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  androidx.fragment.app.d0
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.CharSequence
 *  java.lang.Exception
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.fragment.app.d0;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.o0;
import s7.j;
import y6.e;

public final class LightSensorTestActivity
extends n
implements SensorEventListener {
    public static final /* synthetic */ int T;
    public SensorManager Q;
    public Sensor R;
    public TextView S;

    public final void onAccuracyChanged(Sensor sensor, int n2) {
    }

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558447);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        try {
            SensorManager sensorManager;
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            this.S = (TextView)this.findViewById(2131362728);
            View view = this.findViewById(2131362259);
            j.h((Object)view, "findViewById(R.id.imgBtnFailed)");
            MaterialButton materialButton = (MaterialButton)view;
            View view2 = this.findViewById(2131362260);
            j.h((Object)view2, "findViewById(R.id.imgBtnSuccess)");
            MaterialButton materialButton2 = (MaterialButton)view2;
            if (Build.VERSION.SDK_INT < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(MainActivity.U);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(MainActivity.U);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new o0(editor, this, 0));
            materialButton2.setOnClickListener((View.OnClickListener)new o0(editor, this, 1));
            Object object = this.getSystemService("sensor");
            j.g(object, "null cannot be cast to non-null type android.hardware.SensorManager");
            this.Q = sensorManager = (SensorManager)object;
            this.R = sensorManager.getDefaultSensor(5);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public final void onPause() {
        SensorManager sensorManager = this.Q;
        if (sensorManager != null) {
            sensorManager.unregisterListener((SensorEventListener)this);
        }
        d0.super.onPause();
    }

    public final void onResume() {
        SensorManager sensorManager = this.Q;
        if (sensorManager != null) {
            sensorManager.registerListener((SensorEventListener)this, this.R, 3);
        }
        d0.super.onResume();
    }

    public final void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor;
        boolean bl = sensorEvent != null && (sensor = sensorEvent.sensor) != null && sensor.getType() == 5;
        if (bl) {
            String string = xe1.e((int)((int)Math.rint((double)sensorEvent.values[0])), (String)" lx");
            TextView textView = this.S;
            if (textView == null) {
                return;
            }
            textView.setText((CharSequence)string);
        }
    }
}

