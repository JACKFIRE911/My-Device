/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.content.SharedPreferences
 *  android.content.res.ColorStateList
 *  android.os.Bundle
 *  android.os.RemoteException
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.ImageView
 *  android.widget.TextView
 *  androidx.activity.m
 *  androidx.activity.p
 *  androidx.activity.u
 *  androidx.fragment.app.d0
 *  androidx.fragment.app.m0
 *  androidx.lifecycle.LifecycleCoroutineScopeImpl
 *  androidx.lifecycle.u
 *  com.bumptech.glide.d
 *  com.google.android.gms.internal.ads.vf
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.card.MaterialCardView
 *  com.google.android.material.chip.Chip
 *  com.google.android.material.progressindicator.CircularProgressIndicator
 *  java.lang.CharSequence
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import a8.b1;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.os.RemoteException;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.m;
import androidx.activity.p;
import androidx.fragment.app.d0;
import androidx.fragment.app.m0;
import androidx.lifecycle.LifecycleCoroutineScopeImpl;
import androidx.lifecycle.u;
import ba.e0;
import ba.w;
import c.a;
import com.google.android.gms.internal.ads.vf;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.chip.Chip;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.c0;
import ea.d;
import o4.c;
import o4.f;
import q0.b;
import v4.f0;
import v4.z2;
import w8.a0;
import x4.b0;
import y6.e;

public final class AutomaticTestActivity
extends n {
    public static final /* synthetic */ int z0;
    public MaterialCardView Q;
    public c5.c R;
    public y4.a S;
    public SharedPreferences T;
    public TextView U;
    public TextView V;
    public CircularProgressIndicator W;
    public ImageView X;
    public MaterialCardView Y;
    public MaterialCardView Z;
    public MaterialCardView a0;
    public MaterialCardView b0;
    public MaterialCardView c0;
    public MaterialCardView d0;
    public MaterialCardView e0;
    public TextView f0;
    public TextView g0;
    public TextView h0;
    public TextView i0;
    public TextView j0;
    public TextView k0;
    public TextView l0;
    public ImageView m0;
    public ImageView n0;
    public ImageView o0;
    public ImageView p0;
    public ImageView q0;
    public ImageView r0;
    public ImageView s0;
    public Chip t0;
    public Chip u0;
    public Chip v0;
    public Chip w0;
    public Chip x0;
    public Chip y0;

    public static final void s(AutomaticTestActivity automaticTestActivity, int n2) {
        CircularProgressIndicator circularProgressIndicator = automaticTestActivity.W;
        if (circularProgressIndicator != null) {
            circularProgressIndicator.b(n2, true);
        }
        String string = xe1.e((int)n2, (String)"%");
        TextView textView = automaticTestActivity.V;
        if (textView == null) {
            return;
        }
        textView.setText((CharSequence)string);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        try {
            Chip chip;
            Chip chip2;
            Chip chip3;
            Chip chip4;
            CircularProgressIndicator circularProgressIndicator;
            Chip chip5;
            Chip chip6;
            d0.super.onCreate(bundle);
            this.setContentView(2131558441);
            this.r((MaterialToolbar)this.findViewById(2131362659));
            this.T = this.getSharedPreferences("optimizations", 0);
            this.W = circularProgressIndicator = (CircularProgressIndicator)this.findViewById(2131362483);
            if (circularProgressIndicator != null) {
                int[] arrn = new int[]{MainActivity.U};
                circularProgressIndicator.setIndicatorColor(arrn);
            }
            this.U = (TextView)this.findViewById(2131362793);
            this.V = (TextView)this.findViewById(2131362750);
            this.X = (ImageView)this.findViewById(2131362291);
            this.Y = (MaterialCardView)this.findViewById(2131361981);
            this.Z = (MaterialCardView)this.findViewById(2131361995);
            this.a0 = (MaterialCardView)this.findViewById(2131361984);
            this.b0 = (MaterialCardView)this.findViewById(2131361986);
            this.c0 = (MaterialCardView)this.findViewById(2131361985);
            this.d0 = (MaterialCardView)this.findViewById(2131361982);
            this.e0 = (MaterialCardView)this.findViewById(2131361998);
            this.f0 = (TextView)this.findViewById(2131362724);
            this.g0 = (TextView)this.findViewById(2131362818);
            this.h0 = (TextView)this.findViewById(2131362770);
            this.i0 = (TextView)this.findViewById(2131362774);
            this.j0 = (TextView)this.findViewById(2131362772);
            this.k0 = (TextView)this.findViewById(2131362738);
            this.l0 = (TextView)this.findViewById(2131362837);
            this.m0 = (ImageView)this.findViewById(2131362270);
            this.n0 = (ImageView)this.findViewById(2131362301);
            this.o0 = (ImageView)this.findViewById(2131362281);
            this.p0 = (ImageView)this.findViewById(2131362285);
            this.q0 = (ImageView)this.findViewById(2131362283);
            this.r0 = (ImageView)this.findViewById(2131362274);
            this.s0 = (ImageView)this.findViewById(2131362303);
            Intent intent = new Intent("android.settings.SETTINGS");
            this.t0 = chip6 = (Chip)this.findViewById(2131362067);
            if (chip6 != null) {
                chip6.setChipBackgroundColor(ColorStateList.valueOf((int)MainActivity.U));
            }
            Chip chip7 = this.t0;
            if (chip7 != null) {
                chip7.setOnClickListener((View.OnClickListener)new e9.b(this, intent, 0));
            }
            this.u0 = chip3 = (Chip)this.findViewById(2131362064);
            if (chip3 != null) {
                chip3.setChipBackgroundColor(ColorStateList.valueOf((int)MainActivity.U));
            }
            Chip chip8 = this.u0;
            if (chip8 != null) {
                chip8.setOnClickListener((View.OnClickListener)new e9.b(this, intent, 1));
            }
            this.v0 = chip4 = (Chip)this.findViewById(2131362066);
            if (chip4 != null) {
                chip4.setChipBackgroundColor(ColorStateList.valueOf((int)MainActivity.U));
            }
            Chip chip9 = this.v0;
            if (chip9 != null) {
                chip9.setOnClickListener((View.OnClickListener)new e9.b(this, intent, 2));
            }
            this.w0 = chip2 = (Chip)this.findViewById(2131362065);
            if (chip2 != null) {
                chip2.setChipBackgroundColor(ColorStateList.valueOf((int)MainActivity.U));
            }
            Chip chip10 = this.w0;
            if (chip10 != null) {
                chip10.setOnClickListener((View.OnClickListener)new e9.b(this, intent, 3));
            }
            this.x0 = chip5 = (Chip)this.findViewById(2131362063);
            if (chip5 != null) {
                chip5.setChipBackgroundColor(ColorStateList.valueOf((int)MainActivity.U));
            }
            Chip chip11 = this.x0;
            if (chip11 != null) {
                chip11.setOnClickListener((View.OnClickListener)new e9.b(this, intent, 4));
            }
            this.y0 = chip = (Chip)this.findViewById(2131362068);
            if (chip != null) {
                chip.setChipBackgroundColor(ColorStateList.valueOf((int)MainActivity.U));
            }
            Chip chip12 = this.y0;
            if (chip12 != null) {
                chip12.setOnClickListener((View.OnClickListener)new e9.b(this, intent, 5));
            }
            m0 m02 = new m0(this);
            if (!b1.W) {
                o4.d d2 = new o4.d((Context)this, "ca-app-pub-9823272508031979/6646959081");
                d2.b(new b(20, this));
                try {
                    f0 f02 = d2.b;
                    vf vf2 = new vf(4, false, -1, false, 1, null, false, 0, 0, false);
                    f02.p3(vf2);
                }
                catch (RemoteException remoteException) {
                    b0.k("Failed to specify native ad options", remoteException);
                }
                d2.c(new a0(4, this));
                d2.a().a(new f(new a(24)));
                y4.a.a((Context)this, "ca-app-pub-9823272508031979/6035510872", new f(new a(24)), new c0(this, m02));
            }
            ((m)this).x.a((u)this, (p)m02);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public final void onResume() {
        d0.super.onResume();
        w8.d d2 = new w8.d(3);
        LifecycleCoroutineScopeImpl lifecycleCoroutineScopeImpl = com.bumptech.glide.d.k((u)this);
        d d3 = e0.a;
        d3.getClass();
        e.g0((w)lifecycleCoroutineScopeImpl, e.r0(d3, d2), new e9.a0(this, null), 2);
    }
}

