/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.TextView
 *  androidx.activity.h
 *  androidx.activity.m
 *  androidx.activity.result.c
 *  androidx.activity.result.e
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.u
 *  com.bumptech.glide.d
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.concurrent.atomic.AtomicInteger
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import androidx.activity.h;
import androidx.activity.m;
import androidx.fragment.app.d0;
import androidx.lifecycle.u;
import ba.e0;
import ba.w;
import c.c;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.h0;
import ea.d;
import java.util.concurrent.atomic.AtomicInteger;
import q0.b;
import s7.j;
import y6.e;

public final class BluetoothTestActivity
extends n {
    public static final /* synthetic */ int V;
    public TextView Q;
    public MaterialButton R;
    public SharedPreferences.Editor S;
    public final androidx.activity.result.e T;
    public final e.h0 U;

    public BluetoothTestActivity() {
        c c2 = new c();
        b b3 = new b(21, this);
        StringBuilder stringBuilder = new StringBuilder("activity_rq#");
        stringBuilder.append(((m)this).A.getAndIncrement());
        String string = stringBuilder.toString();
        this.T = ((m)this).B.c(string, (u)this, (j)c2, (androidx.activity.result.c)b3);
        this.U = new e.h0(12, this);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        try {
            MaterialButton materialButton;
            int n2 = MainActivity.U;
            d0.super.onCreate(bundle);
            this.setContentView(2131558442);
            this.r((MaterialToolbar)this.findViewById(2131362659));
            View view = this.findViewById(2131362686);
            j.h((Object)view, "findViewById(R.id.txtBluetoothStatus)");
            this.Q = (TextView)view;
            View view2 = this.findViewById(2131361924);
            j.h((Object)view2, "findViewById(R.id.btnDone)");
            this.R = materialButton = (MaterialButton)view2;
            int n5 = Build.VERSION.SDK_INT;
            if (n5 < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(n2);
                MaterialButton materialButton2 = this.R;
                if (materialButton2 == null) {
                    j.I("btnDone");
                    throw null;
                }
                materialButton2.setTextColor(-1);
            }
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            j.h((Object)editor, "sharedPrefs.edit()");
            this.S = editor;
            MaterialButton materialButton3 = this.R;
            if (materialButton3 != null) {
                materialButton3.setOnClickListener((View.OnClickListener)new g7.b(7, this));
                this.registerReceiver((BroadcastReceiver)this.U, new IntentFilter("android.bluetooth.adapter.action.STATE_CHANGED"));
                e.g0((w)com.bumptech.glide.d.k((u)this), e0.a, new h0(this, null), 2);
                return;
            }
            j.I("btnDone");
            throw null;
        }
        catch (Exception exception) {
            TextView textView = this.Q;
            if (textView == null) {
                j.I("txtBluetoothStatus");
                throw null;
            }
            textView.setText(2131952380);
            SharedPreferences.Editor editor = this.S;
            if (editor == null) {
                j.I("editPrefs");
                throw null;
            }
            editor.putInt("bluetooth_test_status", 0);
            SharedPreferences.Editor editor2 = this.S;
            if (editor2 != null) {
                editor2.apply();
                exception.printStackTrace();
                return;
            }
            j.I("editPrefs");
            throw null;
        }
    }

    @Override
    public final void onDestroy() {
        super.onDestroy();
        this.unregisterReceiver((BroadcastReceiver)this.U);
    }
}

