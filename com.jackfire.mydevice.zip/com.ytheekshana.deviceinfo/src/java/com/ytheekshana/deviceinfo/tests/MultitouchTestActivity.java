/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.view.Window
 *  android.widget.TextView
 *  androidx.constraintlayout.widget.ConstraintLayout
 *  androidx.fragment.app.d0
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.TextView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.d0;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import com.ytheekshana.deviceinfo.tests.MultiTouchCanvas;
import e.n;
import e9.s0;
import e9.t0;
import m8.d;
import n0.q1;
import n0.q2;
import n0.r1;
import n0.r2;
import n0.s2;
import q0.b;
import s7.j;
import y6.e;

public final class MultitouchTestActivity
extends n {
    public static final /* synthetic */ int R;
    public MultiTouchCanvas Q;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        int n2;
        d d3;
        MultiTouchCanvas multiTouchCanvas;
        block7 : {
            q2 q22;
            e.m((Context)this);
            d0.super.onCreate(bundle);
            this.setContentView(2131558450);
            try {
                View view = this.findViewById(2131362421);
                j.h((Object)view, "findViewById(R.id.multitouchConstraintLayout)");
                ConstraintLayout constraintLayout = (ConstraintLayout)view;
                Window window = this.getWindow();
                n2 = Build.VERSION.SDK_INT;
                if (n2 >= 30) {
                    r1.a(window, false);
                } else {
                    q1.a(window, false);
                }
                Window window2 = this.getWindow();
                int n5 = Build.VERSION.SDK_INT;
                if (n5 >= 30) {
                    d3 = new s2(window2);
                    break block7;
                }
                q22 = n5 >= 26 ? new r2(window2, (View)constraintLayout) : new q2(window2, (View)constraintLayout);
            }
            catch (Exception exception) {
                exception.printStackTrace();
                return;
            }
            d3 = q22;
        }
        ((d)d3).w();
        ((d)d3).D();
        View view = this.findViewById(2131362719);
        j.h((Object)view, "findViewById(R.id.txtInfo)");
        TextView textView = (TextView)view;
        this.Q = multiTouchCanvas = (MultiTouchCanvas)this.findViewById(2131362419);
        if (multiTouchCanvas != null) {
            multiTouchCanvas.setStatusListener(new b(22, (Object)textView));
        }
        SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
        MaterialButton materialButton = (MaterialButton)this.findViewById(2131362259);
        MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131362260);
        if (n2 < 31 || !MainActivity.Z) {
            materialButton.setBackgroundColor(MainActivity.U);
            materialButton.setTextColor(-1);
            materialButton.setIconTintResource(2131100428);
            materialButton2.setBackgroundColor(MainActivity.U);
            materialButton2.setTextColor(-1);
            materialButton2.setIconTintResource(2131100428);
        }
        materialButton.setOnClickListener((View.OnClickListener)new t0(editor, this, 0));
        materialButton2.setOnClickListener((View.OnClickListener)new t0(editor, this, 1));
    }

    @Override
    public final void onDestroy() {
        MultiTouchCanvas multiTouchCanvas = this.Q;
        if (multiTouchCanvas != null) {
            multiTouchCanvas.setStatusListener(null);
        }
        super.onDestroy();
    }
}

