/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.hardware.Sensor
 *  android.hardware.SensorEvent
 *  android.hardware.SensorEventListener
 *  android.hardware.SensorManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Vibrator
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.fragment.app.d0
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.View;
import androidx.fragment.app.d0;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.c0;
import e.n;
import e9.k0;
import s7.j;
import y6.e;

public final class EarProximityTestActivity
extends n
implements SensorEventListener {
    public static final /* synthetic */ int T;
    public Vibrator Q;
    public Sensor R;
    public SensorManager S;

    public final void onAccuracyChanged(Sensor sensor, int n2) {
    }

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558444);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        try {
            SensorManager sensorManager;
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            View view = this.findViewById(2131362259);
            j.h((Object)view, "findViewById(R.id.imgBtnFailed)");
            MaterialButton materialButton = (MaterialButton)view;
            View view2 = this.findViewById(2131362260);
            j.h((Object)view2, "findViewById(R.id.imgBtnSuccess)");
            MaterialButton materialButton2 = (MaterialButton)view2;
            if (Build.VERSION.SDK_INT < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(MainActivity.U);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(MainActivity.U);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new k0(editor, this, 0));
            materialButton2.setOnClickListener((View.OnClickListener)new k0(editor, this, 1));
            this.Q = j.s((Context)this);
            Object object = this.getSystemService("sensor");
            j.g(object, "null cannot be cast to non-null type android.hardware.SensorManager");
            this.S = sensorManager = (SensorManager)object;
            this.R = sensorManager.getDefaultSensor(8);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    public final void onPause() {
        SensorManager sensorManager;
        Vibrator vibrator = this.Q;
        if (vibrator != null) {
            vibrator.cancel();
        }
        if ((sensorManager = this.S) != null) {
            sensorManager.unregisterListener((SensorEventListener)this);
        }
        d0.super.onPause();
    }

    public final void onResume() {
        SensorManager sensorManager = this.S;
        if (sensorManager != null) {
            sensorManager.registerListener((SensorEventListener)this, this.R, 3);
        }
        d0.super.onResume();
    }

    public final void onSensorChanged(SensorEvent sensorEvent) {
        Sensor sensor;
        boolean bl = true;
        boolean bl2 = sensorEvent != null && (sensor = sensorEvent.sensor) != null && sensor.getType() == 8 ? bl : false;
        if (bl2) {
            float f4 = sensorEvent.values[0];
            if (f4 >= -4.0f && f4 <= 4.0f) {
                long[] arrl = new long[]{0L, 1000L, 0L};
                Vibrator vibrator = this.Q;
                if (vibrator == null || vibrator.hasVibrator() != bl) {
                    bl = false;
                }
                if (bl) {
                    if (Build.VERSION.SDK_INT >= 26) {
                        Vibrator vibrator2 = this.Q;
                        if (vibrator2 != null) {
                            c0.y(vibrator2, c0.k(arrl));
                            return;
                        }
                    } else {
                        Vibrator vibrator3 = this.Q;
                        if (vibrator3 != null) {
                            vibrator3.vibrate(arrl, 0);
                            return;
                        }
                    }
                }
            } else {
                Vibrator vibrator = this.Q;
                if (vibrator != null) {
                    vibrator.cancel();
                }
            }
        }
    }
}

