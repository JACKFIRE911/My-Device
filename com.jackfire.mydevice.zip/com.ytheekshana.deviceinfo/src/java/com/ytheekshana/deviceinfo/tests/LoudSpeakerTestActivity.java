/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.media.MediaPlayer
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.fragment.app.d0
 *  androidx.lifecycle.u
 *  com.bumptech.glide.d
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.d0;
import androidx.lifecycle.u;
import ba.e0;
import ba.w;
import com.bumptech.glide.d;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.p0;
import e9.q0;
import ea.c;
import y6.e;

public final class LoudSpeakerTestActivity
extends n {
    public static final /* synthetic */ int R;
    public MediaPlayer Q;

    public final void onCreate(Bundle bundle) {
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558448);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        try {
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            MaterialButton materialButton = (MaterialButton)this.findViewById(2131362259);
            MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131362260);
            if (Build.VERSION.SDK_INT < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(MainActivity.U);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(MainActivity.U);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new p0(editor, this, 0));
            materialButton2.setOnClickListener((View.OnClickListener)new p0(editor, this, 1));
            e.g0((w)d.k((u)this), e0.b, new q0(this, null), 2);
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }

    @Override
    public final void onDestroy() {
        MediaPlayer mediaPlayer;
        MediaPlayer mediaPlayer2 = this.Q;
        if (mediaPlayer2 != null) {
            mediaPlayer2.reset();
        }
        if ((mediaPlayer = this.Q) != null) {
            mediaPlayer.release();
        }
        this.Q = null;
        super.onDestroy();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onPause() {
        try {
            MediaPlayer mediaPlayer = this.Q;
            if (mediaPlayer != null) {
                mediaPlayer.stop();
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
        d0.super.onPause();
    }
}

