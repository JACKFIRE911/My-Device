/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.SharedPreferences
 *  android.content.SharedPreferences$Editor
 *  android.hardware.camera2.CameraManager
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.View
 *  android.view.View$OnClickListener
 *  androidx.fragment.app.d0
 *  com.google.android.material.appbar.MaterialToolbar
 *  com.google.android.material.button.MaterialButton
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.String
 */
package com.ytheekshana.deviceinfo.tests;

import android.content.Context;
import android.content.SharedPreferences;
import android.hardware.camera2.CameraManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.fragment.app.d0;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.ytheekshana.deviceinfo.MainActivity;
import e.n;
import e9.n0;
import s7.j;
import w8.t;
import y6.e;

public final class FlashlightTestActivity
extends n {
    public static final /* synthetic */ int T;
    public boolean Q;
    public CameraManager R;
    public String S = "";

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void onCreate(Bundle bundle) {
        String string;
        e.m((Context)this);
        d0.super.onCreate(bundle);
        this.setContentView(2131558446);
        this.r((MaterialToolbar)this.findViewById(2131362659));
        try {
            CameraManager cameraManager;
            SharedPreferences.Editor editor = this.getSharedPreferences("tests", 0).edit();
            MaterialButton materialButton = (MaterialButton)this.findViewById(2131362259);
            MaterialButton materialButton2 = (MaterialButton)this.findViewById(2131362260);
            if (Build.VERSION.SDK_INT < 31 || !MainActivity.Z) {
                materialButton.setBackgroundColor(MainActivity.U);
                materialButton.setTextColor(-1);
                materialButton.setIconTintResource(2131100428);
                materialButton2.setBackgroundColor(MainActivity.U);
                materialButton2.setTextColor(-1);
                materialButton2.setIconTintResource(2131100428);
            }
            materialButton.setOnClickListener((View.OnClickListener)new n0(editor, this, 0));
            materialButton2.setOnClickListener((View.OnClickListener)new n0(editor, this, 1));
            this.Q = false;
            Object object = this.getSystemService("camera");
            j.g(object, "null cannot be cast to non-null type android.hardware.camera2.CameraManager");
            this.R = cameraManager = (CameraManager)object;
            String[] arrstring = cameraManager.getCameraIdList();
            string = arrstring != null ? arrstring[0] : null;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
        if (string == null) {
            string = "";
        }
        this.S = string;
        e.k((Context)this, "android.permission.CAMERA", new t(this, 1));
    }

    @Override
    public final void onDestroy() {
        if (this.Q) {
            this.s(false);
        }
        super.onDestroy();
    }

    public final void onPause() {
        if (this.Q) {
            this.s(false);
        }
        d0.super.onPause();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public final void s(boolean bl) {
        try {
            CameraManager cameraManager = this.R;
            if (cameraManager != null) {
                cameraManager.setTorchMode(this.S, bl);
            }
            this.Q = bl;
            return;
        }
        catch (Exception exception) {
            exception.printStackTrace();
            return;
        }
    }
}

