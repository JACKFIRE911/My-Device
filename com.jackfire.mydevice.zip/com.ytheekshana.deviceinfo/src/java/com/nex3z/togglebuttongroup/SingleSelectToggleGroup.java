/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.widget.Checkable
 *  java.lang.Object
 *  java.util.ArrayList
 *  java.util.Collection
 */
package com.nex3z.togglebuttongroup;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Checkable;
import i1.n;
import i1.n0;
import i4.b;
import java.util.ArrayList;
import java.util.Collection;
import s5.g;
import s7.j;
import u8.c;
import u8.d;
import w8.h;
import x8.l;
import y6.e;
import y8.a;
import z8.q0;
import z8.r0;

public class SingleSelectToggleGroup
extends d {
    public c F;
    public int G = -1;

    public SingleSelectToggleGroup(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    private void setCheckedId(int n3) {
        this.e(n3, true);
    }

    public final void addView(View view, int n3, ViewGroup.LayoutParams layoutParams) {
        if (view instanceof Checkable && ((Checkable)view).isChecked()) {
            View view2;
            int n5 = this.G;
            if (n5 != -1 && (view2 = this.findViewById(n5)) != null && view2 instanceof Checkable) {
                ((Checkable)view2).setChecked(false);
            }
            if (view.getId() == -1) {
                view.setId(View.generateViewId());
            }
            this.setCheckedId(view.getId());
        }
        ViewGroup.super.addView(view, n3, layoutParams);
    }

    @Override
    public final void d(View view, boolean bl) {
        if (bl) {
            int n3;
            View view2;
            int n5 = this.G;
            if (n5 != -1 && n5 != view.getId() && (view2 = this.findViewById(this.G)) != null && view2 instanceof Checkable) {
                ((Checkable)view2).setChecked(false);
            }
            if (this.A == (n3 = view.getId())) {
                this.A = -1;
                this.e(n3, false);
                return;
            }
            this.setCheckedId(n3);
        }
    }

    public final void e(int n3, boolean bl) {
        c c4;
        this.G = n3;
        if (bl && (c4 = this.F) != null) {
            b b3 = (b)c4;
            l l2 = (l)b3.t;
            ArrayList arrayList = (ArrayList)b3.s;
            r0 r02 = (r0)((Object)b3.r);
            j.i((Object)arrayList, "$featureList2");
            j.i((Object)r02, "this$0");
            View view = this.findViewById(this.getCheckedId());
            j.h((Object)view, "group.findViewById(group.checkedId)");
            e.D0(new q0(r02, (h)view, arrayList, null));
            if (l2 != null) {
                ArrayList arrayList2 = l2.u;
                n n5 = g.b(new a(arrayList2, arrayList, 3));
                arrayList2.clear();
                arrayList2.addAll((Collection)arrayList);
                n5.a(l2);
            }
        }
    }

    public int getCheckedId() {
        return this.G;
    }

    public final void onFinishInflate() {
        ViewGroup.super.onFinishInflate();
        int n3 = this.z;
        if (n3 == -1) {
            n3 = this.A;
        }
        if (n3 != -1) {
            View view = this.findViewById(n3);
            if (view != null && view instanceof Checkable) {
                ((Checkable)view).setChecked(true);
            }
            this.e(n3, false);
        }
    }

    public void setOnCheckedChangeListener(c c4) {
        this.F = c4;
    }
}

