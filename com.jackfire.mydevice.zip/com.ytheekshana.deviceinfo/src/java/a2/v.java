/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package a2;

import a8.b1;

public final class v
extends b1 {
    public final Throwable u0;

    public v(Throwable throwable) {
        this.u0 = throwable;
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("FAILURE (");
        stringBuilder.append(this.u0.getMessage());
        stringBuilder.append(")");
        return stringBuilder.toString();
    }
}

