/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  ba.w0
 *  j1.a
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.util.concurrent.Executor
 *  java.util.concurrent.TimeUnit
 *  l2.h
 *  l2.j
 *  t9.l
 */
package a2;

import ba.f0;
import ba.w0;
import j1.a;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeUnit;
import l2.h;
import l2.j;

public final class l
implements m7.a {
    public final j q;

    public l(w0 w02) {
        j j3 = new j();
        this.q = j3;
        w02.B(false, true, (t9.l)new a(1, (Object)this));
    }

    @Override
    public final void b(Runnable runnable, Executor executor) {
        this.q.b(runnable, executor);
    }

    public final boolean cancel(boolean bl) {
        return this.q.cancel(bl);
    }

    public final Object get() {
        return this.q.get();
    }

    public final Object get(long l3, TimeUnit timeUnit) {
        return this.q.get(l3, timeUnit);
    }

    public final boolean isCancelled() {
        return this.q.q instanceof l2.a;
    }

    public final boolean isDone() {
        return this.q.isDone();
    }
}

