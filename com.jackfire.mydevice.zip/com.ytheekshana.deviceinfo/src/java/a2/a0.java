/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.util.LinkedHashSet
 *  java.util.UUID
 */
package a2;

import a2.c0;
import a2.d0;
import a2.z;
import j2.s;
import java.util.LinkedHashSet;
import java.util.UUID;
import s7.j;

public final class a0
extends d0 {
    public a0(z z2) {
        j.i(z2, "builder");
        super(z2.a, z2.b, z2.c);
    }
}

