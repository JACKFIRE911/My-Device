/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  android.app.Notification$Builder
 *  android.os.RemoteException
 *  android.util.Log
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewParent
 *  androidx.fragment.app.a0
 *  androidx.fragment.app.u0
 *  ba.f
 *  com.google.android.gms.internal.ads.a70
 *  com.google.android.gms.internal.ads.bb1
 *  com.google.android.gms.internal.ads.bf1
 *  com.google.android.gms.internal.ads.lq
 *  com.google.android.gms.internal.ads.lw
 *  com.google.android.gms.internal.ads.s90
 *  com.google.android.gms.internal.ads.se1
 *  com.google.android.gms.internal.ads.te1
 *  com.google.android.gms.internal.ads.wp
 *  com.google.android.gms.internal.ads.xe1
 *  com.google.android.gms.internal.ads.ze1
 *  com.google.android.gms.internal.measurement.c1
 *  com.google.android.gms.internal.measurement.f0
 *  com.google.android.gms.internal.measurement.h1
 *  com.google.android.gms.internal.measurement.x0
 *  java.lang.ClassCastException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  x4.b0
 */
package a2;

import android.app.Notification;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import androidx.fragment.app.a0;
import androidx.fragment.app.u0;
import ba.f;
import com.google.android.gms.internal.ads.a70;
import com.google.android.gms.internal.ads.bb1;
import com.google.android.gms.internal.ads.bf1;
import com.google.android.gms.internal.ads.lq;
import com.google.android.gms.internal.ads.lw;
import com.google.android.gms.internal.ads.s90;
import com.google.android.gms.internal.ads.se1;
import com.google.android.gms.internal.ads.te1;
import com.google.android.gms.internal.ads.wp;
import com.google.android.gms.internal.ads.xe1;
import com.google.android.gms.internal.ads.ze1;
import com.google.android.gms.internal.measurement.c1;
import com.google.android.gms.internal.measurement.f0;
import com.google.android.gms.internal.measurement.h1;
import com.google.android.gms.internal.measurement.x0;
import x4.b0;

public abstract class s {
    public static /* synthetic */ void A(Object object) {
        throw new ClassCastException();
    }

    public static /* synthetic */ String B(int n2) {
        if (n2 == 1) {
            return "ENQUEUED";
        }
        if (n2 == 2) {
            return "RUNNING";
        }
        if (n2 == 3) {
            return "SUCCEEDED";
        }
        if (n2 == 4) {
            return "FAILED";
        }
        if (n2 == 5) {
            return "BLOCKED";
        }
        if (n2 == 6) {
            return "CANCELLED";
        }
        throw null;
    }

    public static /* synthetic */ String C(int n2) {
        if (n2 == 1) {
            return "UNKNOWN_PREFIX";
        }
        if (n2 == 2) {
            return "TINK";
        }
        if (n2 == 3) {
            return "LEGACY";
        }
        if (n2 == 4) {
            return "RAW";
        }
        if (n2 == 5) {
            return "CRUNCHY";
        }
        if (n2 == 6) {
            return "UNRECOGNIZED";
        }
        throw null;
    }

    public static /* synthetic */ String D(int n2) {
        if (n2 == 1) {
            return "NOT_REQUIRED";
        }
        if (n2 == 2) {
            return "CONNECTED";
        }
        if (n2 == 3) {
            return "UNMETERED";
        }
        if (n2 == 4) {
            return "NOT_ROAMING";
        }
        if (n2 == 5) {
            return "METERED";
        }
        if (n2 == 6) {
            return "TEMPORARILY_UNMETERED";
        }
        return "null";
    }

    public static /* synthetic */ String E(int n2) {
        if (n2 == 1) {
            return "ENQUEUED";
        }
        if (n2 == 2) {
            return "RUNNING";
        }
        if (n2 == 3) {
            return "SUCCEEDED";
        }
        if (n2 == 4) {
            return "FAILED";
        }
        if (n2 == 5) {
            return "BLOCKED";
        }
        if (n2 == 6) {
            return "CANCELLED";
        }
        return "null";
    }

    public static /* synthetic */ String F(int n2) {
        if (n2 == 1) {
            return "NONE";
        }
        if (n2 == 2) {
            return "ADDING";
        }
        if (n2 == 3) {
            return "REMOVING";
        }
        return "null";
    }

    public static /* synthetic */ String G(int n2) {
        if (n2 == 1) {
            return "REMOVED";
        }
        if (n2 == 2) {
            return "VISIBLE";
        }
        if (n2 == 3) {
            return "GONE";
        }
        if (n2 == 4) {
            return "INVISIBLE";
        }
        return "null";
    }

    public static /* synthetic */ String H(int n2) {
        if (n2 == 1) {
            return "HTML_DISPLAY";
        }
        if (n2 == 2) {
            return "NATIVE_DISPLAY";
        }
        if (n2 == 3) {
            return "VIDEO";
        }
        return "null";
    }

    public static final void a(int n2, View view) {
        if (n2 != 0) {
            int n3 = n2 - 1;
            if (n3 != 0) {
                if (n3 != 1) {
                    if (n3 != 2) {
                        if (n3 != 3) {
                            return;
                        }
                        if (u0.K((int)2)) {
                            StringBuilder stringBuilder = new StringBuilder("SpecialEffectsController: Setting view ");
                            stringBuilder.append((Object)view);
                            stringBuilder.append(" to INVISIBLE");
                            Log.v((String)"FragmentManager", (String)stringBuilder.toString());
                        }
                        view.setVisibility(4);
                        return;
                    }
                    if (u0.K((int)2)) {
                        StringBuilder stringBuilder = new StringBuilder("SpecialEffectsController: Setting view ");
                        stringBuilder.append((Object)view);
                        stringBuilder.append(" to GONE");
                        Log.v((String)"FragmentManager", (String)stringBuilder.toString());
                    }
                    view.setVisibility(8);
                    return;
                }
                if (u0.K((int)2)) {
                    StringBuilder stringBuilder = new StringBuilder("SpecialEffectsController: Setting view ");
                    stringBuilder.append((Object)view);
                    stringBuilder.append(" to VISIBLE");
                    Log.v((String)"FragmentManager", (String)stringBuilder.toString());
                }
                view.setVisibility(0);
                return;
            }
            ViewGroup viewGroup = (ViewGroup)view.getParent();
            if (viewGroup != null) {
                if (u0.K((int)2)) {
                    StringBuilder stringBuilder = new StringBuilder("SpecialEffectsController: Removing view ");
                    stringBuilder.append((Object)view);
                    stringBuilder.append(" from container ");
                    stringBuilder.append((Object)viewGroup);
                    Log.v((String)"FragmentManager", (String)stringBuilder.toString());
                }
                viewGroup.removeView(view);
            }
            return;
        }
        throw null;
    }

    public static int b(int n2) {
        if (n2 != 0) {
            if (n2 != 4) {
                if (n2 == 8) {
                    return 3;
                }
                throw new IllegalArgumentException(xe1.f((String)"Unknown visibility ", (int)n2));
            }
            return 4;
        }
        return 2;
    }

    public static int c(View view) {
        if (view.getAlpha() == 0.0f && view.getVisibility() == 0) {
            return 4;
        }
        return s.b(view.getVisibility());
    }

    public static final boolean d(int n2) {
        return n2 == 3 || n2 == 4 || n2 == 6;
        {
        }
    }

    public static final int e(int n2) {
        if (n2 != 6) {
            return s.k(n2);
        }
        throw new IllegalArgumentException("Can't get the number of an unknown enum value.");
    }

    public static int f(int n2) {
        if (n2 != 0) {
            if (n2 != 1) {
                if (n2 != 2) {
                    if (n2 != 3) {
                        if (n2 != 4) {
                            return 0;
                        }
                        return 5;
                    }
                    return 4;
                }
                return 3;
            }
            return 2;
        }
        return 1;
    }

    public static /* synthetic */ String g(int n2) {
        if (n2 == 1) {
            return "java.version";
        }
        if (n2 == 2) {
            return "java.vendor";
        }
        if (n2 == 3) {
            return "java.vendor.url";
        }
        if (n2 == 4) {
            return "java.home";
        }
        if (n2 == 5) {
            return "java.vm.specification.version";
        }
        if (n2 == 6) {
            return "java.vm.specification.vendor";
        }
        if (n2 == 7) {
            return "java.vm.specification.name";
        }
        if (n2 == 8) {
            return "java.vm.version";
        }
        if (n2 == 9) {
            return "java.vm.vendor";
        }
        if (n2 == 10) {
            return "java.vm.name";
        }
        if (n2 == 11) {
            return "java.specification.version";
        }
        if (n2 == 12) {
            return "java.specification.vendor";
        }
        if (n2 == 13) {
            return "java.specification.name";
        }
        if (n2 == 14) {
            return "java.class.version";
        }
        if (n2 == 15) {
            return "java.class.path";
        }
        if (n2 == 16) {
            return "java.library.path";
        }
        if (n2 == 17) {
            return "java.io.tmpdir";
        }
        if (n2 == 18) {
            return "java.compiler";
        }
        if (n2 == 19) {
            return "java.ext.dirs";
        }
        if (n2 == 20) {
            return "os.name";
        }
        if (n2 == 21) {
            return "os.arch";
        }
        if (n2 == 22) {
            return "os.version";
        }
        if (n2 == 23) {
            return "file.separator";
        }
        if (n2 == 24) {
            return "path.separator";
        }
        if (n2 == 25) {
            return "line.separator";
        }
        if (n2 == 26) {
            return "user.name";
        }
        if (n2 == 27) {
            return "user.home";
        }
        if (n2 == 28) {
            return "user.dir";
        }
        throw null;
    }

    public static /* synthetic */ String h(int n2) {
        if (n2 == 1) {
            return "htmlDisplay";
        }
        if (n2 == 2) {
            return "nativeDisplay";
        }
        if (n2 == 3) {
            return "video";
        }
        throw null;
    }

    public static /* synthetic */ String i(int n2) {
        if (n2 == 1) {
            return "beginToRender";
        }
        if (n2 == 2) {
            return "definedByJavascript";
        }
        if (n2 == 3) {
            return "onePixel";
        }
        if (n2 == 4) {
            return "unspecified";
        }
        throw null;
    }

    public static /* synthetic */ int j(int n2) {
        if (n2 == 1) {
            return 0;
        }
        if (n2 == 2) {
            return 1;
        }
        if (n2 == 3) {
            return 2;
        }
        if (n2 == 4) {
            return 3;
        }
        if (n2 == 5) {
            return 4;
        }
        if (n2 == 6) {
            return -1;
        }
        throw null;
    }

    public static /* synthetic */ int k(int n2) {
        if (n2 == 1) {
            return 0;
        }
        if (n2 == 2) {
            return 1;
        }
        if (n2 == 3) {
            return 2;
        }
        if (n2 == 4) {
            return 3;
        }
        if (n2 == 5) {
            return 4;
        }
        if (n2 == 6) {
            return -1;
        }
        throw null;
    }

    public static int l(int n2, int n3, int n4) {
        int n5 = n2 / n3;
        return n4 + (n5 + n5);
    }

    public static RemoteException m(String string, Throwable throwable) {
        b0.h((String)string, (Throwable)throwable);
        return new RemoteException();
    }

    public static bf1 n(ze1 ze12, int n2) {
        return se1.b((te1)new lw((bf1)ze12, n2));
    }

    public static bf1 o(bf1 bf12, s90 s902, int n2) {
        return se1.b((te1)new a70(bf12, (bf1)s902, n2));
    }

    public static bf1 p(bf1 bf12, s90 s902, bf1 bf13, int n2) {
        return se1.b((te1)new wp(bf12, (bf1)s902, bf13, n2));
    }

    public static bf1 q(bf1 bf12, bf1 bf13, int n2) {
        return se1.b((te1)new lq(bf12, bf13, n2));
    }

    public static String r(h1 h12, f0 f02, int n2, long l2) {
        h12.b((c1)new x0(h12, f02, n2));
        return f02.i0(l2);
    }

    public static String s(String string, a0 a02, String string2) {
        StringBuilder stringBuilder = new StringBuilder(string);
        stringBuilder.append((Object)a02);
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public static String t(String string, String string2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(string);
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public static String u(String string, String string2, String string3) {
        StringBuilder stringBuilder = new StringBuilder(string);
        stringBuilder.append(string2);
        stringBuilder.append(string3);
        return stringBuilder.toString();
    }

    public static String v(StringBuilder stringBuilder, String string, String string2) {
        stringBuilder.append(string);
        stringBuilder.append(string2);
        return stringBuilder.toString();
    }

    public static /* synthetic */ void w() {
        new android.app.Notification$Builder;
    }

    public static /* synthetic */ void x(f f2) {
        throw new ClassCastException();
    }

    public static /* synthetic */ void y(bb1 bb12) {
        if (bb12 == null) {
            return;
        }
        throw new ClassCastException();
    }

    public static /* synthetic */ void z(Object object) {
        if (object == null) {
            return;
        }
        throw new ClassCastException();
    }
}

