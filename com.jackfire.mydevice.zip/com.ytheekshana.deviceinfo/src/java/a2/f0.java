/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.work.WorkerParameters
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.lang.reflect.Constructor
 */
package a2;

import a2.q;
import a2.r;
import android.content.Context;
import androidx.work.WorkerParameters;
import java.lang.reflect.Constructor;

public abstract class f0 {
    public static final String a = r.f("WorkerFactory");

    public final q a(Context context, String string, WorkerParameters workerParameters) {
        Class class_;
        String string2 = a;
        try {
            class_ = Class.forName((String)string).asSubclass(q.class);
        }
        catch (Throwable throwable) {
            r r2 = r.d();
            StringBuilder stringBuilder = new StringBuilder("Invalid class: ");
            stringBuilder.append(string);
            r2.c(string2, stringBuilder.toString(), throwable);
            class_ = null;
        }
        q q2 = null;
        if (class_ != null) {
            try {
                q q3;
                q2 = q3 = (q)class_.getDeclaredConstructor(new Class[]{Context.class, WorkerParameters.class}).newInstance(new Object[]{context, workerParameters});
            }
            catch (Throwable throwable) {
                r r3 = r.d();
                StringBuilder stringBuilder = new StringBuilder("Could not instantiate ");
                stringBuilder.append(string);
                r3.c(string2, stringBuilder.toString(), throwable);
            }
        }
        if (q2 != null) {
            if (!q2.isUsed()) {
                return q2;
            }
            String string3 = this.getClass().getName();
            StringBuilder stringBuilder = new StringBuilder("WorkerFactory (");
            stringBuilder.append(string3);
            stringBuilder.append(") returned an instance of a ListenableWorker (");
            stringBuilder.append(string);
            stringBuilder.append(") which has already been invoked. createWorker() must always return a new instance of a ListenableWorker.");
            throw new IllegalStateException(stringBuilder.toString());
        }
        return q2;
    }
}

