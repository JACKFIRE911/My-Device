/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.work.CoroutineWorker
 *  java.lang.Class
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 */
package a2;

import a2.l;
import androidx.work.CoroutineWorker;
import ba.w;
import ba.x;
import j9.g;
import l2.j;
import m9.d;
import o9.h;
import t9.p;

public final class e
extends h
implements p {
    public l u;
    public int v;
    public final /* synthetic */ l w;
    public final /* synthetic */ CoroutineWorker x;

    public e(l l2, CoroutineWorker coroutineWorker, d d3) {
        this.w = l2;
        this.x = coroutineWorker;
        super(d3);
    }

    @Override
    public final d a(Object object, d d3) {
        return new e(this.w, this.x, d3);
    }

    @Override
    public final Object f(Object object, Object object2) {
        e e3 = (e)this.a((w)object, (d)object2);
        g g2 = g.a;
        e3.i(g2);
        return g2;
    }

    @Override
    public final Object i(Object object) {
        int n3 = this.v;
        if (n3 != 0) {
            if (n3 == 1) {
                l l2 = this.u;
                x.u(object);
                l2.q.j(object);
                return g.a;
            }
            throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
        }
        x.u(object);
        this.u = this.w;
        this.v = 1;
        this.x.getClass();
        throw new IllegalStateException("Not implemented");
    }
}

