/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.String
 */
package a2;

import a8.b1;

public final class w
extends b1 {
    public final String toString() {
        return "IN_PROGRESS";
    }
}

