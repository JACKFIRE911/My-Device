/*
 * Decompiled with CFR 0.0.
 */
package a2;

import a2.f0;

public final class e0
extends f0 {
}

