/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.work.CoroutineWorker
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package a2;

import a2.p;
import androidx.work.CoroutineWorker;
import ba.w;
import ba.x;
import j9.g;
import l2.j;
import m9.d;
import n9.a;
import o9.h;

public final class f
extends h
implements t9.p {
    public int u;
    public final /* synthetic */ CoroutineWorker v;

    public f(CoroutineWorker coroutineWorker, d d3) {
        this.v = coroutineWorker;
        super(d3);
    }

    @Override
    public final d a(Object object, d d3) {
        return new f(this.v, d3);
    }

    @Override
    public final Object f(Object object, Object object2) {
        return ((f)this.a((w)object, (d)object2)).i(g.a);
    }

    @Override
    public final Object i(Object object) {
        CoroutineWorker coroutineWorker;
        block6 : {
            a a4 = a.q;
            int n3 = this.u;
            coroutineWorker = this.v;
            if (n3 != 0) {
                if (n3 == 1) {
                    x.u(object);
                    break block6;
                }
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            x.u(object);
            this.u = 1;
            object = coroutineWorker.a((d)this);
            if (object != a4) break block6;
            return a4;
        }
        try {
            p p5 = (p)object;
            coroutineWorker.v.j(p5);
        }
        catch (Throwable throwable) {
            coroutineWorker.v.k(throwable);
        }
        return g.a;
    }
}

