/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 */
package a2;

import a2.h;
import a2.r;
import java.util.ArrayList;

public abstract class k {
    public static final String a = r.f("InputMerger");

    public abstract h a(ArrayList var1);
}

