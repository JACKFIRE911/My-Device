/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 */
package a2;

import android.util.Log;

public final class r {
    public static final Object b = new Object();
    public static volatile r c;
    public final int a;

    public r(int n2) {
        this.a = n2;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static r d() {
        Object object;
        Object object2 = object = b;
        synchronized (object2) {
            if (c != null) return c;
            c = new r(3);
            return c;
        }
    }

    public static String f(String string) {
        int n2 = string.length();
        StringBuilder stringBuilder = new StringBuilder(23);
        stringBuilder.append("WM-");
        if (n2 >= 20) {
            stringBuilder.append(string.substring(0, 20));
        } else {
            stringBuilder.append(string);
        }
        return stringBuilder.toString();
    }

    public final void a(String string, String string2) {
        if (this.a <= 3) {
            Log.d((String)string, (String)string2);
        }
    }

    public final void b(String string, String string2) {
        if (this.a <= 6) {
            Log.e((String)string, (String)string2);
        }
    }

    public final void c(String string, String string2, Throwable throwable) {
        if (this.a <= 6) {
            Log.e((String)string, (String)string2, (Throwable)throwable);
        }
    }

    public final void e(String string, String string2) {
        if (this.a <= 4) {
            Log.i((String)string, (String)string2);
        }
    }

    public final void g(String string, String string2) {
        if (this.a <= 5) {
            Log.w((String)string, (String)string2);
        }
    }
}

