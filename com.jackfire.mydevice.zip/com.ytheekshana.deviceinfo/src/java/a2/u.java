/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.util.LinkedHashSet
 *  java.util.UUID
 */
package a2;

import a2.c0;
import a2.d0;
import a2.t;
import j2.s;
import java.util.LinkedHashSet;
import java.util.UUID;
import s7.j;

public final class u
extends d0 {
    public u(t t2) {
        j.i(t2, "builder");
        super(t2.a, t2.b, t2.c);
    }
}

