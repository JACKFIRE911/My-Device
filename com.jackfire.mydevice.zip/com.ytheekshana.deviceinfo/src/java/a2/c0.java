/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  j2.s
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Collection
 *  java.util.LinkedHashSet
 *  java.util.Set
 *  java.util.UUID
 *  s7.j
 */
package a2;

import a2.d;
import a2.d0;
import a2.h;
import android.os.Build;
import ba.x;
import j2.s;
import java.util.Collection;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import s7.j;

public abstract class c0 {
    public UUID a;
    public s b;
    public final LinkedHashSet c;

    public c0(Class class_) {
        s s2;
        UUID uUID = UUID.randomUUID();
        j.h((Object)uUID, (String)"randomUUID()");
        this.a = uUID;
        String string = this.a.toString();
        j.h((Object)string, (String)"id.toString()");
        this.b = s2 = new s(string, 0, class_.getName(), null, null, null, 0L, 0L, 0L, null, 0, 0, 0L, 0L, 0L, 0L, false, 0, 0, 1048570, 0);
        String[] arrstring = new String[]{class_.getName()};
        LinkedHashSet linkedHashSet = new LinkedHashSet(x.o(1));
        linkedHashSet.add((Object)arrstring[0]);
        this.c = linkedHashSet;
    }

    public final d0 a() {
        s s2;
        d0 d02 = this.b();
        d d2 = this.b.j;
        boolean bl = Build.VERSION.SDK_INT >= 24 && true ^ ((Collection)d2.h).isEmpty() || d2.d || d2.b || d2.c;
        s s3 = this.b;
        if (s3.q) {
            if (bl ^ true) {
                long l2 = s3.g LCMP 0L;
                boolean bl2 = false;
                if (l2 <= 0) {
                    bl2 = true;
                }
                if (!bl2) {
                    throw new IllegalArgumentException("Expedited jobs cannot be delayed".toString());
                }
            } else {
                throw new IllegalArgumentException("Expedited jobs only support network and storage constraints".toString());
            }
        }
        UUID uUID = UUID.randomUUID();
        j.h((Object)uUID, (String)"randomUUID()");
        this.a = uUID;
        String string = uUID.toString();
        j.h((Object)string, (String)"id.toString()");
        s s4 = this.b;
        j.i((Object)s4, (String)"other");
        String string2 = s4.c;
        int n2 = s4.b;
        String string3 = s4.d;
        h h2 = new h(s4.e);
        h h3 = new h(s4.f);
        long l3 = s4.g;
        long l5 = s4.h;
        long l6 = s4.i;
        d d3 = s4.j;
        j.i((Object)d3, (String)"other");
        boolean bl3 = d3.b;
        boolean bl4 = d3.c;
        int n3 = d3.a;
        boolean bl5 = d3.d;
        boolean bl6 = d3.e;
        Set set = d3.h;
        this.b = s2 = new s(string, n2, string2, string3, h2, h3, l3, l5, l6, new d(n3, bl3, bl4, bl5, bl6, d3.f, d3.g, set), s4.k, s4.l, s4.m, s4.n, s4.o, s4.p, s4.q, s4.r, s4.s, 524288, 0);
        this.c();
        return d02;
    }

    public abstract d0 b();

    public abstract c0 c();
}

