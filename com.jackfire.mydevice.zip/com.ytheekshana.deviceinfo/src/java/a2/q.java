/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.net.Network
 *  android.net.Uri
 *  androidx.work.WorkerParameters
 *  j.g
 *  j2.w
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Throwable
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Set
 *  java.util.UUID
 *  java.util.concurrent.Executor
 *  k2.s
 *  k2.t
 *  l2.j
 *  m2.a
 *  m7.a
 *  n0.t1
 */
package a2;

import a2.b0;
import a2.f0;
import a2.h;
import a2.i;
import a2.j;
import android.content.Context;
import android.net.Network;
import android.net.Uri;
import androidx.work.WorkerParameters;
import j.g;
import j2.w;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.Executor;
import k2.s;
import k2.t;
import m2.a;
import n0.t1;

public abstract class q {
    public final Context q;
    public final WorkerParameters r;
    public volatile boolean s;
    public boolean t;

    public q(Context context, WorkerParameters workerParameters) {
        if (context != null) {
            if (workerParameters != null) {
                this.q = context;
                this.r = workerParameters;
                return;
            }
            throw new IllegalArgumentException("WorkerParameters is null");
        }
        throw new IllegalArgumentException("Application Context is null");
    }

    public final Context getApplicationContext() {
        return this.q;
    }

    public Executor getBackgroundExecutor() {
        return this.r.f;
    }

    public m7.a getForegroundInfoAsync() {
        l2.j j2 = new l2.j();
        j2.k((Throwable)new IllegalStateException("Expedited WorkRequests require a ListenableWorker to provide an implementation for `getForegroundInfoAsync()`"));
        return j2;
    }

    public final UUID getId() {
        return this.r.a;
    }

    public final h getInputData() {
        return this.r.b;
    }

    public final Network getNetwork() {
        return (Network)this.r.d.t;
    }

    public final int getRunAttemptCount() {
        return this.r.e;
    }

    public final Set<String> getTags() {
        return this.r.c;
    }

    public a getTaskExecutor() {
        return this.r.g;
    }

    public final List<String> getTriggeredContentAuthorities() {
        return (List)this.r.d.r;
    }

    public final List<Uri> getTriggeredContentUris() {
        return (List)this.r.d.s;
    }

    public f0 getWorkerFactory() {
        return this.r.h;
    }

    public final boolean isStopped() {
        return this.s;
    }

    public final boolean isUsed() {
        return this.t;
    }

    public void onStopped() {
    }

    public final m7.a setForegroundAsync(i i2) {
        j j2 = this.r.j;
        Context context = this.getApplicationContext();
        UUID uUID = this.getId();
        s s2 = (s)j2;
        s2.getClass();
        l2.j j3 = new l2.j();
        t1 t12 = new t1((Object)s2, (Object)j3, (Object)uUID, (Object)i2, (Object)context, 1);
        ((w)s2.a).l((Runnable)t12);
        return j3;
    }

    public m7.a setProgressAsync(h h2) {
        b0 b02 = this.r.i;
        this.getApplicationContext();
        UUID uUID = this.getId();
        t t2 = (t)b02;
        t2.getClass();
        l2.j j2 = new l2.j();
        g g2 = new g((Object)t2, (Object)uUID, (Object)h2, (Object)j2, 3);
        ((w)t2.b).l((Runnable)g2);
        return j2;
    }

    public final void setUsed() {
        this.t = true;
    }

    public abstract m7.a startWork();

    public final void stop() {
        this.s = true;
        this.onStopped();
    }
}

