/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a2.w
 *  a2.x
 *  java.lang.Object
 */
package a2;

import a2.w;
import a2.x;

public interface y {
    public static final x a = new x();
    public static final w b = new w();
}

