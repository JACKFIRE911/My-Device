/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a2;

import a2.h;
import a2.p;

public final class o
extends p {
    public final h a;

    public o(h h3) {
        this.a = h3;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null && o.class == object.getClass()) {
            o o4 = (o)object;
            return this.a.equals(o4.a);
        }
        return false;
    }

    public final int hashCode() {
        return 31 * o.class.getName().hashCode() + this.a.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Success {mOutputData=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

