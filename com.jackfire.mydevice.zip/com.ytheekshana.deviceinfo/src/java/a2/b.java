/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a2.e0
 *  b7.e
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.Runtime
 *  java.util.concurrent.ExecutorService
 *  java.util.concurrent.Executors
 *  java.util.concurrent.ThreadFactory
 *  m8.d
 *  t8.c
 */
package a2;

import a2.a;
import a2.e0;
import b7.e;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import m8.d;
import t8.c;

public final class b {
    public final ExecutorService a = b.a(false);
    public final ExecutorService b = b.a(true);
    public final e0 c = new e0();
    public final d d = new d();
    public final c e = new c(14);
    public final int f = 4;
    public final int g = Integer.MAX_VALUE;
    public final int h = 20;

    public b(e e2) {
    }

    public static ExecutorService a(boolean bl) {
        return Executors.newFixedThreadPool((int)Math.max((int)2, (int)Math.min((int)(-1 + Runtime.getRuntime().availableProcessors()), (int)4)), (ThreadFactory)new a(bl));
    }
}

