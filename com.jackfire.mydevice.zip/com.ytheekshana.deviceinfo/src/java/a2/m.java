/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a2;

import a2.h;
import a2.p;

public final class m
extends p {
    public final h a;

    public m() {
        h h3 = h.c;
        this.a = h3;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null && m.class == object.getClass()) {
            m m4 = (m)object;
            return this.a.equals(m4.a);
        }
        return false;
    }

    public final int hashCode() {
        return 31 * m.class.getName().hashCode() + this.a.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Failure {mOutputData=");
        stringBuilder.append((Object)this.a);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

