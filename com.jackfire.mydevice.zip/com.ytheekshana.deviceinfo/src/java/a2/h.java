/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.io.ByteArrayInputStream
 *  java.io.ByteArrayOutputStream
 *  java.io.IOException
 *  java.io.InputStream
 *  java.io.ObjectInputStream
 *  java.io.ObjectOutputStream
 *  java.io.OutputStream
 *  java.lang.Class
 *  java.lang.ClassNotFoundException
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package a2;

import a2.r;
import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class h {
    public static final String b = r.f("Data");
    public static final h c;
    public final HashMap a;

    public static {
        h h2 = new h(new HashMap());
        h.c(h2);
        c = h2;
    }

    public h(h h2) {
        this.a = new HashMap((Map)h2.a);
    }

    public h(HashMap hashMap) {
        this.a = new HashMap((Map)hashMap);
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static h a(byte[] var0) {
        block21 : {
            block22 : {
                block23 : {
                    block24 : {
                        var1_1 = h.b;
                        if (var0.length > 10240) throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
                        var2_2 = new HashMap();
                        var3_3 = new ByteArrayInputStream(var0);
                        var4_4 = new ObjectInputStream((InputStream)var3_3);
                        break block24;
                        catch (Throwable var12_11) {
                            var13_13 = null;
                            break block21;
                        }
                        catch (ClassNotFoundException var22_14) {
                        }
                        catch (IOException var22_15) {
                            // empty catch block
                        }
                        var23_17 = var22_16;
                        var4_4 = null;
                        var5_10 = var23_17;
                        ** GOTO lbl-1000
                    }
                    for (var18_5 = var4_4.readInt(); var18_5 > 0; --var18_5) {
                        var2_2.put((Object)var4_4.readUTF(), var4_4.readObject());
                    }
                    try {
                        var4_4.close();
                    }
                    catch (IOException var20_6) {
                        Log.e((String)var1_1, (String)"Error in Data#fromByteArray: ", (Throwable)var20_6);
                    }
                    break block23;
                    catch (Throwable var11_7) {
                        break block22;
                    }
                    catch (ClassNotFoundException var5_8) {
                        ** GOTO lbl-1000
                    }
                    catch (IOException var5_9) {}
lbl-1000: // 3 sources:
                    {
                        Log.e((String)var1_1, (String)"Error in Data#fromByteArray: ", (Throwable)var5_10);
                        if (var4_4 == null) break block23;
                    }
                    try {
                        var4_4.close();
                    }
                    catch (IOException var9_18) {
                        Log.e((String)var1_1, (String)"Error in Data#fromByteArray: ", (Throwable)var9_18);
                    }
                }
                try {
                    var3_3.close();
                    return new h(var2_2);
                }
                catch (IOException var7_19) {
                    Log.e((String)var1_1, (String)"Error in Data#fromByteArray: ", (Throwable)var7_19);
                }
                return new h(var2_2);
            }
            var12_12 = var11_7;
            var13_13 = var4_4;
        }
        if (var13_13 != null) {
            try {
                var13_13.close();
            }
            catch (IOException var16_20) {
                Log.e((String)var1_1, (String)"Error in Data#fromByteArray: ", (Throwable)var16_20);
            }
        }
        try {
            var3_3.close();
            throw var12_12;
        }
        catch (IOException var14_21) {
            Log.e((String)var1_1, (String)"Error in Data#fromByteArray: ", (Throwable)var14_21);
        }
        throw var12_12;
    }

    /*
     * WARNING - Removed back jump from a try to a catch block - possible behaviour change.
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static byte[] c(h var0) {
        block21 : {
            block22 : {
                block23 : {
                    var1_1 = h.b;
                    var2_2 = new ByteArrayOutputStream();
                    var3_3 = null;
                    var4_4 = new ObjectOutputStream((OutputStream)var2_2);
                    var4_4.writeInt(var0.a.size());
                    for (Map.Entry var22_6 : var0.a.entrySet()) {
                        var4_4.writeUTF((String)var22_6.getKey());
                        var4_4.writeObject(var22_6.getValue());
                    }
                    try {
                        var4_4.close();
                    }
                    catch (IOException var18_7) {
                        Log.e((String)var1_1, (String)"Error in Data#toByteArray: ", (Throwable)var18_7);
                    }
                    try {
                        var2_2.close();
                    }
                    catch (IOException var20_8) {
                        Log.e((String)var1_1, (String)"Error in Data#toByteArray: ", (Throwable)var20_8);
                    }
                    if (var2_2.size() > 10240) throw new IllegalStateException("Data cannot occupy more than 10240 bytes when serialized");
                    return var2_2.toByteArray();
                    catch (Throwable var12_9) {
                        break block21;
                    }
                    catch (IOException var5_12) {
                        var3_3 = var4_4;
                        ** GOTO lbl-1000
                    }
                    catch (Throwable var12_10) {
                        break block22;
                    }
                    catch (IOException var5_13) {
                        // empty catch block
                    }
lbl-1000: // 2 sources:
                    {
                        Log.e((String)var1_1, (String)"Error in Data#toByteArray: ", (Throwable)var5_14);
                        var7_15 = var2_2.toByteArray();
                        if (var3_3 == null) break block23;
                    }
                    try {
                        var3_3.close();
                    }
                    catch (IOException var10_16) {
                        Log.e((String)var1_1, (String)"Error in Data#toByteArray: ", (Throwable)var10_16);
                    }
                }
                try {
                    var2_2.close();
                    return var7_15;
                }
                catch (IOException var8_17) {
                    Log.e((String)var1_1, (String)"Error in Data#toByteArray: ", (Throwable)var8_17);
                    return var7_15;
                }
            }
            var4_4 = var3_3;
        }
        if (var4_4 != null) {
            try {
                var4_4.close();
            }
            catch (IOException var15_18) {
                Log.e((String)var1_1, (String)"Error in Data#toByteArray: ", (Throwable)var15_18);
            }
        }
        try {
            var2_2.close();
            throw var12_11;
        }
        catch (IOException var13_19) {
            Log.e((String)var1_1, (String)"Error in Data#toByteArray: ", (Throwable)var13_19);
        }
        throw var12_11;
    }

    public final String b(String string) {
        Object object = this.a.get((Object)string);
        if (object instanceof String) {
            return (String)object;
        }
        return null;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null) {
            if (h.class != object.getClass()) {
                return false;
            }
            h h2 = (h)object;
            HashMap hashMap = this.a;
            Set set = hashMap.keySet();
            if (!set.equals((Object)h2.a.keySet())) {
                return false;
            }
            for (String string : set) {
                Object object2 = hashMap.get((Object)string);
                Object object3 = h2.a.get((Object)string);
                boolean bl = object2 != null && object3 != null ? (object2 instanceof Object[] && object3 instanceof Object[] ? Arrays.deepEquals((Object[])((Object[])object2), (Object[])((Object[])object3)) : object2.equals(object3)) : object2 == object3;
                if (bl) continue;
                return false;
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        return 31 * this.a.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("Data {");
        HashMap hashMap = this.a;
        if (!hashMap.isEmpty()) {
            for (String string : hashMap.keySet()) {
                stringBuilder.append(string);
                stringBuilder.append(" : ");
                Object object = hashMap.get((Object)string);
                if (object instanceof Object[]) {
                    stringBuilder.append(Arrays.toString((Object[])((Object[])object)));
                } else {
                    stringBuilder.append(object);
                }
                stringBuilder.append(", ");
            }
        }
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

