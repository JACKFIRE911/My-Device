/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package a2;

import a2.p;

public final class n
extends p {
    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        return object != null && n.class == object.getClass();
    }

    public final int hashCode() {
        return n.class.getName().hashCode();
    }

    public final String toString() {
        return "Retry";
    }
}

