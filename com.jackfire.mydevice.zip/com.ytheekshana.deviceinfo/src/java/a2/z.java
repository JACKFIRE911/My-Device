/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.ytheekshana.deviceinfo.widget.WidgetService
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.concurrent.TimeUnit
 */
package a2;

import a2.a0;
import a2.c0;
import a2.d0;
import a2.r;
import com.ytheekshana.deviceinfo.widget.WidgetService;
import j2.s;
import java.util.concurrent.TimeUnit;
import s7.j;

public final class z
extends c0 {
    public z(long l3, TimeUnit timeUnit) {
        long l4;
        long l5;
        j.i((Object)timeUnit, "repeatIntervalTimeUnit");
        super(WidgetService.class);
        s s3 = this.b;
        long l6 = timeUnit.toMillis(l3);
        s3.getClass();
        long l7 = 900000L;
        long l8 = l6 LCMP l7;
        String string = s.u;
        if (l8 < 0) {
            r.d().g(string, "Interval duration lesser than minimum allowed value; Changed to 900000");
        }
        long l9 = l8 < 0 ? l7 : l6;
        if (l8 < 0) {
            l6 = l7;
        }
        if ((l4 = (l9 LCMP l7)) < 0) {
            r.d().g(string, "Interval duration lesser than minimum allowed value; Changed to 900000");
        }
        if (l4 >= 0) {
            l7 = l9;
        }
        s3.h = l7;
        long l10 = l6 LCMP 300000L;
        if (l10 < 0) {
            r.d().g(string, "Flex duration lesser than minimum allowed value; Changed to 300000");
        }
        if (l6 > s3.h) {
            r r4 = r.d();
            StringBuilder stringBuilder = new StringBuilder("Flex duration greater than interval duration; Changed to ");
            stringBuilder.append(l9);
            r4.g(string, stringBuilder.toString());
        }
        if (300000L <= (l5 = s3.h)) {
            if (l10 < 0) {
                l6 = 300000L;
            } else if (l6 > l5) {
                l6 = l5;
            }
            s3.i = l6;
            return;
        }
        StringBuilder stringBuilder = new StringBuilder("Cannot coerce value to an empty range: maximum ");
        stringBuilder.append(l5);
        stringBuilder.append(" is less than minimum 300000.");
        throw new IllegalArgumentException(stringBuilder.toString());
    }

    @Override
    public final d0 b() {
        if (true ^ this.b.q) {
            return new a0(this);
        }
        throw new IllegalArgumentException("PeriodicWorkRequests cannot be expedited".toString());
    }

    @Override
    public final c0 c() {
        return this;
    }
}

