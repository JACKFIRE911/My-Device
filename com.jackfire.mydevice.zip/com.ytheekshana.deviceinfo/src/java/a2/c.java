/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  s7.j
 */
package a2;

import android.net.Uri;
import s7.j;

public final class c {
    public final Uri a;
    public final boolean b;

    public c(boolean bl, Uri uri) {
        this.a = uri;
        this.b = bl;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        Class class_ = object != null ? object.getClass() : null;
        if (!j.b(c.class, (Object)class_)) {
            return false;
        }
        j.g((Object)object, (String)"null cannot be cast to non-null type androidx.work.Constraints.ContentUriTrigger");
        c c2 = (c)object;
        if (!j.b((Object)this.a, (Object)c2.a)) {
            return false;
        }
        return this.b == c2.b;
    }

    public final int hashCode() {
        int n2 = 31 * this.a.hashCode();
        int n3 = this.b ? 1231 : 1237;
        return n2 + n3;
    }
}

