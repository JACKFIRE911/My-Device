/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.LinkedHashMap
 *  java.util.Map$Entry
 *  java.util.Set
 *  java.util.TreeMap
 *  k1.a
 *  s7.j
 */
package a2;

import android.util.Log;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import k1.a;
import s7.j;

public final class g {
    public HashMap a;

    public /* synthetic */ g() {
        this.a = new LinkedHashMap();
    }

    public /* synthetic */ g(int n2) {
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    this.a = new HashMap();
                    return;
                }
                super();
                return;
            }
            super();
            this.a = new HashMap();
            return;
        }
        super();
        this.a = new HashMap();
    }

    public /* varargs */ void a(a ... arra) {
        j.i((Object)arra, (String)"migrations");
        for (a a2 : arra) {
            TreeMap treeMap;
            int n2;
            HashMap hashMap = this.a;
            int n3 = a2.a;
            Integer n4 = n3;
            Object object = hashMap.get((Object)n4);
            if (object == null) {
                object = new TreeMap();
                hashMap.put((Object)n4, object);
            }
            if ((treeMap = (TreeMap)object).containsKey((Object)(n2 = a2.b))) {
                StringBuilder stringBuilder = new StringBuilder("Overriding migration ");
                stringBuilder.append(treeMap.get((Object)n2));
                stringBuilder.append(" with ");
                stringBuilder.append((Object)a2);
                Log.w((String)"ROOM", (String)stringBuilder.toString());
            }
            treeMap.put((Object)n2, (Object)a2);
        }
    }

    public void b(HashMap hashMap) {
        for (Map.Entry entry : hashMap.entrySet()) {
            String string = (String)entry.getKey();
            Object object = entry.getValue();
            if (object == null) {
                this.a.put((Object)string, null);
                continue;
            }
            Class class_ = object.getClass();
            if (class_ != Boolean.class && class_ != Byte.class && class_ != Integer.class && class_ != Long.class && class_ != Float.class && class_ != Double.class && class_ != String.class && class_ != Boolean[].class && class_ != Byte[].class && class_ != Integer[].class && class_ != Long[].class && class_ != Float[].class && class_ != Double[].class && class_ != String[].class) {
                int n2;
                if (class_ == boolean[].class) {
                    HashMap hashMap2 = this.a;
                    boolean[] arrbl = (boolean[])object;
                    Boolean[] arrboolean = new Boolean[arrbl.length];
                    for (n2 = 0; n2 < arrbl.length; ++n2) {
                        arrboolean[n2] = arrbl[n2];
                    }
                    hashMap2.put((Object)string, (Object)arrboolean);
                    continue;
                }
                if (class_ == byte[].class) {
                    HashMap hashMap3 = this.a;
                    byte[] arrby = (byte[])object;
                    Byte[] arrbyte = new Byte[arrby.length];
                    while (n2 < arrby.length) {
                        arrbyte[n2] = arrby[n2];
                        ++n2;
                    }
                    hashMap3.put((Object)string, (Object)arrbyte);
                    continue;
                }
                if (class_ == int[].class) {
                    HashMap hashMap4 = this.a;
                    int[] arrn = (int[])object;
                    Integer[] arrinteger = new Integer[arrn.length];
                    while (n2 < arrn.length) {
                        arrinteger[n2] = arrn[n2];
                        ++n2;
                    }
                    hashMap4.put((Object)string, (Object)arrinteger);
                    continue;
                }
                if (class_ == long[].class) {
                    HashMap hashMap5 = this.a;
                    long[] arrl = (long[])object;
                    Long[] arrlong = new Long[arrl.length];
                    while (n2 < arrl.length) {
                        arrlong[n2] = arrl[n2];
                        ++n2;
                    }
                    hashMap5.put((Object)string, (Object)arrlong);
                    continue;
                }
                if (class_ == float[].class) {
                    HashMap hashMap6 = this.a;
                    float[] arrf = (float[])object;
                    Float[] arrfloat = new Float[arrf.length];
                    while (n2 < arrf.length) {
                        arrfloat[n2] = Float.valueOf((float)arrf[n2]);
                        ++n2;
                    }
                    hashMap6.put((Object)string, (Object)arrfloat);
                    continue;
                }
                if (class_ == double[].class) {
                    HashMap hashMap7 = this.a;
                    double[] arrd = (double[])object;
                    Double[] arrdouble = new Double[arrd.length];
                    while (n2 < arrd.length) {
                        arrdouble[n2] = arrd[n2];
                        ++n2;
                    }
                    hashMap7.put((Object)string, (Object)arrdouble);
                    continue;
                }
                StringBuilder stringBuilder = new StringBuilder("Key ");
                stringBuilder.append(string);
                stringBuilder.append("has invalid type ");
                stringBuilder.append((Object)class_);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            this.a.put((Object)string, object);
        }
    }
}

