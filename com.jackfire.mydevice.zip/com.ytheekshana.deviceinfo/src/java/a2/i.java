/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Notification
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package a2;

import android.app.Notification;

public final class i {
    public final int a;
    public final int b;
    public final Notification c;

    public i(int n2, int n3, Notification notification) {
        this.a = n2;
        this.c = notification;
        this.b = n3;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null) {
            if (i.class != object.getClass()) {
                return false;
            }
            i i2 = (i)object;
            if (this.a != i2.a) {
                return false;
            }
            if (this.b != i2.b) {
                return false;
            }
            return this.c.equals((Object)i2.c);
        }
        return false;
    }

    public final int hashCode() {
        return 31 * (31 * this.a + this.b) + this.c.hashCode();
    }

    public final String toString() {
        StringBuilder stringBuilder = new StringBuilder("ForegroundInfo{mNotificationId=");
        stringBuilder.append(this.a);
        stringBuilder.append(", mForegroundServiceType=");
        stringBuilder.append(this.b);
        stringBuilder.append(", mNotification=");
        stringBuilder.append((Object)this.c);
        stringBuilder.append('}');
        return stringBuilder.toString();
    }
}

