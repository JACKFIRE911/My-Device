/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j2.s
 *  java.lang.Object
 *  java.lang.String
 *  java.util.LinkedHashSet
 *  java.util.Set
 *  java.util.UUID
 *  s7.j
 */
package a2;

import j2.s;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.UUID;
import s7.j;

public abstract class d0 {
    public final UUID a;
    public final s b;
    public final Set c;

    public d0(UUID uUID, s s2, LinkedHashSet linkedHashSet) {
        j.i((Object)uUID, (String)"id");
        j.i((Object)s2, (String)"workSpec");
        j.i((Object)linkedHashSet, (String)"tags");
        this.a = uUID;
        this.b = s2;
        this.c = linkedHashSet;
    }
}

