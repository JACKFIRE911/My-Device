/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.util.concurrent.ThreadFactory
 *  java.util.concurrent.atomic.AtomicInteger
 *  s.h
 */
package a2;

import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;
import s.h;

public final class a
implements ThreadFactory {
    public final AtomicInteger a = new AtomicInteger(0);
    public final /* synthetic */ boolean b;

    public a(boolean bl) {
        this.b = bl;
    }

    public final Thread newThread(Runnable runnable) {
        String string = this.b ? "WM.task-" : "androidx.work-";
        StringBuilder stringBuilder = h.b((String)string);
        stringBuilder.append(this.a.incrementAndGet());
        return new Thread(runnable, stringBuilder.toString());
    }
}

