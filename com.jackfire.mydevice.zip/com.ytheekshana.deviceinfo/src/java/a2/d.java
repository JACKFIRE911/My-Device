/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.google.android.gms.internal.ads.xe1
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.util.Set
 *  k9.l
 *  s.h
 *  s7.j
 */
package a2;

import com.google.android.gms.internal.ads.xe1;
import java.util.Set;
import k9.l;
import s.h;
import s7.j;

public final class d {
    public static final d i;
    public final int a;
    public final boolean b;
    public final boolean c;
    public final boolean d;
    public final boolean e;
    public final long f;
    public final long g;
    public final Set h;

    public static {
        d d2;
        i = d2 = new d(1, false, false, false, false, -1L, -1L, (Set)l.q);
    }

    public d(int n2, boolean bl, boolean bl2, boolean bl3, boolean bl4, long l2, long l3, Set set) {
        xe1.o((int)n2, (String)"requiredNetworkType");
        j.i((Object)set, (String)"contentUriTriggers");
        this.a = n2;
        this.b = bl;
        this.c = bl2;
        this.d = bl3;
        this.e = bl4;
        this.f = l2;
        this.g = l3;
        this.h = set;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        boolean bl = false;
        if (object != null) {
            if (!j.b(d.class, (Object)object.getClass())) {
                return false;
            }
            d d2 = (d)object;
            if (this.b != d2.b) {
                return false;
            }
            if (this.c != d2.c) {
                return false;
            }
            if (this.d != d2.d) {
                return false;
            }
            if (this.e != d2.e) {
                return false;
            }
            if (this.f != d2.f) {
                return false;
            }
            if (this.g != d2.g) {
                return false;
            }
            if (this.a != d2.a) {
                return false;
            }
            bl = j.b((Object)this.h, (Object)d2.h);
        }
        return bl;
    }

    public final int hashCode() {
        int n2 = 31 * (31 * (31 * (31 * (31 * h.c((int)this.a) + this.b) + this.c) + this.d) + this.e);
        long l2 = this.f;
        int n3 = 31 * (n2 + (int)(l2 ^ l2 >>> 32));
        long l3 = this.g;
        return 31 * (n3 + (int)(l3 ^ l3 >>> 32)) + this.h.hashCode();
    }
}

