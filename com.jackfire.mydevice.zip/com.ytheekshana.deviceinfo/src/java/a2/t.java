/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.work.OverwritingInputMerger
 *  java.lang.Class
 *  java.lang.String
 */
package a2;

import a2.c0;
import a2.d0;
import a2.u;
import androidx.work.OverwritingInputMerger;
import j2.s;

public final class t
extends c0 {
    public t(Class class_) {
        super(class_);
        this.b.d = OverwritingInputMerger.class.getName();
    }

    @Override
    public final d0 b() {
        return new u(this);
    }

    @Override
    public final c0 c() {
        return this;
    }
}

