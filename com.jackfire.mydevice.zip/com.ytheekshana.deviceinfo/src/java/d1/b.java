/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.LinkedHashMap
 */
package d1;

import java.util.LinkedHashMap;

public abstract class b {
    public final LinkedHashMap a = new LinkedHashMap();
}

