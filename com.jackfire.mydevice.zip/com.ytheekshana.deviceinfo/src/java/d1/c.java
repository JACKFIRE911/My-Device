/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.lifecycle.v0
 *  androidx.lifecycle.x0
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.UnsupportedOperationException
 *  t9.l
 */
package d1;

import androidx.lifecycle.v0;
import androidx.lifecycle.x0;
import d1.e;
import d1.f;
import s7.j;
import t9.l;

public final class c
implements x0 {
    public final f[] q;

    public /* varargs */ c(f ... arrf) {
        j.i(arrf, "initializers");
        this.q = arrf;
    }

    public final v0 a(Class class_) {
        throw new UnsupportedOperationException("Factory.create(String) is unsupported.  This Factory requires `CreationExtras` to be passed into `create` method.");
    }

    public final v0 j(Class class_, e e4) {
        f[] arrf = this.q;
        int n5 = arrf.length;
        v0 v02 = null;
        for (int i3 = 0; i3 < n5; ++i3) {
            f f4 = arrf[i3];
            if (!j.b((Object)f4.a, (Object)class_)) continue;
            Object object = f4.b.g((Object)e4);
            v02 = object instanceof v0 ? (v0)object : null;
        }
        if (v02 != null) {
            return v02;
        }
        throw new IllegalArgumentException("No initializer set for given class ".concat(class_.getName()));
    }
}

