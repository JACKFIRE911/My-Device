/*
 * Decompiled with CFR 0.0.
 */
package d1;

import d1.b;

public final class a
extends b {
    public static final a b = new a();
}

