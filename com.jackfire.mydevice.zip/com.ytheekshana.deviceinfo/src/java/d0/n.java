/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.reflect.Method
 */
package d0;

import java.lang.reflect.Method;

public abstract class n {
    public static final Object a = new Object();
    public static Method b;
    public static boolean c;
}

