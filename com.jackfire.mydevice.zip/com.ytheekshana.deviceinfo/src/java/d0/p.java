/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.ColorStateList
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.content.res.Resources$NotFoundException
 *  android.content.res.Resources$Theme
 *  android.content.res.XmlResourceParser
 *  android.graphics.Typeface
 *  android.util.Log
 *  android.util.SparseArray
 *  android.util.TypedValue
 *  java.io.IOException
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ThreadLocal
 *  java.lang.Throwable
 *  java.util.WeakHashMap
 *  k.e
 *  org.xmlpull.v1.XmlPullParserException
 *  q.i
 *  q5.a
 *  t8.c
 */
package d0;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Typeface;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import d0.e;
import d0.k;
import d0.l;
import java.io.IOException;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParserException;
import q.i;
import q5.a;
import t8.c;

public abstract class p {
    public static final ThreadLocal a = new ThreadLocal();
    public static final WeakHashMap b = new WeakHashMap(0);
    public static final Object c = new Object();

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public static void a(l l2, int n2, ColorStateList colorStateList, Resources.Theme theme) {
        Object object;
        Object object2 = object = c;
        synchronized (object2) {
            WeakHashMap weakHashMap = b;
            SparseArray sparseArray = (SparseArray)weakHashMap.get((Object)l2);
            if (sparseArray == null) {
                sparseArray = new SparseArray();
                weakHashMap.put((Object)l2, (Object)sparseArray);
            }
            sparseArray.append(n2, (Object)new k(colorStateList, l2.a.getConfiguration(), theme));
            return;
        }
    }

    public static Typeface b(Context context, int n2) {
        if (context.isRestricted()) {
            return null;
        }
        return p.c(context, n2, new TypedValue(), 0, null, false, false);
    }

    /*
     * Loose catch block
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Lifted jumps to return sites
     */
    public static Typeface c(Context context, int n2, TypedValue typedValue, int n5, k.e e2, boolean bl, boolean bl2) {
        Typeface typeface;
        block16 : {
            block15 : {
                block19 : {
                    String string;
                    i i2;
                    Resources resources;
                    block18 : {
                        block17 : {
                            resources = context.getResources();
                            resources.getValue(n2, typedValue, true);
                            CharSequence charSequence = typedValue.string;
                            if (charSequence == null) {
                                StringBuilder stringBuilder = new StringBuilder("Resource \"");
                                stringBuilder.append(resources.getResourceName(n2));
                                stringBuilder.append("\" (");
                                stringBuilder.append(Integer.toHexString((int)n2));
                                stringBuilder.append(") is not a Font: ");
                                stringBuilder.append((Object)typedValue);
                                throw new Resources.NotFoundException(stringBuilder.toString());
                            }
                            string = charSequence.toString();
                            if (string.startsWith("res/")) break block17;
                            if (e2 != null) {
                                e2.c(-3);
                            }
                            break block15;
                        }
                        i2 = e0.l.b;
                        int n6 = typedValue.assetCookie;
                        typeface = (Typeface)i2.b((Object)e0.l.b(resources, n2, string, n6, n5));
                        if (typeface == null) break block18;
                        if (e2 != null) {
                            e2.d(typeface);
                        }
                        break block16;
                    }
                    if (bl2) break block15;
                    try {
                        if (string.toLowerCase().endsWith(".xml")) {
                            e e3 = a.u((XmlResourceParser)resources.getXml(n2), (Resources)resources);
                            if (e3 == null) {
                                Log.e((String)"ResourcesCompat", (String)"Failed to find font-family tag");
                                if (e2 != null) {
                                    e2.c(-3);
                                }
                                break block15;
                            }
                            typeface = e0.l.a(context, e3, resources, n2, string, typedValue.assetCookie, n5, e2, bl);
                            break block16;
                        }
                        int n7 = typedValue.assetCookie;
                        typeface = e0.l.a.q(context, resources, n2, string, n5);
                        if (typeface != null) {
                            i2.c((Object)e0.l.b(resources, n2, string, n7, n5), (Object)typeface);
                        }
                        if (e2 != null) {
                            if (typeface != null) {
                                e2.d(typeface);
                            } else {
                                e2.c(-3);
                            }
                        }
                        break block16;
                    }
                    catch (IOException iOException) {}
                    Log.e((String)"ResourcesCompat", (String)"Failed to read xml resource ".concat(string), (Throwable)iOException);
                    break block19;
                    catch (XmlPullParserException xmlPullParserException) {}
                    Log.e((String)"ResourcesCompat", (String)"Failed to parse xml resource ".concat(string), (Throwable)xmlPullParserException);
                }
                if (e2 != null) {
                    e2.c(-3);
                }
            }
            typeface = null;
        }
        if (typeface != null) return typeface;
        if (e2 != null) return typeface;
        if (bl2) {
            return typeface;
        }
        StringBuilder stringBuilder = new StringBuilder("Font resource ID #0x");
        stringBuilder.append(Integer.toHexString((int)n2));
        stringBuilder.append(" could not be retrieved.");
        throw new Resources.NotFoundException(stringBuilder.toString());
    }
}

