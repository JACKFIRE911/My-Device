/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Color
 *  j7.b
 *  java.lang.Math
 *  java.lang.Object
 */
package d0;

import android.graphics.Color;
import d0.q;
import e0.e;
import j7.b;

public final class a {
    public final float a;
    public final float b;
    public final float c;
    public final float d;
    public final float e;
    public final float f;

    public a(float f2, float f4, float f5, float f6, float f7, float f8) {
        this.a = f2;
        this.b = f4;
        this.c = f5;
        this.d = f6;
        this.e = f7;
        this.f = f8;
    }

    public static a a(int n2) {
        q q2 = q.k;
        float f2 = b.k((int)Color.red((int)n2));
        float f4 = b.k((int)Color.green((int)n2));
        float f5 = b.k((int)Color.blue((int)n2));
        float[][] arrf = b.m;
        float[] arrf2 = arrf[0];
        float f6 = f2 * arrf2[0] + f4 * arrf2[1] + f5 * arrf2[2];
        float[] arrf3 = arrf[1];
        float f7 = f2 * arrf3[0] + f4 * arrf3[1] + f5 * arrf3[2];
        float[] arrf4 = arrf[2];
        float f8 = f2 * arrf4[0] + f4 * arrf4[1] + f5 * arrf4[2];
        float[][] arrf5 = b.j;
        float[] arrf6 = arrf5[0];
        float f10 = f6 * arrf6[0] + f7 * arrf6[1] + f8 * arrf6[2];
        float[] arrf7 = arrf5[1];
        float f11 = f6 * arrf7[0] + f7 * arrf7[1] + f8 * arrf7[2];
        float[] arrf8 = arrf5[2];
        float f12 = f6 * arrf8[0] + f7 * arrf8[1] + f8 * arrf8[2];
        float[] arrf9 = q2.g;
        float f13 = f10 * arrf9[0];
        float f14 = f11 * arrf9[1];
        float f15 = f12 * arrf9[2];
        float f16 = Math.abs((float)f13);
        float f17 = q2.h;
        float f18 = (float)Math.pow((double)((double)(f16 * f17) / 100.0), (double)0.42);
        float f19 = (float)Math.pow((double)((double)(f17 * Math.abs((float)f14)) / 100.0), (double)0.42);
        float f20 = (float)Math.pow((double)((double)(f17 * Math.abs((float)f15)) / 100.0), (double)0.42);
        float f21 = f18 * (400.0f * Math.signum((float)f13)) / (f18 + 27.13f);
        float f22 = f19 * (400.0f * Math.signum((float)f14)) / (f19 + 27.13f);
        float f23 = f20 * (400.0f * Math.signum((float)f15)) / (f20 + 27.13f);
        double d2 = 11.0 * (double)f21 + -12.0 * (double)f22;
        double d3 = f23;
        float f24 = (float)(d2 + d3) / 11.0f;
        float f25 = (float)((double)(f21 + f22) - d3 * 2.0) / 9.0f;
        float f26 = f21 * 20.0f;
        float f27 = f22 * 20.0f;
        float f28 = (f26 + f27 + 21.0f * f23) / 20.0f;
        float f29 = (f23 + (f27 + f21 * 40.0f)) / 20.0f;
        float f30 = 180.0f * (float)Math.atan2((double)f25, (double)f24) / 3.1415927f;
        if (f30 < 0.0f) {
            f30 += 360.0f;
        } else if (f30 >= 360.0f) {
            f30 -= 360.0f;
        }
        float f32 = f30;
        float f33 = 3.1415927f * f32 / 180.0f;
        float f34 = f29 * q2.b;
        float f35 = q2.a;
        double d4 = f34 / f35;
        float f36 = q2.j;
        float f37 = q2.d;
        float f38 = 100.0f * (float)Math.pow((double)d4, (double)(f36 * f37));
        Math.sqrt((double)(f38 / 100.0f));
        float f39 = f35 + 4.0f;
        float f40 = (double)f32 < 20.14 ? 360.0f + f32 : f32;
        float f41 = 3846.1538f * (0.25f * (float)(3.8 + Math.cos((double)(2.0 + 3.141592653589793 * (double)f40 / 180.0)))) * q2.e * q2.c * (float)Math.sqrt((double)(f24 * f24 + f25 * f25)) / (f28 + 0.305f);
        float f42 = (float)Math.pow((double)(1.64 - Math.pow((double)0.29, (double)q2.f)), (double)0.73) * (float)Math.pow((double)f41, (double)0.9);
        float f43 = f42 * (float)Math.sqrt((double)((double)f38 / 100.0));
        float f44 = f43 * q2.i;
        Math.sqrt((double)(f42 * f37 / f39));
        float f45 = 1.7f * f38 / (1.0f + 0.007f * f38);
        float f46 = 43.85965f * (float)Math.log((double)(1.0f + f44 * 0.0228f));
        double d5 = f33;
        float f47 = f46 * (float)Math.cos((double)d5);
        float f48 = f46 * (float)Math.sin((double)d5);
        a a2 = new a(f32, f43, f38, f45, f47, f48);
        return a2;
    }

    public static a b(float f2, float f4, float f5) {
        q q2 = q.k;
        double d2 = (double)f2 / 100.0;
        Math.sqrt((double)d2);
        float f6 = 4.0f + q2.a;
        float f7 = f4 * q2.i;
        Math.sqrt((double)(f4 / (float)Math.sqrt((double)d2) * q2.d / f6));
        float f8 = 3.1415927f * f5 / 180.0f;
        float f10 = 1.7f * f2 / (1.0f + 0.007f * f2);
        float f11 = 43.85965f * (float)Math.log((double)(1.0 + 0.0228 * (double)f7));
        double d3 = f8;
        float f12 = f11 * (float)Math.cos((double)d3);
        float f13 = f11 * (float)Math.sin((double)d3);
        a a2 = new a(f5, f4, f2, f10, f12, f13);
        return a2;
    }

    public final int c(q q2) {
        double d2;
        float f2 = this.b;
        double d3 = (double)f2 DCMPL 0.0;
        float f4 = this.c;
        float f5 = d3 != false && (d2 = (double)f4) != 0.0 ? f2 / (float)Math.sqrt((double)(d2 / 100.0)) : 0.0f;
        float f6 = (float)Math.pow((double)((double)f5 / Math.pow((double)(1.64 - Math.pow((double)0.29, (double)q2.f)), (double)0.73)), (double)1.1111111111111112);
        double d4 = 3.1415927f * this.a / 180.0f;
        float f7 = 0.25f * (float)(3.8 + Math.cos((double)(2.0 + d4)));
        float f8 = (float)Math.pow((double)((double)f4 / 100.0), (double)(1.0 / (double)q2.d / (double)q2.j)) * q2.a;
        float f10 = f7 * 3846.1538f * q2.e * q2.c;
        float f11 = f8 / q2.b;
        float f12 = (float)Math.sin((double)d4);
        float f13 = (float)Math.cos((double)d4);
        float f14 = f6 * (23.0f * (0.305f + f11)) / (f10 * 23.0f + f13 * (11.0f * f6) + f12 * (f6 * 108.0f));
        float f15 = f13 * f14;
        float f16 = f14 * f12;
        float f17 = f11 * 460.0f;
        float f18 = (f17 + 451.0f * f15 + 288.0f * f16) / 1403.0f;
        float f19 = (f17 - 891.0f * f15 - 261.0f * f16) / 1403.0f;
        float f20 = (f17 - f15 * 220.0f - f16 * 6300.0f) / 1403.0f;
        float f21 = (float)Math.max((double)0.0, (double)(27.13 * (double)Math.abs((float)f18) / (400.0 - (double)Math.abs((float)f18))));
        float f22 = Math.signum((float)f18);
        float f23 = 100.0f / q2.h;
        float f24 = f22 * f23 * (float)Math.pow((double)f21, (double)2.380952380952381);
        float f25 = (float)Math.max((double)0.0, (double)(27.13 * (double)Math.abs((float)f19) / (400.0 - (double)Math.abs((float)f19))));
        float f26 = f23 * Math.signum((float)f19) * (float)Math.pow((double)f25, (double)2.380952380952381);
        float f27 = (float)Math.max((double)0.0, (double)(27.13 * (double)Math.abs((float)f20) / (400.0 - (double)Math.abs((float)f20))));
        float f28 = f23 * Math.signum((float)f20) * (float)Math.pow((double)f27, (double)2.380952380952381);
        float[] arrf = q2.g;
        float f29 = f24 / arrf[0];
        float f30 = f26 / arrf[1];
        float f32 = f28 / arrf[2];
        float[][] arrf2 = b.k;
        float[] arrf3 = arrf2[0];
        float f33 = f29 * arrf3[0] + f30 * arrf3[1] + f32 * arrf3[2];
        float[] arrf4 = arrf2[1];
        float f34 = f29 * arrf4[0] + f30 * arrf4[1] + f32 * arrf4[2];
        float[] arrf5 = arrf2[2];
        float f35 = f29 * arrf5[0] + f30 * arrf5[1] + f32 * arrf5[2];
        return e.a(f33, f34, f35);
    }
}

