/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.TypedArray
 *  java.lang.Object
 */
package d0;

import android.content.res.TypedArray;

public abstract class d {
    public static int a(TypedArray typedArray, int n2) {
        return typedArray.getType(n2);
    }
}

