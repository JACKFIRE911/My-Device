/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.appcompat.widget.r
 *  java.lang.Object
 *  java.lang.String
 */
package d0;

import androidx.appcompat.widget.r;
import d0.e;

public final class h
implements e {
    public final r a;
    public final int b;
    public final int c;
    public final String d;

    public h(r r4, int n5, int n6, String string) {
        this.a = r4;
        this.c = n5;
        this.b = n6;
        this.d = string;
    }
}

