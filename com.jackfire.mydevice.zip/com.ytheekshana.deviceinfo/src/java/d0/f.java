/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package d0;

import d0.e;
import d0.g;

public final class f
implements e {
    public final g[] a;

    public f(g[] arrg) {
        this.a = arrg;
    }
}

