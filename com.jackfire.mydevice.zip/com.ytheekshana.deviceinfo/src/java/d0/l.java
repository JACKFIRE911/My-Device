/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  java.lang.Class
 *  java.lang.Object
 *  m0.b
 */
package d0;

import android.content.res.Resources;
import m0.b;

public final class l {
    public final Resources a;
    public final Resources.Theme b;

    public l(Resources resources, Resources.Theme theme) {
        this.a = resources;
        this.b = theme;
    }

    public final boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object != null) {
            if (l.class != object.getClass()) {
                return false;
            }
            l l2 = (l)object;
            return this.a.equals((Object)l2.a) && b.a((Object)this.b, (Object)l2.b);
        }
        return false;
    }

    public final int hashCode() {
        Object[] arrobject = new Object[]{this.a, this.b};
        return b.b((Object[])arrobject);
    }
}

