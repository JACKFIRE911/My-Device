/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  com.google.android.gms.internal.ads.cj1
 *  java.lang.Object
 */
package d0;

import android.content.res.Resources;
import com.google.android.gms.internal.ads.cj1;

public abstract class o {
    public static void a(Resources.Theme theme) {
        cj1.i((Resources.Theme)theme);
    }
}

