/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package d0;

public final class g {
    public final String a;
    public final int b;
    public final boolean c;
    public final String d;
    public final int e;
    public final int f;

    public g(int n2, int n5, int n6, String string, String string2, boolean bl) {
        this.a = string;
        this.b = n2;
        this.c = bl;
        this.d = string2;
        this.e = n5;
        this.f = n6;
    }
}

