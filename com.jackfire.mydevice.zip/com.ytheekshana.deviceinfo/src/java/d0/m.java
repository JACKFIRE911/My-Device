/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  com.google.android.material.sidesheet.SideSheetBehavior
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.ref.WeakReference
 *  k.e
 */
package d0;

import android.view.View;
import com.google.android.material.sidesheet.SideSheetBehavior;
import java.lang.ref.WeakReference;
import k.e;

public final class m
implements Runnable {
    public final /* synthetic */ int q;
    public final /* synthetic */ int r;
    public final /* synthetic */ Object s;

    public /* synthetic */ m(Object object, int n2, int n5) {
        this.q = n5;
        this.s = object;
        this.r = n2;
    }

    public final void run() {
        int n2 = this.q;
        int n5 = this.r;
        Object object = this.s;
        switch (n2) {
            default: {
                break;
            }
            case 0: {
                ((e)object).f(n5);
                return;
            }
        }
        SideSheetBehavior sideSheetBehavior = (SideSheetBehavior)object;
        View view = (View)sideSheetBehavior.o.get();
        if (view != null) {
            sideSheetBehavior.t(n5, view, false);
        }
    }
}

