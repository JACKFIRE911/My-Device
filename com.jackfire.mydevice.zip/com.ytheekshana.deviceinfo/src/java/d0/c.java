/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.ColorStateList
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.content.res.TypedArray
 *  android.content.res.XmlResourceParser
 *  android.graphics.LinearGradient
 *  android.graphics.RadialGradient
 *  android.graphics.Shader
 *  android.graphics.Shader$TileMode
 *  android.graphics.SweepGradient
 *  android.util.AttributeSet
 *  android.util.Xml
 *  i5.j
 *  j2.c
 *  java.lang.Class
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.StackTraceElement
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  org.xmlpull.v1.XmlPullParser
 *  org.xmlpull.v1.XmlPullParserException
 *  s5.m
 *  t8.c
 */
package d0;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.util.Xml;
import d0.b;
import i5.j;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import q5.a;
import s5.m;

public final class c
implements f8.a {
    public int q;
    public Object r;
    public Object s;

    public c(Shader shader, ColorStateList colorStateList, int n5) {
        this.r = shader;
        this.s = colorStateList;
        this.q = n5;
    }

    public c(j j3) {
        this.s = n7.b.r(150, (n3.a)new t8.c(18, (Object)this));
        this.r = j3;
    }

    public /* varargs */ c(f8.a ... arra) {
        this.q = 1024;
        this.r = arra;
        this.s = new m(1024, 15, null);
    }

    public static c b(Resources resources, int n5, Resources.Theme theme) {
        block16 : {
            XmlResourceParser xmlResourceParser;
            String string;
            block17 : {
                block20 : {
                    SweepGradient sweepGradient;
                    block19 : {
                        float f4;
                        float f6;
                        int n6;
                        j2.c c4;
                        float f7;
                        block18 : {
                            int n7;
                            float f8;
                            int n8;
                            ArrayList arrayList;
                            int n9;
                            float f9;
                            int n10;
                            ArrayList arrayList2;
                            boolean bl;
                            float f10;
                            float f11;
                            block15 : {
                                int n11;
                                xmlResourceParser = resources.getXml(n5);
                                AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
                                while ((n11 = xmlResourceParser.next()) != 2 && n11 != 1) {
                                }
                                if (n11 != 2) break block16;
                                String string2 = xmlResourceParser.getName();
                                string2.getClass();
                                if (!string2.equals((Object)"gradient")) {
                                    if (string2.equals((Object)"selector")) {
                                        ColorStateList colorStateList = b.b(resources, xmlResourceParser, attributeSet, theme);
                                        return new c(null, colorStateList, colorStateList.getDefaultColor());
                                    }
                                    StringBuilder stringBuilder = new StringBuilder();
                                    stringBuilder.append(xmlResourceParser.getPositionDescription());
                                    stringBuilder.append(": unsupported complex color tag ");
                                    stringBuilder.append(string2);
                                    throw new XmlPullParserException(stringBuilder.toString());
                                }
                                string = xmlResourceParser.getName();
                                if (!string.equals((Object)"gradient")) break block17;
                                TypedArray typedArray = a.s(resources, theme, attributeSet, a0.a.d);
                                f10 = a.i(typedArray, (XmlPullParser)xmlResourceParser, "startX", 8, 0.0f);
                                float f12 = a.i(typedArray, (XmlPullParser)xmlResourceParser, "startY", 9, 0.0f);
                                float f13 = a.i(typedArray, (XmlPullParser)xmlResourceParser, "endX", 10, 0.0f);
                                f9 = a.i(typedArray, (XmlPullParser)xmlResourceParser, "endY", 11, 0.0f);
                                f4 = a.i(typedArray, (XmlPullParser)xmlResourceParser, "centerX", 3, 0.0f);
                                f7 = a.i(typedArray, (XmlPullParser)xmlResourceParser, "centerY", 4, 0.0f);
                                n8 = a.j(typedArray, (XmlPullParser)xmlResourceParser, "type", 2, 0);
                                n7 = !a.p((XmlPullParser)xmlResourceParser, "startColor") ? 0 : typedArray.getColor(0, 0);
                                bl = a.p((XmlPullParser)xmlResourceParser, "centerColor");
                                n9 = !a.p((XmlPullParser)xmlResourceParser, "centerColor") ? 0 : typedArray.getColor(7, 0);
                                n10 = !a.p((XmlPullParser)xmlResourceParser, "endColor") ? 0 : typedArray.getColor(1, 0);
                                n6 = a.j(typedArray, (XmlPullParser)xmlResourceParser, "tileMode", 6, 0);
                                f6 = a.i(typedArray, (XmlPullParser)xmlResourceParser, "gradientRadius", 5, 0.0f);
                                typedArray.recycle();
                                int n12 = 1 + xmlResourceParser.getDepth();
                                arrayList = new ArrayList(20);
                                arrayList2 = new ArrayList(20);
                                do {
                                    int n13 = xmlResourceParser.next();
                                    f8 = f13;
                                    if (n13 == 1) break;
                                    int n14 = xmlResourceParser.getDepth();
                                    f11 = f12;
                                    if (n14 >= n12 || n13 != 3) {
                                        if (n13 == 2 && n14 <= n12 && xmlResourceParser.getName().equals((Object)"item")) {
                                            TypedArray typedArray2 = a.s(resources, theme, attributeSet, a0.a.e);
                                            boolean bl2 = typedArray2.hasValue(0);
                                            boolean bl3 = typedArray2.hasValue(1);
                                            if (bl2 && bl3) {
                                                int n15 = typedArray2.getColor(0, 0);
                                                float f14 = typedArray2.getFloat(1, 0.0f);
                                                typedArray2.recycle();
                                                arrayList2.add((Object)n15);
                                                arrayList.add((Object)Float.valueOf((float)f14));
                                            } else {
                                                StringBuilder stringBuilder = new StringBuilder();
                                                stringBuilder.append(xmlResourceParser.getPositionDescription());
                                                stringBuilder.append(": <item> tag requires a 'color' attribute and a 'offset' attribute!");
                                                throw new XmlPullParserException(stringBuilder.toString());
                                            }
                                        }
                                        f13 = f8;
                                        f12 = f11;
                                        continue;
                                    }
                                    break block15;
                                    break;
                                } while (true);
                                f11 = f12;
                            }
                            if ((c4 = arrayList2.size() > 0 ? new j2.c(arrayList2, arrayList) : null) == null) {
                                c4 = bl ? new j2.c(n7, n9, n10) : new j2.c(n7, n10);
                            }
                            if (n8 == 1) break block18;
                            if (n8 != 2) {
                                int[] arrn = (int[])c4.r;
                                float[] arrf = (float[])c4.s;
                                Shader.TileMode tileMode = n6 != 1 ? (n6 != 2 ? Shader.TileMode.CLAMP : Shader.TileMode.MIRROR) : Shader.TileMode.REPEAT;
                                Shader.TileMode tileMode2 = tileMode;
                                sweepGradient = new LinearGradient(f10, f11, f8, f9, arrn, arrf, tileMode2);
                            } else {
                                sweepGradient = new SweepGradient(f4, f7, (int[])c4.r, (float[])c4.s);
                            }
                            break block19;
                        }
                        if (f6 <= 0.0f) break block20;
                        int[] arrn = (int[])c4.r;
                        float[] arrf = (float[])c4.s;
                        Shader.TileMode tileMode = n6 != 1 ? (n6 != 2 ? Shader.TileMode.CLAMP : Shader.TileMode.MIRROR) : Shader.TileMode.REPEAT;
                        Shader.TileMode tileMode3 = tileMode;
                        sweepGradient = new RadialGradient(f4, f7, f6, arrn, arrf, tileMode3);
                    }
                    return new c((Shader)sweepGradient, null, 0);
                }
                throw new XmlPullParserException("<gradient> tag requires 'gradientRadius' attribute with radial type");
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(xmlResourceParser.getPositionDescription());
            stringBuilder.append(": invalid gradient color tag ");
            stringBuilder.append(string);
            throw new XmlPullParserException(stringBuilder.toString());
        }
        throw new XmlPullParserException("No start tag found");
    }

    @Override
    public final StackTraceElement[] a(StackTraceElement[] arrstackTraceElement) {
        if (arrstackTraceElement.length <= this.q) {
            return arrstackTraceElement;
        }
        f8.a[] arra = (f8.a[])this.r;
        int n5 = arra.length;
        StackTraceElement[] arrstackTraceElement2 = arrstackTraceElement;
        for (int i3 = 0; i3 < n5; ++i3) {
            f8.a a3 = arra[i3];
            if (arrstackTraceElement2.length <= this.q) break;
            arrstackTraceElement2 = a3.a(arrstackTraceElement);
        }
        if (arrstackTraceElement2.length > this.q) {
            arrstackTraceElement2 = ((m)this.s).a(arrstackTraceElement2);
        }
        return arrstackTraceElement2;
    }

    public final boolean c() {
        Object object;
        return (Shader)this.r == null && (ColorStateList)(object = this.s) != null && ((ColorStateList)object).isStateful();
    }

    public final boolean d(int[] arrn) {
        ColorStateList colorStateList;
        int n5;
        if (this.c() && (n5 = (colorStateList = (ColorStateList)this.s).getColorForState(arrn, colorStateList.getDefaultColor())) != this.q) {
            this.q = n5;
            return true;
        }
        return false;
    }
}

