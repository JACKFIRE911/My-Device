/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.Resources
 *  android.content.res.Resources$Theme
 *  android.graphics.drawable.Drawable
 *  java.lang.Object
 */
package d0;

import android.content.res.Resources;
import android.graphics.drawable.Drawable;

public abstract class i {
    public static Drawable a(Resources resources, int n2, Resources.Theme theme) {
        return resources.getDrawable(n2, theme);
    }

    public static Drawable b(Resources resources, int n2, int n5, Resources.Theme theme) {
        return resources.getDrawableForDensity(n2, n5, theme);
    }
}

