/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  j7.b
 *  java.lang.Math
 *  java.lang.Object
 */
package d0;

import j7.b;

public final class q {
    public static final q k;
    public final float a;
    public final float b;
    public final float c;
    public final float d;
    public final float e;
    public final float f;
    public final float[] g;
    public final float h;
    public final float i;
    public final float j;

    public static {
        float f2;
        float f4;
        float f5;
        q q2;
        float[] arrf = b.l;
        float f6 = (float)(63.66197723675813 * (double)b.n() / 100.0);
        float[][] arrf2 = b.j;
        float f7 = arrf[0];
        float[] arrf3 = arrf2[0];
        float f8 = f7 * arrf3[0];
        float f10 = arrf[1];
        float f11 = f8 + f10 * arrf3[1];
        float f12 = arrf[2];
        float f13 = f11 + f12 * arrf3[2];
        float[] arrf4 = arrf2[1];
        float f14 = f7 * arrf4[0] + f10 * arrf4[1] + f12 * arrf4[2];
        float[] arrf5 = arrf2[2];
        float f15 = f7 * arrf5[0] + f10 * arrf5[1] + f12 * arrf5[2];
        if ((double)1.0f >= 0.9) {
            f5 = 0.100000046f;
            f2 = 0.59f;
        } else {
            f5 = 0.12999998f;
            f2 = 0.525f;
        }
        float f16 = f5 + f2;
        float f17 = 1.0f * (1.0f - 0.2777778f * (float)Math.exp((double)((-f6 - 42.0f) / 92.0f)));
        double d2 = f17;
        if (d2 > 1.0) {
            f17 = 1.0f;
        } else if (d2 < 0.0) {
            f17 = 0.0f;
        }
        float[] arrf6 = new float[]{1.0f + f17 * (100.0f / f13) - f17, 1.0f + f17 * (100.0f / f14) - f17, 1.0f + f17 * (100.0f / f15) - f17};
        float f18 = 1.0f / (1.0f + 5.0f * f6);
        float f19 = f18 * (f18 * (f18 * f18));
        float f20 = 1.0f - f19;
        float f21 = f19 * f6 + f20 * (0.1f * f20) * (float)Math.cbrt((double)(5.0 * (double)f6));
        float f22 = b.n() / arrf[1];
        double d3 = f22;
        float f23 = 1.48f + (float)Math.sqrt((double)d3);
        float f24 = 0.725f / (float)Math.pow((double)d3, (double)0.2);
        float[] arrf7 = new float[]{(float)Math.pow((double)((double)(f13 * (f21 * arrf6[0])) / 100.0), (double)0.42), (float)Math.pow((double)((double)(f14 * (f21 * arrf6[1])) / 100.0), (double)0.42), f4 = (float)Math.pow((double)((double)(f15 * (f21 * arrf6[2])) / 100.0), (double)0.42)};
        float f25 = arrf7[0];
        float f26 = f25 * 400.0f / (f25 + 27.13f);
        float f27 = arrf7[1];
        float f28 = f27 * 400.0f / (f27 + 27.13f);
        float f29 = 400.0f * f4 / (f4 + 27.13f);
        float f30 = f24 * (f28 + f26 * 2.0f + f29 * 0.05f);
        k = q2 = new q(f22, f30, f24, f24, f16, 1.0f, arrf6, f21, (float)Math.pow((double)f21, (double)0.25), f23);
    }

    public q(float f2, float f4, float f5, float f6, float f7, float f8, float[] arrf, float f10, float f11, float f12) {
        this.f = f2;
        this.a = f4;
        this.b = f5;
        this.c = f6;
        this.d = f7;
        this.e = f8;
        this.g = arrf;
        this.h = f10;
        this.i = f11;
        this.j = f12;
    }
}

