/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  java.io.File
 *  java.lang.Object
 */
package c0;

import android.content.Context;
import android.graphics.drawable.Drawable;
import java.io.File;

public abstract class c {
    public static File a(Context context) {
        return context.getCodeCacheDir();
    }

    public static Drawable b(Context context, int n2) {
        return context.getDrawable(n2);
    }

    public static File c(Context context) {
        return context.getNoBackupFilesDir();
    }
}

