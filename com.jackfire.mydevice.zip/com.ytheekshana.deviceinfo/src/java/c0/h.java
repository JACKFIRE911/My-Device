/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.File
 *  java.lang.Object
 */
package c0;

import android.content.Context;
import java.io.File;

public abstract class h {
    public static File[] a(Context context) {
        return context.getExternalMediaDirs();
    }
}

