/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.io.File
 *  java.lang.Object
 *  java.lang.String
 */
package c0;

import android.content.Context;
import java.io.File;

public abstract class b {
    public static File[] a(Context context) {
        return context.getExternalCacheDirs();
    }

    public static File[] b(Context context, String string) {
        return context.getExternalFilesDirs(string);
    }

    public static File[] c(Context context) {
        return context.getObbDirs();
    }
}

