/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.net.Uri
 *  java.io.File
 *  java.io.IOException
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.SecurityException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 */
package c0;

import android.net.Uri;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;

public final class i {
    public final String a;
    public final HashMap b = new HashMap();

    public i(String string) {
        this.a = string;
    }

    public final File a(Uri uri) {
        String string = uri.getEncodedPath();
        int n2 = string.indexOf(47, 1);
        String string2 = Uri.decode((String)string.substring(1, n2));
        String string3 = Uri.decode((String)string.substring(n2 + 1));
        File file = (File)this.b.get((Object)string2);
        if (file != null) {
            File file2;
            File file3 = new File(file, string3);
            try {
                file2 = file3.getCanonicalFile();
            }
            catch (IOException iOException) {
                StringBuilder stringBuilder = new StringBuilder("Failed to resolve canonical path for ");
                stringBuilder.append((Object)file3);
                throw new IllegalArgumentException(stringBuilder.toString());
            }
            if (file2.getPath().startsWith(file.getPath())) {
                return file2;
            }
            throw new SecurityException("Resolved path jumped beyond configured root");
        }
        StringBuilder stringBuilder = new StringBuilder("Unable to find configured root for ");
        stringBuilder.append((Object)uri);
        throw new IllegalArgumentException(stringBuilder.toString());
    }
}

