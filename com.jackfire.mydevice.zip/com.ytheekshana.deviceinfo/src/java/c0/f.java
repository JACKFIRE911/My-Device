/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.BroadcastReceiver
 *  android.content.ComponentName
 *  android.content.Context
 *  android.content.Intent
 *  android.content.IntentFilter
 *  android.os.Handler
 *  androidx.appcompat.widget.c1
 *  com.bumptech.glide.e
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package c0;

import a2.s;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Handler;
import androidx.appcompat.widget.c1;
import com.bumptech.glide.e;

public abstract class f {
    public static Intent a(Context context, BroadcastReceiver broadcastReceiver, IntentFilter intentFilter, String string, Handler handler, int n2) {
        if ((n2 & 4) != 0 && string == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(context.getPackageName());
            stringBuilder.append(".DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION");
            String string2 = stringBuilder.toString();
            if (e.d((Context)context, (String)string2) == 0) {
                return context.registerReceiver(broadcastReceiver, intentFilter, string2, handler);
            }
            throw new RuntimeException(s.u("Permission ", string2, " is required by your application to receive broadcasts, please add it to your manifest"));
        }
        return c1.j((Context)context, (BroadcastReceiver)broadcastReceiver, (IntentFilter)intentFilter, (String)string, (Handler)handler, (int)(n2 & 1));
    }

    public static ComponentName b(Context context, Intent intent) {
        return c1.i((Context)context, (Intent)intent);
    }
}

