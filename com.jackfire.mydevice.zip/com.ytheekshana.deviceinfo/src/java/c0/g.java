/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.appcompat.widget.e1
 *  java.lang.Object
 *  java.util.concurrent.Executor
 */
package c0;

import android.content.Context;
import androidx.appcompat.widget.e1;
import java.util.concurrent.Executor;

public abstract class g {
    public static Executor a(Context context) {
        return e1.m((Context)context);
    }
}

