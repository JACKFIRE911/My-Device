/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  java.lang.Object
 */
package c0;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public abstract class a {
    public static void a(Context context, Intent[] arrintent, Bundle bundle) {
        context.startActivities(arrintent, bundle);
    }

    public static void b(Context context, Intent intent, Bundle bundle) {
        context.startActivity(intent, bundle);
    }
}

