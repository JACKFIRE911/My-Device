/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  androidx.appcompat.widget.i0
 *  java.io.File
 *  java.lang.Object
 */
package c0;

import android.content.Context;
import androidx.appcompat.widget.i0;
import java.io.File;

public abstract class e {
    public static Context a(Context context) {
        return i0.f((Context)context);
    }

    public static File b(Context context) {
        return i0.m((Context)context);
    }

    public static boolean c(Context context) {
        return i0.z((Context)context);
    }
}

