/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 */
package c0;

import android.content.Context;

public abstract class d {
    public static int a(Context context, int n2) {
        return context.getColor(n2);
    }

    public static <T> T b(Context context, Class<T> class_) {
        return (T)context.getSystemService(class_);
    }

    public static String c(Context context, Class<?> class_) {
        return context.getSystemServiceName(class_);
    }
}

