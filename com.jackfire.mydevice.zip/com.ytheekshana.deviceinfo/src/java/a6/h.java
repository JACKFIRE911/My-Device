/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package a6;

import a8.b1;
import android.os.Parcel;
import android.os.Parcelable;
import l5.t;
import m5.a;
import y5.p;

public final class h
extends a {
    public static final Parcelable.Creator<h> CREATOR = new p(6);
    public final int q;
    public final t r;

    public h(int n3, t t3) {
        this.q = n3;
        this.r = t3;
    }

    public final void writeToParcel(Parcel parcel, int n3) {
        int n5 = b1.M(parcel, 20293);
        b1.D(parcel, 1, this.q);
        b1.F(parcel, 2, this.r, n3);
        b1.b0(parcel, n5);
    }
}

