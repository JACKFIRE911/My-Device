/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Looper
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 */
package a6;

import a6.e;
import a6.f;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import j5.g;
import j5.h;
import k5.d;
import l5.i;
import z5.c;

public final class a
extends i
implements c {
    public final boolean A = true;
    public final l5.f B;
    public final Bundle C;
    public final Integer D;

    public a(Context context, Looper looper, l5.f f4, Bundle bundle, g g2, h h4) {
        super(context, looper, 44, f4, g2, h4);
        this.B = f4;
        this.C = bundle;
        this.D = f4.h;
    }

    @Override
    public final int d() {
        return 12451000;
    }

    /*
     * Exception decompiling
     */
    @Override
    public final void e(e var1) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl207.1 : ACONST_NULL : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final boolean g() {
        return this.A;
    }

    @Override
    public final void h() {
        this.j = new c.a(27, this);
        this.x(2, null);
    }

    @Override
    public final /* synthetic */ IInterface j(IBinder iBinder) {
        if (iBinder == null) {
            return null;
        }
        IInterface iInterface = iBinder.queryLocalInterface("com.google.android.gms.signin.internal.ISignInService");
        if (iInterface instanceof f) {
            return (f)iInterface;
        }
        return new f(iBinder);
    }

    @Override
    public final Bundle n() {
        l5.f f4 = this.B;
        String string = f4.e;
        boolean bl = this.c.getPackageName().equals((Object)string);
        Bundle bundle = this.C;
        if (!bl) {
            bundle.putString("com.google.android.gms.signin.internal.realClientPackageName", f4.e);
        }
        return bundle;
    }

    @Override
    public final String q() {
        return "com.google.android.gms.signin.internal.ISignInService";
    }

    @Override
    public final String r() {
        return "com.google.android.gms.signin.service.START";
    }
}

