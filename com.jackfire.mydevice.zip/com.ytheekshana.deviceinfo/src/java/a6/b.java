/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package a6;

import a8.b1;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import m5.a;
import y5.p;

public final class b
extends a {
    public static final Parcelable.Creator<b> CREATOR = new p(4);
    public final int q;
    public final int r;
    public final Intent s;

    public b(int n3, int n4, Intent intent) {
        this.q = n3;
        this.r = n4;
        this.s = intent;
    }

    public final void writeToParcel(Parcel parcel, int n3) {
        int n5 = b1.M(parcel, 20293);
        b1.D(parcel, 1, this.q);
        b1.D(parcel, 2, this.r);
        b1.F(parcel, 3, (Parcelable)this.s, n3);
        b1.b0(parcel, n5);
    }
}

