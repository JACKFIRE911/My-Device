/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  a6.b
 *  a6.g
 *  a6.i
 *  android.os.Binder
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.Parcelable$Creator
 *  androidx.appcompat.widget.j
 *  com.google.android.gms.auth.api.signin.GoogleSignInAccount
 *  com.google.android.gms.common.api.Status
 *  i5.b
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  k5.z
 */
package a6;

import a6.b;
import a6.e;
import a6.g;
import a6.i;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import androidx.appcompat.widget.j;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.api.Status;
import k5.z;
import v5.a;

public abstract class d
extends Binder
implements e,
IInterface {
    public d() {
        this.attachInterface((IInterface)this, "com.google.android.gms.signin.internal.ISignInCallbacks");
    }

    public final boolean A1(int n2, Parcel parcel, Parcel parcel2, int n3) {
        if (n2 > 16777215) {
            if (super.onTransact(n2, parcel, parcel2, n3)) {
                return true;
            }
        } else {
            parcel.enforceInterface(this.getInterfaceDescriptor());
        }
        switch (n2) {
            default: {
                return false;
            }
            case 9: {
                (g)a.a(parcel, g.CREATOR);
                break;
            }
            case 8: {
                i i3 = (i)a.a(parcel, i.CREATOR);
                z z2 = (z)this;
                j j3 = new j((Object)z2, 28, (Object)i3);
                z2.r.post((Runnable)j3);
                break;
            }
            case 7: {
                (Status)a.a(parcel, Status.CREATOR);
                (GoogleSignInAccount)a.a(parcel, GoogleSignInAccount.CREATOR);
                break;
            }
            case 6: {
                (Status)a.a(parcel, Status.CREATOR);
                break;
            }
            case 4: {
                (Status)a.a(parcel, Status.CREATOR);
                break;
            }
            case 3: {
                (i5.b)a.a(parcel, i5.b.CREATOR);
                (b)a.a(parcel, b.CREATOR);
            }
        }
        parcel2.writeNoException();
        return true;
    }

    public final IBinder asBinder() {
        return this;
    }
}

