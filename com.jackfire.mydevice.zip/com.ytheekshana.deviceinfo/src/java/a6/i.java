/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 */
package a6;

import a8.b1;
import android.os.Parcel;
import android.os.Parcelable;
import i5.b;
import l5.u;
import m5.a;
import y5.p;

public final class i
extends a {
    public static final Parcelable.Creator<i> CREATOR = new p(7);
    public final int q;
    public final b r;
    public final u s;

    public i(int n3, b b3, u u2) {
        this.q = n3;
        this.r = b3;
        this.s = u2;
    }

    public final void writeToParcel(Parcel parcel, int n3) {
        int n5 = b1.M(parcel, 20293);
        b1.D(parcel, 1, this.q);
        b1.F(parcel, 2, this.r, n3);
        b1.F(parcel, 3, this.s, n3);
        b1.b0(parcel, n5);
    }
}

