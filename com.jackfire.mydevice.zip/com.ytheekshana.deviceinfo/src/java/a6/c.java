/*
 * Decompiled with CFR 0.0.
 */
package a6;

import a6.d;

public abstract class c
extends d {
}

