/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.IBinder
 *  com.google.android.gms.internal.ads.j9
 *  java.lang.String
 */
package a6;

import android.os.IBinder;
import com.google.android.gms.internal.ads.j9;

public final class f
extends j9 {
    public f(IBinder iBinder) {
        super(iBinder, "com.google.android.gms.signin.internal.ISignInService", 1);
    }
}

