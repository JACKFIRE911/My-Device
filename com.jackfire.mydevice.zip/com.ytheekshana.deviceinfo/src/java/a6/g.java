/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package a6;

import a8.b1;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;
import java.util.List;
import m5.a;
import y5.p;

public final class g
extends a {
    public static final Parcelable.Creator<g> CREATOR = new p(5);
    public final List q;
    public final String r;

    public g(String string, ArrayList arrayList) {
        this.q = arrayList;
        this.r = string;
    }

    public final void writeToParcel(Parcel parcel, int n3) {
        int n5 = b1.M(parcel, 20293);
        b1.I(parcel, 1, this.q);
        b1.G(parcel, 2, this.r);
        b1.b0(parcel, n5);
    }
}

