/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Paint
 *  android.graphics.Paint$Style
 *  android.graphics.Path
 *  java.lang.Object
 */
package a7;

import android.graphics.Paint;
import android.graphics.Path;
import e0.e;

public final class a {
    public static final int[] i = new int[3];
    public static final float[] j = new float[]{0.0f, 0.5f, 1.0f};
    public static final int[] k = new int[4];
    public static final float[] l = new float[]{0.0f, 0.0f, 0.5f, 1.0f};
    public final Paint a;
    public final Paint b;
    public final Paint c;
    public int d;
    public int e;
    public int f;
    public final Path g = new Path();
    public final Paint h;

    public a() {
        Paint paint;
        Paint paint2;
        this.h = paint = new Paint();
        this.a = new Paint();
        this.a(-16777216);
        paint.setColor(0);
        this.b = paint2 = new Paint(4);
        paint2.setStyle(Paint.Style.FILL);
        this.c = new Paint(paint2);
    }

    public final void a(int n2) {
        this.d = e.c(n2, 68);
        this.e = e.c(n2, 20);
        this.f = e.c(n2, 0);
        this.a.setColor(this.d);
    }
}

