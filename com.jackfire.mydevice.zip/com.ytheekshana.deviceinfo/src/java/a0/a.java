/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package a0;

public abstract class a {
    public static final int[] a = new int[]{16843173, 16843551, 16844359, 2130968630, 2130969267};
    public static final int[] b = new int[]{2130969159, 2130969160, 2130969161, 2130969162, 2130969163, 2130969164, 2130969165};
    public static final int[] c = new int[]{16844082, 16844083, 16844095, 16844143, 16844144, 2130969157, 2130969166, 2130969167, 2130969168, 2130969934};
    public static final int[] d = new int[]{16843165, 16843166, 16843169, 16843170, 16843171, 16843172, 16843265, 16843275, 16844048, 16844049, 16844050, 16844051};
    public static final int[] e = new int[]{16843173, 16844052};
}

