/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.CharSequence
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.OutOfMemoryError
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package aa;

import aa.e;
import s7.j;
import x9.a;
import x9.c;

public abstract class f
extends e {
    public static boolean W1(String string, String string2) {
        j.i(string, "<this>");
        int n3 = f.Z1(string, string2, 0, false);
        boolean bl = false;
        if (n3 >= 0) {
            bl = true;
        }
        return bl;
    }

    public static final boolean X1(String string, String string2, boolean bl) {
        if (string == null) {
            return string2 == null;
        }
        if (!bl) {
            return string.equals((Object)string2);
        }
        return string.equalsIgnoreCase(string2);
    }

    public static /* synthetic */ boolean Y1(String string) {
        return f.X1(string, "", false);
    }

    /*
     * Enabled aggressive block sorting
     */
    public static final int Z1(CharSequence charSequence, String string, int n3, boolean bl) {
        int n5;
        j.i((Object)charSequence, "<this>");
        if (!bl) {
            if (charSequence instanceof String) return ((String)charSequence).indexOf(string, n3);
        }
        int n6 = charSequence.length();
        if (n3 < 0) {
            n3 = 0;
        }
        if (n6 > (n5 = charSequence.length())) {
            n6 = n5;
        }
        c c4 = new c(n3, n6);
        boolean bl2 = charSequence instanceof String;
        int n7 = c4.s;
        int n8 = c4.r;
        if (!bl2) {
            if (n7 <= 0 || n3 > n8) {
                if (n7 >= 0) return -1;
                if (n8 > n3) return -1;
            }
        } else {
            if (n7 <= 0 || n3 > n8) {
                if (n7 >= 0) return -1;
                if (n8 > n3) return -1;
            }
            do {
                String string2 = (String)charSequence;
                int n9 = string.length();
                if (f.a2(0, n3, n9, string, string2, bl)) {
                    return n3;
                }
                if (n3 == n8) return -1;
                n3 += n7;
            } while (true);
        }
        do {
            boolean bl3;
            int n10 = string.length();
            if (n3 >= 0 && string.length() - n10 >= 0 && n3 <= charSequence.length() - n10) {
                int n11 = 0;
                do {
                    bl3 = true;
                    if (n11 < n10) {
                        char c5;
                        char c6;
                        char c7;
                        char c8 = string.charAt(0 + n11);
                        if (c8 != (c5 = charSequence.charAt(n3 + n11)) && (!bl || (c7 = Character.toUpperCase((char)c8)) != (c6 = Character.toUpperCase((char)c5)) && Character.toLowerCase((char)c7) != Character.toLowerCase((char)c6))) {
                            bl3 = false;
                        }
                        if (!bl3) break;
                        ++n11;
                        continue;
                    }
                    break;
                } while (true);
            } else {
                bl3 = false;
            }
            if (bl3) {
                return n3;
            }
            if (n3 == n8) return -1;
            n3 += n7;
        } while (true);
    }

    public static final boolean a2(int n3, int n5, int n6, String string, String string2, boolean bl) {
        j.i(string, "<this>");
        j.i(string2, "other");
        if (!bl) {
            return string.regionMatches(n3, string2, n5, n6);
        }
        return string.regionMatches(bl, n3, string2, n5, n6);
    }

    public static String b2(String string, String string2, String string3) {
        int n3;
        j.i(string, "<this>");
        int n5 = f.Z1(string, string2, 0, false);
        if (n5 < 0) {
            return string;
        }
        int n6 = string2.length();
        if (n6 >= (n3 = 1)) {
            n3 = n6;
        }
        int n7 = string.length() - n6 + string3.length();
        if (n7 >= 0) {
            StringBuilder stringBuilder = new StringBuilder(n7);
            int n8 = 0;
            do {
                stringBuilder.append((CharSequence)string, n8, n5);
                stringBuilder.append(string3);
                n8 = n5 + n6;
            } while (n5 < string.length() && (n5 = f.Z1(string, string2, n5 + n3, false)) > 0);
            stringBuilder.append((CharSequence)string, n8, string.length());
            String string4 = stringBuilder.toString();
            j.h(string4, "stringBuilder.append(this, i, length).toString()");
            return string4;
        }
        throw new OutOfMemoryError();
    }

    public static boolean c2(String string, String string2) {
        j.i(string, "<this>");
        return string.startsWith(string2);
    }

    public static String d2(String string) {
        j.i(string, "<this>");
        j.i(string, "missingDelimiterValue");
        int n3 = string.lastIndexOf(46, -1 + string.length());
        if (n3 == -1) {
            return string;
        }
        String string2 = string.substring(n3 + 1, string.length());
        j.h(string2, "this as java.lang.String\u2026ing(startIndex, endIndex)");
        return string2;
    }

    public static final CharSequence e2(CharSequence charSequence) {
        j.i((Object)charSequence, "<this>");
        int n3 = charSequence.length() - 1;
        int n5 = 0;
        boolean bl = false;
        while (n5 <= n3) {
            int n6 = !bl ? n5 : n3;
            char c4 = charSequence.charAt(n6);
            boolean bl2 = Character.isWhitespace((char)c4) || Character.isSpaceChar((char)c4);
            if (!bl) {
                if (!bl2) {
                    bl = true;
                    continue;
                }
                ++n5;
                continue;
            }
            if (!bl2) break;
            --n3;
        }
        return charSequence.subSequence(n5, n3 + 1);
    }
}

