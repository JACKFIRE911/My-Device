/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.charset.Charset
 *  s7.j
 */
package aa;

import java.nio.charset.Charset;
import s7.j;

public abstract class a {
    public static final Charset a;

    public static {
        Charset charset = Charset.forName((String)"UTF-8");
        j.h((Object)charset, (String)"forName(\"UTF-8\")");
        a = charset;
        j.h((Object)Charset.forName((String)"UTF-16"), (String)"forName(\"UTF-16\")");
        j.h((Object)Charset.forName((String)"UTF-16BE"), (String)"forName(\"UTF-16BE\")");
        j.h((Object)Charset.forName((String)"UTF-16LE"), (String)"forName(\"UTF-16LE\")");
        j.h((Object)Charset.forName((String)"US-ASCII"), (String)"forName(\"US-ASCII\")");
        j.h((Object)Charset.forName((String)"ISO-8859-1"), (String)"forName(\"ISO-8859-1\")");
    }
}

