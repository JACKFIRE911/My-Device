/*
 * Decompiled with CFR 0.0.
 */
package aa;

import aa.d;

public abstract class e
extends d {
}

