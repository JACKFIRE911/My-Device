/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.CharSequence
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.regex.Matcher
 *  java.util.regex.Pattern
 *  s7.j
 *  y6.e
 */
package aa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import s7.j;
import y6.e;

public final class b
implements Serializable {
    public final Pattern q;

    public b() {
        Pattern pattern = Pattern.compile((String)"\n");
        j.h((Object)pattern, (String)"compile(pattern)");
        this.q = pattern;
    }

    public final List a(String string) {
        Matcher matcher = this.q.matcher((CharSequence)string);
        if (!matcher.find()) {
            return e.h0((Object)string.toString());
        }
        ArrayList arrayList = new ArrayList(10);
        int n2 = 0;
        do {
            arrayList.add((Object)string.subSequence(n2, matcher.start()).toString());
            n2 = matcher.end();
        } while (matcher.find());
        arrayList.add((Object)string.subSequence(n2, string.length()).toString());
        return arrayList;
    }

    public final String toString() {
        String string = this.q.toString();
        j.h((Object)string, (String)"nativePattern.toString()");
        return string;
    }
}

