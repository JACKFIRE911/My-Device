/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.util.Collection
 */
package aa;

import java.util.Collection;
import s7.j;
import y6.e;

public abstract class c
extends e {
    public static final int V1(Iterable iterable) {
        j.i((Object)iterable, "<this>");
        if (iterable instanceof Collection) {
            return ((Collection)iterable).size();
        }
        return 10;
    }
}

