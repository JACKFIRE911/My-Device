/*
 * Decompiled with CFR 0.0.
 */
package aa;

import aa.c;

public abstract class d
extends c {
}

