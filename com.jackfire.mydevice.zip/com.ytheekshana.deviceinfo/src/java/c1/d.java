/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.animation.Interpolator
 *  java.lang.Math
 *  java.lang.Object
 *  u7.c
 */
package c1;

import android.view.animation.Interpolator;
import u7.c;

public abstract class d
implements Interpolator {
    public final float[] a;
    public final float b;

    public d(float[] arrf) {
        this.a = arrf;
        this.b = 1.0f / (float)(-1 + arrf.length);
    }

    public final float getInterpolation(float f2) {
        if (f2 >= 1.0f) {
            return 1.0f;
        }
        if (f2 <= 0.0f) {
            return 0.0f;
        }
        float[] arrf = this.a;
        int n2 = Math.min((int)((int)(f2 * (float)(-1 + arrf.length))), (int)(-2 + arrf.length));
        float f4 = n2;
        float f5 = this.b;
        float f6 = (f2 - f4 * f5) / f5;
        float f7 = arrf[n2];
        return c.b((float)arrf[n2 + 1], (float)f7, (float)f6, (float)f7);
    }
}

