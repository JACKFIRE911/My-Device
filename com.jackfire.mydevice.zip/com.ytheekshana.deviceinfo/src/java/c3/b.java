/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.ColorSpace
 *  android.graphics.ColorSpace$Named
 *  android.graphics.ImageDecoder
 *  android.graphics.ImageDecoder$ImageInfo
 *  android.graphics.ImageDecoder$OnHeaderDecodedListener
 *  android.graphics.ImageDecoder$Source
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.Log
 *  android.util.Size
 *  androidx.appcompat.widget.c1
 *  androidx.appcompat.widget.e1
 *  java.lang.Boolean
 *  java.lang.Class
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  u2.b
 *  u2.j
 *  u2.k
 *  u2.l
 */
package c3;

import android.graphics.ColorSpace;
import android.graphics.ImageDecoder;
import android.os.Build;
import android.util.Log;
import android.util.Size;
import androidx.appcompat.widget.c1;
import androidx.appcompat.widget.e1;
import c3.a;
import d3.n;
import d3.p;
import d3.u;
import u2.j;
import u2.k;
import u2.l;

public final class b
implements ImageDecoder.OnHeaderDecodedListener {
    public final u a;
    public final int b;
    public final int c;
    public final u2.b d;
    public final n e;
    public final boolean f;
    public final l g;

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     * Converted monitor instructions to comments
     * Lifted jumps to return sites
     */
    public b(int n2, int n5, k k2) {
        if (u.j == null) {
            Class<u> class_ = u.class;
            // MONITORENTER : d3.u.class
            if (u.j == null) {
                u.j = new u();
            }
            // MONITOREXIT : class_
        }
        this.a = u.j;
        this.b = n2;
        this.c = n5;
        this.d = (u2.b)k2.c(p.f);
        this.e = (n)k2.c(n.f);
        j j2 = p.i;
        boolean bl = k2.c(j2) != null && (Boolean)k2.c(j2) != false;
        this.f = bl;
        this.g = (l)k2.c(p.g);
    }

    public final void onHeaderDecoded(ImageDecoder imageDecoder, ImageDecoder.ImageInfo imageInfo, ImageDecoder.Source source) {
        int n2;
        if (this.a.a(this.b, this.c, this.f, false)) {
            e1.q((ImageDecoder)imageDecoder);
        } else {
            e1.A((ImageDecoder)imageDecoder);
        }
        if (this.d == u2.b.r) {
            e1.C((ImageDecoder)imageDecoder);
        }
        e1.t((ImageDecoder)imageDecoder, (a)new a());
        Size size = e1.k((ImageDecoder.ImageInfo)imageInfo);
        int n5 = this.b;
        if (n5 == Integer.MIN_VALUE) {
            n5 = size.getWidth();
        }
        if ((n2 = this.c) == Integer.MIN_VALUE) {
            n2 = size.getHeight();
        }
        float f2 = this.e.b(size.getWidth(), size.getHeight(), n5, n2);
        int n6 = Math.round((float)(f2 * (float)size.getWidth()));
        int n7 = Math.round((float)(f2 * (float)size.getHeight()));
        if (Log.isLoggable((String)"ImageDecoder", (int)2)) {
            StringBuilder stringBuilder = new StringBuilder("Resizing from [");
            stringBuilder.append(size.getWidth());
            stringBuilder.append("x");
            stringBuilder.append(size.getHeight());
            stringBuilder.append("] to [");
            stringBuilder.append(n6);
            stringBuilder.append("x");
            stringBuilder.append(n7);
            stringBuilder.append("] scaleFactor: ");
            stringBuilder.append(f2);
            Log.v((String)"ImageDecoder", (String)stringBuilder.toString());
        }
        e1.r((ImageDecoder)imageDecoder, (int)n6, (int)n7);
        l l2 = this.g;
        if (l2 != null) {
            int n8 = Build.VERSION.SDK_INT;
            if (n8 >= 28) {
                l l3 = l.q;
                boolean bl = false;
                if (l2 == l3) {
                    ColorSpace colorSpace = e1.c((ImageDecoder.ImageInfo)imageInfo);
                    bl = false;
                    if (colorSpace != null) {
                        boolean bl2 = c1.w((ColorSpace)e1.c((ImageDecoder.ImageInfo)imageInfo));
                        bl = false;
                        if (bl2) {
                            bl = true;
                        }
                    }
                }
                ColorSpace.Named named = bl ? c1.n() : c1.B();
                e1.s((ImageDecoder)imageDecoder, (ColorSpace)c1.p((ColorSpace.Named)named));
                return;
            }
            if (n8 >= 26) {
                e1.s((ImageDecoder)imageDecoder, (ColorSpace)c1.p((ColorSpace.Named)c1.B()));
            }
        }
    }
}

