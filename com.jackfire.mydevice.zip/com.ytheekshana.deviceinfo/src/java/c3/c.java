/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  com.bumptech.glide.g
 *  java.lang.Object
 *  java.security.MessageDigest
 */
package c3;

import com.bumptech.glide.g;
import java.security.MessageDigest;
import u2.o;
import w2.e0;

public final class c
implements o {
    public static final c b = new c();

    @Override
    public final void a(MessageDigest messageDigest) {
    }

    @Override
    public final e0 b(g g2, e0 e02, int n3, int n5) {
        return e02;
    }
}

