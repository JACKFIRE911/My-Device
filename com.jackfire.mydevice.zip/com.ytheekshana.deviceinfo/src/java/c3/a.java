/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.ImageDecoder
 *  android.graphics.ImageDecoder$DecodeException
 *  android.graphics.ImageDecoder$OnPartialImageListener
 *  java.lang.Object
 */
package c3;

import android.graphics.ImageDecoder;

public final class a
implements ImageDecoder.OnPartialImageListener {
    public final boolean onPartialImage(ImageDecoder.DecodeException decodeException) {
        return false;
    }
}

