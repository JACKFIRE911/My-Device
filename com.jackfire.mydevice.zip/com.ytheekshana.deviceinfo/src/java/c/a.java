/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.ClipData
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.os.IBinder
 *  android.os.IInterface
 *  android.os.Parcel
 *  android.os.SystemClock
 *  android.util.Base64
 *  android.view.ContentInfo
 *  android.view.Menu
 *  android.view.MenuItem
 *  android.view.View
 *  android.view.Window
 *  android.view.Window$Callback
 *  androidx.appcompat.widget.ActionMenuView
 *  androidx.appcompat.widget.Toolbar
 *  androidx.appcompat.widget.j4
 *  androidx.appcompat.widget.m
 *  androidx.appcompat.widget.p
 *  androidx.appcompat.widget.p4
 *  androidx.appcompat.widget.s2
 *  androidx.appcompat.widget.t1
 *  androidx.viewpager2.widget.ViewPager2
 *  androidx.work.impl.WorkDatabase
 *  com.bumptech.glide.manager.n
 *  com.bumptech.glide.manager.u
 *  com.google.ads.mediation.admob.AdMobAdapter
 *  com.google.android.gms.internal.ads.ai1
 *  com.google.android.gms.internal.ads.d5
 *  com.google.android.gms.internal.ads.f5
 *  com.google.android.gms.internal.ads.sr
 *  i5.b
 *  j.i
 *  j.o
 *  j.q
 *  j2.w
 *  java.io.ByteArrayInputStream
 *  java.io.File
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.security.MessageDigest
 *  java.security.NoSuchAlgorithmException
 *  java.util.ArrayDeque
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 *  java.util.concurrent.CopyOnWriteArrayList
 *  l5.i
 *  n0.q2
 *  n0.r2
 *  n0.s2
 *  t8.c
 *  u2.k
 *  u5.b
 *  u5.h
 *  u7.e
 *  w2.u
 *  y2.h
 *  z1.k
 */
package c;

import a8.b1;
import android.content.ClipData;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.SystemClock;
import android.util.Base64;
import android.view.ContentInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.widget.j4;
import androidx.appcompat.widget.p;
import androidx.appcompat.widget.p4;
import androidx.appcompat.widget.t1;
import androidx.viewpager2.widget.ViewPager2;
import androidx.work.impl.WorkDatabase;
import b6.j;
import com.bumptech.glide.manager.n;
import com.bumptech.glide.manager.u;
import com.google.ads.mediation.admob.AdMobAdapter;
import com.google.android.gms.internal.ads.ai1;
import com.google.android.gms.internal.ads.d5;
import com.google.android.gms.internal.ads.f5;
import com.google.android.gms.internal.ads.sr;
import e.x0;
import j.g;
import j.h;
import j.i;
import j.m;
import j.o;
import j.q;
import j2.w;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import l5.b;
import l5.d;
import l5.e;
import n0.q2;
import n0.r2;
import n0.s;
import n0.s2;
import u2.c;
import u2.k;
import v4.c2;
import w2.e0;
import w2.v;
import w2.x;

public final class a
implements t1,
androidx.appcompat.widget.s2,
m,
e0.s,
n0.g,
o0.x,
n3.a,
c,
g3.a,
n,
d5,
d,
b,
k5.j {
    public final /* synthetic */ int q;
    public Object r;

    public a(int n2) {
        this.q = n2;
        if (n2 != 23) {
            if (n2 != 24) {
                this.r = new ArrayDeque();
                return;
            }
            super();
            c2 c22 = new c2();
            this.r = c22;
            c22.d.add((Object)"B3EEABB8EE11C2BE770B684D95219ECB");
            return;
        }
        super();
        this.r = null;
    }

    public /* synthetic */ a(int n2, Object object) {
        this.q = n2;
        this.r = object;
    }

    public a(Resources resources) {
        this.q = 21;
        this.r = resources;
    }

    public a(ContentInfo contentInfo) {
        this.q = 10;
        contentInfo.getClass();
        this.r = ai1.l((Object)contentInfo);
    }

    public a(Window window, View view) {
        this.q = 11;
        int n2 = Build.VERSION.SDK_INT;
        if (n2 >= 30) {
            this.r = new s2(window);
            return;
        }
        if (n2 >= 26) {
            this.r = new r2(window, view);
            return;
        }
        this.r = new q2(window, view);
    }

    public a(WorkDatabase workDatabase) {
        this.q = 15;
        s7.j.i((Object)workDatabase, "workDatabase");
        this.r = workDatabase;
    }

    public static ByteArrayInputStream u(String string) {
        if (string.startsWith("data:image")) {
            int n2 = string.indexOf(44);
            if (n2 != -1) {
                if (string.substring(0, n2).endsWith(";base64")) {
                    return new ByteArrayInputStream(Base64.decode((String)string.substring(n2 + 1), (int)0));
                }
                throw new IllegalArgumentException("Not a base64 image data URL.");
            }
            throw new IllegalArgumentException("Missing comma in data URL.");
        }
        throw new IllegalArgumentException("Not a valid image data URL.");
    }

    @Override
    public final void U() {
        ((k5.d)this.r).U();
    }

    @Override
    public final void a(i5.b b4) {
        boolean bl = b4.r == 0;
        if (bl) {
            e e4 = (e)this.r;
            e4.c(null, e4.o());
            return;
        }
        l5.c c4 = ((e)this.r).p;
        if (c4 != null) {
            c4.i0(b4);
        }
    }

    @Override
    public final ClipData b() {
        return ai1.b((ContentInfo)((ContentInfo)this.r));
    }

    public final void c(o o5, MenuItem menuItem) {
        ((i)this.r).w.removeCallbacksAndMessages((Object)o5);
    }

    @Override
    public final boolean e(View view) {
        ViewPager2 viewPager2 = (ViewPager2)view;
        z1.k k3 = (z1.k)this.r;
        int n2 = viewPager2.getCurrentItem() - 1;
        ViewPager2 viewPager22 = k3.u;
        if (viewPager22.H) {
            viewPager22.c(n2, true);
        }
        return true;
    }

    @Override
    public final int f() {
        return ai1.a((ContentInfo)((ContentInfo)this.r));
    }

    @Override
    public final Object g() {
        switch (this.q) {
            default: {
                break;
            }
            case 17: {
                p4 p42 = (p4)this.r;
                w2.u u3 = new w2.u((z2.d)p42.q, (z2.d)p42.r, (z2.d)p42.s, (z2.d)p42.t, (v)p42.u, (x)p42.v, (m0.c)p42.w);
                return u3;
            }
        }
        try {
            y2.h h3 = new y2.h(MessageDigest.getInstance((String)"SHA-256"));
            return h3;
        }
        catch (NoSuchAlgorithmException noSuchAlgorithmException) {
            throw new RuntimeException((Throwable)noSuchAlgorithmException);
        }
    }

    /*
     * Exception decompiling
     */
    @Override
    public final boolean h(Object var1, File var2, k var3) {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public final void i(o o5) {
        m m4;
        switch (this.q) {
            default: {
                break;
            }
            case 5: {
                m m6 = ((ActionMenuView)this.r).L;
                if (m6 != null) {
                    m6.i(o5);
                }
                return;
            }
        }
        androidx.appcompat.widget.m m7 = ((Toolbar)this.r).q.J;
        boolean bl = m7 != null && m7.f();
        if (!bl) {
            Iterator iterator = ((CopyOnWriteArrayList)((Toolbar)this.r).W.s).iterator();
            while (iterator.hasNext()) {
                ((s)iterator.next()).d((Menu)o5);
            }
        }
        if ((m4 = ((Toolbar)this.r).h0) != null) {
            m4.i(o5);
        }
    }

    @Override
    public final int j(Object object) {
        return ((k0.h)object).c;
    }

    @Override
    public final boolean k(Object object) {
        return ((k0.h)object).d;
    }

    public final void l(o o5, q q4) {
        int n5;
        block4 : {
            ((i)this.r).w.removeCallbacksAndMessages(null);
            int n6 = ((i)this.r).y.size();
            for (n5 = 0; n5 < n6; ++n5) {
                if (o5 != ((h)((i)this.r).y.get((int)n5)).b) {
                    continue;
                }
                break block4;
            }
            n5 = -1;
        }
        if (n5 == -1) {
            return;
        }
        int n7 = n5 + 1;
        int n8 = ((i)this.r).y.size();
        h h3 = null;
        if (n7 < n8) {
            h3 = (h)((i)this.r).y.get(n7);
        }
        h h4 = h3;
        g g4 = new g(this, h4, (Object)q4, (Object)o5, 0);
        long l3 = 200L + SystemClock.uptimeMillis();
        ((i)this.r).w.postAtTime((Runnable)g4, (Object)o5, l3);
    }

    @Override
    public final boolean m(o o5, MenuItem menuItem) {
        switch (this.q) {
            default: {
                break;
            }
            case 5: {
                p p3 = ((ActionMenuView)this.r).Q;
                if (p3 != null) {
                    j4 j42;
                    Toolbar toolbar = (Toolbar)((t8.c)p3).r;
                    boolean bl = toolbar.W.w(menuItem) ? true : ((j42 = toolbar.b0) != null ? ((x0)((u7.e)j42).r).t.onMenuItemSelected(0, menuItem) : false);
                    if (bl) {
                        return true;
                    }
                }
                return false;
            }
        }
        m m4 = ((Toolbar)this.r).h0;
        return m4 != null && m4.m(o5, menuItem);
    }

    @Override
    public final ContentInfo n() {
        return (ContentInfo)this.r;
    }

    @Override
    public final int o() {
        return ai1.z((ContentInfo)((ContentInfo)this.r));
    }

    public final void p(f5 f52) {
        ((sr)this.r).d((Throwable)f52);
    }

    @Override
    public final void q(l5.i i3, Object object) {
        u5.b b4 = (u5.b)i3;
        j j3 = (j)object;
        u5.d d4 = (u5.d)b4.p();
        u5.h h3 = new u5.h(j3);
        Parcel parcel = Parcel.obtain();
        parcel.writeInterfaceToken("com.google.android.gms.appset.internal.IAppSetService");
        parcel.writeInt(1);
        b1.b0(parcel, b1.M(parcel, 20293));
        parcel.writeStrongBinder((IBinder)h3);
        Parcel parcel2 = Parcel.obtain();
        try {
            d4.q.transact(1, parcel, parcel2, 0);
            parcel2.readException();
            return;
        }
        finally {
            parcel.recycle();
            parcel2.recycle();
        }
    }

    @Override
    public final e0 r(e0 e02, k k3) {
        Resources resources = (Resources)this.r;
        if (e02 == null) {
            return null;
        }
        return new d3.d(resources, e02);
    }

    public final void s(Bundle bundle) {
        c2 c22 = (c2)this.r;
        c22.getClass();
        String string = AdMobAdapter.class.getName();
        c22.b.putBundle(string, bundle);
        if (AdMobAdapter.class.equals(AdMobAdapter.class) && bundle.getBoolean("_emulatorLiveAds")) {
            ((c2)this.r).d.remove((Object)"B3EEABB8EE11C2BE770B684D95219ECB");
        }
    }

    @Override
    public final void t(int n5) {
        ((k5.d)this.r).t(n5);
    }

    public final String toString() {
        switch (this.q) {
            default: {
                return super.toString();
            }
            case 22: {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(super.toString());
                stringBuilder.append("{fragment=");
                stringBuilder.append((Object)((u)this.r));
                stringBuilder.append("}");
                return stringBuilder.toString();
            }
            case 10: 
        }
        StringBuilder stringBuilder = new StringBuilder("ContentInfoCompat{");
        stringBuilder.append((Object)((ContentInfo)this.r));
        stringBuilder.append("}");
        return stringBuilder.toString();
    }
}

