/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  androidx.activity.m
 *  androidx.activity.result.b
 *  java.lang.Object
 */
package c;

import android.content.Intent;
import androidx.activity.m;
import androidx.activity.result.b;
import s7.j;

public final class c
extends j {
    @Override
    public final Object B(Intent intent, int n5) {
        return new b(intent, n5);
    }

    @Override
    public final Intent m(m m4, Object object) {
        Intent intent = (Intent)object;
        j.i((Object)m4, "context");
        j.i((Object)intent, "input");
        return intent;
    }
}

