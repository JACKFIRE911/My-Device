/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.Intent
 *  androidx.activity.m
 *  java.lang.Boolean
 *  java.lang.Iterable
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Iterator
 *  java.util.LinkedHashMap
 *  k9.m
 */
package c;

import android.content.Context;
import android.content.Intent;
import androidx.activity.m;
import b0.e;
import ba.x;
import c.a;
import j9.c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import k9.k;
import s7.j;

public final class b
extends j {
    @Override
    public final Object B(Intent intent, int n5) {
        k k3 = k.q;
        if (n5 != -1) {
            return k3;
        }
        if (intent == null) {
            return k3;
        }
        String[] arrstring = intent.getStringArrayExtra("androidx.activity.result.contract.extra.PERMISSIONS");
        int[] arrn = intent.getIntArrayExtra("androidx.activity.result.contract.extra.PERMISSION_GRANT_RESULTS");
        if (arrn != null) {
            if (arrstring == null) {
                return k3;
            }
            ArrayList arrayList = new ArrayList(arrn.length);
            int n6 = arrn.length;
            int n7 = 0;
            for (int i3 = 0; i3 < n6; ++i3) {
                boolean bl = arrn[i3] == 0;
                arrayList.add((Object)bl);
            }
            ArrayList arrayList2 = new ArrayList();
            int n8 = arrstring.length;
            while (n7 < n8) {
                String string = arrstring[n7];
                if (string != null) {
                    arrayList2.add((Object)string);
                }
                ++n7;
            }
            Iterator iterator = arrayList2.iterator();
            Iterator iterator2 = arrayList.iterator();
            ArrayList arrayList3 = new ArrayList(Math.min((int)aa.c.V1((Iterable)arrayList2), (int)aa.c.V1((Iterable)arrayList)));
            while (iterator.hasNext() && iterator2.hasNext()) {
                arrayList3.add((Object)new c(iterator.next(), iterator2.next()));
            }
            k3 = k9.m.d0((ArrayList)arrayList3);
        }
        return k3;
    }

    @Override
    public final Intent m(m m4, Object object) {
        String[] arrstring = (String[])object;
        j.i((Object)m4, "context");
        j.i(arrstring, "input");
        Intent intent = new Intent("androidx.activity.result.contract.action.REQUEST_PERMISSIONS").putExtra("androidx.activity.result.contract.extra.PERMISSIONS", arrstring);
        j.h((Object)intent, "Intent(ACTION_REQUEST_PE\u2026EXTRA_PERMISSIONS, input)");
        return intent;
    }

    @Override
    public final a q(m m4, Object object) {
        String[] arrstring = (String[])object;
        j.i((Object)m4, "context");
        j.i(arrstring, "input");
        int n5 = arrstring.length;
        boolean bl = true;
        boolean bl2 = n5 == 0 ? bl : false;
        if (bl2) {
            return new a(0, k.q);
        }
        int n6 = arrstring.length;
        for (int i3 = 0; i3 < n6; ++i3) {
            boolean bl3 = e.a((Context)m4, arrstring[i3]) == 0 ? bl : false;
            if (bl3) continue;
            bl = false;
            break;
        }
        if (bl) {
            int n7 = x.o(arrstring.length);
            if (n7 < 16) {
                n7 = 16;
            }
            LinkedHashMap linkedHashMap = new LinkedHashMap(n7);
            int n8 = arrstring.length;
            for (int i4 = 0; i4 < n8; ++i4) {
                linkedHashMap.put((Object)arrstring[i4], (Object)Boolean.TRUE);
            }
            return new a(0, (Object)linkedHashMap);
        }
        return null;
    }
}

