/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.view.AbsSavedState
 *  androidx.appcompat.widget.s3
 *  com.google.android.material.sidesheet.SideSheetBehavior
 *  java.lang.ClassLoader
 */
package c7;

import android.os.Parcel;
import android.os.Parcelable;
import android.view.AbsSavedState;
import androidx.appcompat.widget.s3;
import com.google.android.material.sidesheet.SideSheetBehavior;
import u0.b;

public final class c
extends b {
    public static final Parcelable.Creator<c> CREATOR = new s3(10);
    public final int s;

    public c(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.s = parcel.readInt();
    }

    public c(AbsSavedState absSavedState, SideSheetBehavior sideSheetBehavior) {
        super((Parcelable)absSavedState);
        this.s = sideSheetBehavior.h;
    }

    @Override
    public final void writeToParcel(Parcel parcel, int n5) {
        parcel.writeParcelable(this.q, n5);
        parcel.writeInt(this.s);
    }
}

