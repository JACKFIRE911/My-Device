/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewParent
 *  com.google.android.material.sidesheet.SideSheetBehavior
 *  java.lang.Class
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.ref.WeakReference
 */
package c7;

import a2.s;
import android.view.View;
import android.view.ViewParent;
import com.google.android.material.sidesheet.SideSheetBehavior;
import d0.m;
import java.lang.ref.WeakReference;
import n0.l0;
import o0.x;

public final class a
implements x {
    public final /* synthetic */ SideSheetBehavior q;
    public final /* synthetic */ int r;

    public /* synthetic */ a(SideSheetBehavior sideSheetBehavior, int n5) {
        this.q = sideSheetBehavior;
        this.r = n5;
    }

    @Override
    public final boolean e(View view) {
        SideSheetBehavior sideSheetBehavior = this.q;
        sideSheetBehavior.getClass();
        int n5 = this.r;
        if (n5 != 1 && n5 != 2) {
            WeakReference weakReference = sideSheetBehavior.o;
            if (weakReference != null && weakReference.get() != null) {
                View view2 = (View)sideSheetBehavior.o.get();
                m m4 = new m((Object)sideSheetBehavior, n5, 1);
                ViewParent viewParent = view2.getParent();
                boolean bl = viewParent != null && viewParent.isLayoutRequested() && l0.b(view2);
                if (bl) {
                    view2.post((Runnable)m4);
                    return true;
                }
                m4.run();
                return true;
            }
            sideSheetBehavior.s(n5);
            return true;
        }
        StringBuilder stringBuilder = new StringBuilder("STATE_");
        String string = n5 == 1 ? "DRAGGING" : "SETTLING";
        throw new IllegalArgumentException(s.v(stringBuilder, string, " should not be set externally."));
    }
}

