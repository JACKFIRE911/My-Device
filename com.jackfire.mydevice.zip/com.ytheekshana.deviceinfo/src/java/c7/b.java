/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.ViewGroup$MarginLayoutParams
 *  com.google.android.material.sidesheet.SideSheetBehavior
 *  java.lang.Class
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.ref.WeakReference
 *  java.util.Iterator
 *  java.util.LinkedHashSet
 *  n5.b
 */
package c7;

import a2.s;
import android.view.View;
import android.view.ViewGroup;
import ba.x;
import com.google.android.material.sidesheet.SideSheetBehavior;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.LinkedHashSet;

public final class b
extends n7.b {
    public final /* synthetic */ SideSheetBehavior j;

    public b(SideSheetBehavior sideSheetBehavior) {
        this.j = sideSheetBehavior;
    }

    @Override
    public final int c(View view, int n5) {
        SideSheetBehavior sideSheetBehavior = this.j;
        return x.b(n5, sideSheetBehavior.a.e(), sideSheetBehavior.m);
    }

    @Override
    public final int d(View view, int n5) {
        return view.getTop();
    }

    @Override
    public final int h(View view) {
        return this.j.m;
    }

    @Override
    public final void m(int n5) {
        if (n5 == 1) {
            SideSheetBehavior sideSheetBehavior = this.j;
            if (sideSheetBehavior.g) {
                sideSheetBehavior.s(1);
            }
        }
    }

    @Override
    public final void n(View view, int n5, int n6) {
        ViewGroup.MarginLayoutParams marginLayoutParams;
        LinkedHashSet linkedHashSet;
        SideSheetBehavior sideSheetBehavior = this.j;
        WeakReference weakReference = sideSheetBehavior.p;
        View view2 = weakReference != null ? (View)weakReference.get() : null;
        if (view2 != null && (marginLayoutParams = (ViewGroup.MarginLayoutParams)view2.getLayoutParams()) != null) {
            n5.b b4 = sideSheetBehavior.a;
            int n7 = view.getLeft();
            view.getRight();
            int n8 = ((SideSheetBehavior)b4.q).m;
            if (n7 <= n8) {
                marginLayoutParams.rightMargin = n8 - n7;
            }
            view2.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams);
        }
        if (!(linkedHashSet = sideSheetBehavior.t).isEmpty()) {
            n5.b b5 = sideSheetBehavior.a;
            b5.h();
            b5.e();
            Iterator iterator = linkedHashSet.iterator();
            if (!iterator.hasNext()) {
                return;
            }
            s.z(iterator.next());
            throw null;
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @Override
    public final void o(View var1_1, float var2_2, float var3_3) {
        block9 : {
            block8 : {
                var4_4 = this.j;
                var5_5 = var4_4.a;
                var5_5.getClass();
                if (var2_2 < 0.0f) ** GOTO lbl-1000
                var7_6 = Math.abs((float)((float)var1_1.getRight() + var2_2 * ((SideSheetBehavior)var5_5.q).k));
                ((SideSheetBehavior)var5_5.q).getClass();
                var9_7 = var7_6 > 0.5f;
                if (!var9_7) break block8;
                var14_8 = Math.abs((float)var2_2) > Math.abs((float)var3_3);
                if (!var14_8) ** GOTO lbl-1000
                ((SideSheetBehavior)var5_5.q).getClass();
                if (var3_3 > (float)500) {
                    var15_9 = true;
                } else lbl-1000: // 2 sources:
                {
                    var15_9 = false;
                }
                if (var15_9) ** GOTO lbl-1000
                var16_10 = var1_1.getLeft();
                var17_11 = (var5_5.h() - var5_5.e()) / 2;
                var18_12 = false;
                if (var16_10 > var17_11) {
                    var18_12 = true;
                }
                if (!var18_12) ** GOTO lbl-1000
                ** GOTO lbl-1000
            }
            if (var2_2 == 0.0f) break block9;
            var12_13 = Math.abs((float)var2_2) FCMPL Math.abs((float)var3_3);
            var13_14 = false;
            if (var12_13 > 0) {
                var13_14 = true;
            }
            if (var13_14) ** GOTO lbl-1000
        }
        ** if (Math.abs((int)((var10_15 = var1_1.getLeft()) - var5_5.e())) >= Math.abs((int)(var10_15 - var5_5.h()))) goto lbl-1000
        ** GOTO lbl-1000
lbl-1000: // 3 sources:
        {
            var11_16 = 3;
            ** GOTO lbl38
        }
lbl-1000: // 5 sources:
        {
            var11_16 = 5;
        }
lbl38: // 2 sources:
        var4_4.t(var11_16, var1_1, true);
    }

    @Override
    public final boolean s(View view, int n5) {
        SideSheetBehavior sideSheetBehavior = this.j;
        if (sideSheetBehavior.h == 1) {
            return false;
        }
        WeakReference weakReference = sideSheetBehavior.o;
        boolean bl = false;
        if (weakReference != null) {
            Object object = weakReference.get();
            bl = false;
            if (object == view) {
                bl = true;
            }
        }
        return bl;
    }
}

